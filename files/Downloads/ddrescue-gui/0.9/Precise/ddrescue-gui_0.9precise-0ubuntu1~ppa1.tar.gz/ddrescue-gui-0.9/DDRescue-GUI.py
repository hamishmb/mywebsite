#!/usr/bin/env /usr/bin/python
import time
import os
import wx
import wx.html
 
print "DDRescue-GUI Version 1.0 (UNFINISHED) Starting..."

#Begin Main Window   
class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(800,360))
        MainPanel = wx.Panel(self)

        # Create a Statusbar in the bottom of the window and set the text.
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

        # Add some text
        welcometext = wx.StaticText(MainPanel, -1, "Welcome to DDRescue-GUI!", pos=(310,15))
        inputtext = wx.StaticText(MainPanel, -1, "Device/file to image from:", pos=(10, 40))  
        outputtext = wx.StaticText(MainPanel, -1, "Device/file to create image on:", pos=(590, 40)) 
        logfiletext = wx.StaticText(MainPanel, -1, "Position for logfile:", pos=(300,40))

        # Create some buttons
        startbutton = wx.Button(MainPanel, wx.ID_ANY, "Start", pos=(620,197))
        abortbutton = wx.Button(MainPanel, wx.ID_ANY, "Abort", pos=(710,197))

        # Create some choiceboxes
        inputfilelist = ['CD/DVD (/dev/sr0)', 'Secondary HDD/Partition', 'Other/Specify'] 
	outputfilelist = ['Secondary HDD/Partition', 'Default Image (iso)', 'Image (img)', 'Other/Specify']
	inputchoice = wx.Choice(MainPanel, -1, (10,64), choices=inputfilelist)
	outputchoice = wx.Choice(MainPanel, -1, (590,64), choices=outputfilelist)
        logfilechoice = wx.Choice(MainPanel, -1, (300,64), choices=['None - not recommended', 'Specify'])

        # Creating the menus.
        filemenu = wx.Menu()
        editmenu = wx.Menu()
        viewmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        # Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuPrefs = editmenu.Append(wx.ID_ANY, "&Preferences", "General settings")

        # Creating the menubar.
        menuBar = wx.MenuBar()

        # Adding menus to the MenuBar
        menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        menuBar.Append(editmenu,"&Edit") # Adding the "editmenu" to the MenuBar
        menuBar.Append(viewmenu,"&View") # Adding the "viewmenu" to the MenuBar
        menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar 
        self.SetMenuBar(menuBar)  # Adding the MenuBar to the Frame content.

        # Creating a progress bar (for the time being, it fills and empties over and over again)
        self.count = 0
        self.ProgressBar = wx.Gauge(MainPanel, -1, 50, (10, 200), (600,25))
        self.ProgressBar.SetBezelFace(3)
        self.ProgressBar.SetShadowWidth(3)
        
        self.BindEvents(self) #Use a function to do this
        
    #Create Functions     
    def BindEvents(self, event): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Prefs, self.menuPrefs)
        self.Bind(wx.EVT_IDLE, self.FillProgress)

    def FillProgress(self, event):
        self.count = self.count + 1
        if self.count >= 50:
            self.count = 0
        self.ProgressBar.SetValue(self.count)
        time.sleep(0.2)

    def OnAbout(self,e):
        # A message dialog box with an OK button
        AboutDlg = AboutWindow(self)
        AboutDlg.ShowModal()
        AboutDlg.Destroy()

    def OnExit(self,e):
        self.Close(True)  

    def Prefs(self,e):
        # A dialog to modify settings
        PreferencesWindow().Show()
        # Grab settings from Setttings Window (using print(var))
        # Not done yet ******************************

    def DevInfo(self,e): 
        # Use zenity for this dialog
        #oldhdds = os.popen2("mount | grep /dev/hd") #Variable for finding ata/ide HDDs
        #cds = os.popen2("mount | grep /dev/sr") #Variable for finding CD/DVD drives
        #newhdds&usbs = os.popen2("mount | grep /dev/sd") #Variable for finding sata/scsi HDDs and usb drives
        #Use sed commands to process
        #Do later
        Dialog = os.popen2("zenity --title='DDRescue-GUI - Device Information' --text='Here are all the detected devices on your computer' --list --column='Device' 'Primary Hard Drive Partition no. x (/dev/sdax)' 'None' 'CD/DVD drives (/dev/srx)' 'None' 'USB Drives (/dev/sdb,/dev/sdc,etc)' 'None' --column='Additional Information'") #No autodetect yet.
         
#End Main Window
#Begin About Window
class AboutWindow(wx.Dialog):

    # HTML text for the about dialog
    text = '''
<html>
<body bgcolor="#0B610B">
<center><table bgcolor="#04B404" width="100%" cellspacing="0" cellpadding="0" border="1">
<tr>
    <td align="center"><hl>DDRescue-GUI</hl></td>
</tr>
</table>
</center>
<p><b>DDRescue-GUI</b> is a GUI frontend to make ddrescue easier to use.</p>


<p> 
It is written in Python (version 2.x) and wxPython, and is available to you under the terms of the GPLv3.
New versions can be downloaded at: https://launchpad.net/ddrescue-gui
</p>


<p>
DDRescue-GUI was brought to you by Hamish McIntyre-Bhatty, Copyright &copy; 2013.
</p>
</body>
</html>
'''
    # End HTML
    def __init__(self, parent):
       wx.Dialog.__init__(self, parent, -1, 'About DDRescue-GUI', size=(440,400))

       html = wx.html.HtmlWindow(self)
       html.SetPage(self.text)
       okaybutton = wx.Button(self, wx.ID_OK, "Okay")

       sizer = wx.BoxSizer(wx.VERTICAL)
       sizer.Add(html, 1, wx.EXPAND|wx.ALL, 5)
       sizer.Add(okaybutton, 0, wx.ALIGN_CENTER|wx.ALL, 5)
      
       self.SetSizer(sizer)
       self.Layout()

#End About Window
#Begin Preferences Window
class PreferencesWindow(wx.Frame):

    title = "DDRescue-GUI - Preferences" 

    def __init__(self):
       wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(800,270))
       PrefsPanel=wx.Panel(self)

       # Create a button to exit
       self.exitbutton = wx.Button(PrefsPanel, -1, "Close", pos=(100, 200)) 

       # Create some Text
       wx.StaticText(PrefsPanel, -1, "Data recovery settings (starred (*) options require ddrescue at version >= 1.16)", (10,15))
       blcksizetext = wx.StaticText(PrefsPanel, -1, "Block (cluster) size of input device:", (340,50))
       badsecttext = wx.StaticText(PrefsPanel, -1, "Retry bad sectors:", (340, 80))
       dskrdspdtext = wx.StaticText(PrefsPanel, -1, "Set disk read speed (CDs/DVDs only):", (340, 110)) 
       maxerrstext = wx.StaticText(PrefsPanel, -1, "Maximum number of errors before exiting:", (340, 140))
       skipsizetext = wx.StaticText(PrefsPanel, -1, "Amount of data to skip on a read error:", (340, 170))
       sectsizetext = wx.StaticText(PrefsPanel, -1, "Number of sectors to copy at a time:", (340,200))
       timeouttext = wx.StaticText(PrefsPanel, -1, "Max time since last successful read before exiting:", (300, 230)) 

       # Create Some Checkboxes
       self.dskaccesscb = wx.CheckBox(PrefsPanel, -1, "Use direct disc access (Recommended)", (10, 50), (290, 20))
       self.overwritecb = wx.CheckBox(PrefsPanel, -1, "Overwrite output device or partition", (10, 75), (290, 20))
       self.reversecb = wx.CheckBox(PrefsPanel, -1, "Reverse direction of copy operations", (10, 100), (290, 20))
       self.prealloccb = wx.CheckBox(PrefsPanel, -1, "Preallocate space on disc for output file", (10, 125), (310, 20))
       self.nosplitcb = wx.CheckBox(PrefsPanel, -1, "Do a soft run (don't read bad areas of disk)", (10,150), (315,20))

       # Set Checkbox's states (1 = enabled, 0 = disabled)
       self.dskaccesscb.SetValue(1)
       self.overwritecb.SetValue(0)
       self.reversecb.SetValue(0)
       self.prealloccb.SetValue(1)
       self.nosplitcb.SetValue(1)

       # Create Some Choiceboxes
       self.blcksizechoice = wx.Choice(PrefsPanel, -1, (650, 42), choices=['Auto', 'CD/DVD - 2048', 'HDD - 1024', 'HDD - 512'])   
       self.badsectchoice = wx.Choice(PrefsPanel, -1, (650, 72), choices=['Once', 'Default (Twice)', 'Three times', 'Five times', 'Forever'])
       self.dskrdspdchoice = wx.Choice(PrefsPanel, -1, (650, 102), choices=['Maximum', '8x', ' Default (4x)', '2x', '1x'])   
       self.maxerrschoice = wx.Choice(PrefsPanel, -1, (650, 132), choices=['Default (Infinite)', '100', '50', '30', '10', '5'])
       self.skipsizechoice = wx.Choice(PrefsPanel, -1, (650, 162), choices=['16 KB', 'Default (8 KB)', '4 KB', '2 KB', '1 KB']) 
       self.sectsizechoice = wx.Choice(PrefsPanel, -1, (650, 192), choices=['256', 'Default (128)', '64', '32']) 
       self.timeoutchoice = wx.Choice(PrefsPanel, -1, (650, 222), choices=['Infinite', '10 Mins', 'Default (5 Mins)', '2 Mins'])

       # Set default selections for the Choiceboxes (choices count up from 0)
       self.blcksizechoice.SetSelection(0)
       self.badsectchoice.SetSelection(1)
       self.dskrdspdchoice.SetSelection(2)
       self.maxerrschoice.SetSelection(0)
       self.skipsizechoice.SetSelection(1)
       self.sectsizechoice.SetSelection(1)
       self.timeoutchoice.SetSelection(2)

       #Bind all settingswindow events
       self.Bind(wx.EVT_BUTTON, self.SetCMDOptions, self.exitbutton)
       self.Bind(wx.EVT_CLOSE, self.SetCMDOptions)
      
       #Counter for the exit loop
       self.AlreadyRun = 0

    def SetCMDOptions(self, event):
       #Use a while loop to set almost all ddrescue cmd-line options before closing the dialog
       while self.AlreadyRun == 0:
           #Insure this only runs once.
           self.AlreadyRun = 1
           print "Saving Options..."

           # Use a series of if loops to set options:
  
           # Define global variables:
           global Diskaccess
           global Overwrite
           global Reverse
           global Preallocate
           global Nosplit
           global Blocksize
           global Badsectretry
           global Readspeed
           global Maxerrors
           global Skipsize
           global Sectorsize
           global Timeout

           # Checkboxes:
           if self.dskaccesscb.IsChecked(): #If the checkbox is checked, then
               Diskaccess = "-d" #add a commandline option to ddrescue
               print "Using direct disk access..."
           else: #If not, then 
               Diskaccess = "" #add nothing to commandline option
               print "Not using direct disk access..."

           if self.overwritecb.IsChecked():
               Overwrite = "-f"
               print "Overwriting output file..."
           else:
               Overwrite = ""
               print "Not overwriting output file..."

           if self.reversecb.IsChecked():
               Reverse = "-R"
               print "Set to reverse direction of all copy operations..."
           else:
               Reverse = ""
               print "Set to do all copy operations in normal direction..."
           
           if self.prealloccb.IsChecked():
               Preallocate = "-p"
               print "Set to preallocate disk space..."
           else:
               Preallocate = ""
               print "Set to not preallocate disk space..."
           
           if self.nosplitcb.IsChecked():
               Nosplit = "-n"
               print "Set to ignore bad areas of disk..."
           else:
               Nosplit = ""
               print "Set to split bad areas of disk..."

           # ChoiceBoxes:
           # Blocksize Choice:
           if self.blcksizechoice.GetCurrentSelection() == 0: # If the first option is selected:
               Blocksize = "Calculate"
               print "Using autodetect blocksize..."
           if self.blcksizechoice.GetCurrentSelection() == 1: # If the second option is selected: etc...
               Blocksize = "-b 2048" 
               print "Using blocksize 2048..."
           if self.blcksizechoice.GetCurrentSelection() == 2:
               Blocksize = "-b 1024"
               print "Using blocksize 1024..."
           if self.blcksizechoice.GetCurrentSelection() == 3:
               Blocksize = "-b 512"
               print "Using blocksize 512..."

           # No. of times to retry bad sectors:
           if self.badsectchoice.GetCurrentSelection() == 0:
               Badsectretry = "-r 1"
               print "Set to retry bad sectors once..."
           if self.badsectchoice.GetCurrentSelection() == 1:
               Badsectretry = "-r 2"
               print "Set to retry bad sectors twice..."
           if self.badsectchoice.GetCurrentSelection() == 2:
               Badsectretry = "-r 3"
               print "Set to retry bad sectors three times..."
           if self.badsectchoice.GetCurrentSelection() == 3:
               Badsectretry = "-r 5"
               print "Set to retry bad sectors five times..."
           if self.badsectchoice.GetCurrentSelection() == 4:
               Badsectretry = "-r -1"
               print "Set to retry bad sectors forever..."
           # Set disk read speed (CD/DVD only): #Soon use commands to run this here 
           if self.dskrdspdchoice.GetCurrentSelection() == 0:
               Readspeed = ""
               print "Using Maximum disk read speed..."
           if self.dskrdspdchoice.GetCurrentSelection() == 1:
               Readspeed = "eject -x 8"
               print "Using 8x as disk read speed..."
           if self.dskrdspdchoice.GetCurrentSelection() == 2:
               Readspeed = "eject -x 4"
               print "Using 4x as disk read speed"
           if self.dskrdspdchoice.GetCurrentSelection() == 3:
               Readspeed = "eject -x 2"
               print "Using 2x as disk read speed"
           if self.dskrdspdchoice.GetCurrentSelection() == 4:
               Readspeed = "eject -x 1"
               print "Using 1x as disk read speed"
           # Set maximum errors before exiting:
           if self.maxerrschoice.GetCurrentSelection() == 0:
               Maxerrors = ""
               print "Set to allow an infinite number of errors before exiting..."
           if self.maxerrschoice.GetCurrentSelection() == 1:
               Maxerrors = "-e 100"
               print "Set to allow 100 errors before exiting..."
           if self.maxerrschoice.GetCurrentSelection() == 2:
               Maxerrors = "-e 50"
               print "Set to allow 50 errors before exiting..."
           if self.maxerrschoice.GetCurrentSelection() == 3:
               Maxerrors = "-e 30"
               print "Set to allow 30 errors before exiting..."
           if self.maxerrschoice.GetCurrentSelection() == 4:
               Maxerrors = "-e 10"
               print "Set to allow 10 errors before exiting..."
           if self.maxerrschoice.GetCurrentSelection() == 5:
               Maxerrors = "-e 5"
               print "Set to allow 5 errors before exiting..."
           #No. of kbytes to initially skip on read error
           if self.skipsizechoice.GetCurrentSelection() == 0:
               Skipsize = "-k 128"
               print "Set to use 128 KBits as initial skip size..."
           if self.skipsizechoice.GetCurrentSelection() == 1:
               Skipsize = "-k 64"
               print "Set to use 64 KBits as initial skip size..."
           if self.skipsizechoice.GetCurrentSelection() == 2:
               Skipsize = "-k 32"
               print "Set to use 32 KBits as initial skip size..."
           if self.skipsizechoice.GetCurrentSelection() == 3:
               Skipsize = "-k 16"
               print "Set to use 16 KBits as initial skip size..."
           if self.skipsizechoice.GetCurrentSelection() == 4:
               Skipsize = "-k 8"
               print "Set to use 8 KBits as initial skip size..."
           #No. of sectors to copy at a tme
           if self.sectsizechoice.GetCurrentSelection() == 0:
               Sectorsize = "-c 256"
               print "Set to copy 256 sectors at a time..."
           if self.sectsizechoice.GetCurrentSelection() == 1:
               Sectorsize = "-c 128"
               print "Set to copy 128 sectors at a time..."
           if self.sectsizechoice.GetCurrentSelection() == 2:
               Sectorsize = "-c 64"
               print "Set to copy 64 sectors at a time..."
           if self.sectsizechoice.GetCurrentSelection() == 3:
               Sectorsize = "-c 32"
               print "Set to copy 32 sectors at a time..."
           #How long since last successful read before exiting:
           if self.timeoutchoice.GetCurrentSelection() == 0:
               Timeout = ""
               print "No timeout set..."
           if self.timeoutchoice.GetCurrentSelection() == 1:
               Timeout = "-T 600"
               print "Using 600 seconds as timeout value..."
           if self.timeoutchoice.GetCurrentSelection() == 2:
               Timeout = "-T 300"
               print "Using 300 seconds as timeout value..."
           if self.timeoutchoice.GetCurrentSelection() == 3:
               Timeout = "-T 120"
               print "Using 120 seconds as timeout value..." 
           #End while loop as all settings are now set as global variables...

       # Finally, exit
       print "Finished saving options..."
       print "Closing Preferences Window..."
       self.Destroy()

#End Preferences Window
app = wx.App(False)
MainFrame = MainWindow(None, "DDRescue-GUI")
MainFrame.Show()
app.MainLoop()
