#!/bin/bash
#Determines blocksize of devices for DDRescue-GUI
#Get Input file from commandline options.
if [ $# -eq 0 ] ; then
    echo "Gets blocksizes of devices for DDRescue-GUI. Can also be used seperately."
    echo "E.g. /opt/ddrescue-gui/DDrescue-gui-getblocksize.sh -d <yourdevicehere>"
    exit 0
fi
while getopts "h?d:" opt; do
    case "$opt" in
    h|\?)
        echo "Gets blocksizes of devices for DDRescue-GUI. Can also be used seperately."
        echo "E.g. /opt/ddrescue-gui/DDrescue-gui-getblocksize.sh -d <yourdevicehere>"
        exit 0
        ;;
    d)  
        InputFileChosen=$OPTARG
        ;;
    esac
done
#Get given device's blocksize and output it into a file.
Blocksize=$(/sbin/blockdev --getpbsz $InputFileChosen)
if [[ $? == "0" ]] ; then 
    #$Blocksize cannot be an error message.   
    echo $Blocksize > /tmp/ddrescue-gui/devblocksize
    exit 0
else
    #$Blocksize must be an error message.
    echo "" > /tmp/ddrescue-gui/devblocksize
    exit 1
fi

