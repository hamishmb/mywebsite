#!/bin/bash
#Script to obtain list of available devices.
#Obtain the data about connected devices.
mount | grep /dev/hd | sed 's/ .*//' > /tmp/ddrescue-gui/idedevices
mount | grep /dev/sr | sed 's/ .*//' > /tmp/ddrescue-gui/cddvddevices
mount | grep /dev/sd | sed 's/ .*//' > /tmp/ddrescue-gui/usbsatadevices
