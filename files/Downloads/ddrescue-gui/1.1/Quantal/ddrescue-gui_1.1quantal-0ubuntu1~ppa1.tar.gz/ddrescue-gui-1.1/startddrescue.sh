#!/bin/bash
#Starts ddrescue for DDRescue-GUI
#Get ddrescue's options from commandline.
if [ $# -eq 0 ] ; then
    echo "Starts ddrescue using cmdline options."
    echo "E.g. /opt/ddrescue-gui/startddrescue.sh -o=<youroptionshere>"
    exit 0
fi
while getopts "h?o:" opt; do
    case "$opt" in
    h|\?)
        echo "Starts ddrescue using cmdline options."
        echo "E.g. /opt/ddrescue-gui/startddrescue.sh -o=<youroptionshere>"
        exit 0
        ;;
    o)  
        OPTIONS=$OPTARG
        ;;
    esac
done
#Run ddrescue with given options.
ddrescue $OPTIONS > /tmp/ddrescue-gui/ddrescueoutput.txt
