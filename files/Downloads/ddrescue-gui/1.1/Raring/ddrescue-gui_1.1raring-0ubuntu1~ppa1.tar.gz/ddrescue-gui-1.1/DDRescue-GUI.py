#!/usr/bin/env /usr/bin/python
#Import modules
import time
import subprocess
from subprocess import PIPE, Popen, STDOUT
import os
import shutil
import wx
import wx.html

#Import libs for threading.
from wx.lib.pubsub import Publisher
from threading import Thread

#Begin Main Window   
class MainWindow(wx.Frame):
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(800,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        print "DDRescue-GUI Version 1.1 Starting..."

        # Make a temporary directory for data used by this program, if not already present.
        if not os.path.exists("/tmp/ddrescue-gui"):
            os.mkdir("/tmp/ddrescue-gui")

        # Initialize some global variables here to aviod later problems.
        global LogFileChosen
        LogFileChosen = "None"
        global OutputFileChosen
        OutputFileChosen = "None"
        global InputFileChosen
        InputFileChosen = "None"

        # Create a Statusbar in the bottom of the window and set the text.
        global statusbar
        statusbar = self.CreateStatusBar()
        statusbar.SetStatusText("Ready.")

        # Add the selection text
        welcometext = wx.StaticText(self.MainPanel, -1, "Welcome to DDRescue-GUI!", pos=(270,15))
        inputtext = wx.StaticText(self.MainPanel, -1, "Device/file to image from:", pos=(10, 40))  
        outputtext = wx.StaticText(self.MainPanel, -1, "Device/file to image to:", pos=(590, 40)) 
        logfiletext = wx.StaticText(self.MainPanel, -1, "Position for logfile:", pos=(300,40))

        # Add the data information text 
        self.recovereddata = wx.StaticText(self.MainPanel, -1, "Recovered data:", pos=(20,130))
        self.unreadabledata = wx.StaticText(self.MainPanel, -1, "Unreadable data:", pos=(270,130))
        self.currentreadrate = wx.StaticText(self.MainPanel, -1, "Current read rate:", pos=(530,130))
        self.numerrors = wx.StaticText(self.MainPanel, -1, "Number of read errors:", pos=(20,180))
        self.avgreadrate = wx.StaticText(self.MainPanel, -1, "Average read rate:", pos=(270,180))
        self.timesincelastread = wx.StaticText(self.MainPanel, -1, "Time since last sucessful read:", pos=(530,180))

        # Create some buttons
        self.startbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Start", pos=(620,270))
        self.abortbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Abort", pos=(710,270))
        self.refreshbutton = wx.Button(self.MainPanel, wx.ID_ANY, " Refresh List of Devices ", pos=(622,240))

        # Disable the abort button.
        self.abortbutton.Disable()

        # Create the choiceboxes.
        self.UpdateFileChoices(self)

        # Creating the menus.
        filemenu = wx.Menu()
        editmenu = wx.Menu()
        viewmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        # Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuPrefs = editmenu.Append(wx.ID_ANY, "&Preferences", "General settings")

        # Creating the menubar.
        self.menuBar = wx.MenuBar()

        # Adding menus to the MenuBar
        self.menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        self.menuBar.Append(editmenu,"&Edit") # Adding the "editmenu" to the MenuBar
        self.menuBar.Append(viewmenu,"&View") # Adding the "viewmenu" to the MenuBar
        self.menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar 

        # Adding the MenuBar to the Frame content.
        self.SetMenuBar(self.menuBar)

        # Create a wildcard for the open and save dialogs
        self.wildcard = "ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*" 

        # Set up to receive information from backend.
        Publisher().subscribe(self.UpdateRecoveredInfo, "recoveredupdate")
        Publisher().subscribe(self.UpdateErrsizeInfo, "errsizeupdate")
        Publisher().subscribe(self.UpdateReadRateInfo, "readrateupdate")
        Publisher().subscribe(self.UpdatenumerrorsInfo, "numerrsupdate")
        Publisher().subscribe(self.UpdateavgReadRateInfo, "avgreadrateupdate")
        Publisher().subscribe(self.UpdateTimeSinceLastReadInfo, "timesincelastreadupdate")
        Publisher().subscribe(self.UpdateStatusbar, "statusbarupdate")
        Publisher().subscribe(self.RecoveryEnded, "finished")

        self.BindEvents(self)
        
    #Create Functions
     
    def BindEvents(self, event): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Prefs, self.menuPrefs)
        self.Bind(wx.EVT_BUTTON, self.OnStart, self.startbutton)
        self.Bind(wx.EVT_BUTTON, self.UpdateFileChoices, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.OnAbort, self.abortbutton)

    def UpdateFileChoices(self,event):
        #Method to create/refresh i/o and log file choiceboxes.
        # Run a short bash script to collect data about connected devices.
        Popen("bash /opt/ddrescue-gui/listdevices.sh", shell=True).wait()

        # Create some lists
        self.inputfilelist = ['-- Please Select --', 'Other/Specify'] 
	self.outputfilelist = ['-- Please Select --', 'Other/Specify']

        #Add device information to the inputfilelist. (lines containing el.replace remove \n characters)
        idedevicesfile = open('/tmp/ddrescue-gui/idedevices', 'r').readlines()
        idedeviceslist = [el.replace('\n', '') for el in idedevicesfile]
        cddvddevicesfile = open('/tmp/ddrescue-gui/cddvddevices', 'r').readlines()
        cddvddeviceslist = [el.replace('\n', '') for el in cddvddevicesfile]
        usbsatadevicesfile = open('/tmp/ddrescue-gui/usbsatadevices', 'r').readlines()
        usbsatadeviceslist = [el.replace('\n', '') for el in usbsatadevicesfile]
        #Append each device to the input list.
        for idedevice in idedeviceslist:   
            self.inputfilelist.append(idedevice)
        for cddvddevice in cddvddeviceslist:   
            self.inputfilelist.append(cddvddevice)
        for usbsatadevice in usbsatadeviceslist: 
            self.inputfilelist.append(usbsatadevice)
        
        # Create some choiceboxes using the newly created/updated lists.
	self.inputchoice = wx.Choice(self.MainPanel, -1, (10,64), choices=self.inputfilelist)
	self.outputchoice = wx.Choice(self.MainPanel, -1, (590,64), choices=self.outputfilelist)
        self.logfilechoice = wx.Choice(self.MainPanel, -1, (300,64), choices=['-- Please Select --', 'None - not recommended', 'Specify'])

        #Bind the events here.
        self.Bind(wx.EVT_CHOICE, self.SelectInputFile, self.inputchoice)
        self.Bind(wx.EVT_CHOICE, self.SelectOutputFile, self.outputchoice)
        self.Bind(wx.EVT_CHOICE, self.SelectLogFile, self.logfilechoice)

        #Let the starter script know that the choiceboxes have been reset. 
        global checksettings
        checksettings = "FALSE"

        # Notify the user with the statusbar
        statusbar.SetStatusText("Updated List of devices.")
        time.sleep(1)
        statusbar.SetStatusText("Ready.")

    def SelectInputFile(self,event):
        #Function for selecting input file/device and set variable to selected value.
        global InputFileChosen #Let the function know we are using a global variable
        InputFileChosen = self.inputchoice.GetStringSelection()
        if InputFileChosen == "Other/Specify":
            InputFileDlg = wx.FileDialog(self.MainPanel, "Select Input File/Device...", defaultDir="/dev", wildcard=self.wildcard, style=wx.OPEN)
            if InputFileDlg.ShowModal() == wx.ID_OK:
                InputFileChosen = InputFileDlg.GetPath()
                self.inputchoice.Append(InputFileChosen)
                self.inputchoice.SetStringSelection(InputFileChosen)
            else:
                InputFileChosen = "None"
                self.inputchoice.SetStringSelection("-- Please Select --")

        if InputFileChosen == "-- Please Select --":
            InputFileChosen = "None"

    def SelectOutputFile(self,event):
        #Function for selecting output file/device and set variable to selected value.
        global OutputFileChosen #Let the function know we are using a global variable
        OutputFileChosen = self.outputchoice.GetStringSelection()
        if OutputFileChosen == "-- Please Select --":
            OutputFileChosen = "None"

        if OutputFileChosen == "Other/Specify":
            OutputFileDlg = wx.FileDialog(self.MainPanel, "Select Output File/Device...", defaultDir=os.environ["HOME"], wildcard=self.wildcard, style=wx.SAVE | wx.OVERWRITE_PROMPT)
            if OutputFileDlg.ShowModal() == wx.ID_OK:
                OutputFileChosen = OutputFileDlg.GetPath()
                self.outputchoice.Append(OutputFileChosen)
                self.outputchoice.SetStringSelection(OutputFileChosen)
            else:
                OutputFileChosen = "None"
                self.outputchoice.SetStringSelection("-- Please Select --")

    def SelectLogFile(self,event):
        #Function for selecting log file position/name and set variable to selected value.
        global LogFileChosen #Let the function know we are using a global variable
        LogFileChosen = self.logfilechoice.GetStringSelection()
        if LogFileChosen == "-- Please Select --":
            LogFileChosen = "None"

        if LogFileChosen == "None - not recommended":
            warndlg = wx.MessageDialog(self.MainPanel, 'You have not chosen to use a log file. If you do not use one, you will have to start from scratch in the event of a power outage, or if the program is interrupted. Are you sure you do not want to use a logfile?', 'DDRescue-GUI', wx.YES_NO | wx.ICON_EXCLAMATION).ShowModal()
            if warndlg == wx.ID_YES:
                LogFileChosen = ""
            else:
                LogFileChosen = "None"
                self.logfilechoice.SetStringSelection("-- Please Select --")

        if LogFileChosen == "Specify":
            LogFileDlg = wx.FileDialog(self.MainPanel, "Select Log File Position & Name...", defaultDir=os.environ["HOME"], wildcard="Log Files|*.log", style=wx.SAVE)
            if LogFileDlg.ShowModal() == wx.ID_OK:
                LogFileChosen = LogFileDlg.GetPath()
                self.logfilechoice.Append(LogFileChosen)
                self.logfilechoice.SetStringSelection(LogFileChosen)
            else:
                LogFileChosen = "None"
                self.logfilechoice.SetStringSelection("-- Please Select --")

    def OnAbout(self,e):
        # A message dialog box with an OK button
        AboutWindow().Show()

    def Prefs(self,e):
        # A dialog to modify settings
        # If input and output files are set (do not equal "None") then continue.
        if InputFileChosen != "None" and OutputFileChosen != "None":
            PreferencesWindow().Show()
        else:
            wx.MessageDialog(self.MainPanel, 'Please select input and output files first!', 'DDRescue-GUI -- Error!', wx.OK | wx.ICON_ERROR).ShowModal()

    def DevInfo(self,e): 
        # Use a seperate bash script and zenity for this dialog
        DevInfoDlg = Popen("bash /opt/ddrescue-gui/devinfodlg.sh", shell=True)

    def OnStart(self,e):
        # Function to start ddrescue and check final settings. UNFINISHED ***
        statusbar.SetStatusText("Checking Settings...")
        if checksettings != "TRUE":
            wx.MessageDialog(self.MainPanel, 'Sorry, it is important that you check the settings before you start the recovery!', 'DDRescue-GUI -- Error!', wx.OK | wx.ICON_ERROR).ShowModal()
            statusbar.SetStatusText("Ready.")
        if checksettings == "TRUE":
            if InputFileChosen != "None" and LogFileChosen != "None" and OutputFileChosen != "None":
                global ProgressBar
                ProgressBar = wx.Gauge(self.MainPanel, -1, 5000, (10,273), (600,25))
                ProgressBar.SetBezelFace(3)
                ProgressBar.SetShadowWidth(3)
                statusbar.SetStatusText("Starting DDRescue...")
                wx.MessageDialog(self.MainPanel, 'DDRescue is now about to be started. Please wait for up to 10 seconds for DDRescue-GUI to start updating.', 'DDRescue-GUI -- Information', wx.OK | wx.ICON_INFORMATION).ShowModal()
                #Disable and enable all necessary items.
                self.abortbutton.Enable()
                self.refreshbutton.Disable()
                self.startbutton.Disable()
                self.inputchoice.Disable()
                self.outputchoice.Disable()
                self.logfilechoice.Disable()
                self.menuBar.EnableTop(0, False) 
                self.menuBar.EnableTop(1, False) 
                self.menuBar.EnableTop(2, False) 
                self.menuBar.EnableTop(3, False) 
                StartBackend()
            else:
                wx.MessageDialog(self.MainPanel, 'Please set Input file, Log file and Output file correctly before starting!', 'DDRescue-GUI -- Error!', wx.OK | wx.ICON_ERROR).ShowModal()
                statusbar.SetStatusText("Ready.")  

    #The next functions are to update the display with info from the backend.
    def UpdateRecoveredInfo(self,msg):
        self.recovereddata.SetLabel("Recovered data: "+msg.data)

    def UpdateErrsizeInfo(self,msg):
        self.unreadabledata.SetLabel("Unreadable data: "+msg.data) 

    def UpdateReadRateInfo(self,msg):
        self.currentreadrate.SetLabel("Current read rate: "+msg.data)

    def UpdatenumerrorsInfo(self,msg):
        self.numerrors.SetLabel("Number of read errors: "+msg.data)

    def UpdateavgReadRateInfo(self,msg):
        self.avgreadrate.SetLabel("Average read rate: "+msg.data)

    def UpdateTimeSinceLastReadInfo(self,msg):
        self.timesincelastread.SetLabel("Time since last sucessful read: "+msg.data)

    def UpdateStatusbar(self,msg):
        global statusbar
        statusbar.SetStatusText(msg.data)

    def OnAbort(self,e):
        #Ask ddrescue to exit.
        termddrescue = Popen("killall ddrescue", shell=True).wait() 

    def RecoveryEnded(self,e):
        wx.MessageDialog(self.MainPanel, "Your Image File can be located at: "+OutputFileChosen+" Please close DDRescue-GUI", "DDRescue-GUI - Recovery Finished!", style=wx.OK, pos=wx.DefaultPosition).ShowModal()
        global statusbar
        
        
    def OnExit(self,e):
        shutil.rmtree('/tmp/ddrescue-gui')
        self.Close(True)  

#End Main Window
#Begin About Window
class AboutWindow(wx.Frame):
    def __init__(self):
       wx.Frame.__init__(self, wx.GetApp().TopWindow, title="About DDRescue-GUI", size=(400,300), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
       AboutPanel=wx.Panel(self)
       
       #Basically consists of static text.
       icon = wx.Image('/opt/ddrescue-gui/ddrescue-gui.jpg', wx.BITMAP_TYPE_ANY, index=1)
       displayicon = wx.StaticBitmap(AboutPanel, -1, wx.BitmapFromImage(icon), (0,-50))
       name = wx.StaticText(AboutPanel, -1, "DDRescue-GUI version 1.1", (120,80))
       description = wx.StaticText(AboutPanel, -1, "GUI Frontend for GNU ddrescue", (100,110))
       copyright1 = wx.StaticText(AboutPanel, -1, u'DDRescue-GUI Copyright \xa9 2013 Hamish McIntyre-Bhatty', (12,150))
       copyright2 = wx.StaticText(AboutPanel, -1, u'GNU ddrescue Copyright \xa9 2013 Free Software Foundation', (5,170))
       licence = wx.StaticText(AboutPanel, -1, 'These programs are available to you under the terms of the', (5,190))
       license2 = wx.StaticText(AboutPanel, -1, 'GNU GPL v3. They have ABSOLUTELY NO WARRANTY;', (20,210))
       license3 = wx.StaticText(AboutPanel, -1, 'visit http://www.gnu.org/licenses/old-licenses/gpl-2.0.html', (2,230))
       closebutton = wx.Button(AboutPanel, -1, "Close", pos=(160,250))   

       #Bind event.
       self.Bind(wx.EVT_BUTTON, self.OnExit, closebutton)
 
    def OnExit(self,e):
        self.Destroy()
       
#End About Window
#Begin Preferences Window
class PreferencesWindow(wx.Frame):

    title = "DDRescue-GUI - Preferences" 

    def __init__(self):
       wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(800,270), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
       PrefsPanel=wx.Panel(self)

       # Notify MainWindow that this has been run.
       global checksettings
       checksettings = "TRUE"

       # Create a button to exit
       self.exitbutton = wx.Button(PrefsPanel, -1, "Close", pos=(100, 200)) 

       # Create some Text
       wx.StaticText(PrefsPanel, -1, "Welcome to Preferences. The default settings should be decently acceptable in most cases.", (10,15))
       blcksizetext = wx.StaticText(PrefsPanel, -1, "Block (cluster) size of input device:", (340,50))
       badsecttext = wx.StaticText(PrefsPanel, -1, "No. of times to retry bad sectors:", (340, 80))
       dskrdspdtext = wx.StaticText(PrefsPanel, -1, "Set disk read speed (CDs/DVDs only):", (340, 110)) 
       maxerrstext = wx.StaticText(PrefsPanel, -1, "Maximum number of errors before exiting:", (340, 140))
       skipsizetext = wx.StaticText(PrefsPanel, -1, "Amount of data to skip on a read error (Kb):", (340, 170))
       sectsizetext = wx.StaticText(PrefsPanel, -1, "Number of clusters to copy at a time:", (340,200))
       timeouttext = wx.StaticText(PrefsPanel, -1, "Max time since last successful read before exiting:", (300, 230)) 

       # Create Some Checkboxes
       self.dskaccesscb = wx.CheckBox(PrefsPanel, -1, "Use direct disc access (Recommended)", (10, 50), (290, 20))
       self.overwritecb = wx.CheckBox(PrefsPanel, -1, "Overwrite output device or partition", (10, 75), (290, 20))
       self.reversecb = wx.CheckBox(PrefsPanel, -1, "Read from finish to start (Reverse)", (10, 100), (290, 20))
       self.prealloccb = wx.CheckBox(PrefsPanel, -1, "Preallocate space on disc for output file", (10, 125), (310, 20))
       self.nosplitcb = wx.CheckBox(PrefsPanel, -1, "Do a soft run (don't read bad areas of disk)", (10,150), (315,20))

       # Set Checkbox's states (1 = enabled, 0 = disabled)
       self.dskaccesscb.SetValue(0)
       self.overwritecb.SetValue(0)
       self.reversecb.SetValue(0)
       self.prealloccb.SetValue(0)
       self.nosplitcb.SetValue(0)

       # Create Some Choiceboxes
       self.blcksizechoice = wx.Choice(PrefsPanel, -1, (650, 42), choices=['Auto', '4096', '2048', '1024', '512'])   
       self.badsectchoice = wx.Choice(PrefsPanel, -1, (650, 72), choices=['0', '1', 'Default (2)', '3', '5', 'Forever'])
       self.dskrdspdchoice = wx.Choice(PrefsPanel, -1, (650, 102), choices=['Maximum', '8x', '4x', '2x', '1x'])   
       self.maxerrschoice = wx.Choice(PrefsPanel, -1, (650, 132), choices=['Default (Infinite)', '100', '50', '30', '10', '5'])
       self.skipsizechoice = wx.Choice(PrefsPanel, -1, (650, 162), choices=['128', '64', '32', '16', '8']) 
       self.clustsizechoice = wx.Choice(PrefsPanel, -1, (650, 192), choices=['256', 'Default (128)', '64', '32']) 
       self.timeoutchoice = wx.Choice(PrefsPanel, -1, (650, 222), choices=['Infinite', '20 Mins', '10 Mins', '5 Mins', '2 Mins'])

       # Set default selections for the Choiceboxes (choices count up from 0)
       self.blcksizechoice.SetSelection(0)
       self.badsectchoice.SetSelection(1)
       self.dskrdspdchoice.SetSelection(0)
       self.maxerrschoice.SetSelection(0)
       self.skipsizechoice.SetSelection(0)
       self.clustsizechoice.SetSelection(1)
       self.timeoutchoice.SetSelection(2)

       #Disable some options that don't yet work or aren't supported by the version of ubuntu this package is designed for.
       self.skipsizechoice.Disable() #Doesn't work yet.
       self.dskaccesscb.Disable() #Doesn't work in python, will soon remove.
       self.dskrdspdchoice.Disable() #Not finished yet.

       #Bind all settingswindow events
       self.Bind(wx.EVT_BUTTON, self.SetCMDOptions, self.exitbutton)
       self.Bind(wx.EVT_CLOSE, self.SetCMDOptions)
      
       #Counter for the exit loop
       self.AlreadyRun = 0

    def SetCMDOptions(self, event):
       #Use a while loop to set almost all ddrescue cmd-line options before closing the dialog
       while self.AlreadyRun == 0:
           #Insure this only runs once.
           self.AlreadyRun = 1

           print "Saving Options..."

           # Use a series of if loops to set options:
  
           # Define global variables:
           global Diskaccess
           global Overwrite
           global Reverse
           global Preallocate
           global Nosplit
           global Blocksize
           global Badsectretry
           global Readspeed
           global Maxerrors
           global Skipsize
           global Clustersize
           global Timeout

           # Checkboxes (written as cb):
           #direct disk access doesn't work under python, so disabled.
           #if self.dskaccesscb.IsChecked(): #If the checkbox is checked, then
           #    Diskaccess = "-d" #add a commandline option to ddrescue
           #    print "Using direct disk access..."
           #else: #If not, then 
           #    Diskaccess = "" #add nothing to commandline option
           #    print "Not using direct disk access..."

           if self.overwritecb.IsChecked():
               Overwrite = "-f"
               print "Overwriting output file..."
           else:
               Overwrite = ""
               print "Not overwriting output file..."

           if self.reversecb.IsChecked():
               Reverse = "-R"
               print "Set to reverse direction of all copy operations..."
           else:
               Reverse = ""
               print "Set to do all copy operations in normal direction..."
           
           if self.prealloccb.IsChecked():
               Preallocate = "-p"
               print "Set to preallocate disk space..."
           else:
               Preallocate = ""
               print "Set to not preallocate disk space..."
           
           if self.nosplitcb.IsChecked():
               Nosplit = "-n"
               print "Set to ignore bad areas of disk..."
           else:
               Nosplit = ""
               print "Set to split bad areas of disk..."

           # ChoiceBoxes:
           # Blocksize Choice:
           Blocksize = "-b "+self.blcksizechoice.GetStringSelection()

           # If set to auto, determine blocksize with a command.
           if Blocksize == "-b Auto":
              #Start a process to do this for us, waiting for it to finish.
              statusbar.SetStatusText("Determining block size for device/file "+InputFileChosen+". Please Wait...")
              getblocksize = Popen("bash /opt/ddrescue-gui/getblocksize.sh -d "+InputFileChosen, shell=True)
              retcode = getblocksize.wait()
              if retcode == 0:
                  with open('/tmp/ddrescue-gui/devblocksize', 'r') as BlockSizeFile:
                      Blocksize = "-b "+BlockSizeFile.read().replace("\n","")
                  #Set blocksize
              else:
                  Blocksize = ""
                  #Input file is standard file, don't set blocksize

           statusbar.SetStatusText("Ready.")
           print "Using "+Blocksize+" as blocksize"

           # No. of times to retry bad sectors:
           if self.badsectchoice.GetCurrentSelection() == 2:
               Badsectretry = "-r 2"
               print "Set to retry bad sectors 2 times..."
           if self.badsectchoice.GetCurrentSelection() == 5:
               Badsectretry = "-r -1"
               print "Set to retry bad sectors forever..."
           if self.badsectchoice.GetCurrentSelection() != 2 and self.badsectchoice.GetCurrentSelection() != 5:
               Badsectretry = "-r "+self.badsectchoice.GetStringSelection()
               print "Set to retry bad sectors "+Badsectretry+" times..."

           # Set disk read speed (CD/DVD only): #Soon use commands to run this here, disabled becuase not finished. 
           #if self.dskrdspdchoice.GetCurrentSelection() == 0:
           #    Readspeed = ""
           #    print "Using Maximum disk read speed..."
           #if self.dskrdspdchoice.GetCurrentSelection() == 1:
           #    Readspeed = "8"
           #    print "Using 8x as disk read speed..."
           #if self.dskrdspdchoice.GetCurrentSelection() == 2:
           #    Readspeed = "4"
           #    print "Using 4x as disk read speed"
           #if self.dskrdspdchoice.GetCurrentSelection() == 3:
           #    Readspeed = "2"
           #    print "Using 2x as disk read speed"
           #if self.dskrdspdchoice.GetCurrentSelection() == 4:
           #    Readspeed = "1"
           #    print "Using 1x as disk read speed"

           # Set maximum errors before exiting:
           if self.maxerrschoice.GetStringSelection() == "Default (Infinite)":
               Maxerrors = ""
               print "Set to allow an infinite number of errors before exiting..."
           else:
               Maxerrors = "-e "+self.maxerrschoice.GetStringSelection()
               print "Set to allow "+Maxerrors+" errors before exiting..."

           #Skipsize disabled becuase it isn't working at the moment.
           #No. of kbytes to initially skip on read error. Multiplying number by 1000
           #Skipsize = "-K "+str((int(self.skipsizechoice.GetStringSelection()) * 1000))
           #Skipsize = ""
           #print "Set to use "+Skipsize+" KBits as initial skip size..."
           
           #No. of clusters to copy at a tme
           if self.clustsizechoice.GetStringSelection() == "Default (128)":
               Clustersize = "-c 128"
               print "Set to copy 128 clusters at a time..."
           else:
               Clustersize = "-c "+self.clustsizechoice.GetStringSelection()
               print "Set to copy "+Clustersize+" clusters at a time..."

           #How long since last successful read before exiting:
           if self.timeoutchoice.GetCurrentSelection() == 0:
               Timeout = ""
               print "Allowing infinite timeout..."
           if self.timeoutchoice.GetCurrentSelection() == 1:
               Timeout = "-T 1200"
               print "Using 1200 seconds as timeout value..."
           if self.timeoutchoice.GetCurrentSelection() == 2:
               Timeout = "-T 600"
               print "Using 600 seconds as timeout value..."
           if self.timeoutchoice.GetCurrentSelection() == 3:
               Timeout = "-T 300"
               print "Using 300 seconds as timeout value..."
           if self.timeoutchoice.GetCurrentSelection() == 4:
               Timeout = "-T 120"
               print "Using 120 seconds as timeout value..." 
           #End while loop as all settings are now set as global variables...

       # Finally, exit
       print "Finished saving options..."
       print "Closing Preferences Window..."
       self.Destroy()

#End Preferences Window
#Begin Backend thread.
class StartBackend(Thread):
    def __init__(self):
        #Initialize and start the thread.
        Thread.__init__(self)
        self.start()
    def run(self):
        #Set disk read speed (if any). Disabled.
        #setdiskreadspeed = Popen("eject -x "+Readspeed, shell=True).wait()

        #Start ddrescue
        ddrescuecommand = Popen("bash /opt/ddrescue-gui/startddrescue.sh -o '-v "+Reverse+" "+Preallocate+" "+Nosplit+" "+Blocksize+" "+Badsectretry+ " "+Maxerrors+" "+Clustersize+" "+Timeout+" "+InputFileChosen+" "+OutputFileChosen+" "+LogFileChosen+"'", shell=True)
        
        #Do a sleep to insure the process has started.
        time.sleep(8)

        #Grab some useful initial data (amount of data), and unit (KB, MB, GB etc...).
        datatorecover = subprocess.check_output("cat /tmp/ddrescue-gui/ddrescueoutput.txt | grep 'About to copy' | awk '{print $4}'", shell=True).replace('\n', '')
        unitfordatatorecover = subprocess.check_output("cat /tmp/ddrescue-gui/ddrescueoutput.txt | grep 'About to copy' | awk '{print $5}'", shell=True).replace('\n', '')
        print "DDRescue is about to copy "+datatorecover+" "+unitfordatatorecover

        #Set progressbar's range.
        global ProgressBar
        ProgressBar.SetRange(int(datatorecover))

        #Create a unit list for converting data between KB, MB, GB for the progressbar.
        unitlist = ['null', 'B', 'kB', 'MB', 'GB', 'TB', 'PB']

        #Get only the first 2 chars from the unitfordatatorecover to make it compatible with the list.
        unitfordatatorecover = unitfordatatorecover[:2]

        while ddrescuecommand.poll() is None:
            #ddrescue is running.
            #Grab and preprocess (remove junk from) ddrescue's output. (all commands remove line endings too)
            stdin,stdout = os.popen2("tail -n 5 /tmp/ddrescue-gui/ddrescueoutput.txt")
            stdin.close()
            outputfile = stdout.readlines(); stdout.close()
            output1 = [el.replace('\n', '') for el in outputfile]
            output2 = [el.replace('\r', '') for el in output1]
            ddrescueoutput = str([el.replace('"\x1b[A\x1b[A\x1b[A"', '') for el in output2])

            #Grab current amount (number), and unit of recovered data, removing also a commar.
            recovereddatanum = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $15}'", shell=True).replace('\n', '')
            recovereddataunit = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $16}'", shell=True).replace('\n', '').replace(',', '')
            
            #Grab size of unreadable data.
            errsize = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $18, $19}'", shell=True).replace('\n', '').replace(',', '')

            #Grab current read rate.
            currentreadrate = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $22, $23}'", shell=True).replace('\n', '').replace(',', '')

            #Grab no. of errors.
            numerrors = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $28}'", shell=True).replace('\n', '').replace(',', '')

            #Grab average read rate.
            avgreadrate = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $31, $32}'", shell=True).replace('\n', '').replace(',', '')

            #Grab time since last sucessful read.
            timesincelastread = subprocess.check_output("echo '"+ddrescueoutput+"' | awk '{print $41, $42}'", shell=True).replace('\n', '').replace(',', '')

            #Grab status (use different technique).
            status = subprocess.check_output("tail -n 1 /tmp/ddrescue-gui/ddrescueoutput.txt", shell=True).replace('\n', '')

            #Figure out if a calculation is needed for the progressbar's data.
            #Use a try loop to correct errors.
            try:
                numdatatorecover = unitlist.index(unitfordatatorecover)
                numrecovereddataunit = unitlist.index(recovereddataunit)
                unitnum = numrecovereddataunit - numdatatorecover
                if unitnum == -2:
                    recovereddatanum = int(recovereddatanum)/1000000
                if unitnum == -1:
                    recovereddatanum = int(recovereddatanum)/1000
                if unitnum == 0:
                    recoveredatanum = int(recovereddatanum)
                if unitnum == 1:
                    recovereddatanum = int(recovereddatanum)*1000
                if unitnum == 2:
                    recovereddatanum = int(recovereddatanum)*1000000
                recovereddataunit = unitfordatatorecover
            except ValueError:
                wx.CallAfter(Publisher().sendMessage, "statusbarupdate", "Waiting for ddrescue to recover some data...")
                time.sleep(5)
            except UnboundLocalError:
                wx.CallAfter(Publisher().sendMessage, "statusbarupdate", "Waiting for ddrescue to recover some data...")
                time.sleep(5)
            else:
                #Update progressbar
                ProgressBar.SetValue(int(recovereddatanum))

                #Send messages to GUI for updating.
                wx.CallAfter(Publisher().sendMessage, "recoveredupdate", str(recovereddatanum)+" "+recovereddataunit)
                wx.CallAfter(Publisher().sendMessage, "errsizeupdate", errsize)
                wx.CallAfter(Publisher().sendMessage, "readrateupdate", currentreadrate)
                wx.CallAfter(Publisher().sendMessage, "numerrsupdate", numerrors)
                wx.CallAfter(Publisher().sendMessage, "avgreadrateupdate", avgreadrate)
                wx.CallAfter(Publisher().sendMessage, "timesincelastreadupdate", timesincelastread)
                wx.CallAfter(Publisher().sendMessage, "statusbarupdate", status)

                #Sleep for 1 second to keep in sync with ddrescue's updates.
                time.sleep(1)

            if ddrescuecommand.poll() is not None:
                print "Recovery finished."
                wx.CallAfter(Publisher().sendMessage, "finished", "The recovery was sucessful.")

#End Backend thread
app = wx.App(False)
MainFrame = MainWindow(None, "DDRescue-GUI")
MainFrame.Show()
app.MainLoop()
