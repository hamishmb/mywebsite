#!/bin/bash
# Device information dialog shell script for DDRescue-GUI Version 1.2
# Copyright (C) 2013 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Obtain the data about connected devices.
idehdds=$(cat /tmp/ddrescue-gui/idedevices)
cdsordvds=$(cat /tmp/ddrescue-gui/cddvddevices)
satahddsorusbs=$(cat /tmp/ddrescue-gui/usbsatadevices)
if [[ -z $idehdds ]] ; then
    idehdds=None
fi
if [[ -z $cdsordvds ]] ; then
    cdsordvds=None
fi
if [[ -z $satahddsorusbs ]] ; then
    stathddsorusbs=None
fi
#Run zenity with the information included.
zenity --title='DDRescue-GUI - Device Information' --text='Here are all the detected devices on your computer' --list --column='Type' 'IDE Hard drives: ' $idehdds 'CD/DVD drives: ' $cdsordvds 'USB Drives/Sata/SCSI Hard drives: ' $satahddsorusbs
