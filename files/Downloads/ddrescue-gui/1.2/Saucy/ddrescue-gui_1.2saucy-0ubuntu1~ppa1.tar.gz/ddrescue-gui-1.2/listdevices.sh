#!/bin/bash
# Device detector for DDRescue-GUI Version 1.2
# Copyright (C) 2013 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Obtain data about connected devices.
mount | grep /dev/hd | sed 's/ .*//' > /tmp/ddrescue-gui/idedevices
mount | grep /dev/sr | sed 's/ .*//' > /tmp/ddrescue-gui/cddvddevices
mount | grep /dev/sd | sed 's/ .*//' > /tmp/ddrescue-gui/usbsatadevices
