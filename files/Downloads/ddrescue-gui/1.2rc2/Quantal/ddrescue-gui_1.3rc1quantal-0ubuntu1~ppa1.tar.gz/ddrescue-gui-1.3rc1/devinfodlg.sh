#!/bin/bash
#Script to manage and create ddrescue-gui's device infomation dialog.
#Obtain the data about connected devices.
idehdds=$(cat /tmp/ddrescue-gui/idedevices)
cdsordvds=$(cat /tmp/ddrescue-gui/cddvddevices)
satahddsorusbs=$(cat /tmp/ddrescue-gui/usbsatadevices)
if [[ -z $idehdds ]] ; then
    idehdds=None
fi
if [[ -z $cdsordvds ]] ; then
    cdsordvds=None
fi
if [[ -z $satahddsorusbs ]] ; then
    stathddsorusbs=None
fi
#Run zenity with the information included.
zenity --title='DDRescue-GUI - Device Information' --text='Here are all the detected devices on your computer' --list --column='Type' 'IDE Hard drives: ' $idehdds 'CD/DVD drives: ' $cdsordvds 'USB Drives/Sata/SCSI Hard drives: ' $satahddsorusbs
