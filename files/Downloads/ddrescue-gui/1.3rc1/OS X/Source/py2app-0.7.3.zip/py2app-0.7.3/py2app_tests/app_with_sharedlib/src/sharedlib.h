#ifndef SHARED_LIB_H
#define SHARED_LIB_H

extern int squared(int);
extern int doubled(int);
extern int half(int);

#endif /* SHARED_LIB_H */
