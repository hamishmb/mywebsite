from setuptools import setup

setup(
    name='BasicApp',
    app=['main.py'],
)
