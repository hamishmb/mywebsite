#!/usr/bin/env python
import unittest
import sys
import logging
logger = logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s: %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p', level=logging.DEBUG)
logger.debug("d")

import re

sys.path.append("..")
import GetDevInfo

from GetDevInfo.getdevinfo import Main as DevInfoTools

class TestStringMethods(unittest.TestCase):

  def test_upper(self):
      self.assertEqual('foo'.upper(), 'FOO')

  def test_isupper(self):
      self.assertTrue('FOO'.isupper())
      self.assertFalse('Foo'.isupper())

  def test_split(self):
      s = 'hello world'
      self.assertEqual(s.split(), ['hello', 'world'])
      # check that s.split fails when the separator is not a string
      with self.assertRaises(TypeError):
          s.split(2)

  def test_foundexactmatch(self):
      GetDevInfo.getdevinfo.re = re
      self.assertEqual(DevInfoTools().FoundExactMatch("\devsr0", "sdfgrodu ouh sougo,srdo, ,\devsr0, oighu", Log=False), True)

  def test_ispartition(self):
      GetDevInfo.getdevinfo.logger = logger
      GetDevInfo.getdevinfo.Linux = True
      self.assertEqual(DevInfoTools().IsPartition("/dev/sr0"), False)
