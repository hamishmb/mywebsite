#!/usr/bin/env python
# -*- coding: utf-8 -*- 
# DDRescue-GUI Main Script Version 1.4~rc1
# This file is part of DDRescue-GUI.
# Copyright (C) 2013-2015 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Do future imports to prepare to support python 3. Use unicode strings rather than ASCII strings, as they fix potential problems.
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
from __future__ import unicode_literals

#Import other modules
import wx
import wx.animate
import wx.lib.stattext
import wx.lib.statbmp
import threading
import getopt
import logging
import time
import platform
import subprocess #*** Instead of using endless calls to subprocess, make a seperate function like WxFixBoot's one, and use that instead so we can log output ***
import re
import os
import sys
import shutil

#Import custom-made modules
import GetDevInfo
from GetDevInfo.getdevinfo import Main as DevInfoTools

#Define the version number and the release date as global variables.
Version = "1.4~rc1"
ReleaseDate = "25/4/2015"

def usage():
    print("\nUsage: DDRescue-GUI.py [OPTION]\n\n")
    print("Options:\n")
    print("       -h, --help:                   Show this help message")
    print("       -L, --localdir                Use the current directory as the rescource path. Helpful for testing on OS X, but please don't use it on a production machine.")
    print("       -q, --quiet:                  Show only warning, error and critical error messages in the log file. Very unhelpful for debugging, and not recommended.")
    print("       -v, --verbose:                Enable logging of info messages, as well as warnings, errors and critical errors.")
    print("                                     Not the best for debugging, but acceptable if there is little disk space.")
    print("       -d, --debug:                  Log lots of boring debug messages, as well as information, warnings, errors and critical errors. Usually used for diagnostic purposes.")
    print("                                     The default, as it's very helpful if problems are encountered, and the user needs help\n")
    print("DDRescue-GUI "+Version+" is released under the GNU GPL Version 3")
    print("Copyright (C) Hamish McIntyre-Bhatty 2013-2015")

#Determine if running on Linux or Mac.
global Linux
if platform.system() == 'Linux':
    Linux = True

    #Set the resource path to /usr/share/ddrescue-gui/
    RescourcePath = '/usr/share/ddrescue-gui' 
elif platform.system() == 'Darwin':
    Linux = False

    try:
        #Set the resource path from an environment variable, as mac .apps can be found in various places.
        RescourcePath = os.environ['RESOURCEPATH']
    except KeyError:
        #Use '.' as the rescource path instead as a fallback.
    	RescourcePath = "."

#Check all cmdline options are valid.
try:
    opts, args = getopt.getopt(sys.argv[1:], "hLqvd", ["help", "localdir", "quiet", "verbose", "debug"])
except getopt.GetoptError as err:
    #Invalid option. Show the help message and then exit.
    #Show the error.
    print(unicode(err))
    usage()
    sys.exit(2)

#Determine the option(s) given, and change the level of logging based on cmdline options.
loggerLevel = logging.DEBUG

for o, a in opts:
    if o in ["-q", "--quiet"]:
        loggerLevel = logging.WARNING
    elif o in ["-v", "--verbose"]:
        loggerLevel = logging.INFO
    elif o in ["-d", "--debug"]:
        loggerLevel = logging.DEBUG
    elif o in ["-L", "--localdir"]:
        RescourcePath = "."
    elif o in ["-h", "--help"]:
        usage()
        sys.exit()
    else:
        assert False, "unhandled option"

#If we aren't running as root, relaunch immediately.
if os.geteuid() != 0:
    #Relaunch as root.
    subprocess.Popen([RescourcePath+"/helperscripts/runasroot.sh"])
    sys.exit("\nSorry, this program must be run with root privileges.\nRestarting as root...")

#Set up logging with default logging mode as debug.
logger = logging.getLogger('DDRescue-GUI 1.4~rc1')
logging.basicConfig(filename='/var/log/ddrescue-gui.log', format='%(asctime)s - %(name)s - %(levelname)s: %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p')
logger.setLevel(loggerLevel)

#Log which OS we're running on at warning level, so it's always in the log file.
if Linux:
    logger.warning("Detected Linux...")
else:
    logger.warning("Detected Mac OS X...")

#Setup custom-made modules (make global variables accessible inside the package).
GetDevInfo.getdevinfo.subprocess = subprocess
GetDevInfo.getdevinfo.re = re
GetDevInfo.getdevinfo.logger = logger
GetDevInfo.getdevinfo.Linux = Linux

#Begin Device Information Handler thread.
class GetDeviceInformation(threading.Thread):
    def __init__(self, ParentWindow):
        """Initialize and start the thread."""
        self.ParentWindow = ParentWindow
        threading.Thread.__init__(self)
        self.start()

    def run(self):
        """Get Device Information and return it as a list with embedded lists"""
        #Use a module I've written to collect data about connected devices, and return it.
        wx.CallAfter(self.ParentWindow.ReceiveDeviceInfo, DevInfoTools().GetInfo())

#End Device Information Handler thread.
#Starter Class
class MyApp(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        """Prepare and display a splash screen"""
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = RescourcePath+"/images/ddgoestotherescue.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

        #Make sure it's painted, which fixes the problem with the previous tempramental splash screen.
        wx.Yield()

    def OnExit(self, Event=None):
        """Close the splash screen and start MainWindow"""
        self.Hide()

        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True
            MainFrame = MainWindow()
            app.SetTopWindow(MainFrame)
            MainFrame.Show(True)

            #Skip handling the event so the main frame starts.
            Event.Skip()

#End splash screen
#Begin Main Window   
class MainWindow(wx.Frame):
    def __init__(self):
        """Initialize MainWindow"""
        wx.Frame.__init__(self, None, title="DDRescue-GUI", size=(700,360), style=wx.DEFAULT_FRAME_STYLE)
        self.MainPanel = wx.Panel(self)
        self.SetClientSize(wx.Size(700,360))

        print("DDRescue-GUI Version 1.4~rc1 Starting...")
        logger.info("DDRescue-GUI Version 1.4~rc1 Starting...")
        logger.info("Release date: "+ReleaseDate)
        logger.info("Running on wxPython version: "+wx.version()+"...")

        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it.
        logger.debug("MainWindow().__init__(): Creating temporary directory /tmp/ddrescue-gui...")

        if os.path.exists("/tmp/ddrescue-gui"):
            logger.warning("MainWindow().__init__(): Directory /tmp/ddrescue-gui already exists! Deleting and recreating it...")
            shutil.rmtree("/tmp/ddrescue-gui")
        os.mkdir("/tmp/ddrescue-gui")

        #Set the frame's icon.
        global AppIcon
        AppIcon = wx.Icon(RescourcePath+"/images/Logo.png", wx.BITMAP_TYPE_PNG)
        wx.Frame.SetIcon(self, AppIcon)

        #Set some variables
        logger.debug("MainWindow().__init__(): Setting some essential variables...")
        self.SetVars()

        #Create a Statusbar in the bottom of the window and set the text.
        logger.debug("MainWindow().__init__(): Creating Status Bar...")
        self.MakeStatusBar()

        #Add text
        logger.debug("MainWindow().__init__(): Creating text...")
        self.CreateText()

        #Create some buttons
        logger.debug("MainWindow().__init__(): Creating buttons...")
        self.CreateButtons()

        #Create the choiceboxes.
        logger.debug("MainWindow().__init__(): Creating choiceboxes...")
        self.CreateChoiceBoxes()

        #Create other widgets.
        logger.debug("MainWindow().__init__(): Creating all other widgets...")
        self.CreateOtherWidgets()

        #Update the device info.
        logger.debug("MainWindow().__init__(): Updating device info...")
        self.GetDeviceInfo()

        #Create the menus.
        logger.debug("MainWindow().__init__(): Creating menus...")
        self.CreateMenus()

        #Set up sizers.
        logger.debug("MainWindow().__init__(): Setting up sizers...")
        self.SetupSizers()

        #Bind all events.
        logger.debug("MainWindow().__init__(): Binding events...")
        self.BindEvents()

        #Make sure the window is displayed properly.
        self.OnDetailedInfo()
        self.OnTerminalOutput()

        #Call Layout() on self.MainPanel() to ensure it displays properly.
        self.MainPanel.Layout()

        logger.info("MainWindow().__init__(): Ready. Waiting for events...")

    #Create Functions
    def SetVars(self):
        """Set some essential variables""" #*** Try to get rid of this if possible ***
        global RecoveringData
        global InputFile
        global OutputFile
        global LogFile
        global CheckedSettings
        RecoveringData = False
        InputFile = None
        OutputFile = None
        LogFile = None
        CheckedSettings = False

    def MakeStatusBar(self):
        """Create and set up a statusbar"""
        self.StatusBar = self.CreateStatusBar()
        self.StatusBar.SetFieldsCount(2)
        self.StatusBar.SetStatusWidths([-3, -1])
        self.StatusBar.SetStatusText("Ready.", 0)
        self.StatusBar.SetStatusText("v"+Version+" ("+ReleaseDate+")", 1) 

    def CreateText(self):
        """Create all text for MainWindow"""
        self.TitleText = wx.StaticText(self.MainPanel, -1, "Welcome to DDRescue-GUI!")
        self.InputText = wx.StaticText(self.MainPanel, -1, "Image Source:")
        self.LogFileText = wx.StaticText(self.MainPanel, -1, "Log File:")
        self.OutputText = wx.StaticText(self.MainPanel, -1, "Image Destination:") 

        #Also create special text for showing and hiding recovery info and terminal output.
        self.DetailedInfoText = wx.lib.stattext.GenStaticText(self.MainPanel, -1, "Detailed Info")
        self.TerminalOutputText = wx.lib.stattext.GenStaticText(self.MainPanel, -1, "Terminal Output")

        #And some text for basic recovery information.
        self.TimeElapsedText = wx.StaticText(self.MainPanel, -1, "Time Elapsed:")
        self.TimeRemainingText = wx.StaticText(self.MainPanel, -1, "Estimated Time Remaining:")

    def CreateButtons(self):
        """Create all buttons for MainWindow"""
        self.SettingsButton = wx.Button(self.MainPanel, -1, "Settings")
        self.UpdateDeviceInfoButton = wx.Button(self.MainPanel, -1, "Update Device Info")          
        self.ShowDeviceInfoButton = wx.Button(self.MainPanel, -1, "Device Information")
        self.ControlButton = wx.Button(self.MainPanel, -1, "Start")

    def CreateChoiceBoxes(self):
        """Create all choiceboxes for MainWindow"""
        self.InputChoiceBox = wx.Choice(self.MainPanel, -1, choices=['-- Please Select --', 'Specify Path'])
        self.LogChoiceBox = wx.Choice(self.MainPanel, -1, choices=['-- Please Select --', 'None - not recommended', 'Specify'])
        self.OutputChoiceBox = wx.Choice(self.MainPanel, -1, choices=['-- Please Select --', 'Specify Path'])

        self.InputChoiceBox.SetStringSelection("-- Please Select --")
        self.LogChoiceBox.SetStringSelection("-- Please Select --")
        self.OutputChoiceBox.SetStringSelection("-- Please Select --")

    def CreateOtherWidgets(self):
        """Create all other widgets for MainWindow"""
        #Create the animation for the throbber.
        throb = wx.animate.Animation(RescourcePath+"/images/Throbber.gif")
        self.Throbber = wx.animate.AnimationCtrl(self.MainPanel, -1, throb)
        self.Throbber.SetUseWindowBackgroundColour(True)
        self.Throbber.SetInactiveBitmap(wx.Bitmap(RescourcePath+"/images/ThrobberRest.png", wx.BITMAP_TYPE_PNG))

        #Create the list control for the detailed info.
        self.ListCtrl = wx.ListCtrl(self.MainPanel, -1, style=wx.LC_REPORT|wx.BORDER_SUNKEN|wx.LC_VRULES)
        self.ListCtrl.InsertColumn(col=0, heading="Category", format=wx.LIST_FORMAT_CENTRE, width=150)
        self.ListCtrl.InsertColumn(col=1, heading="Value", format=wx.LIST_FORMAT_CENTRE, width=-1)

        #Create a text control for terminal output.
        self.OutputBox = wx.TextCtrl(self.MainPanel, -1, "", style=wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_WORDWRAP)
        self.OutputBox.SetBackgroundColour((0,0,0))
        self.OutputBox.SetDefaultStyle(wx.TextAttr(wx.WHITE))

        #Create the arrows.
        img1 = wx.Image(RescourcePath+"/images/ArrowDown.png", wx.BITMAP_TYPE_PNG)
        img2 = wx.Image(RescourcePath+"/images/ArrowRight.png", wx.BITMAP_TYPE_PNG)
        self.DownArrowImage = wx.BitmapFromImage(img1)
        self.RightArrowImage = wx.BitmapFromImage(img2)

        self.Arrow1 = wx.lib.statbmp.GenStaticBitmap(self.MainPanel, -1, self.DownArrowImage)
        self.Arrow2 = wx.lib.statbmp.GenStaticBitmap(self.MainPanel, -1, self.DownArrowImage)

        #Create the progress bar.
        self.ProgressBar = wx.Gauge(self.MainPanel, -1, 5000)
        self.ProgressBar.SetBezelFace(3)
        self.ProgressBar.SetShadowWidth(3)

    def SetupSizers(self):
        """Setup sizers for MainWindow"""
        #Make the main boxsizer.
        MainSizer = wx.BoxSizer(wx.VERTICAL)

        #Make the file choices sizer.
        FileChoicesSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Make the input sizer.
        InputSizer = wx.BoxSizer(wx.VERTICAL)

        #Add items to the input sizer.
        InputSizer.Add(self.InputText, 1, wx.TOP|wx.BOTTOM|wx.ALIGN_CENTER, 10)
        InputSizer.Add(self.InputChoiceBox, 1, wx.BOTTOM|wx.ALIGN_CENTER, 10)

        #Make the log sizer.
        LogSizer = wx.BoxSizer(wx.VERTICAL)

        #Add items to the log sizer.
        LogSizer.Add(self.LogFileText, 1, wx.TOP|wx.BOTTOM|wx.ALIGN_CENTER, 10)
        LogSizer.Add(self.LogChoiceBox, 1, wx.BOTTOM|wx.ALIGN_CENTER, 10)

        #Make the output sizer.
        OutputSizer = wx.BoxSizer(wx.VERTICAL)

        #Add items to the output sizer.
        OutputSizer.Add(self.OutputText, 1, wx.TOP|wx.BOTTOM|wx.ALIGN_CENTER, 10)
        OutputSizer.Add(self.OutputChoiceBox, 1, wx.BOTTOM|wx.ALIGN_CENTER, 10)

        #Add items to the file choices sizer.
        FileChoicesSizer.Add(InputSizer, 1, wx.ALIGN_CENTER)
        FileChoicesSizer.Add(LogSizer, 1, wx.ALIGN_CENTER)
        FileChoicesSizer.Add(OutputSizer, 1, wx.ALIGN_CENTER)

        #Make the button sizer.
        ButtonSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add items to the button sizer.
        ButtonSizer.Add(self.SettingsButton, 1, wx.RIGHT|wx.ALIGN_CENTER|wx.EXPAND, 10)
        ButtonSizer.Add(self.UpdateDeviceInfoButton, 1, wx.ALIGN_CENTER|wx.EXPAND, 10)
        ButtonSizer.Add(self.ShowDeviceInfoButton, 1, wx.LEFT|wx.ALIGN_CENTER|wx.EXPAND, 10)

        #Make the throbber sizer.
        ThrobberSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add items to the throbber sizer.
        ThrobberSizer.Add(self.Arrow1, 0, wx.LEFT|wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL, 10)
        ThrobberSizer.Add(self.DetailedInfoText, 1, wx.LEFT|wx.ALIGN_LEFT|wx.ALIGN_CENTER_VERTICAL, 10)
        ThrobberSizer.Add(self.Throbber, 0, wx.LEFT|wx.RIGHT|wx.ALIGN_CENTER|wx.ALIGN_CENTER_VERTICAL, 10)
        ThrobberSizer.Add(self.Arrow2, 0, wx.RIGHT|wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 10)
        ThrobberSizer.Add(self.TerminalOutputText, 1, wx.RIGHT|wx.ALIGN_RIGHT|wx.ALIGN_CENTER_VERTICAL, 10)

        #Make the info sizer.
        self.InfoSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add items to the info sizer.
        self.InfoSizer.Add(self.ListCtrl, 1, wx.RIGHT|wx.LEFT|wx.ALIGN_CENTER|wx.EXPAND, 22)
        self.InfoSizer.Add(self.OutputBox, 1, wx.RIGHT|wx.LEFT|wx.ALIGN_CENTER|wx.EXPAND, 22)

        #Make the info text sizer.
        InfoTextSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add items to the info text sizer.
        InfoTextSizer.Add(self.TimeElapsedText, 1, wx.RIGHT|wx.ALIGN_CENTER, 22)
        InfoTextSizer.Add(self.TimeRemainingText, 1, wx.LEFT|wx.ALIGN_CENTER, 22)

        #Arrow1 is horizontal when starting, so hide self.ListCtrl.
        self.InfoSizer.Detach(self.ListCtrl)
        self.ListCtrl.Hide()

        #Arrow2 is horizontal when starting, so hide self.OutputBox.
        self.InfoSizer.Detach(self.OutputBox)
        self.OutputBox.Hide()

        #Make the progress sizer.
        self.ProgressSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add items to the progress sizer.
        self.ProgressSizer.Add(self.ProgressBar, 1, wx.ALL|wx.ALIGN_CENTER, 10)
        self.ProgressSizer.Add(self.ControlButton, 0, wx.ALL|wx.ALIGN_RIGHT, 10)

        #Add items to the main sizer.
        MainSizer.Add(self.TitleText, 0, wx.TOP|wx.ALIGN_CENTER, 10)
        MainSizer.Add(wx.StaticLine(self.MainPanel), 0, wx.ALL|wx.EXPAND, 10)
        MainSizer.Add(FileChoicesSizer, 0, wx.ALL|wx.ALIGN_CENTER|wx.EXPAND, 10)
        MainSizer.Add(wx.StaticLine(self.MainPanel), 0, wx.ALL|wx.EXPAND, 10)
        MainSizer.Add(ButtonSizer, 0, wx.ALL|wx.ALIGN_CENTER|wx.EXPAND, 10)
        MainSizer.Add(wx.StaticLine(self.MainPanel), 0, wx.TOP|wx.EXPAND, 10)
        MainSizer.Add(ThrobberSizer, 0, wx.ALL|wx.ALIGN_CENTER|wx.EXPAND, 5)
        MainSizer.Add(self.InfoSizer, 1, wx.TOP|wx.BOTTOM|wx.ALIGN_CENTER|wx.EXPAND, 10)
        MainSizer.Add(InfoTextSizer, 0, wx.ALL|wx.ALIGN_CENTER|wx.EXPAND, 10)
        MainSizer.Add(self.ProgressSizer, 0, wx.TOP|wx.BOTTOM|wx.ALIGN_CENTER|wx.EXPAND, 10)

        #Get the sizer set up for the frame.
        self.MainPanel.SetSizer(MainSizer)
        MainSizer.SetMinSize(wx.Size(700,360))
        MainSizer.SetSizeHints(self)

    def CreateMenus(self):
        """Create the menus"""
        filemenu = wx.Menu()
        editmenu = wx.Menu()
        viewmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.MenuAbout = helpmenu.Append(wx.ID_ANY, "&About", "Information about this program")
        self.MenuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.MenuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.MenuSettings = editmenu.Append(wx.ID_ANY, "&Settings", "General settings")

        #Creating the menubar.
        self.MenuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        self.MenuBar.Append(filemenu,"&File")
        self.MenuBar.Append(editmenu,"&Edit")
        self.MenuBar.Append(viewmenu,"&View")
        self.MenuBar.Append(helpmenu,"&Help")

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(self.MenuBar)

    def BindEvents(self): 
        """Bind all events for MainWindow"""
        #Menus.
        self.Bind(wx.EVT_MENU, self.ShowSettings, self.MenuSettings)
        self.Bind(wx.EVT_MENU, self.OnAbout, self.MenuAbout)
        self.Bind(wx.EVT_MENU, self.ShowDevInfo, self.MenuDevInfo)

        #Choiceboxes.
        self.Bind(wx.EVT_CHOICE, self.SetInputFile, self.InputChoiceBox)
        self.Bind(wx.EVT_CHOICE, self.SetOutputFile, self.OutputChoiceBox)
        self.Bind(wx.EVT_CHOICE, self.SetLogFile, self.LogChoiceBox)

        #Buttons.
        self.Bind(wx.EVT_BUTTON, self.OnControlButton, self.ControlButton)
        self.Bind(wx.EVT_BUTTON, self.GetDeviceInfo, self.UpdateDeviceInfoButton)
        self.Bind(wx.EVT_BUTTON, self.ShowSettings, self.SettingsButton)
        self.Bind(wx.EVT_BUTTON, self.ShowDevInfo, self.ShowDeviceInfoButton)

        #Text.
        self.DetailedInfoText.Bind(wx.EVT_LEFT_DOWN, self.OnDetailedInfo)
        self.TerminalOutputText.Bind(wx.EVT_LEFT_DOWN, self.OnTerminalOutput)

        #Images.
        self.Arrow1.Bind(wx.EVT_LEFT_DOWN, self.OnDetailedInfo)
        self.Arrow2.Bind(wx.EVT_LEFT_DOWN, self.OnTerminalOutput)

        #Size events.
        self.Bind(wx.EVT_SIZE, self.OnSize)

        #OnExit events.        
        self.Bind(wx.EVT_MENU, self.OnExit, self.MenuExit)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

    def OnSize(self, Event=None):
        """Auto resize the ListCtrl columns"""
        #Force the width and height of the ListCtrl to be the right size, as the sizer won't shrink it on wxpython > 2.8.12.1
        #Get the width and height of the frame.
        Width, Height = self.GetClientSizeTuple()

        #Calculate the correct width for the ListCtrl
        if self.OutputBox.IsShown():
            ListCtrlWidth = (Width - 88)/2
        else:
            ListCtrlWidth = (Width - 44)

        #Set the size.
        self.ListCtrl.SetColumnWidth(0, 150)
        self.ListCtrl.SetColumnWidth(1, ListCtrlWidth - 150)
        self.ListCtrl.SetClientSize(wx.Size(ListCtrlWidth, 240))

        if Event != None:
            Event.Skip()

    def OnDetailedInfo(self, Event=None):
        """Show/Hide the detailed info, and rotate the arrow"""
        #Get the width and height of the frame.
        Width, Height = self.GetClientSizeTuple()

        if self.Arrow1.GetBitmap() == self.DownArrowImage:
            self.Arrow1.SetBitmap(self.RightArrowImage)

            #Arrow1 is now horizontal, so hide self.ListCtrl.
            self.InfoSizer.Detach(self.ListCtrl)
            self.ListCtrl.Hide()

            if self.OutputBox.IsShown() == False:
                self.SetClientSize(wx.Size(Width,360))

        else:
            self.Arrow1.SetBitmap(self.DownArrowImage)

            #Arrow1 is now vertical, so show self.ListCtrl2
            self.InfoSizer.Insert(0, self.ListCtrl, 1, wx.RIGHT|wx.LEFT|wx.ALIGN_CENTER|wx.EXPAND, 22)
            self.ListCtrl.Show()

            self.SetClientSize(wx.Size(Width,600))

        #Call Layout() on self.MainPanel() and self.OnSize() to ensure it displays properly.
        self.OnSize()
        self.MainPanel.Layout()

    def OnTerminalOutput(self, Event=None):
        """Show/Hide the terminal output, and rotate the arrow"""
        #Get the width and height of the frame.
        Width, Height = self.GetClientSizeTuple()

        if self.Arrow2.GetBitmap() == self.DownArrowImage:
            self.Arrow2.SetBitmap(self.RightArrowImage)

            #Arrow2 is now horizontal, so hide self.OutputBox.
            self.InfoSizer.Detach(self.OutputBox)
            self.OutputBox.Hide()

            if self.ListCtrl.IsShown() == False:
                self.SetClientSize(wx.Size(Width,360))

        else:
            self.Arrow2.SetBitmap(self.DownArrowImage)

            #Arrow2 is now vertical, so show self.OutputBox.
            if self.ListCtrl.IsShown():
                self.InfoSizer.Insert(1, self.OutputBox, 1, wx.RIGHT|wx.LEFT|wx.ALIGN_CENTER|wx.EXPAND, 22)
            else:
                self.InfoSizer.Insert(0, self.OutputBox, 1, wx.RIGHT|wx.LEFT|wx.ALIGN_CENTER|wx.EXPAND, 22)

            self.OutputBox.Show()

            self.SetClientSize(wx.Size(Width,600))

        #Call Layout() on self.MainPanel() and self.OnSize to ensure it displays properly.
        self.OnSize()
        self.MainPanel.Layout()

    def GetDeviceInfo(self, Event=None):
        """Call the thread to get device info, disable the update button, and start the throbber"""
        logger.info("MainWindow().GetDeviceInfo(): Getting new device information...")
        self.UpdateStatusBar("Getting new device information... Please wait...")

        #Disable stuff to prevent problems.
        self.UpdateDeviceInfoButton.Disable()
        self.ShowDeviceInfoButton.Disable()
        self.InputChoiceBox.Disable()
        self.OutputChoiceBox.Disable()

        #Call the thread and get the throbber going.
        GetDeviceInformation(self)
        self.Throbber.Play()

    def ReceiveDeviceInfo(self, Info):
        """Get new device info and to call the function that updates the choiceboxes"""
        logger.info("MainWindow().ReceiveDeviceInfo(): Getting new device information...")
        global DeviceInfo
        DeviceInfo = Info

        #Update the file choices.
        self.UpdateFileChoices()

        #Stop the throbber and enable stuff again.
        self.Throbber.Stop()

        self.UpdateDeviceInfoButton.Enable()
        self.ShowDeviceInfoButton.Enable()
        self.InputChoiceBox.Enable()
        self.OutputChoiceBox.Enable()

    def UpdateFileChoices(self):
        """Update the device entries in the choiceboxes"""
        logger.info("MainWindow().UpdateFileChoices(): Updating the GUI with the new device information...")

        #Grab the device list from the other device info.
        DeviceList = DeviceInfo[0]

        try:
            self.CustomInputPathsList.sort()
            self.CustomOutputPathsList.sort()

        except AttributeError:
            #We are starting up, so do some extra stuff.
            #Prepare some choiceboxes using the newly created device list.
            logger.info("MainWindow().UpdateFileChoices(): Preparing choiceboxes...")

            #Make note that there are no custom selections yet, because we haven't even finished the startup routine yet!
            self.CustomInputPathsList = []
            self.CustomOutputPathsList = []

        finally:
            #Keep the user's current selections and any custom paths added to the choiceboxes while we update them.
            logger.info("MainWindow().UpdateFileChoices(): Updating choiceboxes...")

            #Grab Current selection.
            CurrentInputStringSelection = self.InputChoiceBox.GetStringSelection()
            CurrentOutputStringSelection = self.OutputChoiceBox.GetStringSelection()

            #Clear the choiceboxes.
            self.InputChoiceBox.Clear()
            self.OutputChoiceBox.Clear()

            #Add everything back again.
            for Element in ['-- Please Select --', 'Specify Path'] + DeviceList + self.CustomInputPathsList:
                self.InputChoiceBox.Append(Element)

            for Element in ['-- Please Select --', 'Specify Path'] + DeviceList + self.CustomOutputPathsList:
                self.OutputChoiceBox.Append(Element)

            #Set the current selections again, if we can (if the selection is a device, it may have been removed).
            if self.InputChoiceBox.FindString(CurrentInputStringSelection) != -1:
                self.InputChoiceBox.SetStringSelection(CurrentInputStringSelection)

            if self.OutputChoiceBox.FindString(CurrentOutputStringSelection) != -1:
                self.OutputChoiceBox.SetStringSelection(CurrentOutputStringSelection)

        #Notify the user with the statusbar.
        self.UpdateStatusBar("Ready.")

    def SetInputFile(self, Event=None):
        """Get the input file/device and set a variable to the selected value"""
        logger.debug("MainWindow().SelectInputFile(): Getting user selection...")

        global InputFile
        InputFile = self.InputChoiceBox.GetStringSelection()

        if InputFile == "Specify Path":
            InputFileDlg = wx.FileDialog(self.MainPanel, "Select Input File/Device...", defaultDir="/dev", wildcard="SATA HDDs/USB Drives|sd*|IDE/ATA HDDs|hd*|Optical Drives|sr*|Floppy Drives|fd*|ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*" , style=wx.OPEN)
            if InputFileDlg.ShowModal() == wx.ID_OK:
                InputFile = InputFileDlg.GetPath()
                logger.info("MainWindow().SelectInputFile(): User selected custom file: "+InputFile+"...")
                self.CustomInputPathsList.append(InputFile)
                self.InputChoiceBox.Append(InputFile)
                self.InputChoiceBox.SetStringSelection(InputFile)
            else:
                logger.info("MainWindow().SelectInputFile(): User declined custom file selection. Resetting InputFile...")
                InputFile = None
                self.InputChoiceBox.SetStringSelection("-- Please Select --")

        elif InputFile not in [None, "-- Please Select --"] and InputFile == OutputFile:
            logger.warning("MainWindow().SelectInputFile(): InputFile equals OutputFile!, resetting to None and warning user...")
            wx.MessageDialog(self.MainPanel, "You can't use the same file as both the source and the destination!", 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()
            InputFile = None
            self.InputChoiceBox.SetStringSelection("-- Please Select --")

        elif InputFile == "-- Please Select --":
            logger.info("MainWindow().SelectInputFile(): Input file reset..")
            InputFile = None

        if InputFile != None:
            if InputFile[0:5] != "/dev/":
                wx.MessageDialog(self.MainPanel, "DDRescue-GUI has detected that you're recovering from a file rather than a device. Please check that this is correct.", "DDRescue-GUI - Warning!", style=wx.OK | wx.ICON_EXCLAMATION, pos=wx.DefaultPosition).ShowModal()

    def SetOutputFile(self, Event=None):
        """Get the output file/device and set a variable to the selected value"""
        logger.debug("MainWindow().SelectOutputFile(): Getting user selection...")
        global OutputFile
        OutputFile = self.OutputChoiceBox.GetStringSelection()

        if OutputFile == "Specify Path":
            OutputFileDlg = wx.FileDialog(self.MainPanel, "Select Output File/Device...", defaultDir=os.environ["HOME"], wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*" , style=wx.SAVE)
            if OutputFileDlg.ShowModal() == wx.ID_OK:
                OutputFile = OutputFileDlg.GetPath()
                logger.info("MainWindow().SelectOutputFile(): User selected custom file: "+OutputFile+"...")
                self.CustomOutputPathsList.append(OutputFile)
                self.OutputChoiceBox.Append(OutputFile)
                self.OutputChoiceBox.SetStringSelection(OutputFile)
            else:
                logger.info("MainWindow().SelectOutputFile(): User declined custom file selection. Resetting OutputFile...")
                OutputFile = None
                self.OutputChoiceBox.SetStringSelection("-- Please Select --")

        elif OutputFile not in [None, "-- Please Select --"] and OutputFile == InputFile:
            logger.warning("MainWindow().SelectOutputFile(): OutputFile equals InputFile!, resetting to None and warning user...")
            wx.MessageDialog(self.MainPanel, "You can't use the same file as both the source and the destination!", 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()
            OutputFile = None
            self.OutputChoiceBox.SetStringSelection("-- Please Select --")

        elif OutputFile == "-- Please Select --":
            logger.debug("MainWindow().SelectInputFile(): Output file reset...")
            OutputFile = None

        #If the file selected is a device, double check with the user.
        if OutputFile != None:
            if OutputFile[0:5] == "/dev/":
                 Dlg = wx.MessageDialog(self.MainPanel, "You have selected a device to recover to rather than an image! Please be doubly sure that you have selected the right device, or else you may lose data! Click yes to accept the device, click no to cancel the selection.\n\nNote: If you decide to recover to a device, please enable the option labeled 'Overwrite output device or partition' in the settings window.", 'DDRescue-GUI -- Warning!', wx.YES_NO | wx.ICON_EXCLAMATION).ShowModal()
                 if Dlg == wx.ID_YES:
                     logger.warning("MainWindow().SelectOutputFile(): Accepted device as output file!")
                 else:
                     logger.info("MainWindow().SelectOutputFile(): User declined selecting a device as the output file. Resetting OutputFile...")
                     OutputFile = None
                     self.OutputChoiceBox.SetStringSelection("-- Please Select --")

    def SetLogFile(self, Event=None):
        """Get the log file position/name and set a variable to the selected value"""
        logger.debug("MainWindow().SelectLogFile(): Getting user selection...")
        global LogFile
        LogFile = self.LogChoiceBox.GetStringSelection()

        if LogFile == "None - not recommended":
            Dlg = wx.MessageDialog(self.MainPanel, 'You have not chosen to use a log file. If you do not use one, you will have to start from scratch in the event of a power outage, or if the program is interrupted. Are you sure you do not want to use a logfile?', 'DDRescue-GUI - Warning', wx.YES_NO | wx.ICON_EXCLAMATION).ShowModal()
            if Dlg == wx.ID_YES:
                logger.warning("MainWindow().SelectLogFile(): User isn't using a log file, despite our warning!")
                LogFile = ""
            else:
                logger.info("MainWindow().SelectLogFile(): User decided against not using a log file. Good!")
                LogFile = None
                self.LogChoiceBox.SetStringSelection("-- Please Select --")

        elif LogFile == "Specify":
            LogFileDlg = wx.FileDialog(self.MainPanel, "Select Log File Position & Name...", defaultDir=os.environ["HOME"], wildcard="Log Files|*.log", style=wx.SAVE)
            if LogFileDlg.ShowModal() == wx.ID_OK:
                LogFile = LogFileDlg.GetPath()
                logger.debug("MainWindow().SelectLogFile(): User selected custom file: "+LogFile+"...")
                self.LogChoiceBox.Append(LogFile)
                self.LogChoiceBox.SetStringSelection(LogFile)
            else:
                logger.debug("MainWindow().SelectLogFile(): User declined custom file selection. Resetting LogFile...")
                LogFile = None
                self.LogChoiceBox.SetStringSelection("-- Please Select --")

        elif LogFile == "-- Please Select --":
            logger.debug("MainWindow().SelectLogFile(): LogFile reset.")
            LogFile = None

    def OnAbout(self, Event=None):
        """Show the about box"""
        logger.debug("MainWindow().OnAbout(): Showing about box...")
        aboutbox = wx.AboutDialogInfo()
        aboutbox.SetIcon(AppIcon)
        aboutbox.Name = "DDRescue-GUI"
        aboutbox.Version = Version
        aboutbox.Copyright = "(C) 2013-2015 Hamish McIntyre-Bhatty"
        aboutbox.Description = "GUI frontend for GNU ddrescue"
        aboutbox.WebSite = ("https://launchpad.net/ddrescue-gui", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty", "Minnie McIntyre-Bhatty (GUI Design)"]
        aboutbox.Artists = ["Holly McIntyre-Bhatty"]
        aboutbox.License = "DDRescue-GUI is free software: you can redistribute it and/or modify it\nunder the terms of the GNU General Public License version 3 or,\nat your option, any later version.\n\nDDRescue-GUI is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\nGNU General Public License for more details.\n\nYou should have received a copy of the GNU General Public License\nalong with DDRescue-GUI.  If not, see <http://www.gnu.org/licenses/>.\n\nGNU ddrescue is also released under the GPLv3, and bundled with\nthe Mac OS X version of this program, but I am NOT the author of \nGNU ddrescue. For more information on GNU ddrescue, visit\nhttps://www.gnu.org/software/ddrescue/ddrescue.html"

        #Show the about box
        wx.AboutBox(aboutbox)

    def ShowSettings(self, Event=None):
        """Show the Settings Window"""
        #If input and output files are set (do not equal None) then continue.
        if None not in [InputFile, OutputFile]:
            SettingsWindow(self).Show()
        else:
            wx.MessageDialog(self.MainPanel, 'Please select input and output files first!', 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()

    def ShowDevInfo(self, Event=None):
        """Show the Device Information Window"""
        DevInfoWindow(self).Show()

    def OnControlButton(self, Event=None):
        """Handle events from the control button, as its purpose changes during and after recovery. Call self.OnAbort() or self.OnStart() as required."""
        if RecoveringData:
            self.OnAbort()
        else:
            self.OnStart()

    def OnStart(self):
        """Check the settings, and start the backend thread"""
        logger.info("MainWindow().OnStart(): Checking settings...")
        self.UpdateStatusBar("Checking Settings...")

        if CheckedSettings == False:
            logger.error("MainWindow().OnStart(): The settings haven't been checked properly! Aborting recovery...")
            wx.MessageDialog(self.MainPanel, 'Sorry, it is important that you check the settings before you start the recovery! The recovery will now be aborted.', 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()
            self.UpdateStatusBar("Ready.")

        elif None not in [InputFile, LogFile, OutputFile]:
            #Create the items for self.ListCtrl.
            Width, Height = self.ListCtrl.GetClientSizeTuple()

            #First column.
            self.ListCtrl.InsertStringItem(index=0, label="Recovered Data")
            self.ListCtrl.InsertStringItem(index=1, label="Unreadable Data")
            self.ListCtrl.InsertStringItem(index=2, label="Current Read Rate")
            self.ListCtrl.InsertStringItem(index=3, label="Average Read Rate")
            self.ListCtrl.InsertStringItem(index=4, label="Bad Sectors")
            self.ListCtrl.InsertStringItem(index=5, label="Input Position")
            self.ListCtrl.InsertStringItem(index=6, label="Output Position")
            self.ListCtrl.InsertStringItem(index=7, label="Time Since Last Read")
            self.ListCtrl.SetColumnWidth(0, 150)

            #Second column.
            self.ListCtrl.SetStringItem(index=0, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=1, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=2, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=3, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=4, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=5, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=6, col=1, label="Unknown")
            self.ListCtrl.SetStringItem(index=7, col=1, label="Unknown")
            self.ListCtrl.SetColumnWidth(1, Width - 150)

            logger.info("MainWindow().OnStart(): Settings check complete. Starting BackendThread()...")
            self.UpdateStatusBar("Starting DDRescue...")
            wx.MessageDialog(self.MainPanel, "DDRescue is now about to be started. Please close all other programs now to prevent problems. Please wait for up to 10 seconds for DDRescue-GUI to start updating.", 'DDRescue-GUI - Information', wx.OK | wx.ICON_INFORMATION).ShowModal() 

            #Notify the user (Linux only).
            if Linux:
                subprocess.call(["notify-send", "DDRescue-GUI", "The recovery is about to start...", "-i", "/usr/share/pixmaps/ddrescue-gui.png"])

            #Disable and enable all necessary items.
            self.UpdateDeviceInfoButton.Disable()
            self.InputChoiceBox.Disable()
            self.OutputChoiceBox.Disable()
            self.LogChoiceBox.Disable()
            self.MenuAbout.Enable(False)
            self.MenuExit.Enable(False) 
            self.MenuDevInfo.Enable(False)
            self.MenuSettings.Enable(False)
            self.ControlButton.SetLabel("Abort")

            #Start the backend thread.
            BackendThread(self)

        else:
            logger.error("MainWindow().OnStart(): One or more of InputFIle, OutputFile or LogFile hasn't been set! Aborting Recovery...")
            wx.MessageDialog(self.MainPanel, 'Please set the Input file, Log file and Output file correctly before starting!', 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()
            self.UpdateStatusBar("Ready.")  

    #The next functions are to update the display with info from the backend.
    def UpdateRecoveredInfo(self,msg):
        """Update the item that displays info on the current amount of recovered data"""
        logger.debug("MainWindow().UpdateRecoveredInfo(): Recovered data: "+msg)
        self.ListCtrl.SetStringItem(index=0, col=1, label=msg)

    def UpdateErrsizeInfo(self,msg):
        """Update the item that displays info on the current amount of unreadable data"""
        logger.debug("MainWindow().UpdateErrsizeInfo(): Unreadable data: "+msg)
        self.ListCtrl.SetStringItem(index=1, col=1, label=msg)

    def UpdateReadRateInfo(self,msg):
        """Update the item that displays info on the current read rate"""
        logger.debug("MainWindow().UpdateReadRateInfo(): Current read rate: "+msg)
        self.ListCtrl.SetStringItem(index=2, col=1, label=msg)

    def UpdateavgReadRateInfo(self,msg):
        """Update the item that displays info on the average read rate"""
        logger.debug("MainWindow().UpdateavgReadRateInfo(): Average read rate: "+msg)
        self.ListCtrl.SetStringItem(index=3, col=1, label=msg)

    def UpdatenumerrorsInfo(self,msg):
        """Update the item that displays info on the current number of errors"""
        logger.debug("MainWindow().UpdatenumerrorsInfo(): Number of bad areas: "+msg)
        self.ListCtrl.SetStringItem(index=4, col=1, label=msg)

    def UpdateTimeSinceLastReadInfo(self,msg):
        """Update the item that displays info on the time since the last successful read"""
        logger.debug("MainWindow().UpdateTimeSinceLastReadInfo(): Time since last successful read: "+msg)
        self.ListCtrl.SetStringItem(index=7, col=1, label=msg)

    def UpdateTimeLeft(self,msg):
        """Update the text that displays info on the estimated time remaining"""
        logger.debug("MainWindow().UpdateTimeLeft(): Remaining time: "+msg)
        self.TimeRemainingText.SetLabel("Time Remaining: "+msg)

    def UpdateStatusBar(self,msg):
        """Update the satusbar with a new message"""
        logger.debug("MainWindow().UpdateStatusBar(): New status bar message: "+msg)
        self.StatusBar.SetStatusText(msg.replace('\n', ''), 0)

    def SetProgressBarRange(self,msg):
        """Set the progressbar's range""" 
        logger.debug("MainWindow().SetProgressBarRange(): Setting range "+unicode(msg)+" for self.ProgressBar...")
        self.ProgressBar.SetRange(msg)

    def UpdateProgressBar(self,msg):
        """Update the progressbar"""
        logger.debug("MainWindow().UpdateProgressBar(): Setting value "+unicode(msg)+" for self.ProgressBar...")
        self.ProgressBar.SetValue(msg)

    def OnAbort(self):
        """Abort the recovery"""
        #Ask ddrescue to exit.
        logger.info("MainWindow().OnAbort(): Attempting to kill ddrescue...")
        termddrescue = subprocess.Popen(["killall", "ddrescue"])

        #Disable control button.
        self.ControlButton.Disable()

        #Notify user with throbber.
        self.Throbber.Play()

    def RecoveryFailed(self):
        """Called to log and display errors when the recovery fails""" #*** I may remove this and put the code somewhere else ***
        logger.error("MainWindow().RecoveryFailed(): DDRescue didn't start within 10 seconds! Aborting attempt at recovery and resetting GUI. Maybe settings are incorrect?")
        wx.MessageDialog(None, 'DDRescue did not start within 10 seconds! The GUI will now be reset. Please check all of your settings, and try again. NB: Overwriting the output device is required when recovering to a device.', 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()

    def RecoveryEnded(self):
        """Called to show FinishedWindow when a recovery is completed or aborted by the user""" #*** Use a variable so we can tell and log if the user has aborted the recovery ***
        logger.info("MainWindow().RecoveryEnded(): Recovery finished (or aborted by user)! Sorting out MainWindow and showing FinishedWindow...")

        #If abortingtext exists, remove it.
        try:
            self.AbortingText.Destroy()
        except: pass

        #Disable control button and stop the throbber, if it's playing.
        self.ControlButton.Disable()
        self.Throbber.Stop()

    	#Notify user (Linux only).
        if Linux:
            subprocess.call(["notify-send",  "DDRescue-GUI", "Recovery Finished!", "-i", "/usr/share/pixmaps/ddrescue-gui.png"])

        FinishedWindow(self).Show()

    def Reload(self):
        """Reload and reset MainWindow, so MainWindow is as it was when the program was started""" 
        logger.info("MainWindow().Reload(): Reloading and resetting MainWindow...")
        self.UpdateStatusBar("Restarting, please wait...")

        #Set everything back the way it was before
        self.UpdateDeviceInfoButton.Enable()
        self.ControlButton.Enable()
        self.InputChoiceBox.Enable()
        self.OutputChoiceBox.Enable()
        self.LogChoiceBox.Enable()
        self.MenuAbout.Enable(True)
        self.MenuExit.Enable(True) 
        self.MenuDevInfo.Enable(True)
        self.MenuSettings.Enable(True)

        #Reset text
        self.ListCtrl.ClearAll()
        self.ListCtrl.InsertColumn(col=0, heading="Category", format=wx.LIST_FORMAT_CENTRE, width=-1)
        self.ListCtrl.InsertColumn(col=1, heading="Value", format=wx.LIST_FORMAT_CENTRE, width=-1)
        self.ControlButton.SetLabel("Start")

        #Reset the ProgressBar
        self.ProgressBar.SetValue(0)

        #Set checkedsettings to false and input, output and log file selection to None
        global InputFile
        InputFile = None
        global OutputFile
        OutputFile = None
        global LogFile
        LogFile = None
        global CheckedSettings
        CheckedSettings = False

        #Update choice dialogs and reset checked settings to False
        self.UpdateFileChoices()

        #Reset the choice dialogs.
        self.InputChoiceBox.SetStringSelection("-- Please Select --")
        self.OutputChoiceBox.SetStringSelection("-- Please Select --")
        self.LogChoiceBox.SetStringSelection("-- Please Select --")

        #Sleep
        time.sleep(1)

        logger.info("MainWindow().Reload(): Done. Waiting for events...")
        self.UpdateStatusBar("Ready.")

    def OnExit(self, Event=None, JustFinishedRec=False):
        """Exit the program, if certain conditions are met"""
        #Check if DDRescue-GUI is recovering data.
        logger.info("MainWindow().OnExit(): Preparing to exit...")

        if RecoveringData:
            logger.error("MainWindow().OnExit(): Can't exit while recovering data! Aborting exit attempt...")
            wx.MessageDialog(self.MainPanel, 'You are not allowed to exit the program while recovering data!', 'DDRescue-GUI - Error!', wx.OK | wx.ICON_ERROR).ShowModal()
        else:
            logger.info("MainWindow().OnExit(): Double-checking the exit attempt with the user...")
            dlg = wx.MessageDialog(self.MainPanel, 'Are you sure you want to exit?', 'DDRescue-GUI - Question!', wx.YES_NO | wx.ICON_QUESTION).ShowModal()

            if dlg == wx.ID_YES:
                #Run the exit sequence
                logger.info("MainWindow().OnExit(): Exiting...")

                #Clear the temporary directory if it exists (it should do).
                if os.path.exists("/tmp/ddrescue-gui"):
                    shutil.rmtree('/tmp/ddrescue-gui')

                #Peacefully handle errors before exiting.
                try:
                    if self.ShowOutput:
                        self.ShowOutput.kill()
                except: pass
                finally:
                    logging.shutdown()

                    #Prompt user to save the log file.
                    dlg = wx.MessageDialog(self.MainPanel, "Do you want to keep DDRescue-GUI's log file? For privacy reasons, DDRescue-GUI will delete its log file when closing. If you want to save it, which is helpful for debugging if something went wrong, click yes, and otherwise click no.", "DDRescue-GUI - Question", style=wx.YES_NO | wx.ICON_QUESTION, pos=wx.DefaultPosition)

                    if dlg.ShowModal() == wx.ID_YES:
                        #Ask the user where to save it.
                        Dlg = wx.FileDialog(self.MainPanel, "Save log file to...", defaultDir=os.environ["HOME"], wildcard="Log Files (*.log)|*.log|All Files/Devices (*)|*" , style=wx.SAVE)

                        if Dlg.ShowModal() == wx.ID_OK:
                            #Get the path.
                            File = Dlg.GetPath()

                            #Copy it to the specified path, using a one-liner, and don't bother handling any errors, because this is run as root.
                            subprocess.Popen(['cp', '/var/log/ddrescue-gui.log', File]).wait()

                            wx.MessageDialog(self.MainPanel, 'Done! DDRescue-GUI will now exit.', 'DDRescue-GUI - Information', wx.OK | wx.ICON_INFORMATION).ShowModal()

                        else:
                            wx.MessageDialog(self.MainPanel, 'Okay, DDRescue-GUI will now exit without saving the log file.', 'DDRescue-GUI - Information', wx.OK | wx.ICON_INFORMATION).ShowModal()

                    else:
                        wx.MessageDialog(self.MainPanel, 'Okay, DDRescue-GUI will now exit without saving the log file.', 'DDRescue-GUI - Information', wx.OK | wx.ICON_INFORMATION).ShowModal()

                    #Delete the log file, and don't bother handling any errors, because this is run as root.
                    os.remove('/var/log/ddrescue-gui.log')

                    self.Destroy()

            else:
                #Check if exit was initated by finisheddlg.
                logger.warning("MainWindow().OnExit(): User cancelled exit attempt! Aborting exit attempt...")
                if JustFinishedRec:
                    #If so return to finisheddlg.
                    logger.info("MainWindow().OnExit(): Showing FinishedWindow() again...")
                    FinishedWindow(self).Show()

#End Main Window
#Begin Device Info Window
class DevInfoWindow(wx.Frame):
    def __init__(self,ParentWindow):
        """Initialize DevInfoWindow"""
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="DDRescue-GUI - Device Information", size=(780,310), style=wx.DEFAULT_FRAME_STYLE)
        self.DevInfoPanel=wx.Panel(self)
        self.SetClientSize(wx.Size(780,310))
        self.ParentWindow = ParentWindow
        wx.Frame.SetIcon(self, AppIcon)

        logger.debug("DevInfoWindow().__init__(): Creating widgets...")
        self.CreateWidgets()

        logger.debug("DevInfoWindow().__init__(): Setting up sizers...")
        self.SetupSizers()

        logger.debug("DevInfoWindow().__init__(): Binding events...")
        self.BindEvents()

        #Use already-present info for the list ctrl if possible.
        if 'DeviceInfo' in globals():
            logger.debug("DevInfoWindow().__init__(): Updating list ctrl with device info already present...")
            self.UpdateListCtrl()

        #Call Layout() on self.DevInfoPanel() to ensure it displays properly.
        self.DevInfoPanel.Layout()

        logger.info("DevInfoWindow().__init__(): Ready. Waiting for events...")

    def CreateWidgets(self):
        """Create all widgets for DevInfoWindow"""
        self.TitleText = wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer")
        self.ListCtrl = wx.ListCtrl(self.DevInfoPanel, -1, style=wx.LC_REPORT|wx.LC_VRULES)
        self.OkayButton = wx.Button(self.DevInfoPanel, -1, "Okay")
        self.RefreshButton = wx.Button(self.DevInfoPanel, -1, "Refresh")

        #Create the animation for the throbber.
        throb = wx.animate.Animation(RescourcePath+"/images/Throbber.gif")
        self.Throbber = wx.animate.AnimationCtrl(self.DevInfoPanel, -1, throb)
        self.Throbber.SetUseWindowBackgroundColour(True)
        self.Throbber.SetInactiveBitmap(wx.Bitmap(RescourcePath+"/images/ThrobberRest.png", wx.BITMAP_TYPE_PNG))

    def SetupSizers(self):
        """Set up the sizers for DevInfoWindow"""
        #Make a button boxsizer.
        BottomSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add each object to the button sizer.
        BottomSizer.Add(self.RefreshButton, 0, wx.LEFT|wx.RIGHT|wx.ALIGN_LEFT, 10)
        BottomSizer.Add((20,20), 1)
        BottomSizer.Add(self.Throbber, 0, wx.ALIGN_CENTER)
        BottomSizer.Add((20,20), 1)
        BottomSizer.Add(self.OkayButton, 0, wx.LEFT|wx.RIGHT|wx.ALIGN_RIGHT, 10)

        #Make a boxsizer.
        MainSizer = wx.BoxSizer(wx.VERTICAL)

        #Add each object to the main sizer.
        MainSizer.Add(self.TitleText, 0, wx.ALL|wx.CENTER, 10)
        MainSizer.Add(self.ListCtrl, 1, wx.EXPAND|wx.ALL, 10)
        MainSizer.Add(BottomSizer, 0, wx.EXPAND|wx.ALL ^ wx.TOP, 10)

        #Get the sizer set up for the frame.
        self.DevInfoPanel.SetSizer(MainSizer)
        MainSizer.SetMinSize(wx.Size(780,310))
        MainSizer.SetSizeHints(self)

    def BindEvents(self):
        """Bind all events for DevInfoWindow"""
        self.Bind(wx.EVT_BUTTON, self.GetDeviceInfo, self.RefreshButton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.OkayButton)
        self.Bind(wx.EVT_SIZE, self.OnSize)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

    def OnSize(self, Event=None):
        """Auto resize the ListCtrl columns"""
        Width, Height = self.ListCtrl.GetClientSizeTuple()

        self.ListCtrl.SetColumnWidth(0, int(Width * 0.15))
        self.ListCtrl.SetColumnWidth(1, int(Width * 0.1))
        self.ListCtrl.SetColumnWidth(2, int(Width * 0.1))
        self.ListCtrl.SetColumnWidth(3, int(Width * 0.3))
        self.ListCtrl.SetColumnWidth(4, int(Width * 0.15))
        self.ListCtrl.SetColumnWidth(5, int(Width * 0.2))

        if Event != None:
            Event.Skip()

    def GetDeviceInfo(self, Event=None):
        """Call the thread to get device info, disable the refresh button, and start the throbber"""
        logger.info("DevInfoWindow().UpdateDevInfo(): Generating new device info...")
        self.RefreshButton.Disable()
        self.Throbber.Play()
        GetDeviceInformation(self)

    def ReceiveDeviceInfo(self, Info):
        """Get device data, call self.UpdateListCtrl(), and then call MainWindow().UpdateFileChoices() to refresh the file choices with the new info"""
        global DeviceInfo
        DeviceInfo = Info

        #Update the list control.
        logger.debug("DevInfoWindow().UpdateDevInfo(): Calling self.UpdateListCtrl()...")
        self.UpdateListCtrl()

        #Send update signal to mainwindow.
        logger.debug("DevInfoWindow().UpdateDevInfo(): Calling self.ParentWindow.UpdateFileChoices()...")
        wx.CallAfter(self.ParentWindow.UpdateFileChoices)

        #Stop the throbber and enable the refresh button.
        self.Throbber.Stop()
        self.RefreshButton.Enable()

    def UpdateListCtrl(self, Event=None):
        """Update the list control"""
        logger.debug("DevInfoWindow().UpdateListCtrl(): Clearing all objects in list ctrl...")
        self.ListCtrl.ClearAll()

        #Create the columns.
        logger.debug("DevInfoWindow().UpdateListCtrl(): Inserting columns into list ctrl...")
        self.ListCtrl.InsertColumn(col=0, heading="Name", format=wx.LIST_FORMAT_CENTRE, width=100)
        self.ListCtrl.InsertColumn(col=1, heading="Type", format=wx.LIST_FORMAT_CENTRE, width=80)
        self.ListCtrl.InsertColumn(col=2, heading="Vendor", format=wx.LIST_FORMAT_CENTRE, width=90)
        self.ListCtrl.InsertColumn(col=3, heading="Product", format=wx.LIST_FORMAT_CENTRE, width=160)
        self.ListCtrl.InsertColumn(col=4, heading="Size", format=wx.LIST_FORMAT_CENTRE, width=130)
        self.ListCtrl.InsertColumn(col=5, heading="Description", format=wx.LIST_FORMAT_CENTRE, width=200) 

        #Add info from the custom module.
        logger.debug("DevInfoWindow().UpdateListCtrl(): Adding device info to list ctrl...")

        DeviceList = DeviceInfo[0]
        DeviceTypeInfoList = DeviceInfo[1]
        VendorInfoList = DeviceInfo[2]
        ProductInfoList = DeviceInfo[3]
        SizeInfoList = DeviceInfo[4]
        DescriptionInfoList = DeviceInfo[5]

        #Do all of the data at the same time.
        for DeviceName in DeviceList:
            Number = DeviceList.index(DeviceName)
            self.ListCtrl.InsertStringItem(index=Number, label=DeviceName)
            self.ListCtrl.SetStringItem(index=Number, col=1, label=DeviceTypeInfoList[Number])
            self.ListCtrl.SetStringItem(index=Number, col=2, label=VendorInfoList[Number])
            self.ListCtrl.SetStringItem(index=Number, col=3, label=ProductInfoList[Number])
            self.ListCtrl.SetStringItem(index=Number, col=4, label=SizeInfoList[Number])
            self.ListCtrl.SetStringItem(index=Number, col=5, label=DescriptionInfoList[Number])

        #Auto Resize the columns.
        self.OnSize()

    def OnExit(self, Event=None):
        """Exit DevInfoWindow"""
        logger.info("DevInfoWindow().OnExit(): Closing DevInfoWindow...")
        self.Destroy()

#End Device Info Window
#Begin Settings Window
class SettingsWindow(wx.Frame):
    def __init__(self,ParentWindow):
        """Initialize SettingsWindow"""
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="DDRescue-GUI - Settings", size=(569,479), style=wx.DEFAULT_FRAME_STYLE)
        self.SettingsPanel=wx.Panel(self)
        self.SetClientSize(wx.Size(569,479))
        self.ParentWindow = ParentWindow
        wx.Frame.SetIcon(self, AppIcon)

        #Notify MainWindow that this has been run.
        logger.debug("SettingsWindow().__init__(): Setting CheckedSettings to True...")
        global CheckedSettings
        CheckedSettings = True

        #Create all of the widgets first.
        logger.debug("SettingsWindow().__init__(): Creating buttons...")
        self.CreateButtons()

        logger.debug("SettingsWindow().__init__(): Creating text...")
        self.CreateText()

        logger.debug("SettingsWindow().__init__(): Creating Checkboxes...")
        self.CreateCheckBoxes()

        logger.debug("SettingsWindow().__init__(): Creating Choiceboxes...")
        self.CreateChoiceBoxes()

        #Then setup the sizers and bind events.
        logger.debug("SettingsWindow().__init__(): Setting up sizers...")
        self.SetupSizers()

        logger.debug("SettingsWindow().__init__(): Binding events...")
        self.BindEvents()

        #Call Layout() on self.SettingsPanel() to ensure it displays properly.
        self.SettingsPanel.Layout()

        logger.info("SettingsWindow().__init__(): Ready. Waiting for events...")

    def CreateButtons(self):
        """Create all buttons for SettingsWindow"""
        self.FastRecButton = wx.Button(self.SettingsPanel, -1, "Set to fastest recovery")
        self.BestRecButton = wx.Button(self.SettingsPanel, -1, "Set to best recovery")
        self.DefaultRecButton = wx.Button(self.SettingsPanel, -1, "Balanced (default)")
        self.ExitButton = wx.Button(self.SettingsPanel, -1, "Save settings and close") 

    def CreateText(self):
        """Create all text for SettingsWindow"""
        self.TitleText = wx.StaticText(self.SettingsPanel, -1, "Welcome to Settings.")
        self.BadSectText = wx.StaticText(self.SettingsPanel, -1, "No. of times to retry bad sectors:")
        self.MaxErrorsText = wx.StaticText(self.SettingsPanel, -1, "Maximum number of errors before exiting:")
        self.ClustSizeText = wx.StaticText(self.SettingsPanel, -1, "Number of clusters to copy at a time:")

    def CreateCheckBoxes(self):
        """Create all CheckBoxes for SettingsWindow, and set their default states (all unchecked)"""
        self.OverwriteCB = wx.CheckBox(self.SettingsPanel, -1, "Overwrite output device or partition")
        self.ReverseCB = wx.CheckBox(self.SettingsPanel, -1, "Read from finish to start (Reverse)")
        self.PreallocCB = wx.CheckBox(self.SettingsPanel, -1, "Preallocate space on disc for output file")
        self.NoSplitCB = wx.CheckBox(self.SettingsPanel, -1, "Do a soft run (don't read bad areas of disk)")

        #Set Checkbox's states (1 = enabled, 0 = disabled)
        self.OverwriteCB.SetValue(0)
        self.ReverseCB.SetValue(0)
        self.PreallocCB.SetValue(0)
        self.NoSplitCB.SetValue(0)

    def CreateChoiceBoxes(self):
        """Create all ChoiceBoxes for SettingsWindow, and call self.SetDefaultRec()"""
        self.BadSectChoice = wx.Choice(self.SettingsPanel, -1, choices=['0', '1', 'Default (2)', '3', '5', 'Forever'])  
        self.MaxErrorsChoice = wx.Choice(self.SettingsPanel, -1, choices=['Default (Infinite)', '1000', '500', '100', '50', '10'])
        self.ClustSizeChoice = wx.Choice(self.SettingsPanel, -1, choices=['256', 'Default (128)', '64', '32']) 

        #Set default settings
        self.SetDefaultRec()

    def SetupSizers(self):
        """Set up all sizers for SettingsWindow"""
        #Make a sizer for each choicebox with text, and add the objects for each sizer.
        #Retry bad sectors sizer.
        RetryBSSizer = wx.BoxSizer(wx.HORIZONTAL)
        RetryBSSizer.Add(self.BadSectText, 1, wx.LEFT|wx.TOP, 10)
        RetryBSSizer.Add(self.BadSectChoice, 1, wx.RIGHT, 10)

        #Max errors sizer.
        MaxErrorsSizer = wx.BoxSizer(wx.HORIZONTAL)
        MaxErrorsSizer.Add(self.MaxErrorsText, 1, wx.LEFT|wx.TOP, 10)
        MaxErrorsSizer.Add(self.MaxErrorsChoice, 1, wx.RIGHT, 10)

        #Cluster Size Sizer.
        ClustSizeSizer = wx.BoxSizer(wx.HORIZONTAL)
        ClustSizeSizer.Add(self.ClustSizeText, 1, wx.LEFT|wx.TOP, 10)
        ClustSizeSizer.Add(self.ClustSizeChoice, 1, wx.RIGHT, 10)

        #Make a sizer for the best and fastest recovery buttons now, and add the objects.
        ButtonSizer = wx.BoxSizer(wx.HORIZONTAL)
        ButtonSizer.Add(self.BestRecButton, 3, wx.LEFT|wx.EXPAND, 10)
        ButtonSizer.Add((20,20), 1)
        ButtonSizer.Add(self.FastRecButton, 3, wx.RIGHT|wx.EXPAND, 10)

        #Now create and add all objects to the main sizer in order.
        MainSizer = wx.BoxSizer(wx.VERTICAL)

        #Checkboxes.
        MainSizer.Add(self.TitleText, 3, wx.CENTER|wx.TOP, 10)
        MainSizer.Add(self.ReverseCB, 3, wx.CENTER|wx.ALL, 5)
        MainSizer.Add(self.PreallocCB, 3, wx.CENTER|wx.ALL, 5)
        MainSizer.Add(self.NoSplitCB, 3, wx.CENTER|wx.ALL, 5)
        MainSizer.Add(self.OverwriteCB, 3, wx.CENTER|wx.ALL, 5)

        #Choice box sizers.
        MainSizer.Add(RetryBSSizer, 4, wx.CENTER|wx.EXPAND|wx.ALL, 10)
        MainSizer.Add(MaxErrorsSizer, 4, wx.CENTER|wx.EXPAND|wx.ALL, 10)
        MainSizer.Add(ClustSizeSizer, 4, wx.CENTER|wx.EXPAND|wx.ALL, 10)

        #Add the buttons, and the button sizer.
        MainSizer.Add(self.DefaultRecButton, 4, wx.CENTER|wx.ALL, 10)
        MainSizer.Add(ButtonSizer, 4, wx.CENTER|wx.EXPAND|wx.ALL, 10)
        MainSizer.Add(self.ExitButton, 4, wx.CENTER|wx.ALL, 10)

        #Get the main sizer set up for the frame.
        self.SettingsPanel.SetSizer(MainSizer)
        MainSizer.SetMinSize(wx.Size(569,479))
        MainSizer.SetSizeHints(self)

    def BindEvents(self):
        """Bind all events for SettingsWindow"""
        self.Bind(wx.EVT_CHECKBOX, self.SetSoftRun, self.NoSplitCB)
        self.Bind(wx.EVT_BUTTON, self.SetDefaultRec, self.DefaultRecButton)
        self.Bind(wx.EVT_BUTTON, self.SetFastRec, self.FastRecButton)
        self.Bind(wx.EVT_BUTTON, self.SetBestRec, self.BestRecButton)
        self.Bind(wx.EVT_BUTTON, self.SaveOptions, self.ExitButton)
        self.Bind(wx.EVT_CLOSE, self.SaveOptions)

    def SetSoftRun(self, Event=None):
        """Set up SettingsWindow based on the value of self.NoSplitCB (the "do soft run" CheckBox)"""
        logger.debug("SettingsWindow().SetSoftRun(): Do soft run: "+self.NoSplitCB.GetValue()+". Setting up SettingsWindow accordingly...")

        if self.NoSplitCB.IsChecked():
            self.BadSectChoice.SetSelection(0)
            self.BadSectChoice.Disable()
        else:
            self.Badsectchoice.Enable()
            self.DefaultRec()

    def SetDefaultRec(self, Event=None):
        """Set selections for the Choiceboxes to default settings"""
        logger.debug("SettingsWindow().SetDefaultRec(): Setting up SettingsWindow for default recovery settings...")

        if self.BadSectChoice.IsEnabled():
            self.BadSectChoice.SetSelection(2)

        self.MaxErrorsChoice.SetSelection(0)
        self.ClustSizeChoice.SetSelection(1)

    def SetFastRec(self, Event=None):
        """Set selections for the Choiceboxes to fast recovery settings"""
        logger.debug("SettingsWindow().SetFastRec(): Setting up SettingsWindow for fast recovery settings...")

        if self.BadSectChoice.IsEnabled():
            self.BadSectChoice.SetSelection(0)

        self.MaxErrorsChoice.SetSelection(2)
        self.ClustSizeChoice.SetSelection(0)

    def SetBestRec(self, Event=None):
        """Set selections for the Choiceboxes to best recovery settings"""
        logger.debug("SettingsWindow().SetBestRec(): Setting up SettingsWindow for best recovery settings...")
        if self.BadSectChoice.IsEnabled():
            self.BadSectChoice.SetSelection(2)

        self.MaxErrorsChoice.SetSelection(0)
        self.ClustSizeChoice.SetSelection(3)

    def SaveOptions(self, Event=None):
        """Save all options, and exit SettingsWindow"""
        logger.info("SettingsWindow().SaveOptions(): Saving Options...")

        #Define global variables:
        global OverwriteOutputFile
        global Reverse
        global Preallocate
        global NoSplit
        global InputFileBlockSize
        global BadSectorRetries
        global MaxErrors
        global ClusterSize

        #Checkboxes:
        #Overwrite output device setting.
        if self.OverwriteCB.IsChecked():
            OverwriteOutputFile = "--force"
            logger.info("SettingsWindow().SaveOptions(): Overwriting output file: True.")
        else:
            OverwriteOutputFile = ""
            logger.info("SettingsWindow().SaveOptions(): Overwriting output file: False.")

        #Reverse (read data from the end to the start of the input file) setting.
        if self.ReverseCB.IsChecked():
            Reverse = "-R"
            logger.info("SettingsWindow().SaveOptions(): Reverse direction of read operations: True.")
        else:
            Reverse = ""
            logger.info("SettingsWindow().SaveOptions(): Reverse direction of read operations: False.")

        #Preallocate (preallocate space in the output file) setting.
        if self.PreallocCB.IsChecked():
            Preallocate = "-p"
            logger.info("SettingsWindow().SaveOptions(): Preallocate disk space: True.")
        else:
            Preallocate = ""
            logger.info("SettingsWindow().SaveOptions(): Preallocate disk space: False.")

        #NoSplit (Don't split failed blocks) option.
        if self.NoSplitCB.IsChecked():
            NoSplit = "-n"
            logger.info("SettingsWindow().SaveOptions(): Split failed blocks: True.")
        else:
            NoSplit = ""
            logger.info("SettingsWindow().SaveOptions(): Split failed blocks: False.")

        #ChoiceBoxes:
        #Retry bad sectors option.
        Badsectselection = self.BadSectChoice.GetCurrentSelection()

        if Badsectselection == 2:
            BadSectorRetries = "-r 2"
        elif Badsectselection == 5:
            BadSectorRetries = "-r -1"
        else:
            BadSectorRetries = "-r "+unicode(Badsectselection)

        logger.info("SettingsWindow().SaveOptions(): Retrying bad sectors "+BadSectorRetries[3:]+" times.")

        #Maximum errors before exiting option.
        Maxerrsselection = self.MaxErrorsChoice.GetStringSelection()

        if Maxerrsselection == "Default (Infinite)":
            MaxErrors = ""
            logger.info("SettingsWindow().SaveOptions(): Allowing an infinite number of errors before exiting.") 
        else:
            MaxErrors = "-e "+Maxerrsselection
            logger.info("SettingsWindow().SaveOptions(): Allowing "+MaxErrors[3:]+" errors before exiting.")

        #ClusterSize (No. of sectors to copy at a time) option.
        clustsizeselection = self.ClustSizeChoice.GetStringSelection()

        if clustsizeselection == "Default (128)":
            ClusterSize = "-c 128"
        else:
            ClusterSize = "-c "+clustsizeselection

        logger.info("SettingsWindow().SaveOptions(): ClusterSize is "+ClusterSize[3:]+".")

        #BlockSize detection.
        logger.info("SettingsWindow().SaveOptions(): Determining blocksize of input file...")
        InputFileBlockSize = DevInfoTools().GetBlockSize(InputFile)

        if InputFileBlockSize != None:
                logger.info("SettingsWindow().SaveOptions(): BlockSize of input file: "+InputFileBlockSize+" (bytes).")
                InputFileBlockSize = "-b "+InputFileBlockSize

        else:
            #Input file is standard file, don't set blocksize, notify user.
            InputFileBlockSize = ""
            logger.info("SettingsWindow().SaveOptions(): Input file is a standard file, and therefore has no blocksize.")

        #Finally, exit
        logger.info("SettingsWindow().SaveOptions(): Finished saving options. Closing Settings Window...")
        self.Destroy()

#End Settings Window
#Begin Finished Window
class FinishedWindow(wx.Frame):  
    def __init__(self,ParentWindow):
        """Initialize FinishedWindow"""
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="DDRescue-GUI - Finished!", size=(350,120), style=wx.DEFAULT_FRAME_STYLE)
        self.FinishedPanel = wx.Panel(self)
        self.SetClientSize(wx.Size(350,120))
        self.ParentWindow = ParentWindow
        wx.Frame.SetIcon(self, AppIcon)

        logger.debug("FinishedWindow().__init__(): Creating buttons...")
        self.CreateButtons()

        logger.debug("FinishedWindow().__init__(): Creating Text...")
        self.CreateText()

        logger.debug("FinishedWindow().__init__(): Setting up sizers...")
        self.SetupSizers()

        logger.debug("FinishedWindow().__init__(): Binding events...")
        self.BindEvents()

        #Call Layout() on self.FinishedPanel() to ensure it displays properly.
        self.FinishedPanel.Layout()

        logger.info("FinishedWindow().__init__(): Ready. Waiting for events...")
        
    def CreateButtons(self):
        """Create all buttons for FinishedWindow"""
        self.RestartButton = wx.Button(self.FinishedPanel, -1, "Reset")
        self.MountButton = wx.Button(self.FinishedPanel, -1, "Mount Image/Device")
        self.QuitButton = wx.Button(self.FinishedPanel, -1, "Quit")

    def CreateText(self):
        """Create all text for FinishedWindow"""
        self.TopText = wx.StaticText(self.FinishedPanel, -1, "Your recovered data is at:")
        self.PathText = wx.StaticText(self.FinishedPanel, -1, OutputFile)
        self.BottomText = wx.StaticText(self.FinishedPanel, -1, "What do you want to do now?")

    def SetupSizers(self):
        """Set up all sizers for FinishedWindow"""
        #Make a button boxsizer.
        ButtonSizer = wx.BoxSizer(wx.HORIZONTAL)

        #Add each object to the button sizer.
        ButtonSizer.Add(self.RestartButton, 4, wx.ALIGN_CENTER_VERTICAL|wx.LEFT, 10)
        ButtonSizer.Add((5,5), 1)
        ButtonSizer.Add(self.MountButton, 8, wx.ALIGN_CENTER_VERTICAL)
        ButtonSizer.Add((5,5), 1)
        ButtonSizer.Add(self.QuitButton, 4, wx.ALIGN_CENTER_VERTICAL|wx.RIGHT, 10)

        #Make a boxsizer.
        MainSizer = wx.BoxSizer(wx.VERTICAL)

        #Add each object to the main sizer.
        MainSizer.Add(self.TopText, 1, wx.ALL ^ wx.BOTTOM|wx.CENTER, 10)
        MainSizer.Add(self.PathText, 1, wx.ALL ^ wx.BOTTOM|wx.CENTER, 10)
        MainSizer.Add(self.BottomText, 1, wx.ALL ^ wx.BOTTOM|wx.CENTER, 10)
        MainSizer.Add(ButtonSizer, 0, wx.BOTTOM|wx.EXPAND, 10)

        #Get the sizer set up for the frame.
        self.FinishedPanel.SetSizer(MainSizer)
        MainSizer.SetMinSize(wx.Size(350,120))
        MainSizer.SetSizeHints(self)

    def Restart(self, Event=None):
        """Close FinishedWindow and call MainWindow().Reload() to re-display and reset MainWindow"""
        logger.debug("FinishedWindow().Restart(): Triggering restart and closing FinishedWindow()...")
        wx.CallAfter(self.ParentWindow.Reload)
        self.Destroy()

    def MountFileorDev(self, Event=None):
        """Perform some quick checks and call the platform-dependent mounter function to mount the output file"""
        logger.debug("FinishedWindow().MountFileorDev(): Preparing to mount a File or Device...")
        if InputFile[0:5] == "/dev/":
            #Use different methods for OS X and Linux *** Add support for OS X ***
            if Linux:
                self.MountDevLinux()
            else:
                logger.error("FinishedWindow().MountFileorDev(): Not supported on OS X! Aborting...")
                wx.MessageDialog(self.FinishedPanel, "Sorry, this feature is not yet supported on OS X.", "DDRescue-GUI - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        else:
            #*** Add support for this ***
            logger.error("FinishedWindow().MountFileorDev(): Source is file, not device! Aborting...")
            wx.MessageDialog(self.FinishedPanel, "Sorry, as of version 1.3, mounting the finished image where the source was a file is not supported.", "DDRescue-GUI - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

    def MountDevLinux(self):
        """Mount a Device on linux""" #*** Import stuff from WxFixBoot, including mount points in /mnt/dev/xxx ***
        #*** I am not happy with a lot of this code. Fortunately it'll be dead and gone soon because a lot of it will be replaced with code from WxFixBoot ***
        logger.info("FinishedWindow().MountDevLinux(): Mounting Device: "+InputFile+"...")

        #Create a temporary mountpoint.
        logger.debug("FinishedWindow().MountDevLinux(): Creating temporary mountpoint...")
        os.mkdir('/tmp/ddrescue-gui/mountpoint1')

        #Determine if inputfilechosen is a partition. *** Use info gathered when we collect device info ***
        if InputFile[-1].isdigit():
            #The inputfile must be a partition.
            logger.debug("FinishedWindow().MountDevLinux(): Input file is a partition! Continuing...")

            #Attempt to mount the partition.
            try:
                logger.info("FinishedWindow().MountDevLinux(): Mount attempt 1...")
                subprocess.check_output(['mount', OutputFile, '/tmp/ddrescue-gui/mountpoint1'])
            except subprocess.CalledProcessError:
                #We probably need to specify the filesystem type. *** We can probably get this from the device info we gathered earlier ***
                #Find it.
                logger.error("FinishedWindow().MountDevLinux(): Failed! We probably need to specify the filesystem type. Finding it...")
                fstype = subprocess.check_output(['blkid', '-o', 'value', OutputFile]).split()[-1]

                #Run the mount command a second time.
                logger.info("FinishedWindow().MountDevLinux(): Mount attempt 2...")
                subprocess.check_output(['mount', '-t', fstype, OutputFile, '/tmp/ddrescue-gui/mountpoint1'])
            
            #If we get here without an unhandled exception, it's worked.
            logger.info("FinishedWindow().MountDevLinux(): Success! Waiting for user to finish with it and prompt to unmount it...")

            #Call the unmount loop. ** This isn't the best ever way of doing this **
            self.UnmountImg(False)

        else:
            #The inputfile must NOT be a partition!
            logger.debug("FinishedWindow().MountDevLinux(): Input file isn't a partition! Getting list of contained partitions...")

            #Get the list of contained partitions. *** Don't use a global variable here if we can avoid it ***
            global partitions
            partitions = subprocess.check_output(['kpartx', '-l', OutputFile]).split('\n')
            
            #Show the partition selection Frame. *** Don't do this. If needed, use a seperate python package, but don't call another script ***
            logger.debug("FinishedWindow().MountDevLinux(): Showing partition selection frame...")
            subprocess.Popen([RescourcePath+'/PViewWindow.py', OutputFile]).wait()

            #*** This is going to be replaced soon ***
            with open('/tmp/ddrescue-gui/partitiontomount', 'r') as file:
                PartitionToMount = file.read().split()[0]

            if PartitionToMount != None:
                #Create loop devices for all contained partitions.
                logger.info("FinishedWindow().MountDevLinux(): Contained partition to mount is: "+PartitionToMount+"...")
                subprocess.check_output(['kpartx', '-a', OutputFile])

                try:
                    #Mount the partition.
                    logger.info("FinishedWindow().MountDevLinux(): Mount attempt 1...")
                    subprocess.check_output(['mount', '/dev/mapper/'+PartitionToMount, '/tmp/ddrescue-gui/mountpoint1'])
                except subprocess.CalledProcessError:
                    #We probably need to specify the filesystem type. ** We can probably get this from the device info we gathered earlier **
                    #Find it.
                    logger.error("FinishedWindow().MountDevLinux(): Failed! We probably need to specify the filesystem type. Finding it...")
                    fstype = subprocess.check_output(['blkid', '-o', 'value', '/dev/mapper/'+PartitionToMount]).split()[-1]

                    #*** This isn't handled properly, but it will stop the partition being mounted by causing an error. Fix it ***
                    if fstype == "swap":
                        logger.error("FinishedWindow().MountDevLinux(): Cannot mount a swap partition! Aborting...")
                        wx.MessageDialog(self.FinishedPanel, "You cannot mount a swap partition! Please select a new partition.", "DDRescue-GUI - Error!", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        subprocess.check_output(['kpartx', '-d', OutputFile])
                        os.rmdir("/tmp/ddrescue-gui/mountpoint1")

                    #Run the mount command a second time.
                    logger.info("FinishedWindow().MountDevLinux(): Mount attempt 2...")
                    subprocess.check_output(['mount', '-t', fstype, '/dev/mapper/'+PartitionToMount, '/tmp/ddrescue-gui/mountpoint1'])

                #If we get here without an unhandled exception, it's worked.
                logger.info("FinishedWindow().MountDevLinux(): Success! Waiting for user to finish with it and prompt to unmount it...")

                #Call the Unmount loop. *** This isn't the best ever way of doing this ***
                self.UnmountImg(True)

            else:
                #No partitions to mount selected.
                logger.info("FinishedWindow().MountDevLinux(): No partitions to mount selected! Returning to FinishedWindow()...")
                wx.MessageDialog(self.FinishedPanel, "You chose to not mount any partitions on the image. You will now be brought back to the finishing dialog.", "DDRescue-GUI - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                os.rmdir("/tmp/ddrescue-gui/mountpoint1")              

    def UnmountImg(self,IsDevice):
        """Unmount the Output File"""
        while os.path.exists('/tmp/ddrescue-gui/mountpoint1'):
            try:
                #Notify user.
                wx.MessageDialog(self.FinishedPanel, "Your image has been mounted at the temporary mount point '/tmp/ddrescue-gui/mountpoint1'. When you're finished with your image, close all programs accessing it, and click okay to unmount it.", "DDRescue-GUI - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

                #Now unmount the image.
                logger.info("FinishedWindow().UnmountImg(): Attempting to unmount device...")
                subprocess.check_output(['umount', '/tmp/ddrescue-gui/mountpoint1'])

                #Pull down loops if the InputFile was a device.
                if IsDevice:
                    logger.debug("FinishedWindow().UnmountImg(): Pulling down loop device...")
                    subprocess.check_output(['kpartx', '-d', OutputFile])

            except subprocess.CalledProcessError:
                logger.error("FinishedWindow().UnmountImg(): Failed to umount image! Waiting for user to try again...")
                wx.MessageDialog(self.FinishedPanel, "Your image could not be unmounted! Please insure no programs are still accessing it and try again.", "DDRescue-GUI - Error!", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
            else:
                os.rmdir("/tmp/ddrescue-gui/mountpoint1")

    def CloseFinished(self, Event=None):
        """Close FinishedWindow and trigger closure of MainWindow"""
        logger.info("FinishedWindow().CloseFinished(): Closing FinishedWindow() and calling self.ParentWindow().OnExit()...")
        self.Destroy()
        wx.CallAfter(self.ParentWindow.OnExit, JustFinishedRec=True)

    def BindEvents(self):
        """Bind all events for FinishedWindow"""
        self.Bind(wx.EVT_BUTTON, self.Restart, self.RestartButton)
    	self.Bind(wx.EVT_BUTTON, self.MountFileorDev, self.MountButton)
        self.Bind(wx.EVT_BUTTON, self.CloseFinished, self.QuitButton)
        self.Bind(wx.EVT_CLOSE, self.CloseFinished)

#End Finished Window
#Begin Backend thread. *** Do logging stuff here when I rewrite it ***
class BackendThread(threading.Thread):
    def __init__(self, ParentWindow):
        """Initialize and start the thread."""
        self.ParentWindow = ParentWindow
        threading.Thread.__init__(self)
        self.start()

    def run(self):
        """Main body of the thread, started with self.start()"""
        #Start ddrescue with shell=True, because this is the only way it works.
        #*** In future, dump startddrescue.sh, and intelligently figure out which options have been set to eliminate the spaces in the command ***
        if Linux:
            ddrescuecommand = subprocess.Popen("bash "+RescourcePath+"/helperscripts/startddrescue.sh -l -o '-v "+OverwriteOutputFile+" "+Reverse+" "+Preallocate+" "+NoSplit+" "+InputFileBlockSize+" "+BadSectorRetries+" "+MaxErrors+" "+ClusterSize+" "+InputFile+" "+OutputFile+" "+LogFile+"'", shell=True)
        else:
            ddrescuecommand = subprocess.Popen("bash "+RescourcePath+"/helperscripts/startddrescue.sh -m -o '-v "+OverwriteOutputFile+" "+Reverse+" "+Preallocate+" "+NoSplit+" "+InputFileBlockSize+" "+BadSectorRetries+" "+MaxErrors+" "+ClusterSize+" "+InputFile+" "+OutputFile+" "+LogFile+"'", shell=True)

        #Ensure the exit sequence knows we are recovering data.
        global RecoveringData
        RecoveringData = True
        
        #Grab some useful initial data (amount of data), and unit (KB, MB, GB etc...). Use a try loop to correct errors.
        gotdata = False
        counter = 10
        while gotdata == False:
            time.sleep(1)
            self.GetInitStatus()
            if None not in [self.datatorecover, self.unitfordatatorecover]:
                gotdata = True
            else:
                counter -= 1
                wx.CallAfter(self.ParentWindow.UpdateStatusBar, "ddrescue not started yet. "+unicode(counter)+" seconds till abort...")
                if counter <= 0:
                    #Notify Main Window that the recovery failed.
                    wx.CallAfter(self.ParentWindow.RecoveryFailed)
                    
                    #Restart the GUI
                    RecoveringData = False
                    wx.CallAfter(self.ParentWindow.Reload)
                    self.exit()
                
        print("DDRescue is about to copy "+self.datatorecover+" "+self.unitfordatatorecover)

        #Set progressbar's range.
        wx.CallAfter(self.ParentWindow.SetProgressBarRange, int(self.datatorecover))

        while ddrescuecommand.poll() is None:
            #ddrescue is running.
            #Use a try loop to correct errors.
            try:
                self.GetData()
                wx.CallAfter(self.ParentWindow.UpdateProgressBar, int(self.recovereddatanum))

            except (ValueError,UnboundLocalError,TypeError):
                wx.CallAfter(self.ParentWindow.UpdateStatusBar, "Unable to update the GUI. If this persists, please view terminal output instead.")

            else:
                #Update statusbar.
                wx.CallAfter(self.ParentWindow.UpdateStatusBar, self.status)
                self.recovereddataunit = self.unitfordatatorecover

                #Send messages to GUI for updating.
                wx.CallAfter(self.ParentWindow.UpdateRecoveredInfo, unicode(self.recovereddatanum)+" "+self.recovereddataunit)
                wx.CallAfter(self.ParentWindow.UpdateErrsizeInfo, self.errsize)
                wx.CallAfter(self.ParentWindow.UpdateReadRateInfo, self.currentreadrate)
                wx.CallAfter(self.ParentWindow.UpdatenumerrorsInfo, self.numerrors)
                wx.CallAfter(self.ParentWindow.UpdateavgReadRateInfo, self.avgreadrate)
                wx.CallAfter(self.ParentWindow.UpdateTimeSinceLastReadInfo, self.timesincelastread)
                wx.CallAfter(self.ParentWindow.UpdateTimeLeft, self.timeremaining)

            finally:
                #Sleep for 1 second to keep in sync with ddrescue's updates.
                time.sleep(1)

        RecoveringData = False
        print("Recovery finished.")
        wx.CallAfter(self.ParentWindow.UpdateStatusBar, "Finished!")
        wx.CallAfter(self.ParentWindow.RecoveryEnded)

    def GetInitStatus(self):
        """Get ddrescue's initial status"""
        try:
            #Get the data.
            if Linux:
                self.initdata = subprocess.check_output("cat /tmp/ddrescue-gui/ddrescueoutput.txt | grep 'About to copy'", shell=True).replace('\n', '').split()

                #Cut unneeded junk from this.
                self.unitfordatatorecover = ''.join(self.initdata[4])
                self.datatorecover = ''.join(self.initdata[3])
            else:
                try:
                    #Determine if InputFile is a device.
                    DevNode = unicode(InputFile.split("/dev/")[1])
                except:
                    #If not, use ddrescue's disk size calculation.
                    self.initdata = subprocess.check_output("cat /tmp/ddrescue-gui/ddrescueoutput.txt | grep 'About to copy'", shell=True).replace('\n', '').split()

                    #Cut unneeded junk from this.
                    self.unitfordatatorecover = ''.join(self.initdata[4])
                    self.datatorecover = ''.join(self.initdata[3])
                else:
                   #If so, use Apple's disk utility with shell=True.
                   self.initdata = subprocess.check_output("diskutil list | grep -v 'TYPE' | grep "+DevNode+" | grep -v '/dev' | grep -v 's[0-9]'", shell=True).replace('\n', '').replace('*','').split()

                   #Cut unneeded junk from this.
                   self.unitfordatatorecover = ''.join(self.initdata[3])
                   self.datatorecover = ''.join(self.initdata[2]) 

            #If self.datatorecover <= 400, multiply by 1024 to make progressbar more accurate
            if float(self.datatorecover) <= 400:
                self.ShiftInitUnitsUp()

            #Get only the first 2 chars from the unitfordatatorecover to make it compatible with data conversion.
            self.unitfordatatorecover = self.unitfordatatorecover[:2]

        except subprocess.CalledProcessError:
            self.datatorecoverdata = None
            self.datatorecover = None
            self.unitfordatatorecoverdata = None
            self.unitfordatatorecover = None

    def ShiftInitUnitsUp(self):
        """Shift the unit of measurement up for self.datatorecover"""
        #Create a unitlist.
        unitlist = ['null', 'B', 'kB', 'MB', 'GB', 'TB', 'PB']

        #Multiply by 1024 to shift self.datatorecover up one unit, and keep only the whole number.
        self.datatorecover = unicode(float(self.datatorecover)*1024)
        self.datatorecover,sep,junk = self.datatorecover.partition('.')

        #Shift unit down one place
        oldnumudtr = unitlist.index(self.unitfordatatorecover)
        newnumudtr = oldnumudtr-1
        self.unitfordatatorecover = unitlist[newnumudtr]

    def GetData(self):
        """Grab and preprocess (remove junk from) ddrescue's output. Then convert to a list."""
        outputfile = subprocess.check_output(["tail", "-n", "5", "/tmp/ddrescue-gui/ddrescueoutput.txt"])
        ddrescueoutput = outputfile.replace('\r','')
        ddrescueoutput = ddrescueoutput.replace('\n',' ')
        junk, sep, trimmedddrescueoutput = ddrescueoutput.partition('\x1b[A\x1b[A\x1b[A')
        splitddrescueoutput = trimmedddrescueoutput.split()

        #Grab current amount (number), and unit of recovered data, removing also a commar.
        self.recovereddatanum = ''.join(splitddrescueoutput[1])
        self.recovereddataunit = ''.join(splitddrescueoutput[2]).replace(',','')

        #Convert recovereddatanum and round it.
        self.recovereddatanum = self.ConvertData(self.recovereddatanum,self.unitfordatatorecover,self.recovereddataunit,1000000,1000,False)
        self.recovereddatanum = round(self.recovereddatanum,3)

        #Grab size of unreadable data.
        self.errsize = ' '.join(splitddrescueoutput[4:6]).replace(',','')

        #Grab current read rate.
        self.currentreadrate = ' '.join(splitddrescueoutput[8:10])

        #Grab no. of errors.
        self.numerrors = ''.join(splitddrescueoutput[14]).replace(',','')

        #Grab average read rate.
        self.avgreadratenum = ''.join(splitddrescueoutput[17])
        self.avgreadrateunit = ''.join(splitddrescueoutput[18])
        self.avgreadrate = self.avgreadratenum+" "+self.avgreadrateunit
 
        #Grab time since last sucessful read. Includes fix for '1.2m' appearing as '12m'
        self.timesincelastread = ' '.join(splitddrescueoutput[27:29])

        #Get only the first 2 chars from the avgreadrateunit to make it compatible with data conversion.
        self.tmp = self.avgreadrateunit[:2]

        #Calculate time remaining. Included fix for negative numbers on OS X.
        self.timeremaining = self.CalculateTimeLeft()
        if self.timeremaining[0] == "-":
            self.timeremaining = "Nearly Finished..."

        #Create status.
        junk, sep, status = trimmedddrescueoutput.partition('time')
        status = status.split()
        self.status = ' '.join(status[6:])

    def ConvertData(self,datatoconvert,info1,info2,value1,value2,calcingtimeleft):
        """Converting data so it uses the correct unit of measurement"""
        #Create a unit list. Include 'B/' so the time remaining feature works when avg is (rather dismally!) below 10KB/s.
        if calcingtimeleft:
            unitlist = ['null', 'B/', 'kB', 'MB', 'GB', 'TB', 'PB']
        else:
            unitlist = ['null', 'B', 'kB', 'MB', 'GB', 'TB', 'PB']

        #Perform the actual conversion.
        numinfo1 = unitlist.index(info1)
        numinfo2 = unitlist.index(info2)
        unitnum = numinfo1 - numinfo2
        if unitnum == 2:
            return int(datatoconvert)/+value1
        elif unitnum == 1:
            return int(datatoconvert)/+value2
        elif unitnum == 0:
            return int(datatoconvert)
        elif unitnum == -1:
            return int(datatoconvert)*+value2
        elif unitnum == -2:
            return int(datatoconvert)*+value1

    def CalculateTimeLeft(self):
        """Calculate remaining time based on the average read rate and the current amount of data recovered"""
        #Create status for the statusbar, including remaining time.
        try:
            self.avgreadratenum = self.ConvertData(self.avgreadratenum,self.unitfordatatorecover,self.tmp,100000,1000,True)

            #Then perform the calculation and round it.
            calculationresult = float((int(self.datatorecover)-int(self.recovereddatanum))/int(self.avgreadratenum))

            #Convert between mins,hrs etc...
            if calculationresult <= 60:
                return unicode(round(calculationresult,1))+" seconds"
            elif calculationresult >= 60 and calculationresult <= 3600: 
                return unicode(round(calculationresult/60,1))+" minutes"
            elif calculationresult > 3600:
                return unicode(round(calculationresult/3600,2))+" hours"
        except: 
            return "Calculating..."

#End Backend thread
app = MyApp(False)
app.MainLoop()
