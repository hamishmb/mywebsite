A device information gatherer for Linux and macOS.

Working on both Linux and macOS, this script makes use of lshw, lvdisplay, and blkid (Linux), as well as diskutil (macOS) to get a comprehensive amount of disk information. This information is available in a structured dictionary for ease of use. On Linux it requires lshw, blkid, and lvdisplay to be installed. On Linux, you need beautifulsoup4 (bs4), and lxml to use this tool. On macOS, nothing beyond a standard python2.x/python3.x install is required, but you still need bs4 and lxml if you want to install using the python wheel/through pip.

