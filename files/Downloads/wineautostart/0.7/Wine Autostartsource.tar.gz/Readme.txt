I apoligize as the last version of this package didn't have a readme.
Here are the locations for the files to be placed in :

./wineautostart /usr/bin
./indicator-wineautostart /usr/bin
./cappind.py /usr/bin
./About_wineautostart /usr/bin

 
