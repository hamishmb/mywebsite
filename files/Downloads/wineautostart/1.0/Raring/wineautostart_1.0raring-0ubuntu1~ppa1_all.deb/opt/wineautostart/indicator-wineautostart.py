#!/usr/bin/env python
# Indicator for Wine Autostart Version 1.0
# Copyright (C) 2013 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
import os
import shutil
import time
import gobject
import gtk
import appindicator
import threading
import subprocess

print "Wine Autostart Indicator v1.0 starting..."
#Prepare for Threading
gobject.threads_init()

#Set some vars to kill the threads with.
global KillReceived
KillReceived = False
global KillWA
KillWA = False

# set status intitially
global status
status = "Unknown"

# Make a temporary directory for data used by this program, if not already present.
if not os.path.exists("/tmp/wineautostart"):
    os.mkdir("/tmp/wineautostart")

class Indicator:
    def __init__(self):
        # set up the icons
        ind = appindicator.Indicator ("Indicator-for-WA", "wineautostart", appindicator.CATEGORY_APPLICATION_STATUS)
        ind.set_status (appindicator.STATUS_ACTIVE)
        ind.set_attention_icon ("wineautostart")
 
        # create menus
        global menu
        menu = gtk.Menu()
        controlsmenu = gtk.Menu()

        # Set global variable beforehand
        global StatusItem

        # create some items
        VersionandNameItem = gtk.MenuItem("Wine Autostart 1.0")
        Separator1 = gtk.SeparatorMenuItem()
        StatusItem = gtk.MenuItem("Status: "+status)
        PreferencesItem = gtk.MenuItem("Preferences")
        ControlsItem = gtk.MenuItem("Controls")
        StartItem = gtk.MenuItem("Start")
        StopItem = gtk.MenuItem("Stop")
        Separator2 = gtk.SeparatorMenuItem()
        AboutItem = gtk.MenuItem("About")
        Separator3 = gtk.SeparatorMenuItem()
        QuitItem = gtk.MenuItem("Quit")

        #Start checking for disks.
        StartWineAutostart()

        # Start getting status here (start thread)
        GetStatus()
        time.sleep(1)

        # add the items to the main menu
        menu.append(VersionandNameItem)
        menu.append(Separator1)
        menu.append(StatusItem)
        menu.append(PreferencesItem)
        menu.append(ControlsItem)
        menu.append(Separator2)
        menu.append(AboutItem)
        menu.append(Separator3)
        menu.append(QuitItem)

        # add the items to the controls menu
        controlsmenu.append(StartItem)
        controlsmenu.append(StopItem)
        ControlsItem.set_submenu(controlsmenu)
 
        # bind events (wxpython style)
        PreferencesItem.connect("activate", OpenPreferences)
        StartItem.connect("activate", StartWA)
        StopItem.connect("activate", StopWA)
        AboutItem.connect("activate", DisplayAbout)
        QuitItem.connect("activate", OnQuit)

        # show the items
        VersionandNameItem.show()
        Separator1.show()
        StatusItem.show()
        PreferencesItem.show()
        ControlsItem.show()
        StartItem.show()
        StopItem.show()
        Separator2.show()
        AboutItem.show()
        Separator3.show()
        QuitItem.show()
        ind.set_menu(menu)
        gtk.main()

class PreferencesWindow(gtk.Window):
    def MakeListofDevices(self):
        #Get list of /dev/sr* devices for combobox.
        stringofdevices = subprocess.check_output("mount | grep /dev/sr | sed 's/ .*//'", shell=True).replace('\n', '')
        listofdevices = stringofdevices.split()
        return listofdevices

    def Makesizer(self):
        #Create a means to fix widgets to a particular place.
        self.fixed = gtk.Fixed()

        #Add stuff
        self.fixed.put(self.label, 20, 10)
        self.fixed.put(self.cb, 10, 40)
        self.fixed.put(self.button1, 48, 80)
        self.fixed.put(self.button2, 100, 80)
        
        #Add the "fixed" to the frame.
        self.add(self.fixed)

    def CreateChoicebox(self,junk):
        listofdevices = self.MakeListofDevices()

        #Check the list isn't empty.
        try:
            print listofdevices[0]
        except:
            print "except..."
            self.cb.append_text('No CD/DVD devices! Please refresh.')
            self.cb.set_active(0)
        else:
            self.cb.append_text('-- Please Select --')
            #Since it isn't, add the devices to the list
            for eachdevice in listofdevices:
                self.cb.append_text(eachdevice)
                self.cb.set_active(0)

    def __init__(self):
        super(PreferencesWindow, self).__init__()

        #Set the title, size and position.
        self.set_title("Wine Autostart -- Preferences")
        self.set_default_size(250, 200)
        self.set_position(gtk.WIN_POS_CENTER)

        #Prompt the user.
        dialog = gtk.MessageDialog(type=gtk.MESSAGE_WARNING, buttons=gtk.BUTTONS_OK)
        dialog.set_markup("Please insert a disk into the drive you wish to monitor. If it doesn't show up on the following window, close the following dialog and reopen using the prefences button in the indicator. Thank you.")
        dialog.set_title("Wine Autostart -- Exclamation")
        dialog.run()
        dialog.destroy()
        #Create some text
        self.label = gtk.Label("Please set up which device to monitor.")

        #Add some buttons
        self.button1 = gtk.Button(label='Save', stock=None)
        self.button2 = gtk.Button(label='Close Preferences', stock=None)

        #Set up a combobox to select which device to monitor.
        self.cb = gtk.combo_box_new_text()
        self.CreateChoicebox(self)

        #Make a sizer
        self.Makesizer()
        
        #Bind or "connect" events.
        self.button1.connect("clicked", self.SaveSettings)
        self.button2.connect("clicked", self.ClosePrefs)

        #Show everything.
        self.show_all()

    def SaveSettings(self,widget):
        devicetomonitor = self.cb.get_active_text()
        print devicetomonitor
        subprocess.check_output("pkexec bash -c 'echo "+devicetomonitor+" > /opt/wineautostart/devicetomonitor'", shell=True)

    def ClosePrefs(self,widget):
        print "Closing preferences..."
        self.destroy()

class GetStatus(threading.Thread):
    def __init__(self):
        #Initialize and start the thread.
        super(GetStatus, self).__init__()
        self.start()

    def run(self):
        while KillReceived == False:    
            # Update the status item here
            global StatusItem
            global status
            StatusItem.set_label("Status: "+status)

            time.sleep(1)
            #Do a little sleep to avoid eating CPU power.

class StartWineAutostart(threading.Thread):
    def __init__(self):
        #This is made more complicated because recent versions of
        #WINE return you to the terminal upon running programs, so
        #we need to see if wineserver is running instead of waiting for it to finish,
        #this should also work for old versions of WINE which don't return you to the terminal.

        #Initialize and start the thread.
        super(StartWineAutostart, self).__init__()
        self.start()

    def run(self):
        # Do a first run setup if needed.
        if not os.path.exists("/opt/wineautostart/devicetomonitor"):
            PreferencesWindow()
        while KillWA == False:
            #Allow setting global var 'status'
            global status
            #Use a try loop to see if wineserver is running.
            try:
                subprocess.check_output("pgrep wineserver", shell=True)
                #If it isn't, start the main part of the loop.
            except subprocess.CalledProcessError:
                #If runningsoftware.txt exists, software has just been run, so prompt to eject the disk.
                if os.path.isfile("/tmp/wineautostart/runningsoftware.txt"):
                    subprocess.Popen("python /opt/wineautostart/ejectdialog.py", shell=True).wait()                    
                    if os.path.isfile("/tmp/wineautostart/ignoredisk.txt"):
                        self.IgnoreDisk()

                #Start wineautostart.py here.
                status = "Checking for disk..."
                subprocess.call("python /opt/wineautostart/wineautostart.py", shell=True)

                #If WINE is starting, wait 15 seconds because the startup procedure is slow.
                if os.path.isfile("/tmp/wineautostart/runningsoftware.txt"):
                    #Notify user.
                    subprocess.call("notify-send 'Wine Autostart' 'Wine Autostart is preparing to run software, please wait for up to 30 seconds...' -i /usr/share/pixmaps/wineautostart.png", shell=True)
                    status = "Running software..."
                    print "Waiting for WINE..."
                    time.sleep(15)
                elif os.path.isfile("/tmp/wineautostart/ignoredisk.txt"):
                    self.IgnoreDisk()
                else:
                    #Check again.
                    time.sleep(5)

            #If wineserver is running, wait for it to finish. 
            else:
                status = "Running software..."
                print "wineserver running..."
                time.sleep(10)

    def IgnoreDisk(self):
        #Is caught in a while loop until the disk is unmounted/ejected.
         os.remove("/tmp/wineautostart/ignoredisk.txt")
         try:
             while subprocess.check_output("mount | grep -c /dev/sr", shell=True).replace('\n', '') == "1" and KillWA == False:
                 print "Ignoring"
                 global status
                 status = "Ignoring disk..."
                 time.sleep(10)
         except subprocess.CalledProcessError:
             print "Disk has been ejected..."

    def EjectPrompt(self):
        #Set the status
        global status
        status = "Eject prompt..."

        #Start the eject script.
        subprocess.call("python /opt/wineautostart/ejectdialog.py", shell=True)

def OpenPreferences(w):
    PreferencesWindow()
 
def StartWA(w):
    global KillWA
    KillWA = False
    StartWineAutostart()

def StopWA(w):
    print "Stopping Wine Autostart..."
    global KillWA
    KillWA = True
    time.sleep(1)
    print "Stopped."
    global status
    status = "Stopped. Sleeping..."

def DisplayAbout(w):
    aboutdlg = gtk.AboutDialog()
    logo = gtk.gdk.pixbuf_new_from_file("/opt/wineautostart/logo.png")
    aboutdlg.set_logo(logo)
    aboutdlg.set_program_name("Wine Autostart")
    aboutdlg.set_version("1.0")
    aboutdlg.set_copyright("(C) 2013 Hamish McIntyre-Bhatty")
    aboutdlg.set_comments("Allows Windows (R) Software disks to be run under Linux with WINE")
    aboutdlg.set_website("https://launchpad.net/wineautostart")
    aboutdlg.run()
    aboutdlg.destroy()

def OnQuit(w):
    print "Waiting 2 seconds for all threads to finish..."
    global KillReceived
    KillReceived = True
    global KillWA
    KillWA = True
    time.sleep(2)
    print "Exiting and Cleaning up..."
    if not os.path.exists("/tmp/wineautostart"):
        exit()  
    else:
        shutil.rmtree('/tmp/wineautostart')
        exit()

if __name__ == "__main__":
    Indicator().main()
