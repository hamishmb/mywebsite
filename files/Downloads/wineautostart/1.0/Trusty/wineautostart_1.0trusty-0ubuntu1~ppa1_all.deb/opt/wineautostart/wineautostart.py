#!/usr/bin/env python
#Wine Autostart Backend version 1.0 
#Copyright (C) 2013 Hamish McIntyre-Bhatty
#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
import time
import subprocess
import os
import shutil
import wx

#Get device to monitor.
print "Checking set up."
try:
    with open('/opt/wineautostart/devicetomonitor', 'r') as devicefile:
        print 0
        devicetomonitor = devicefile.read().replace("\n","")
        print 1
        print devicetomonitor
        print 2
except IOError:
    exit()

#Define functions here.
def CheckForDisk(self):
    #Run a command to check for a disk (any /dev/sr* device), and return it to __init__
    return subprocess.check_output("df | grep $(cat /opt/wineautostart/devicetomonitor) | cut -c 50-90", shell=True).replace('\n', '')

def FindAutorunFile(self,diskmountpoint):
    #From now on, it will automatically detect exe files before asking to run them.
    #Use the find command to look for autorun files, and return the result to __init__
    return subprocess.check_output("find '"+diskmountpoint+"'/ -iname 'autorun.inf'", shell=True).replace('\n', '')

def ParseAutorunFile(self,autorunfilepath):
    #Read the autorun file, cutting out all information except the path to a .exe file, if present.
    exefilelineoutput = subprocess.check_output("cat '"+autorunfilepath+"' | grep '.exe'", shell=True).replace('\n', '')
    #Cut out everything before and including '=', then swap '\' for '/', and return to __init__
    return exefilelineoutput.split('=', 1)[-1].replace('\\', '/')
    
def SetToIgnoreDisk(self,diskmountpoint):
    #Create a file to let the indicator know to ignore the disk.
    subprocess.check_output("echo 'True' > /tmp/wineautostart/ignoredisk.txt", shell=True)

    #Notify the user.
    subprocess.call("notify-send 'Wine Autostart' 'The disk at: "+diskmountpoint+" is being ignored until a new disk is inserted. Either the software cannot be run, or this is not an autorun-enabled disk.' -i /usr/share/pixmaps/wineautostart.png", shell=True)

class WineAutostart():
    def __init__(self):
        #Check for a disk.
        global diskmountpoint
        diskmountpoint = CheckForDisk(self)
        if diskmountpoint == "":
            #No disk.
            print "No Disk"
        else:
            print "Disk found!"
            print "Mount point is : "+diskmountpoint

            #Get the exe file information from an autorun.inf file (if present)
            autorunfilepath = FindAutorunFile(self,diskmountpoint)

            #Check if there is an autorun file.
            if autorunfilepath == "":
                #There isn't.
                print "No autorun file"
                SetToIgnoreDisk(self,diskmountpoint) 
            else:
                #There is.
                print "Autorun file is located at: "+autorunfilepath

                #Parse it to try and get a path to exe file.
                print "Attempting to obtain a path to an exe file..."
                exefilepath = ParseAutorunFile(self,autorunfilepath)

                #See if we found one.
                if exefilepath == "":
                    #We haven't.
                    print "No autorun-enabled exefile. Ignoring disk."
                    SetToIgnoreDisk(self,diskmountpoint) 
                else:
                    #We have! Ask the user.
                    print "Exe file found at: "+diskmountpoint+"/"+exefilepath
                    runsoftware = wx.MessageDialog(None, 'Wine Autostart has found Windows (R) software on the cd/dvd you inserted. Do you want to run it?', 'Wine Autostart -- Question', wx.YES_NO | wx.ICON_QUESTION)

                    #Do what the user says.
                    if runsoftware.ShowModal() != wx.ID_YES:
                        print "Won't run software"
                        SetToIgnoreDisk(self,diskmountpoint) 
                    else:
                        winecmd = subprocess.call("wine start /Unix '"+diskmountpoint+"'/'"+exefilepath+"'", shell=True)

                        #Create a file to let the indicator know that software's being run.
                        subprocess.check_output("echo 'True' > /tmp/wineautostart/runningsoftware.txt", shell=True)

                        #This is the end of the script.
                        time.sleep(0.5)

if __name__ == "__main__":
    app = wx.App(False)
    #Start the main part of the script.
    try:
        WineAutostart()
    except:
        self = "None"
        SetToIgnoreDisk(self,diskmountpoint) 
