#!/usr/bin/env python
#Wine Autostart eject dialog version 1.0 
#Copyright (C) 2013 Hamish McIntyre-Bhatty
#This program is free software: you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation, either version 3 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License
#along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
import gtk
import os
import subprocess
import time

class Ejectdlg:
    def __init__(self):
        #Remove the file.
        os.remove("/tmp/wineautostart/runningsoftware.txt")

        #Prompt the user to eject.
        print "Prompting to eject disk..."
        ejectdialog = gtk.MessageDialog(type=gtk.MESSAGE_QUESTION, buttons=gtk.BUTTONS_YES_NO)
        ejectdialog.set_markup("Do you want to eject the disk?")
        ejectdialog.set_title("Wine Autostart -- Question")
        response = ejectdialog.run()
        ejectdialog.destroy()

        #Do what the user says.
        if response == gtk.RESPONSE_YES:
            status = "Ejecting..."
            print "Ejecting disk..."
            subprocess.call("eject /dev/sr0", shell=True)
            time.sleep(4)
            status = "Ejected."
            print "Ejected disk, returning to indicator-wineautostart"
        else:
            print "Not ejecting disk, ignoring until it's ejected..."
            #Create a file to let the indicator know to ignore the disk.
            subprocess.check_output("echo 'True' > /tmp/wineautostart/ignoredisk.txt", shell=True) 

if __name__ == "__main__":
    Ejectdlg()
