#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 0.9
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
import wx
from wx.lib.wordwrap import wordwrap
import time
import os
import subprocess

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen("bash /usr/share/wxfixboot/listdevices.sh", shell=True).wait()

#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v0.9 (23/1/14)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        print "WxFixBoot Version 0.9 UNSTABLE Starting..."

        # Make a temporary directory for data used by this program, if not already present.
        if not os.path.exists("/tmp/wxfixboot"):
            os.mkdir("/tmp/wxfixboot")

        GetDevInfo()

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Bind all events.
        self.BindEvents() 

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        
    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text
        welcometext = wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(125,15))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(120,220))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply Quick Operations + Operations set in options dialog", pos=(20,180))

    def CreateCBs(self):
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall Bootloader", (10,100), (170,20))
        self.updteblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Bootloader", (10,130), (150,20))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", (10,70), (240,20))
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorugh)", (10,40), (250,20))

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_ANY, "&Options", "General settings used during the fix")

        #Creating the menubar.
        self.menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        self.menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        self.menuBar.Append(editmenu,"&Edit") # Adding the "editmenu" to the MenuBar
        self.menuBar.Append(viewmenu,"&View") # Adding the "viewmenu" to the MenuBar
        self.menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar 

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(self.menuBar)

    def Opts(self,e):
        OptionsWindow1().Show()

    def DevInfo(self,e): 
        # Use a seperate bash script and zenity for this dialog
        DevInfoDlg = DevInfoWindow().Show()

    def OnAbout(self,e):
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot"
        aboutbox.Version = "0.9"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = wordwrap(
        "Utility to quickly fix the bootloader on a computer",250,wx.ClientDC(self.MainPanel))
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.License = wordwrap("WxFixBoot is released under the GNU GPL v3",500,wx.ClientDC(self.MainPanel))
        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def OnExit(self,e):
        #Shut down.
        self.Close(True)

#End Main window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):

    title = "WxFixBoot - Options" 

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)

        self.CreateButtons()
        self.CreateText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.BindEvents()

    def CreateButtons(self):
        self.SaveSettings = wx.Button(self.OptsPanel1, -1, "Apply these Settings", pos=(10,320))
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Close", pos=(500,320))
        self.fwOptsButton = wx.Button(self.OptsPanel1, -1, "View Firmware settings", pos=(310,80), size=(250,30))

    def CreateText(self):
        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Changing the advanced settings is not recommended.", (50,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", (10,50))
        wx.StaticText(self.OptsPanel1, -1, "Installed BootLoader:", (10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", (10,110))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader timeout value:", (10,260))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", (10,280)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", (310,50))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", (310,130))

    def CreateCBs(self):
        #Basic settings
        shwprogresscb = wx.CheckBox(self.OptsPanel1, -1, "Show Progress during operations", (10,140), (300,20))
        warnusbcb = wx.CheckBox(self.OptsPanel1, -1, "Warn about disconnecting usb devices", (10,170), (305,20))
        warnprogscb = wx.CheckBox(self.OptsPanel1, -1, "Warn to close all other programs", (10,200), (295,20))
        createlogcb = wx.CheckBox(self.OptsPanel1, -1, "Create a logfile containing all output", (10,230), (295,20))

        #Advanced settings
        chkfscb = wx.CheckBox(self.OptsPanel1, -1, "Check Filesystems on startup (fast)", pos=(310,160), size=(315,20))
        remntfscb = wx.CheckBox(self.OptsPanel1, -1, "Mount all Filesystems as read-only", pos=(310,190), size=(315,20))
        bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector", pos=(310,220), size=(250,20))
        bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table", pos=(310,250), size=(290,20))
        chrootcb = wx.CheckBox(self.OptsPanel1, -1, "Use chroot to reinstall bootloader", pos=(310,280), size=(315,20))       

    def CreateChoiceBs(self):
        #Basic settings
        instblchoice = wx.Choice(self.OptsPanel1, -1, (190,73), choices=['Auto', 'GRUB', 'GRUB-EFI', 'LILO'])
        defaultoschoice = wx.Choice(self.OptsPanel1, -1, (190,103), choices=['Ask me', 'Current', 'Windows NT', 'Windows 9x', 'Linux', 'Apple', 'etc...'])

        #Advanced settings
        rootdevchoice = wx.Choice(self.OptsPanel1, -1, (440,123), choices=['Ask me', '/dev/sda', '/dev/sdb', 'etc...'])

    def CreateSpinners(self):
        bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", (190,257))
        bltimeoutspin.SetRange(-1,100)
        bltimeoutspin.SetValue(-1)

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchfwOpts, self.fwOptsButton)

    def LaunchfwOpts(self,e):
        OptionsWindow2().Show()

    def CloseOpts(self,e):
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):

    title = "WxFixBoot - Firmware Settings"

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(310,270))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace UEFI bootloader with BIOS version", pos=(10,160), size=(290,20))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace BIOS bootloader with UEFI version", pos=(10,190), size=(290,20))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Modify bootloader type based on detected Firmware type", pos=(10,220), size=(375,20))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not change the bootloader's firmware type", pos=(10,250), size=(330,20))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Reinstall BootLoader in:", (130,50))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System:", (130,80))
 
    def CreateRadios(self):
        #Have a system to determine which options to enable based on whether fwtyperadio1 is 'Auto (BIOS)' or 'Auto (UEFI)' ***
        self.fwtyperadio1 = wx.RadioButton(self.OptsPanel2, -1, "Auto", pos=(7,50), style=wx.RB_GROUP)
        self.fwtyperadio2 = wx.RadioButton(self.OptsPanel2, -1, "EFI/UEFI", pos=(7,80))
        self.fwtyperadio3 = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(7,110))

    def CreateChoiceBs(self):
        self.instbldestchoice = wx.Choice(self.OptsPanel2, -1, (295,44), choices=['Ask me', '/dev/sda', '/dev/sdb', 'etc...'])
        self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, (295,74), choices=['Auto', 'MBR', 'GUID'])

    def SetDefaults(self):
        self.UEFItoBIOScb.Disable()
        self.BIOStoUEFIcb.Disable()
        self.useAutocb.Disable()
        self.useAutocb.SetValue(False)
        self.unchangedcb.SetValue(True)
        self.fwtyperadio1.SetValue(True)
        self.fwtyperadio2.SetValue(False)
        self.fwtyperadio3.SetValue(False)
        self.instbldestchoice.SetSelection(0)
        self.partitiontypechoice.SetSelection(0)

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.OnClose, self.exitbutton)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOpts4, self.unchangedcb)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOpts1, self.fwtyperadio1)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOpts2, self.fwtyperadio2)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOpts3, self.fwtyperadio3)

    def ActivateOpts1(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()

    def ActivateOpts2(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.UEFItoBIOScb.Enable()

    def ActivateOpts3(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.UEFItoBIOScb.Disable()
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Enable()

    def ActivateOpts4(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked():
            self.UEFItoBIOScb.Disable()
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
        else:
            if self.fwtyperadio1.GetValue():
                self.ActivateOpts1("Emptyarg")
            elif self.fwtyperadio2.GetValue():
                self.ActivateOpts2("Emptyarg")
            elif self.fwtyperadio3.GetValue():
                self.ActivateOpts3("Emptyarg")

    def OnClose(self,e):
        self.Destroy()

#Begin Device Info Window
class DevInfoWindow(wx.Frame):

    title = "WxFixBoot - Device Information"

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", (30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(300,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(60,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)

    def UpdDevInfo(self,e):
        #Generate device data.
        GetDevInfo()

        #Create/Update a list
        devicelist = []

        #New more efficent way of putting everything in one list.
        with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
            idedevicesfile = idedevicessource.readlines()
            if idedevicesfile != []:
                devicelist = devicelist + idedevicesfile
                devicelist.append('IDE/ATA Devices:')

        with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
            cddvddevicesfile = cddvddevicessource.readlines()
            if cddvddevicesfile != []:
                devicelist.append('CD/DVD Devices:')
                devicelist = devicelist + cddvddevicesfile

        with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
            usbsatadevicesfile = usbsatadevicessource.readlines()
            if usbsatadevicesfile != []:
                devicelist.append('USB or SATA Devices:')
                devicelist = devicelist + usbsatadevicesfile

        #Remove newline chars.
        devicelist = [(el.strip()) for el in devicelist]

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        self.Destroy()

#End Device Info Window
app = wx.App(False)
MainFrame = MainWindow()
MainFrame.Show()
app.MainLoop()
