#!/usr/bin/env python
# -*- coding: utf-8 -*-
# Logfile mover/remover for WxFixBoot version 1.0.1
# This file is part of WxFixBoot.
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# WxFixBoot is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# WxFixBoot is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with WxFixBoot.  If not, see <http://www.gnu.org/licenses/>.

#If this program was called by WxFixBoot.py, the is a log file already present at /var/log/wxfixboot.
#so ask the user if we should move it to /var/log/wxfixboot.log.old, or delete it.

#Import modules. 
import wx
import os
import subprocess

#Define a class with a single function to do the work.
class ManageLogFiles(wx.App):
    def OnInit(self):
        #Show the dialog.
        dlg = wx.MessageDialog(None, "WxFixBoot has detected that there is already a logfile present from a previous run. Click yes to save it to '/var/log/wxfixboot.log.old' for debug purposes, and click no to delete it.", "WxFixBoot - Question", style=wx.YES_NO | wx.ICON_QUESTION, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_YES:
            #Move it to /var/log/wxfixboot.log.old, using a one-liner, and don't bother handling any errors, because this is run as root.
            subprocess.Popen(['mv', '-f', '/var/log/wxfixboot.log', '/var/log/wxfixboot.log.old']).wait()
        else:
            #Delete it, and don't bother handling any errors, because this is run as root.
            os.remove('/var/log/wxfixboot.log')

        #Exit.
        return True

app = ManageLogFiles(False)
app.MainLoop()
