#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 1.0.2
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# WxFixBoot is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# WxFixBoot is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with WxFixBoot.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
from distutils.version import LooseVersion
import wx
import sys
from threading import Thread
import time
import os
import shutil
import subprocess
import logging
import getopt

def usage():
    print "\nUsage: WxFixBoot.py [OPTION]\n"
    print "       -h, --help:                   Show this help message"
    print "       -q, --quiet:                  Show only warning, error and critical messages in the log file. Very unhelpful for debugging, and not recommended."
    print "       -v, --verbose:                Enable logging of info messages, as well as warnings, errors and critical errors."
    print "                                     Not the best for debugging, but acceptable if there is little disk space."
    print "       -d, --debug:                  Log lots of boring debug messages, as well as information, warnings, errors and critical errors. Usually used for diagnostic purposes."
    print "                                     The default, as it's very helpful if problems are encountered, and the user needs help\n"
    print "WxFixBoot 1.0.2 is released under the GNU GPL Version 3"
    print "Copyright (C) Hamish McIntyre-Bhatty 2013-2014"

#If this isn't running as root, relaunch.
if not os.geteuid() == 0:
    subprocess.Popen(["/usr/share/wxfixboot/helperscripts/runasroot.sh"])
    sys.exit("\nSorry, this program must be run with root privileges.\nRestarting as Root...")

#Set up according to cmdline options.
try:
    opts, args = getopt.getopt(sys.argv[1:], "hqvd", ["help", "quiet", "verbose", "debug"])
except getopt.GetoptError as err:
    #Invalid option. Show the help message and then exit.
    #Show the error.
    print str(err)
    usage()
    sys.exit(2)

#Check if the logfile is already present.
if os.path.isfile('/var/log/wxfixboot.log'):
    #It is, so launch a helper script to deal with asking the user what to do (app.MainLoop() hasn't been called yet, so we can't yet use dialogs from this script). Also wait for it to finish before continuing.
    subprocess.Popen(['python', '/usr/share/wxfixboot/helperscripts/moveoldlogfiles.py']).wait()

#Set up logging.
logger = logging.getLogger('WxFixBoot 1.0.2')
logging.basicConfig(filename='/var/log/wxfixboot.log', format='%(asctime)s - %(name)s - %(levelname)s: %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p')
logger.setLevel(logging.DEBUG)

#Determine the option(s) given, and change the level of logging based on cmdline options.
for o, a in opts:
    if o in ["-q", "--quiet"]:
        logger.setLevel(logging.WARNING)
    elif o in ["-v", "--verbose"]:
        logger.setLevel(logging.INFO)
    elif o in ["-d", "--debug"]:
        logger.setLevel(logging.DEBUG)
    elif o in ["-h", "--help"]:
        usage()
        sys.exit()
    else:
        assert False, "unhandled option"

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen(["/usr/share/wxfixboot/helperscripts/listdevices.sh"]).wait()

    #Create/Update a device list
    devicelist = []

    #New more efficient way of putting everything in one list.
    with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
        idedevicesfile = idedevicessource.readlines()
        if idedevicesfile != []:
            devicelist = devicelist + idedevicesfile
            devicelist.append('IDE/ATA Devices:')

    with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
        cddvddevicesfile = cddvddevicessource.readlines()
        if cddvddevicesfile != []:
            devicelist.append('CD/DVD Devices:')
            devicelist = devicelist + cddvddevicesfile

    with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
        usbsatadevicesfile = usbsatadevicessource.readlines()
        if usbsatadevicesfile != []:
            devicelist.append('USB or SATA Devices:')
            devicelist = devicelist + usbsatadevicesfile

    #Remove newline chars.
    return [(el.strip()) for el in devicelist]

def DetermineTextPosition(Panel, text, PanelWidth):
    #Determine where to position text on a frame so it's centered.
    #This function doesn't have any default values, but we can still use keywords.
    NewPanelWidth = PanelWidth

    while True:
        #Calculate length (in pixels) of string given, and then where on the x-axis to place it.
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        #Keep this in a loop, so it can be rerun with increased widths until the text fits.
        font = Panel.GetFont()
        dc = wx.WindowDC(Panel)
        dc.SetFont(font)
        width, height = dc.GetTextExtent(text)

        xpos = (int(NewPanelWidth)-int(width))/2

        #Check the position isn't negative.
        if xpos >= 0:
            break
        else:
            #The text size must be larger than the window! Try again with a bigger width.
            NewPanelWidth += 50

    if NewPanelWidth == PanelWidth:
        #Return the Position.
        return xpos
    else:
        #Return the position and the new width for the panel.
        return [NewPanelWidth, xpos]

def SetDefaults():
    #Options in MainWindow
    global ReinstallBootloader
    global UpdateBootloader
    global QuickFSCheck
    global BadSectCheck
    ReinstallBootloader = False
    UpdateBootloader = False 
    QuickFSCheck = False
    BadSectCheck = False

    #Options in Optionsdlg1
    global SaveOutput
    global FullVerbose
    global Verify
    global BackupBootSector
    global BackupPartitionTable
    global MakeSystemSummary
    global BootloaderTimeout

    #Set them up for default settings.
    SaveOutput = True
    FullVerbose = False
    Verify = True
    BackupBootSector = False
    BackupPartitionTable = False
    MakeSystemSummary = True
    BootloaderTimeout = -1 #Don't change the timeout by default.

    #Options in Bootloader Options dlg
    global BootloaderToInstall
    global BLOptsDlgRun
    BootloaderToInstall = "None"
    BLOptsDlgRun = False

    #Options in Restore dlgs
    global RestoreBootSector
    global BootSectorFile
    global BootSectorTargetDevice
    global BootSectorBackupType
    global RestorePartitionTable
    global PartitionTableFile
    global PartitionTableTargetDevice
    global PartitionTableBackupType
    RestoreBootSector = False
    BootSectorFile = "None"
    BootSectorTargetDevice = "None"
    BootSectorBackupType = "None"
    RestorePartitionTable = False
    PartitionTableFile = "None"
    PartitionTableTargetDevice = "None"
    PartitionTableBackupType = "None"

    #Other Options
    global OptionsDlg1Run
    OptionsDlg1Run = False

def StartProcess(ExecCmds):
    #Start a process given a string with commands to execute.
    #This is here to counteract the language related bug, and to simplify the startup scripts.
    #Run the cmd, but run it though a special wrapper script, to ensure output is always English, fixing bug no 1353713.
    logger.debug("StartProcess(): Starting process: "+ExecCmds)
    runcmd = subprocess.Popen("LC_ALL=C "+ExecCmds, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
    stdout, stderr = runcmd.communicate()

    #Return the return code, and the output back to whichever function ran this process, so it can handle any errors.
    return [int(runcmd.returncode), str(stdout), str(stderr)]

def MountPartitionSafely(Partition, MountPoint):
    #Safely Mount Partitions here, as the code was getting duplicated.
    #Also, check that it isn't already mounted, and that nothing else is already mounted there.
    retval = StartProcess("df | grep "+MountPoint)[0]
    if retval == 0:
        #There is a partition mounted here. Check if it's the one we need mounted here.
        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            #Unmount the partition, and continue.
            logger.warning("MountPartitionSafely(): Unmounting filesystem in the way at "+MountPoint+"...")
            Temp = StartProcess("umount "+MountPoint)
            stdout = Temp[1]
            stderr = Temp[2]
            logger.debug("MountPartitionSafely(): Command: umount "+MountPoint+" stdout: "+stdout+", stderr: "+stderr)
        else:
            #The correct partition is already mounted here.
            logger.debug("MountPartitionSafely(): Partition: "+Partition+" was already mounted at: "+MountPoint+". Continuing...")
            return "Already Mounted"

    #Create the dir if needed.
    if os.path.isdir(MountPoint) == False:
        os.makedirs(MountPoint)
    
    #Mount the device to the mount point. No worries if it's already mounted, as we checked already, and even if it is, any kernel of 2.4 or newer supports mounting FSes twice, and otherwise it'll give an error anyway, which'll be caught and handled.
    Temp = StartProcess("mount "+Partition+" "+MountPoint)
    stdout = Temp[1]
    stderr = Temp[2]

    if stderr == "None" or stdout == "":
        return "Succeeded"
        logger.debug("MountPartitionSafely(): Command: mount "+Partition+" "+MountPoint+" Succeeded! stdout: "+stdout+", stderr: "+stderr)
    else:
        logger.warning("MountPartitionSafely(): Command: mount "+Partition+" "+MountPoint+" Failed! stdout: "+stdout+", stderr: "+stderr)
        return stdout

#Starter Class
class WxFixBoot(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = "/usr/share/wxfixboot/splash.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnCloseSplash)

        #Make sure it's painted, which fixes the problem with the previous temperamental splash screen on DDRescue-GUI <= 1.2
        wx.Yield()

    def OnCloseSplash(self,e):
        #Start the init Frame.
        self.Hide()
        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True

            #Reset the top window and start InitFrame()
            InitFrame = InitialWindow()
            app.SetTopWindow(InitFrame)
            InitFrame.Show(True)

            #Skip the event so the init frame starts.
            e.Skip()

#End splash screen
#Begin Initialization frame
class InitialWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,parent=None,title="WxFixBoot v1.0.2 is preparing to start...",size=(450,300),style=wx.CAPTION)
        self.InitPanel = wx.Panel(self)
        self.SetClientSize(wx.Size(450,300))

        print "WxFixBoot Version 1.0.2 Starting..."
        logger.info("WxFixBoot Version 1.0.2 Starting...")

        #Save the frame's width and height, making it easier to centre text.
        self.width, self.height = self.GetSizeTuple()

        #Create GUI elements
        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBar()

        #Start the Initalization Thread, which performs all necessary startup scripts and checks, and let it know this is the first start.
        logger.debug("Starting InitThread()...")
        InitThread(self,True)       

    def CreateText(self):
        self.DependsCheckText = wx.StaticText(self.InitPanel, -1, "Dependency check...", pos=(10,10))
        self.UnmountFSText = wx.StaticText(self.InitPanel, -1, "Unmounting all unneeded Filesystems...", pos=(10,30))
        self.CheckFSText = wx.StaticText(self.InitPanel, -1, "Quickly Checking Filesystems in fstab...", pos=(10,50))
        self.MountFSText = wx.StaticText(self.InitPanel, -1, "Mounting all Filesystems in fstab...", pos=(10,70))
        self.DetectDevsPartsPartSchemesText = wx.StaticText(self.InitPanel, -1, "Detecting Devices, Partitions, and Partition Schemes...", pos=(10,90))
        self.DetectPartText = wx.StaticText(self.InitPanel, -1, "Detecting Linux Partitions...", pos=(10,110))
        self.RootFSText = wx.StaticText(self.InitPanel, -1, "Determining Root Filesystem and Root Device...", pos=(10,130))
        self.DetectOSsText = wx.StaticText(self.InitPanel, -1, "Detecting Linux OSs...", pos=(10,150))
        self.FirmwareTypeText = wx.StaticText(self.InitPanel, -1, "Determining Firmware Type...", pos=(10,170))
        self.BootloaderText = wx.StaticText(self.InitPanel, -1, "Determining Boot Loader...", pos=(10,190))
        self.FinalCheckText = wx.StaticText(self.InitPanel, -1, "Final check...", pos=(10,210))

    def CreateButtons(self):
        #Create a button, and disable it, to stop the user clicking it before we're ready.
        self.startbutton = wx.Button(self.InitPanel, -1, "Start", pos=((self.width/2)-50,235), size=(100,30))
        self.startbutton.Disable()

        #Bind it to an event here.
        self.Bind(wx.EVT_BUTTON, self.FinishedInitConf, self.startbutton)

    def CreateProgressBar(self):
        #Create a progressbar.
        self.InitProgressBar = wx.Gauge(self.InitPanel, -1, 100, pos=(10,270), size=(self.width-20,25))
        self.InitProgressBar.SetBezelFace(3)
        self.InitProgressBar.SetShadowWidth(3)
        self.InitProgressBar.SetValue(0)
        self.InitProgressBar.Show()

    def UpdateProgressBar(self,msg):
        self.InitProgressBar.SetValue(int(msg))

    def ShowThreadMsgdlg(self,msg,kind="info"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=<kind>, msg=<message>)
        global dlgClosed
        if kind == "info":
            title = "WxFixBoot - Information"
            style = wx.OK | wx.ICON_INFORMATION
        elif kind == "warning":
            title = "WxFixBoot - Warning"
            style = wx.OK | wx.ICON_EXCLAMATION
        elif kind == "error":
            title = "WxFixBoot - Error"
            style = wx.OK | wx.ICON_ERROR

        dlg = wx.MessageDialog(self.InitPanel, msg, title, style, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadYesNodlg(self,msg,title="WxFixBoot - Question"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=<message>, title=<title>)
        global dlgResult
        dlg = wx.MessageDialog(self.InitPanel, msg, title, wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("InitialWindow().ShowThreadYesNodlg(): Result of InitThread yesno dlg was: "+dlgResult)

    def ShowThreadChoicedlg(self,msg,choices,title="WxFixBoot - Select an Option"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=<message>, title=<title>, choices=<data>)
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.InitPanel, msg, title, choices, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("InitialWindow().ShowThreadChoicedlg(): Result of InitThread choice dlg was: "+dlgResult)

    def ShowThreadTextEntrydlg(self,msg,title="WxFixBoot - Text Entry"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=<message>, title=<title>
        global dlgAnswer
        dlg = wx.TextEntryDialog(self.InitPanel, msg, title, "", style=wx.OK|wx.CANCEL, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetValue()
        else:
            dlgAnswer = "Clicked no..."
        logger.debug("InitialWindow().ShowThreadTextEntrydlg(): Result of InitThread text entry dlg was: "+dlgAnswer)

    def ResizeAndUpdateInitFrame(self):
        #We need to resize the panel for the text to fit.
        self.SetClientSize(wx.Size(self.width, self.height))

        #Recreate the progressbar and the Start button, so they're positioned properly.
        self.InitProgressBar.Destroy()
        self.CreateProgressBar()
        self.startbutton.Destroy()
        self.CreateButtons()

    def UpdateDependsCheckText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.DependsCheckText.SetLabel(msg)

    def UpdateUnmountFSText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.UnmountFSText.SetLabel(msg)

    def UpdateMountFSText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.MountFSText.SetLabel(msg)

    def UpdateDetectDevsPartsPartSchemesText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.DetectDevsPartsPartSchemesText.SetLabel(msg)

    def UpdateDetectPartText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.DetectPartText.SetLabel(msg) 

    def UpdateDetectOSsText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.DetectOSsText.SetLabel(msg) 

    def UpdateRootFSText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.RootFSText.SetLabel(msg)

    def UpdateFirmwareTypeText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.FirmwareTypeText.SetLabel(msg)

    def UpdatePartSchemeText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.PartSchemeText.SetLabel(msg)

    def UpdateBootloaderText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.BootloaderText.SetLabel(msg)

    def UpdateCheckFSText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.CheckFSText.SetLabel(msg)

    def UpdateFinalCheckText(self,msg):
        xpos = DetermineTextPosition(Panel=self.InitPanel, text=msg, PanelWidth=self.width)
        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.ResizeAndUpdateInitFrame()
            xpos = xpos[1]

        self.FinalCheckText.SetLabel(msg)
        self.startbutton.Enable()

    def FinishedInitConf(self,e):
        logger.info("Closing Initial Window and Starting Main Window...")

        #Show the user some important information
        wx.MessageDialog(self.InitPanel, "Make sure you have a working internet connection before performing any operations. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        self.Destroy()

        #Start MainFrame.
        MainFrame.Show(True)    

#End Initalization Frame
#Begin Initaization Thread.
class InitThread(Thread):
    def __init__(self, ParentWindow, Starting):
        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it, unless this isn't first run.
        #However, only delete it if no partitions are mounted in it. This has been done before during testing. Otherwise exit.
        self.Starting = Starting
        if self.Starting == True:
            retval = StartProcess("mount | grep '/tmp/wxfixboot'")
            if retval != 0:
                if os.path.isdir("/tmp/wxfixboot"):
                    shutil.rmtree("/tmp/wxfixboot")
                    logger.debug("InitThread(): Cleared WxFixBoot's temporary folder. Most of the time this doesn't need to be done, but it's probably not a problem. Logging this purely for paranoia's sake :)")
                os.mkdir("/tmp/wxfixboot")
            else:
                logger.critical("InitThread(): Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage. Exiting now...")
                self.ShowMsgDlg(Kind="error", Message="Error! Mounted filesystems were found in /tmp/wxfixboot! This should not happen! Please unmount them first to prevent damage. WxFixBoot will now exit.")
                wx.Exit()
                sys.exit("CRITICAL ERROR! Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage.")

        #Initialize the thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        self.start()

    def run(self):
        if self.Starting == True:
            #Set some default settings and wait for the GUI to initialize.
            logger.debug("InitThread(): Starting...")

            #Wait for the GUI.
            time.sleep(1)

            #Check for dependencies
            logger.info("InitThread(): Checking For Dependencies...")
            self.CheckDepends()
            wx.CallAfter(self.ParentWindow.UpdateDependsCheckText, "Dependency check... Passed!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "10")
            logger.info("InitThread(): Done Checking For Dependencies!")

            #Unmount all filesystems, to avoid any (highly unlikely) data corruption.
            logger.info("InitThread(): Unmounting Filesystems...")
            self.UnmountAllFS()
            wx.CallAfter(self.ParentWindow.UpdateUnmountFSText, "Unmounting all unneeded Filesystems... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "20")
            logger.info("InitThread(): Done Unmounting Filsystems!")

            #Check filesystems.
            logger.info("InitThread(): Checking Filesystems...")
            self.CheckFS()
            wx.CallAfter(self.ParentWindow.UpdateCheckFSText, "Quickly Checking Filesystems in fstab... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "30")
            logger.info("InitThread(): Filesystems Checked!")

            #Mount all filesystems.
            logger.info("InitThread(): Mounting Filesystems...")
            self.MountAllFS()
            wx.CallAfter(self.ParentWindow.UpdateMountFSText, "Mounting all Filesystems in fstab... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "40")
            logger.info("InitThread(): Done Mounting Filsystems!")

            #Detect Devices, Partitions, and Partition Schemes
            logger.info("InitThread(): Detecting Devices, Partitions, and PartSchemes...")
            self.DetectDevicesPartitionsAndPartSchemes()
            wx.CallAfter(self.ParentWindow.UpdateDetectDevsPartsPartSchemesText, "Detecting Devices, Partitions, and Partition Schemes... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "50")
            logger.info("InitThread(): Finished Detecting Devices, Partitions, and PartSchemes!")

            #Detect Linux Partitions.
            logger.info("InitThread(): Detecting Linux Partitions...")
            self.DetectLinuxPartitions()
            wx.CallAfter(self.ParentWindow.UpdateDetectPartText, "Detecting Linux Partitions... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "60")
            logger.info("InitThread(): Finished Detecting Linux Partitions!")
  
            #Get the root filesystem and root device.
            logger.info("InitThread(): Determining Root Filesystem and Root Device...")
            self.GetRootFSandRootDev()
            wx.CallAfter(self.ParentWindow.UpdateRootFSText, "Determining Root Filesystem and Root Device... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "70")
            logger.info("InitThread(): Determined Root Filesystem as: "+RootFS+ " , Root Device is "+RootDevice)

            #Get a list of Linux OSs (if LiveDisk = True, this has already been run).
            logger.info("InitThread(): Finding Linux OSs...")
            if LiveDisk == False:
                self.GetLinuxOSs()
            wx.CallAfter(self.ParentWindow.UpdateDetectOSsText, "Detecting Linux OSs... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "80")
            logger.info("InitThread(): Found all Linux OSs. Default: "+DefaultOS)

            #Get the firmware type.
            logger.info("InitThread(): Determining Firmware Type...")
            self.GetFirmwareType()
            wx.CallAfter(self.ParentWindow.UpdateFirmwareTypeText, "Determining Firmware Type... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "90")
            logger.info("InitThread(): Determined Firmware Type as: "+FirmwareType)

            #Get the Bootloader.
            logger.info("InitThread(): Determining The Bootloader...")
            self.GetBootloader()
            wx.CallAfter(self.ParentWindow.UpdateBootloaderText, "Determining Boot Loader... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "100")
            logger.info("InitThread(): Bootloader is: "+Bootloader)

            #Perform final check.
            logger.info("InitThread(): Doing Final Check for error situations...")
            self.FinalCheck()
            wx.CallAfter(self.ParentWindow.UpdateFinalCheckText, "Final check... Done!")
            logger.info("InitThread(): Done Final Check!")
            logger.info("InitThread(): Finished Determining Settings. Exiting InitThread()...")
        else:
            #Get the Bootloader. It reads self.Starting for itself.
            logger.info("InitThread(): Determining The Bootloader...")
            self.GetBootloader()
            logger.info("InitThread(): Bootloader is: "+Bootloader)

    def ShowMsgDlg(self,Message,Kind="info"):
        #Method to handle showing thread message dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowMsgDlg(Kind=<kind>, Message=<message>)
        #Reset dlgClosed, avoiding errors.
        global dlgClosed
        dlgClosed = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=Kind, msg=Message)

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

    def ShowYesNoDlg(self,Message,Title="WxFixBoot - Question"):
        #Method to handle showing thread yes/no dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowYesNoDlg(Message=<message>, Title = <title>)
        #Reset dlgResult, avoiding errors.
        global dlgResult
        dlgResult = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=Message, title=Title)

        #Trap the thread until the user responds.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        #Return dlgResult directly potentially avoiding problems.
        return dlgResult

    def ShowChoiceDlg(self,Message,Title,Choices):
        #Method to handle showing thread choice dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowChoiceDlg(Message=<message>, Title=<title>, Choices=<choices>)
        while True:
            #Reset dlgResult, avoiding errors.
            global dlgResult
            dlgResult = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=Message, title=Title, choices=Choices)

            #Trap the thread until the user responds.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgResult in ["", "Clicked no..."]:
                self.ShowMsgDlg(Kind="warning", Message="Please select a appropriate option.")
            else:
                #Return dlgResult directly potentially avoiding problems.
                return dlgResult

    def ShowTextEntryDlg(self,Message,Title="WxFixBoot - Text Entry"):
        #Method to handle showing thread text entry dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowTextEntryDlg(Message=<message>, Title=<title>)
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=Message, title=Title)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgAnswer == "":
                self.ShowMsgDlg(Kind="warning", Message="Please enter valid name or click cancel.")
            else:
                #Return dlgAnswer directly potentially avoiding problems.
                return dlgAnswer

    def CheckDepends(self):
        #This is a dependency checking function, will will show an error message and kill the app if the dependencies are not met.
        #Create a temporary list to allow WxFixBoot to notify of particular unmet dependencies.
        CmdList = ['mount', '-V', 'umount', '-V', 'parted' ,'-v', 'lsb_release', '-v', 'dmidecode', '-V', 'grep', '-V', 'lsblk', '--help', 'df', '--version', 'chroot', '--version', 'dd', '--version', 'find', '--version']

        #Create a list to contain names of failed commands.
        failedlist = []
        for command in CmdList:
            #If the command does not start with '-', run it as it isn't just an argument.
            if command[0] != "-":
                argument = CmdList[CmdList.index(command)+1]
                #Run the command with its argument and log the output (if in debug mode)
                Temp = StartProcess(command+" "+argument)
                retval = Temp[0]
                stdout = Temp[1]
                stderr = Temp[2]
                logger.debug("InitThread().CheckDepends(): Dependency check: Command: "+command+" stdout: "+stdout+", stderr: "+stderr)

                if retval != 0:
                    logger.error("InitThread().CheckDepends(): Dependency problems! Command: "+command+" failed to execute or wasn't found.")
                    logger.error("InitThread().CheckDepends(): The error was: "+stderr)
                    failedlist.append(command)

        #Check if any commands failed.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("InitThread().CheckDepends(): Dependencies missing! WxFixBoot will exit. The missing dependencies are: "+', '.join(failedlist)+"Exit.")
            self.ShowMsgDlg(Kind="error", Message="The following dependencies could not be found on your system: "+', '.join(failedlist)+"\nPlease install the missing dependencies. WxFixBoot will now exit.")

            wx.Exit()
            sys.exit("Missing dependencies: "+', '.join(failedlist)+" Exiting...")

    def UnmountAllFS(self):
        #Unmount any unnecessary filesystems, to prevent the very unlikely case of data corruption.
        #Warn about removing devices.
        self.ShowMsgDlg(Kind="info", Message="Unnecessary filesystems will now be unmounted. Please remove all unneeded devices connected to your computer and close any other running programs, then click okay. If you're doing a disk check, please plug in any devices you wish to check. However, if you are doing other operations, please do them seperately.")

        #Attempt unmount of all filesystems.
        Temp = StartProcess("umount -ad")
        stdout = Temp[1]
        stderr = Temp[2]
        logger.debug("InitThread().UnmountAllFS(): Command: 'umount -ad' stdout: "+stdout+", stderr: "+stderr)

        #Make sure that we still have rw access on live disks.
        Temp = StartProcess("mount -o remount,rw /")
        stdout = Temp[1]
        stderr = Temp[2]
        logger.debug("InitThread().UnmountAllFS(): Command: 'mount -o remount,rw /' stdout: "+stdout+", stderr: "+stderr)

    def CheckFS(self):
        #Check all non-mounted filesystems.
        Temp = StartProcess("fsck -ARMp")
        stdout = Temp[1]
        stderr = Temp[2]
        logger.debug("InitThread().CheckFS(): Command: 'fsck -ARMp' stdout: "+stdout+", stderr: "+stderr)

    def MountAllFS(self):
        #Mount filsystems defined in the /etc/fstab of the current operating system.
        #All other filesystems will be mounted when/as needed.
        Temp = StartProcess("mount -avw")
        stdout = Temp[1]
        stderr = Temp[2]
        logger.debug("InitThread().MountAllFS(): Command: 'mount -a' stdout: "+stdout+", stderr: "+stderr)
        logger.debug("InitThread().MountAllFS(): 'mount -a' ran fine, continuing...")

    def DetectDevicesPartitionsAndPartSchemes(self):
        #Detect all devices, partitions, and their partition schemes.
        #Define Global Variables.
        global PartitionListWithFSType
        global DeviceList
        global PartSchemeList
        global AutoPartSchemeList
        global GPTInAutoPartSchemeList
        global MBRInAutoPartSchemeList

        #Create a list for the devices.
        DeviceList = []

        #Create a list for Partition Schemes.
        AutoPartSchemeList = []

        #Create a list for the partitions.
        PartitionListWithFSType = []

        Output = StartProcess("lsblk -r -o NAME,FSTYPE | grep -v 'NAME'")[1]
        OutputList = Output.split()

        #Populate the device list, and the Partition List including FS Type.
        for element in OutputList:
            #Check if the element is a device, and doesn't end with a digit (isn't a partition).
            if element[0:2] in ['sd', 'hd'] and element[-1].isdigit() == False:

                #First AutoPartSchemeList
                try:
                    #Check if the element is already in DeviceList, as if it is, it won't be duplicated in AutoPartSchemeList either this way.
                    DeviceList.index('/dev/'+element)
                except ValueError:
                    #It isn't, add it.
                    PartScheme = self.GetDevPartScheme('/dev/'+element)
                    AutoPartSchemeList.append(PartScheme)

                #Now DeviceList
                try:
                    #Check if the element is already in DeviceList.
                    DeviceList.index(element)
                except ValueError:
                    #It isn't, add it.
                    DeviceList.append('/dev/'+element)

            #If instead the partition is not a device, but instead a partition of any type, add it to the Partition List with FSType, along with the next element, if it is not a device or partition.
            elif element[0:2] in ['sd', 'hd'] and element[-1].isdigit() == True:

                PartitionListWithFSType.append('/dev/'+element)
                Temp = OutputList[OutputList.index(element)+1]

                #Add the next element if it's an FSType. If it isn't, put "Unknown" in its place.
                if Temp[0:2] not in ['sd', 'hd']:
                    PartitionListWithFSType.append(Temp)
                else:
                    PartitionListWithFSType.append("Unknown")

        #Now set PartSchemeList the same as AutoPartSchemeList.
        PartSchemeList = AutoPartSchemeList[:]

        logger.debug("InitThread().DetectDevicesPartitionsAndPartSchemes(): DeviceList, PartitionListWithFSType and PartSchemeList Populated okay. Contents (respectively): "+', '.join(DeviceList)+" and: "+', '.join(PartitionListWithFSType)+" and: "+', '.join(PartSchemeList))

        #Finally, save two variables showing whether there are any mbr or gpt entries on the disks.
        #GPT
        try:
            PartSchemeList.index("gpt")
        except ValueError:
            GPTInAutoPartSchemeList = False
        else:
            GPTInAutoPartSchemeList = True

        #MBR(MSDOS)
        try:
            PartSchemeList.index("msdos")
        except ValueError:
            MBRInAutoPartSchemeList = False
        else:
            MBRInAutoPartSchemeList = True

    def GetDevPartScheme(self,Device):
        #Get the partition type on the given Device, and return it.
        Temp = StartProcess("parted -s "+Device+" print | grep 'Partition Table'")[1]
        return Temp.split()[2]

    def DetectLinuxPartitions(self):
        #Get a list of partitions of type ext (2,3 or 4) / btrfs / xfs / jfs / zfs / minix / reiserfs.
        global LinuxPartList

        #Run the command to find them, and save the results in a list.
        Output = StartProcess("lsblk -r -o NAME,FSTYPE | grep 'ext\|btrfs\|xfs\|jfs\|zfs\|minix\|reiserfs'")[1]
        OutputList = Output.split()

        #Check if there are any linux partitions in the list.
        if OutputList == []:
            #There are none, exit.
            logger.critical("InitThread().DetectLinuxPartitions(): No Linux Partitions of type ext(1,2,3,4), btrfs, xfs, jfs, zfs, minix or resierfs found! Exiting...")
            self.ShowMsgDlg(Kind="error", Message="You don't appear to have any Linux partitions. If you do have Linux partitions but WxFixBoot hasn't found them, please file a bug or ask a question on WxFixBoot's launchpad page. If you're using Windows or Mac OS X, then sorry as WxFixBoot has no support for these operating systems. You could instead use the tools provided by Microsoft and Apple to fix any issues with your computer. WxFixBoot will now exit.")

            #Exit.
            wx.Exit()
            sys.exit("Critical Error! No supported Linux filesystems found. Will now exit...")

        LinuxPartList = []

        #Create a list of only the partitions in the list.
        for element in OutputList:
            if element[0:2] in ['sd', 'hd'] and element[-1].isdigit():
                LinuxPartList.append('/dev/'+element)

        #Check if there are any linux partitions in the list.
        if LinuxPartList == []:
            #There are none, exit.
            logger.critical("InitThread().DetectLinuxPartitions(): No Linux Partitions (on HDD) of type ext(1,2,3,4), btrfs, xfs, jfs, zfs, minix or resierfs found! Exiting...")
            self.ShowMsgDlg(Kind="error", Message="You don't appear to have any Linux partitions on your Hard Disks. If you do have Linux partitions but WxFixBoot hasn't found them, please file a bug or ask a question on WxFixBoot's launchpad page. If you're using Windows or Mac OS X, then sorry as WxFixBoot has no support for these operating systems. You could instead use the tools provided by Microsoft and Apple to fix any issues with your computer. WxFixBoot will now exit.")

            #Exit.
            wx.Exit()
            sys.exit("Critical Error! No supported Linux filesystems (on HDD) found. Will now exit...")

        logger.debug("InitThread().DetectLinuxPartitions(): LinuxPartList Populated okay. Contents: "+', '.join(LinuxPartList))

    def GetRootFSandRootDev(self):
        #Determine RootFS, and RootDevice
        #Setup some global vars
        global AutoRootFS
        AutoRootFS = "Unknown"
        global RootFS
        global AutoRootDevice
        global RootDevice
        global LiveDisk
        global DefaultOS
        global AutoDefaultOS

        Result = self.ShowYesNoDlg(Message="Is WxFixBoot being run on a live disk, such as Parted Magic?", Title="WxFixBoot - Live Disk?")
        
        if Result == "Yes":
            logger.warning("InitThread().GetRootFSandRootDev(): User reported WxFixBoot is on a live disk...")

            #Make an early call to GetLinuxOSs()
            LiveDisk = True
            self.GetLinuxOSs()

            self.ShowChoiceDlg(Message="Please select the Linux Operating System you normally boot.", Title="WxFixBoot - Select Operating System", Choices=OSList)

            #Save the info.
            logger.info("InitThread().GetRootFSandRootDev(): User selected default Linux OS of: "+dlgResult+". Continuing...")
            DefaultOS = dlgResult
            AutoDefaultOS = DefaultOS
            RootFS = dlgResult.split()[-1]
            AutoRootFS = RootFS
            RootDevice = RootFS[0:8]
            AutoRootDevice = RootDevice 
        else:
            logger.warning("InitThread().GetRootFSandRootDev(): User reported WxFixBoot isn't on a live disk...")

            self.ShowMsgDlg(Kind="info", Message="Your current OS will be taken as the default OS. You can reset this later if you wish.")

            #By the way the default OS in this case is set later, when OS detection takes place.
            #Put this in a try loop, so the program can safely exit if it goes wrong.
            try:
                RootFS = StartProcess("df -k / | grep -v 'Filesystem'")[1].split()[0]

                #Add support for UUIDs here, as in Ubuntu 15.04 df gives UUIDs.
                if "/dev/disk/by-uuid" in RootFS:
                    #Get a list of UUIDs.
                    UUIDList = StartProcess("blkid")[1].split('\n')

                    #Reformat RootFS.
                    UUID = RootFS.split('/')[-1]

                    #Save the name instead of the UUID.
                    for e in UUIDList:
                        if UUID in e:
                            RootFS = e.split()[0].replace(':', '')

                AutoRootFS = RootFS
                RootDevice = RootFS[0:8]
                AutoRootDevice = RootDevice
                LiveDisk = False
            except:
                logger.critical("InitThread().GetRootFSandRootDev(): Couldn't determine the root device! This program cannot safely continue. WxFixBoot will now exit, and warn the user...")
                self.ShowMsgDlg(Kind="error", Message="WxFixBoot couldn't determine your root device (the device the current OS is running on)! The most likely reason for this is that you're running from a live disk and misreported it, so try restarting WxFixBoot and making the other choice. WxFixBoot will now exit.")
                wx.Exit()
                sys.exit("CRITICAL ERROR! Couldn't determine the root device! This program cannot safely continue. Exiting...")

    def GetLinuxOSs(self):
        #Get the names of all Linux OSs on the HDDs.
        global OSList
        global DefaultOS
        global AutoDefaultOS
        OSList = []

        #Get Linux OSs.
        logger.debug("InitThread().GetLinuxOSs(): Populating OSList...")
        for Partition in LinuxPartList:
            #Skip some stuff if we're ot on a live disk and Partition == AutoRootFS.
            if LiveDisk == False and Partition == AutoRootFS:
                #Look for an OS on this partition.
                Temp = StartProcess("lsb_release -sd")
                retval = Temp[0]
                OS = Temp[1].replace('\n', '')

                #Run the function to get the architechure, letting the function know that it shouldn't use chroot.
                OSArch = self.DetermineOSArchitecture(Partition=Partition, Chroot=False)

                #If the OS's name wasn't found, but its architecture was, there must be an OS here, so ask the user for its name.
                if retval != 0 and OSArch != "None":
                    #As this is the current OS, force the user to name it, or be stuck permanently in a loop.
                    OS = "None"
                    while OS == "None":
                        OS = self.AskForOSName(Partition=Partition, OSArch=OSArch)

                #Don't use elif here, so we'll also save it if self.AskForOSName() was used to determine the name. If it is still None, the user skipped naming it. Ignore it instead.
                if OS != "" and OSArch != "None":
                    #Add this information to the OSList, and set it as the default OS
                    DefaultOS = OS+' (Current OS) '+OSArch+' on partition '+Partition
                    AutoDefaultOS = DefaultOS
                    OSList.append(OS+' (Current OS) '+OSArch+' on partition '+Partition)

            elif Partition[0:7] in ['/dev/sd', '/dev/hd']:
                #We're interested in this element, because it's an HDD or usb disk partition.
                #Mount the partition safely, using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint="/mnt"+Partition)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, as it's safer to do so.
                    logger.warning("InitThread().GetLinuxOSs(): Command: 'mount "+Partition+" /mnt"+Partition+" -r' errored with stderr: "+retstr+"! Ignoring it, as it's safer using a very old linux kernel.")
                else:
                    #Look for an OS on this partition.
                    Temp = StartProcess("chroot /mnt"+Partition+" lsb_release -sd")
                    retval = Temp[0]
                    OS = Temp[1].replace('\n', '')

                    #Run the function to get the architechure, letting the function know that it shouldn't use chroot.
                    OSArch = self.DetermineOSArchitecture(Partition=Partition, Chroot=True)

                    #If the OS's name wasn't found, but its architecture was, there must be an OS here, so ask the user for its name.
                    if retval != 0 and OSArch != "None":
                        OS = self.AskForOSName(Partition=Partition, OSArch=OSArch)

                    #Don't use elif here, so we'll also save it if self.AskForOSName was used to determine the name. If it is still None, the user skipped naming it. Ignore it instead and skip the rest of the loop.
                    if OS != "None" and OSArch != "None":
                        #Add this information to the OSList.
                        OSList.append(OS+' '+OSArch+' on partition '+Partition)

                #Unmount the filesystem.
                time.sleep(0.2)
                StartProcess("umount /mnt"+Partition)

                #Remove the temporary mountpoint
                os.rmdir("/mnt/"+Partition)

        #Check that at least one Linux OS was detected.
        if len(OSList) >= 1:
            logger.debug("InitThread().GetLinuxOSs(): OSList Populated okay. Contents: "+', '.join(OSList))
        else:
            logger.critical("InitThread().GetLinuxOSs(): Couldn't find any linux operating systems! Linux partitions were detected, but don't appear to contain any OSs! WxFixBoot will now exit, and warn the user...")
            self.ShowMsgDlg(Kind="error", Message="Linux partitions were found on your computer, but no Linux operating systems were found! Perhaps you need to recover data from your hard drive, or restore an image first? If you're using Parted Magic, you'll have access to tools that can do that for you now. Otherwise, you may need to install them. WxFixBoot will now exit.")
            wx.Exit()
            sys.exit("CRITICAL ERROR! Couldn't find any linux operating systems! Linux partitions were detected, but don't appear to contain any OSs! Exiting...")

    def DetermineOSArchitecture(self, Partition, Chroot):
        #Look for OS architecture on given partition, looking for 64-bit first, then 32-bit.
        #First set cmd to 64-bit to get it looking for the 64-bit arch first. 
        lookfor = "64-bit"

        #Use a loop to avoid duplicating code.
        while True:
            #Prepare the command based on which arch we're looking for.
            if lookfor == "64-bit":
                cmd = "file -L /usr/bin/ld | grep -wo '64-bit'"
            else:
                cmd = "file -L /usr/bin/ld | grep -wo '32-bit'"

            #If we're using chroot, add that to the command.
            if Chroot == True:
                cmd = "chroot /mnt"+Partition+" "+cmd

            #Now let's check if the OS uses this arch.
            Temp = StartProcess(cmd)
            PartitionArch = Temp[1].replace('\n', '')
            retval = Temp[0]

            if retval != 0 and lookfor == "64-bit":
                #Now look for 32-bit and restart the loop.
                lookfor = "32-bit"
            elif retval != 0:
                #We couldn't find it as either 32-bit or 64-bit!
                PartitionArch = "None"
                break
            else:
                break

        #Return the arch (or None, if we didn't find it).
        return PartitionArch

    def AskForOSName(self,Partition,OSArch):
        #Ask the user if an OS exists on the given partition.
        #This might be a very old linux OS.
        if Partition == AutoRootFS:
            self.ShowMsgDlg(Kind="warning", Message="WxFixBoot couldn't find the name of the current OS. Please name it so that WxFixBoot can function correctly.")
            Result = "Yes"
        else:
            Result = self.ShowYesNoDlg(Message="There is a Linux operating system on partition: "+Partition+" but WxFixBoot couldn't find its name. It isn't the currently running OS. Do you want to name it and include it in the list?. Only click yes if you believe it is a recent OS.")

        if Result == "No":
            logger.info("InitThread().AskForOSName(): User didn't want to name the OS in "+Partition+"! Ignoring it...")
            #User reported no OS in this partition, ignore it.
            return "None"
        else:
            logger.debug("InitThread().AskForOSName(): User reported recent Linux OS in "+Partition+". Asking name of OS...")
            #User reported that an OS is here.
            Result = self.ShowTextEntryDlg(Message="Please enter the name of the operating system that is on "+Partition+".\nIf this is an old Linux distribution, it's probably better to click no here and ignore it for safety reasons, with the exception of it being the currently running OS.\nThe name you specify will be used later in the program", Title="WxFixBoot - Enter OS Name")

            if Result == "Clicked no...":
                logger.debug("InitThread().AskForOSName(): User reported old OS in "+Partition+". Continuing and ignoring it...")
                #User reported old OS in this partition, ignore it.
                return "None"
            else:
                return Result

    def GetFirmwareType(self):
        #Get the firmware type.
        global FirmwareType
        global AutoFirmwareType
        global UEFIVariables

        #Set UEFIVariables to prevent an error on BIOS systems.
        UEFIVariables = False

        #Check if the firmware type is UEFI.
        retval = StartProcess("dmidecode -q -t BIOS | grep 'UEFI'")[0]

        if retval != 0:
            #It's BIOS.
            logger.info("InitThread().GetFirmwareType(): Detected Firmware Type as BIOS...")
            FirmwareType = "BIOS"
            AutoFirmwareType = "BIOS"
        else:
            #It's UEFI.
            logger.info("InitThread().GetFirmwareType(): Detected Firmware Type as UEFI. Looking for UEFI Variables...")
            FirmwareType = "UEFI"
            AutoFirmwareType = "UEFI"

            #Also, look for UEFI variables.
            #Make sure efivars module is loaded. If it doesn't exist, continue anyway.
            Temp = StartProcess("modprobe efivars")
            stdout = Temp[1].replace('\n', '')
            stderr = Temp[2]
            logger.debug("InitThread().GetFirmwareType(): Command: 'modprobe efivars' stdout: "+stdout+", stderr: "+stderr)

            #Look for the UEFI vars in some common directories.
            if os.path.isdir("/sys/firmware/efi/vars"):
                UEFIVariables = True
                logger.info("InitThread().GetFirmwareType(): Found UEFI Variables at /sys/firmware/efi/vars...")
            elif os.path.isdir("/sys/firmware/efi/efivars"):  
                UEFIVariables = True
                logger.info("InitThread().GetFirmwareType(): Found UEFI Variables at /sys/firmware/efi/efivars...")
            else:
                logger.warning("InitThread().GetFirmwareType(): UEFI vars not found in /sys/firmware/efi/vars or /sys/firmware/efi/efivars. Attempting manual mount...")
                #Attempt to manually mount the efi vars, as we couldn't find them.
                if not os.path.isdir("/sys/firmware/efi/vars"):
                    os.mkdir("/sys/firmware/efi/vars")

                Temp = StartProcess("mount -t efivarfs efivars /sys/firmware/efi/vars")
                stdout = Temp[1].replace('\n', '')
                stderr = Temp[2]
                if stderr == "None" or stdout != "None":
                    logger.warning("InitThread().GetFirmwareType(): Failed to mount UEFI vars! Warning user. Ignoring and continuing.")
                    #UEFI vars not available or couldn't be mounted.
                    self.ShowMsgDlg(Kind="warning", Message="Your computer uses UEFI firmware, but the UEFI variables couldn't be mounted or weren't found. Please ensure you've booted in UEFI mode rather than legacy mode to enable access to the UEFI variables. You can attempt installing a UEFI bootloader without them, but it might not work, and it isn't recommended.")
                else:
                    #Successfully mounted them.
                    UEFIVariables = True
                    logger.info("InitThread().GetFirmwareType(): Mounted UEFI Variables at: /sys/firmware/efi/vars. Continuing...")

    def GetBootloader(self):
        #Determine the current bootloader.
        global Bootloader
        global AutoBootloader
        global PrevBootloaderSetting
        global AutoUEFISystemPartition
        global UEFISystemPartition
        global OSList
        global HelpfulUEFIPartition
        global FatPartitions
        if self.Starting == True:
            HelpfulUEFIPartition = False
            PrevBootloaderSetting = "None"
            UEFISystemPartition = "None"
            AutoUEFISystemPartition = "None"
            FatPartitions=['None']

        #Run some inital scripts
        logger.debug("InitThread().GetBootloader(): Copying MBR bootsector to /tmp/wxfixboot/mbrbootsect...")
        Temp = StartProcess("dd if="+RootDevice+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect")
        stdout = Temp[1].replace('\n', '')
        stderr = Temp[2]
        logger.debug("InitThread().GetBootloader(): GetBootloader: Command: 'dd if="+RootDevice+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect' stdout: "+stdout+", stderr: "+stderr)
        
        logger.debug("InitThread().GetBootloader(): Copied MBR bootsector to file.")

        #Wrap this in a loop, so once a Bootloader is found, searching can stop.
        while True:
            #Check for a UEFI partition, but only if this is the first run.
            #Otherwise, skip some stuff.
            if self.Starting == True:
                #Check for a UEFI system partition.
                logger.debug("InitThread().GetBootloader(): Checking For a UEFI partition...")
                AutoUEFISystemPartition = self.CheckForUEFIPartition()
                UEFISystemPartition = AutoUEFISystemPartition

            #If there is no UEFI partition, ask the user.
            if UEFISystemPartition[0:7] not in ["/dev/sd", "/dev/hd"]:
                #There is no UEFI partition.
                #If self.Starting = True, then we'll look for BIOS bootloaders here.
                if self.Starting == True:
                    #Check for GRUB in the MBR
                    logger.debug("InitThread().GetBootloader(): Checking for GRUB in bootsector...")
                    AutoBootloader = self.CheckForGRUBBIOS()
                    if AutoBootloader == "GRUB2":
                        AutoBootloader = self.DetermineGRUBBIOSVersion()
                        break

                    #Check for LILO in MBR
                    logger.debug("InitThread().GetBootloader(): Checking for LILO in bootsector...")
                    AutoBootloader = self.CheckForLILO()
                    if AutoBootloader == "LILO":
                        logger.info("InitThread().GetBootloader(): Found LILO in MBR (shown as LILO in GUI. Continuing...")
                        break

                #No bootloader was found, so ask the user instead.
                #Do a manual selection of the bootloader.
                logger.warning("InitThread().GetBootloader(): Asking user what the bootloader is, as neither GRUB nor LILO was detected in MBR, and no UEFI partition was found...")
                AutoBootloader = self.ManualBootloaderSelect()
                break

            #Mount (or skip if mounted) the UEFI partition.
            logger.info("InitThread().GetBootloader(): Attempting to mount the UEFI partition (if it isn't already)...")
            UEFISYSPMountPoint = self.MountUEFIPartition(UEFISystemPartition)
            logger.info("InitThread().GetBootloader(): UEFI Partition mounted at: "+UEFISYSPMountPoint+". Continuing to look for UEFI bootloaders...")

            #Attempt to figure out which bootloader is present.
            #Check for GRUB-UEFI
            logger.debug("InitThread().GetBootloader(): Checking for GRUB-UEFI in UEFI Partition...")
            AutoBootloader = self.CheckForGRUBUEFI(UEFISYSPMountPoint)
            if AutoBootloader == "GRUB-UEFI":
                logger.info("InitThread().GetBootloader(): Found GRUB in UEFI Partition (shown as GRUB-UEFI in GUI). Continuing...")
                break

            #Check for ELILO
            logger.debug("InitThread().GetBootloader(): Checking for ELILO (ELILO) in UEFI Partition...")
            AutoBootloader = self.CheckForELILO(UEFISYSPMountPoint)
            if AutoBootloader == "ELILO":
                logger.info("InitThread().GetBootloader(): Found LILO in UEFI Partition (shown as ELILO in GUI). Continuing...")
                break

            #Obviously, no bootloader has been found.
            #Do a manual selection.
            logger.warning("InitThread().GetBootloader(): Asking user what the bootloader is, as no bootloader was found...")
            AutoBootloader = self.ManualBootloaderSelect()

            #The program waits until something was chosen, so if it executes this, the bootloader has been set.
            break

        #Set the default bootloader value.
        Bootloader = AutoBootloader

        #If this was started after selecting a new bootloader, send a message to OptionsWindow2, so the program continues.
        if self.Starting == False:
            wx.CallAfter(self.ParentWindow.UEFIPartitionScanned, AutoBootloader)

    def CheckForUEFIPartition(self):
        global FatPartitions
        FatPartitions = ['None']

        #Get a list of partitions of type vfat, if any.
        OutputList = StartProcess("lsblk -r -o NAME,FSTYPE | grep 'vfat'")[1].split()

        #Create another list of only the devices. Ignore anything else.
        for element in OutputList:
            if element[0:2] in ['sd', 'hd']:
                FatPartitions.append("/dev/"+element)

        if LiveDisk == False:
            try:
                UEFISystemPartition = "/dev/"+StartProcess("lsblk -r -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep '/boot'")[1].split()[0]
            except IndexError:
                logger.warning("InitThread().CheckForUEFIPartition(): Failed to find the UEFI Partition. Trying another way...")
                #Try a second way to get the UEFI system partition.
                try:
                    UEFISystemPartition = "/dev/"+StartProcess("lsblk -r -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep 'ESP'")[1].split()[0]
                except IndexError:
                    #Ask the user where it is.
                    logger.warning("InitThread().CheckForUEFIPartition(): Couldn't autodetermine UEFI Partition. Asking the user instead...")
                    AskForUEFIPartition = True
                else:
                    logger.info("InitThread().CheckForUEFIPartition(): Found UEFI Partition at: "+UEFISystemPartition)
                    return UEFISystemPartition
            else:
                logger.info("InitThread().CheckForUEFIPartition(): Found UEFI Partition at: "+UEFISystemPartition)
                return UEFISystemPartition

        if LiveDisk == True or AskForUEFIPartition == True:
            logger.warning("InitThread().CheckForUEFIPartition(): Asking user where UEFI Partition is. If you're running from a live disk, ignore this warning.")
            if FatPartitions != ['None']:
                Result = self.ShowChoiceDlg(Message="Please select your UEFI partition. You can change this later in the bootloader options window if you change your mind, or if it's wrong.\nSelect 'None' if you don't have a UEFI partition.", Title="WxFixBoot - Select UEFI Partition", Choices=FatPartitions)

                if Result in ["Clicked no...", "None"]:
                    logger.warning("InitThread().CheckForUEFIPartition(): User said no UEFI Partition exists. Continuing...")
                    return "None"
                else:
                    logger.info("InitThread().CheckForUEFIPartition(): User reported UEFI partition at: "+Result+". Continuing...")
                    return Result
            else:
                return "None"
                    
    def MountUEFIPartition(self,UEFISystemPartition):
        #Get the UEFI partition's current mountpoint, if it is mounted.
        logger.debug("InitThread().MountUEFIPartition(): Preparing to mount UEFI system Partition if needed...")

        #It isn't mounted, mount it, and also create the directory if needed.
        logger.debug("InitThread().MountUEFIPartition(): Mounting UEFI Partition at /boot/efi...")
        UEFISYSPMountPoint = "/boot/efi"

        #Mount it using the global mount function.            
        Result = MountPartitionSafely(Partition=UEFISystemPartition, MountPoint=UEFISYSPMountPoint)
        if Result == "Success":
            logger.info("InitThread().MountUEFIPartition(): Successfully Mounted UEFI Partition...")
        elif Result == "Already Mounted":
            logger.info("InitThread().MountUEFIPartition(): UEFI Partition already mounted at /boot/efi...")
        else:
            #This very rarely happens!
            logger.error("InitThread().MountUEFIPartition(): Failed to mount UEFI Partition! Continuing anyway, with reported mountpoint as /boot/efi...")
        
        return UEFISYSPMountPoint

    def CheckForGRUBBIOS(self):
        #Check for GRUB (2 and Legacy)
        Temp = StartProcess("cat /tmp/wxfixboot/mbrbootsect | grep 'GRUB'")[1].replace('\n', '')
        if Temp == "Binary file (standard input) matches":
            #Bootloader is GRUB MBR
            return "GRUB2"
        else:
            return "Not GRUB MBR"

    def DetermineGRUBBIOSVersion(self):
        #Check if the system is using grub-legacy or grub2.
        if LiveDisk == False:
            #Find the name of the current OS.
            for OS in OSList:
                if OS.split()[-5] == "OS)":
                    currentos = ' '.join(OS.split()[0:-6])
                else:
                    currentos = "Unknown"

            #Ask the user if this OS installed the bootloader.
            Result = self.ShowYesNoDlg(Message="Was the bootloader installed by the current OS ("+currentos+")? If this OS is the most recently installed one, it probably installed the bootloader. If you're not sure, click No.")
        
            if Result == "Yes":
                #Run a command to print grub's version.
                Temp = StartProcess("grub-install --version")
                stdout = Temp[1].replace('\n', '')
                stderr = Temp[2]
                logger.debug("InitThread().DetermineGRUBVersion(): Command: 'grub-install --version' stdout: "+stdout+", stderr: "+stderr)

                #Try to grab the first number in the list, getting rid of the brackets. If it fails, we've almost certainly got GRUB2.
                Temp = "empty"
                stdout = stdout.replace("(", "").replace(")", "")
                for version in stdout.split():
                    try:
                        float(version)
                    except ValueError: pass
                    else:
                        Temp = version
                        break

                #Check if there is a version number found. If not, it's grub2.
                if Temp == "empty":
                    logger.info("InitThread().DetermineGRUBVersion(): Found GRUB2 in MBR (Shown as GRUB2 in GUI). Continuing...")
                    return "GRUB2"
                else:
                    #If a number was found, check if it's lower than or equal to 1.97 (aka it's grub legacy)
                    if float(Temp) <= 1.97:
                        return "GRUB-LEGACY"
                        logger.warning("InitThread().DetermineGRUBVersion(): Found GRUB-LEGACY in MBR! Some options will be disabled, as grub legacy isn't fully supported because it is obsolete. Continuing...")
                    else:
                        logger.info("InitThread().DetermineGRUBVersion(): Found GRUB2 in MBR (Shown as GRUB2 in GUI). Continuing...")
                        return "GRUB2"
        
        #Ask the user (this'll be run if user said no to YesNo dlg above too -- this isn't in an else staement).
        logger.info("InitThread().DetermineGRUBVersion(): Only listing GRUB2 and GRUB-LEGACY, as WxFixBoot couldn't tell if bootloader was grub2 or legacy.")
        Result = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine if your bootloader was GRUB-LEGACY or GRUB2, so please specify which one it is here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2"])

        if Result != "GRUB-LEGACY/I don't know":
            logger.debug("InitThread().DetermineGRUBVersion(): User reported bootloader is: "+Result+". Continuing...")
            return Result
        else:
            logger.debug("InitThread().DetermineGRUBVersion(): User reported bootloader is: GRUB-LEGACY. Continuing...")
            return "GRUB-LEGACY"

    def CheckForLILO(self):
        #Check for LILO in MBR
        Temp = StartProcess("cat /tmp/wxfixboot/mbrbootsect | grep 'LILO'")[1].replace('\n', '')
        if Temp == "Binary file (standard input) matches":
            #Bootloader is LILO in MBR
            return "LILO"
        else:
            return "Not LILO MBR"

    def CheckForGRUBUEFI(self,UEFISYSPMountPoint):
        global HelpfulUEFIPartition
        #Look for GRUB's UEFI file.
        Temp = StartProcess("find "+UEFISYSPMountPoint+" -iname '*grub*.efi'")[1].replace('\n', '')
        if Temp == "":
            Bootloader = "Not GRUB-UEFI"
            HelpfulUEFIPartition = False
        else:
            #Bootloader is GRUB-UEFI.
            Bootloader = "GRUB-UEFI"
            HelpfulUEFIPartition = True

        return Bootloader

    def CheckForELILO(self,UEFISYSPMountPoint):
        global HelpfulUEFIPartition
        #Look for LILO's UEFI file.
        Temp = StartProcess("find "+UEFISYSPMountPoint+" -iname '*elilo*.efi'")[1].replace('\n', '')
        if Temp == "":
            Bootloader = "Not ELILO"
            HelpfulUEFIPartition = False
        else:
            #Bootloader is ELILO.
            Bootloader = "ELILO"
            HelpfulUEFIPartition = True

        return Bootloader

    def ManualBootloaderSelect(self):
        logger.debug("InitThread().ManualBootloaderSelect(): Manually selecting bootloader...")
        #Offer different selection based on the current state of the system.
        if UEFISystemPartition == "None" and FirmwareType == "UEFI":
            logger.warning("InitThread().ManualBootloaderSelect(): Only listing BIOS bootloaders, as there is no UEFI partition.")
            Result = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2", "LILO"])

        elif UEFISystemPartition != "None" and FirmwareType == "UEFI":
            Result = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2", "GRUB-UEFI", "LILO", "ELILO"])

        else:
            logger.info("InitThread().ManualBootloaderSelect(): Only listing BIOS bootloaders, as this is a BIOS system.")
            Result = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2", "LILO"])

        if Result != "GRUB-LEGACY/I don't know":
            logger.debug("InitThread().ManualBootloaderSelect(): User reported bootloader is: "+Result+". Continuing...")
            return dlgResult
        else:
            logger.debug("InitThread().ManualBootloaderSelect(): User reported bootloader is: GRUB-LEGACY. Continuing...")
            return "GRUB-LEGACY"

    def FinalCheck(self):
        #Check for any conflicting options, and that each variable is set.
        global AutoFirmwareType
        global FirmwareType

        #Create a temporary list containing all variables to be checked, and a list to contain failed variables.
        VarList = ['LiveDisk', 'PartitionListWithFSType', 'LinuxPartList', 'DeviceList', 'AutoRootFS', 'RootFS', 'AutoRootDevice', 'RootDevice', 'LiveDisk', 'DefaultOS', 'AutoDefaultOS', 'OSList', 'FirmwareType', 'AutoFirmwareType', 'UEFIVariables', 'PartSchemeList', 'AutoPartSchemeList', 'GPTInAutoPartSchemeList', 'MBRInAutoPartSchemeList', 'Bootloader', 'AutoBootloader', 'PrevBootloaderSetting', 'UEFISystemPartition', 'HelpfulUEFIPartition']
        FailedList = []

        #Check each global variable is set and declared.
        for var in VarList:
            if var in globals():
                if var == None:
                    #It isn't set.                    
                    logger.critical("InitThread().FinalCheck(): Variable "+var+" hasn't been set, adding it to the failed list...")
                    FailedList.append(var)
            else:
                #It isn't declared.                    
                logger.critical("InitThread().FinalCheck(): Variable "+var+" hasn't been declared, adding it to the failed list...")
                FailedList.append(var)

        #Check if any variables weren't set.
        if FailedList != []:
            #Missing dependencies!
            logger.critical("InitThread().FinalCheck(): Required Settings: "+', '.join(FailedList)+" have not been Determined! This is probably a bug in the program! Exiting...")
            self.ShowMsgDlg(Kind="error", Message="The required variables: "+', '.join(FailedList)+", have not been set! WxFixBoot will now shut down to prevent damage to your system. This is probably a bug in the program. Check the log file at /var/log/wxfixboot.log")

            wx.Exit()
            sys.exit("WxFixBoot: Critial Error: Incorrectly set settings:"+', '.join(FailedList)+" Exiting...")

        #Set some other variables to default values, avoiding problems down the line.
        SetDefaults()

        #Check and warn about conflicting settings.
        #Firmware type warnings.
        if FirmwareType == "BIOS" and Bootloader in ['GRUB-UEFI', 'ELILO']:
            logger.warning("InitThread().FinalCheck(): Bootloader is UEFI-type, but system firmware is BIOS! Odd, perhaps a migrated drive? Continuing and setting firmware type to UEFI...")
            self.ShowMsgDlg(Kind="warning", Message="Your computer seems to use BIOS firmware, but you're using a UEFI-enabled bootloader! WxFixBoot reckons your firmware type was misdetected, and will now set it to UEFI. BIOS firmware does not support booting UEFI-enabled bootloaders, so if you think your firmware type actually is BIOS, it is recommended to install a BIOS-enabled bootloader instead, such as GRUB2. You can safely ignore this message if your firmware type is UEFI.")
            AutoFirmwareType = "UEFI"
            FirmwareType = "UEFI"

        if FirmwareType == "BIOS" and GPTInAutoPartSchemeList == True:
            logger.warning("InitThread().FinalCheck(): Firmware is BIOS, but at least one device on the system is using a gpt partition table! This device probably won't be bootable. WxFixBoot suggests repartitioning, if you intend to boot from that device.")
            self.ShowMsgDlg(Kind="warning", Message="Your computer uses BIOS firmware, but you're using an incompatable partition system on at least one device! BIOS firmware will probably fail to boot your operating system, if it resides on that device, so a repartition may be necessary for that device. You can safely ignore this message if your firmware type has been misdetected, or if you aren't booting from that device.")

        #Partition scheme warnings.
        if MBRInAutoPartSchemeList == True and Bootloader in ['GRUB-UEFI', 'ELILO']:
            logger.warning("InitThread().FinalCheck(): MBR partition table on at least one device, and a UEFI bootloader is in use! This might not work properly. WxFixBoot suggests repartitioning.")
            self.ShowMsgDlg(Kind="warning", Message="You're using a UEFI-enabled bootloader, but you're using an incompatable partition system on at least one device! Some firmware might not support this setup, especially if the UEFI system partition resides on this device, so it is recommended to repartition the device. Ignore this message if you do not boot from this device.")

        if GPTInAutoPartSchemeList == True and Bootloader in ['GRUB2', 'LILO', 'GRUB-LEGACY']:
            logger.warning("InitThread().FinalCheck(): GPT Partition table on at least one device with msdos bootloader! Most BIOS firmware cannot read GPT disks. WxFixBoot suggests repartitioning.")
            self.ShowMsgDlg(Kind="warning", Message="You're using a BIOS-enabled bootloader, but you're using an incompatable partition system on at least one device! Most firmware will not support this setup. Ignore this message if you do not boot from this device.")

        #Bootloader warnings.
        if HelpfulUEFIPartition == False and UEFISystemPartition != "None":
            logger.warning("InitThread().FinalCheck(): Empty UEFI partition!")
            self.ShowMsgDlg(Kind="warning", Message="Your UEFI system partition is empty or doesn't contain any detected bootloaders. If you just created your UEFI system partition, please ensure it's formatted as fat32 or fat16 (Known as vfat in Linux), and then you may continue to install a UEFI bootloader on it. If WxFixBoot didn't detect your UEFI-enabled bootloader, it's still safe to perform operations on the bootloader.")        

#End Initalization Thread.
#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0.2 (6/12/2014)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)
        self.SetClientSize(wx.Size(400,300))

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Save the frame's width and height, making it easier to centre text.
        self.width, self.height = self.GetSizeTuple()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Set up checkboxes
        self.OnCheckBox("empty arg")

        #Bind all events.
        self.BindEvents()

        logger.debug("MainWindow().__init__(): Started. Waiting for events...")

        #Show the about box.
        self.OnAbout("Empty Arg")

    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text, and also calculate the centre position for each text string.
        xpos = DetermineTextPosition(Panel=self.MainPanel, text="Please set the basic settings here first.", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.MainPanel, -1, "Please set the basic settings here first.", pos=(xpos,35))
        xpos = DetermineTextPosition(Panel=self.MainPanel, text="Welcome to WxFixBoot!", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(xpos,15))

        #Add an image.
        img = wx.Image("/usr/share/pixmaps/wxfixboot.png", wx.BITMAP_TYPE_PNG)
        wx.StaticBitmap(self.MainPanel, -1, wx.BitmapFromImage(img), pos=(290,70))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220), size=(90,30))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220), size=(90,30))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(115,220), size=(165,30))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply All Operations", pos=(120,180), size=(150,30))

    def CreateCBs(self):
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorough)", pos=(10,60))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", pos=(10,90))
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall/Fix Bootloader", pos=(10,120))
        self.updateblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Bootloader Config", pos=(10,150))

        #If bootloader is grub legacy, disable some options.
        if Bootloader == "GRUB-LEGACY":
            self.DisableBLOptsGrubLegacy()

    def DisableBLOptsGrubLegacy(self):
        self.reinstblcb.Disable()
        self.updateblcb.Disable()

    def EnableBLOptsNoGrubLegacy(self):
        self.reinstblcb.Enable()
        self.reinstblcb.SetValue(False)
        self.updateblcb.Enable()
        self.updateblcb.SetValue(False)

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate this program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_PREFERENCES, "&Options", "General settings used to modify your system")

        #Creating the menubar.
        menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        menuBar.Append(filemenu,"&File")
        menuBar.Append(editmenu,"&Edit")
        menuBar.Append(viewmenu,"&View")
        menuBar.Append(helpmenu,"&Help")

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(menuBar)

    def OnCheckBox(self,e):
        logger.debug("MainWindow().OnCheckBox() was triggered.")
        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
        else:
            self.chkfscb.Enable()

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
        else:
            self.badsectcheckcb.Enable()

        #Reinstall Bootloader Choicebox
        if self.reinstblcb.IsChecked() and (Bootloader != "GRUB-LEGACY" or RestorePartitionTable == True or RestoreBootSector == True):
            self.reinstblcbwaschecked = True
            self.updateblcb.SetValue(0)
            self.updateblcb.Disable()
        elif self.reinstblcb.IsChecked() == False and Bootloader != "GRUB-LEGACY" and RestorePartitionTable == False and RestoreBootSector == False:
            self.updateblcb.Enable()
            self.reinstblcbwaschecked = False
        else:
            self.reinstblcb.SetValue(0)
            self.reinstblcbwaschecked = False

        #Update Bootloader Choicebox
        if self.updateblcb.IsChecked() and (Bootloader != "GRUB-LEGACY" or RestorePartitionTable == True or RestoreBootSector == True):
            self.updateblcbwaschecked = True
            self.reinstblcb.SetValue(0)
            self.reinstblcb.Disable()
        elif self.updateblcb.IsChecked() == False and Bootloader != "GRUB-LEGACY" and RestorePartitionTable == False and RestoreBootSector == False:
            self.reinstblcb.Enable()
            self.updateblcbwaschecked = False
        else:
            self.updateblcb.SetValue(0)
            self.updateblcbwaschecked = False

    def Opts(self,e):
        global OptionsDlg1Run
        logger.debug("MainWindow().Opts(): Starting Options Window 1 and hiding MainWindow...")

        if self.reinstblcbwaschecked == True or self.updateblcbwaschecked == True:
            dlg = wx.MessageDialog(self.MainPanel, "Do you want to continue? If you reinstall or update your bootloader, some options, such as installing a different bootloader, and restoring backups of the bootsector and partition table, will be reset and disabled. If you want to change other settings, you can always do it after restarting WxFixBoot.", "WxFixBoot - Question", style=wx.YES_NO | wx.ICON_QUESTION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_NO:
                wx.MessageDialog(self.MainPanel, "You will now be returned to the Main Window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                return

        self.SaveMainOpts()

        if UEFISystemPartition == "None":
            wx.MessageDialog(self.MainPanel, "Seeing as you have no UEFI partition, you will be unable to select a UEFI bootloader to install, or as your current bootloader. However, in the bootloader options window, you can select a new UEFI partition.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        elif HelpfulUEFIPartition == False:
            wx.MessageDialog(self.MainPanel, "No bootloaders were found on your UEFI partition. However, you will still be able to select a UEFI bootloader to install, or as your current bootloader, as UEFI bootloader detection is a little bit sketchy. In the bootloader options window, you can select a different UEFI partition.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if FirmwareType == "BIOS":
            wx.MessageDialog(self.MainPanel, "Make sure you set the Root Device correctly here! Chances are, you won't need to change it, but it always needs to be set to the device your system boots off (usually the first hard drive in the system). You can see this information in the default OS selection in the following window. For example if your OS boots off /dev/sdc3, the root device should be set to /dev/sdc. The root device here will also be the device that's backed up if either backup option is selected. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        else:
            wx.MessageDialog(self.MainPanel, "Make sure you set the Root Device correctly here, because it will be the device that's backed up if you choose to back up the partition table. The boot sector to backup in this case is the UEFI System Partition, if there is one. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        OptionsDlg1Run = True
        self.Hide()
        OptionsWindow1(self).Show()

    def DevInfo(self,e):
        logger.debug("MainWindow().DevInfo(): Starting Device Info Window...")
        DevInfoWindow(self).Show()

    def ProgressWindow(self,e):
        if OptionsDlg1Run == True and self.reinstblcbwaschecked == False and self.updateblcbwaschecked == False:
            logger.debug("MainWindow().ProgressWindow(): Starting Progress Window...")
            self.SaveMainOpts()
            ProgressFrame = ProgressWindow()
            app.SetTopWindow(ProgressFrame)
            ProgressFrame.Show(True)
            self.Destroy()
        else:
            wx.MessageDialog(self.MainPanel, "Please check the settings in the Options Window before continuing, especially after changing the options in the Main Window!", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()

    def RefreshMainWindow(self,msg):
        #Refresh the main window to reflect changes in the options, or after a restart.
        logger.debug("MainWindow().RefreshMainWindow(): Refreshing MainWindow...")
            
        #Bootloader options. Also check if the partition table or boot sector are to be restored
        if Bootloader == "GRUB-LEGACY" or RestorePartitionTable == True or RestoreBootSector == True:
            self.DisableBLOptsGrubLegacy()
        else:
            self.EnableBLOptsNoGrubLegacy()

        #Set settings up how they were when MainWindow was hidden earlier, if possible.
        if Bootloader != "GRUB-LEGACY" and RestorePartitionTable == False and RestoreBootSector == False:
            self.reinstblcb.SetValue(ReinstallBootloader)
            self.updateblcb.SetValue(UpdateBootloader)

        self.chkfscb.SetValue(QuickFSCheck)
        self.badsectcheckcb.SetValue(BadSectCheck)

        #Enable and Disable Checkboxes as necessary
        self.OnCheckBox("Empty arg")

        #Reset these to avoid errors.
        self.reinstblcbwaschecked = False
        self.updateblcbwaschecked = False

        #Reveal MainWindow
        self.Show()

    def OnAbout(self,e):
        logger.debug("MainWindow().OnAbout(): Showing About Box...")
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot"
        aboutbox.Version = "1.0.2"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = "Utility to quickly fix the bootloader on\na computer"
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.Artists = ["Holly McIntyre-Bhatty"]
        aboutbox.License = "WxFixBoot is free software: you can redistribute it and/or modify it\nunder the terms of the GNU General Public License version 3 or,\nat your option, any later version.\n\nWxFixBoot is distributed in the hope that it will be useful,\nbut WITHOUT ANY WARRANTY; without even the implied warranty of\nMERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\nGNU General Public License for more details.\n\nYou should have received a copy of the GNU General Public License\nalong with WxFixBoot.  If not, see <http://www.gnu.org/licenses/>."

        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_CLOSE, self.OnExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        self.Bind(wx.EVT_BUTTON, self.ProgressWindow, self.applyopts)

        #Checkboxes on the main window.
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.reinstblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.updateblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.chkfscb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.badsectcheckcb)

    def SaveMainOpts(self):
        #Save all options here.
        logger.debug("MainWindow().SaveMainOpts(): Saving Options on MainWindow...")
        global BootloaderToInstall
        global BootSectorFile
        global RestoreBootSector
        global PartitionTableFile
        global RestorePartitionTable
        global ReinstallBootloader
        global UpdateBootloader
        global QuickFSCheck
        global BadSectCheck
        global Bootloader

        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
            BadSectCheck = True
        else:
            self.chkfscb.Enable()
            BadSectCheck = False

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
            QuickFSCheck = True
        else:
            self.badsectcheckcb.Enable()
            QuickFSCheck = False

        #Reinstall Bootloader Choicebox
        if self.reinstblcb.IsChecked():
            ReinstallBootloader = True

            #Disable some stuff
            BootloaderToInstall = "None"
            BootSectorFile = "None"
            RestoreBootSector = False
            PartitionTableFile = "None"
            RestorePartitionTable = False
        else:
            ReinstallBootloader = False

        #Update Bootloader Choicebox
        if self.updateblcb.IsChecked():
            UpdateBootloader = True

            #Disable some stuff
            BootloaderToInstall = "None"
            BootSectorFile = "None"
            RestoreBootSector = False
            PartitionTableFile = "None"
            RestorePartitionTable = False
        else:
            UpdateBootloader = False

        logger.debug("MainWindow().SaveMainOpts(): MainWindow options saved!")

    def OnExit(self,e):
        #Shut down.
        exitdlg = wx.MessageDialog(self.MainPanel, 'Are you sure you want to exit?', 'WxFixBoot - Question!', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
        if exitdlg == wx.ID_YES:
            logger.debug("MainWindow().OnExit() User triggered exit sequence. Exiting...")
            #Run the exit sequence
            if os.path.isdir("/tmp/wxfixboot"):
                shutil.rmtree('/tmp/wxfixboot')
            self.Destroy()

#End Main window
#Begin Device Info Window
class DevInfoWindow(wx.Frame):
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, parent=wx.GetApp().TopWindow, title="WxFixBoot - Device Information", size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)
        self.SetClientSize(wx.Size(400,310))
        self.ParentWindow = ParentWindow

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", pos=(30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(330,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(70,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitDevInfoDlg)

        logger.debug("DevInfoWindow().__init__(): Device Info Window Started.")

    def UpdDevInfo(self,e):
        #Generate device data.
        devicelist = GetDevInfo()

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        logger.debug("DevInfoWindow().ExitDevInfoDlg(): Device Info Window Closing.")

        #Exit.
        self.Destroy()

#End Device Info Window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):
    def __init__(self, ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Options", size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)
        self.SetClientSize(wx.Size(600,360))
        self.ParentWindow = ParentWindow

        #Save the frame's width and height, making it easier to centre text.
        self.width, self.height = self.GetSizeTuple()

        self.CreateButtons()
        self.CreateText()
        self.UpdateBLOptsText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.SetupOptions()
        self.BindEvents()

        logger.debug("OptionsWindow1().__init__(): OptionsWindow1 Started.")

    def CreateButtons(self):
        #Create Some buttons.
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Apply these Settings and Close", pos=(180,320), size=(235,30))
        self.blOptsButton = wx.Button(self.OptsPanel1, -1, "View Bootloader Options", pos=(210,260), size=(185,30))
        self.restorebootsectbutton = wx.Button(self.OptsPanel1, -1, "Restore Boot Sector", pos=(10,320), size=(160,30))
        self.restoreparttablebutton = wx.Button(self.OptsPanel1, -1, "Restore Partition Table", pos=(425,320), size=(170,30))

    def CreateText(self):
        #Create the text, aligning it where needed.
        xpos = DetermineTextPosition(Panel=self.OptsPanel1, text="Welcome to Options. Please give all the settings a once-over.", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Please give all the settings a once-over.", pos=(xpos,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", pos=(10,40))
        wx.StaticText(self.OptsPanel1, -1, "Installed Bootloader:", pos=(10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", pos=(10,110))
        wx.StaticText(self.OptsPanel1, -1, "Bootloader timeout value:", pos=(10,200))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", pos=(10,220)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", pos=(310,40))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", pos=(320,80))
        xpos = DetermineTextPosition(Panel=self.OptsPanel1, text="Bootloader To Install:", PanelWidth=200)

        if str(xpos).isdigit() == False:
            #Skip resizing the panel.
            xpos = xpos[1]

        wx.StaticText(self.OptsPanel1, -1, "Bootloader To Install:", pos=(xpos,255))
        xpos = DetermineTextPosition(Panel=self.OptsPanel1, text="Selected Firmware Type:", PanelWidth=200)

        if str(xpos).isdigit() == False:
            #Skip resizing the panel.
            xpos = xpos[1]

        wx.StaticText(self.OptsPanel1, -1, "Selected Firmware Type:", pos=(xpos+395,255))

    def CreateCBs(self):
        #Basic settings
        self.fullverbosecb = wx.CheckBox(self.OptsPanel1, -1, "Show diagnostic terminal output", pos=(10,155), size=(270,20))

        #Advanced settings
        self.makesummarycb = wx.CheckBox(self.OptsPanel1, -1, "Save System Report To File", pos=(320,120), size=(315,20))
        self.logoutputcb = wx.CheckBox(self.OptsPanel1, -1, "Save terminal output in Report", pos=(320,150), size=(270,20))
        self.bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector of "+RootDevice, pos=(320,180), size=(280,20))
        self.bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table of "+RootDevice, pos=(320,210), size=(290,20))

    def CreateChoiceBs(self):
        #Basic settings
        self.defaultoschoice = wx.Choice(self.OptsPanel1, -1, pos=(170,103), size=(140,30), choices=OSList)

        #Advanced settings
        self.rootdevchoice = wx.Choice(self.OptsPanel1, -1, pos=(435,73), size=(140,30), choices=["Auto: "+AutoRootDevice]+DeviceList)

    def CreateSpinners(self):
        #Basic option here.
        self.bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", pos=(190,197))
        self.bltimeoutspin.SetRange(-1,100)
        self.bltimeoutspin.SetValue(-1)

    def OnCheckBox(self,e):
        #Manage the checkboxes states.
        if self.makesummarycb.IsChecked():
            self.logoutputcb.Enable()
            self.logoutputcb.SetValue(True)
        else:
            self.logoutputcb.SetValue(False)
            self.logoutputcb.Disable()

    def SetupOptions(self):
        #Load all Options here.
        logger.debug("OptionsWindow1().SetupOptions(): Setting up options in OptionsDlg1...")

        global BootloaderToInstall
        global DefaultOS

        #Boot Loader Time Out
        self.bltimeoutspin.SetValue(BootloaderTimeout)

        #Checkboxes
        #Diagnostic output checkbox.
        if FullVerbose == True:
            self.fullverbosecb.SetValue(True)
        else:
            self.fullverbosecb.SetValue(False)

        #Backup Boot Sector CheckBox
        if BackupBootSector == True:
            self.bkpbootsectcb.SetValue(True)
        else:
            self.bkpbootsectcb.SetValue(False)

        #Backup Partition Table CheckBox
        if BackupPartitionTable == True:
            self.bkpparttablecb.SetValue(True)
        else:
            self.bkpparttablecb.SetValue(False)

        #System Summary checkBox
        if MakeSystemSummary == True:
            self.makesummarycb.SetValue(True)
        else:
            self.makesummarycb.SetValue(False)

        #Save output checkbox.
        if SaveOutput == True:
            self.logoutputcb.SetValue(True)
        else:
            self.logoutputcb.SetValue(False)

        if UEFISystemPartition == "None":
            self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(170,73), size=(140,30), choices=['Auto: '+AutoBootloader, 'GRUB-LEGACY', 'GRUB2', 'LILO'])
        else:
            self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(170,73), size=(140,30), choices=['Auto: '+AutoBootloader, 'GRUB-LEGACY', 'GRUB2', 'GRUB-UEFI', 'LILO', 'ELILO'])

        #Installed Bootloader
        if Bootloader != AutoBootloader:
            self.instblchoice.SetStringSelection(Bootloader)
        else:
            self.instblchoice.SetSelection(0)

        #Default OS
        self.defaultoschoice.SetStringSelection(DefaultOS)
        
        #Root Device
        if RootDevice != AutoRootDevice:
            self.rootdevchoice.SetStringSelection(RootDevice)
        else:
            self.rootdevchoice.SetSelection(0)

        if RestoreBootSector == True or RestorePartitionTable == True:
            #Disable/reset some options.
            self.blOptsButton.Disable()
            self.instblchoice.Disable()
            self.defaultoschoice.Disable()
            self.bltimeoutspin.SetValue(-1)
            self.bltimeoutspin.Disable()

            #Reset some settings.
            BootloaderToInstall = "None"
            DefaultOS = AutoDefaultOS
        else:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()
            self.defaultoschoice.Enable()

        #Disable some options if the bootloader is to be reinstalled or updated.
        if ReinstallBootloader == True or UpdateBootloader == True:
            self.blOptsButton.Disable()
            self.restorebootsectbutton.Disable()
            self.restoreparttablebutton.Disable()

        logger.debug("OptionsWindow1().SetupOptions(): Options in OptionsDlg1 set up!")

    def DrawLines(self,e):
        #Create some border lines on the panel.
        #Every time the window is repainted, these will be redrawn, fixing a previous issue.
        logger.debug("OptionsWindow1().DrawLines() has been triggered.")
        dc = wx.PaintDC(self.OptsPanel1)
        dc.DrawLine(0, 67, 600, 67)
        dc.DrawLine(315, 67, 315, 245)
        dc.DrawLine(0, 245, 600, 245)
        dc.DrawLine(0, 300, 600, 300)

    def UpdateBLOptsText(self):
        #Recreate the Bootloader options text, and make sure it's in the right place.
        #We have to lie about the Panel's Width here, so the test is placed where we want it.
        logger.debug("OptionsWindow1().UpdateBLOptsText(): Updating Bootloader Options text in OptionsDlg1...")

        #Do the Bootloader to install text first.
        xpos = DetermineTextPosition(Panel=self.OptsPanel1, text=BootloaderToInstall, PanelWidth=200)

        if str(xpos).isdigit() == False:
            #Skip resizing the panel.
            xpos = xpos[1]

        try:
            self.BootloaderToInstallText
        except: pass
        else:
            self.BootloaderToInstallText.Destroy()
        finally:
            self.BootloaderToInstallText = wx.StaticText(self.OptsPanel1, -1, BootloaderToInstall, pos=(xpos,275))

        #Do the Firmware Type Text now.
        xpos = DetermineTextPosition(Panel=self.OptsPanel1, text=FirmwareType, PanelWidth=200)

        if str(xpos).isdigit() == False:
            #Skip resizing the panel.
            xpos = xpos[1]

        try:
            self.FirmwareTypeText
        except: pass
        else:
            self.FirmwareTypeText.Destroy()
        finally:
            self.FirmwareTypeText = wx.StaticText(self.OptsPanel1, -1, FirmwareType, pos=(xpos+395,275))

        logger.debug("OptionsWindow1().UpdateBLOptsText(): Bootloader Options text in OptionsDlg1 updated!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CloseOpts)
        self.Bind(wx.EVT_BUTTON, self.LaunchblOpts, self.blOptsButton)
        self.Bind(wx.EVT_BUTTON, self.LaunchBootSectWindow, self.restorebootsectbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchPartTableWindow, self.restoreparttablebutton)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.makesummarycb)
        self.OptsPanel1.Bind(wx.EVT_PAINT, self.DrawLines)

    def LaunchblOpts(self,e):
        #Safeguard program reliability (and continuity) by saving the settings in optionswindow1 first.
        self.SaveOptions("Empty arg")

        #Give some warnings here if needed.
        #Tell the user some options will be disabled if the bootloader is to be reinstalled or updated.
        if ReinstallBootloader == True or UpdateBootloader == True:
            wx.MessageDialog(self.OptsPanel1, "Your current bootloader is to be reinstalled or updated, therefore almost all bootloader-related options here will be disabled. If you want to install a different bootloader, please uncheck the reinstall or update bootloader option in the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a MBR bootloader on BIOS systems.
        if FirmwareType == "BIOS":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is BIOS. Unless you're sure WxFixBoot has misdetected this, and it's actually UEFI, it's recommended that you install an BIOS bootloader, if you are installing a bootloader, such as GRUB2 or LILO, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a UEFI boot loader on UEFI systems, if needed.
        elif FirmwareType == "UEFI":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is UEFI. Unless you're sure WxFixBoot has misdetected this, and it's actually BIOS, it's recommended that you install a UEFI bootloader, if you are installing a bootloader, such as GRUB-UEFI or ELILO, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if UEFISystemPartition == "None" and Bootloader in ['GRUB-UEFI', 'ELILO']:
            wx.MessageDialog(self.OptsPanel1, "You have a UEFI Bootloader, but no UEFI Partition! Something has gone wrong here! WxFixBoot will not install a UEFI bootloader without a UEFI partition, as it's impossible, and those options will now be disabled. Did you change your selected UEFI Partition?", "WxFixBoot - ERROR", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()

        elif UEFISystemPartition == "None":
            wx.MessageDialog(self.OptsPanel1, "You have no UEFI Partition. If you wish to install a UEFI bootloader, you'll need to create one first. WxFixBoot will not install a UEFI bootloader without a UEFI partition, as it's impossible, and those options will now be disabled.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        wx.MessageDialog(self.OptsPanel1, "Most of the settings in the following dialog do not need to be and shouldn't be touched, with the exception of autodetermining the bootloader, or manually selecting one. The firmware type and partition schemes should not normally be changed. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Open the Firmware Options window
        logger.debug("OptionsWindow1().LaunchblOpts(): Starting Options Window 2 (aka Bootloader Options Dlg)...")
        self.Hide()
        OptionsWindow2(self).Show()

    def LaunchBootSectWindow(self,e):
        #Safeguard program reliability (and continuity) by saving the settings in optionswindow1 first.
        self.SaveOptions("Empty arg")

        logger.debug("OptionsWindow1().LaunchBootSectWindow(): Starting Restore BootSector dialog...")
        #Show helpful info if the root device uses gpt.
        Tempnum = DeviceList.index(RootDevice)
        Temp = PartSchemeList[Tempnum]

        if Temp == "gpt":
             wx.MessageDialog(self.OptsPanel1, "Because the selected root device uses gpt, the Target Device selection in the following dialog will be ignored, though you must still set it, and the backup will always be restored to the UEFI Partition. Please keep this in mind and be sure that the UEFI Partition chosen is correct. You can check and change this in the Bootloader Options.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        self.Hide()
        RestoreWindow(ParentWindow=self,Type="BootSector").Show()

    def LaunchPartTableWindow(self,e):
        #Safeguard program reliability (and continuity) by saving the settings in optionswindow1 first.
        self.SaveOptions("Empty arg")

        logger.debug("OptionsWindow1().LaunchPartTableWindow(): Starting Restore PartTable dialog...")
        self.Hide()
        RestoreWindow(ParentWindow=self,Type="PartTable").Show()

    def RefreshOptionsDlg1(self,msg):
        #Check if the partition table or boot sector are to be restored.
        logger.debug("OptionsWindow1().RefreshOptionsDlg1(): Refreshing OptionsDlg1...")
        if RestorePartitionTable == True or RestoreBootSector == True:
            #Disable/reset some options.
            self.blOptsButton.Disable()
            self.instblchoice.Disable()
            self.defaultoschoice.Disable()
            self.bltimeoutspin.SetValue(-1)
            self.bltimeoutspin.Disable()

            #Reset some settings.
            global BootloaderToInstall
            global FirmwareType
            global DefaultOS
            BootloaderToInstall = "None"
            FirmwareType = AutoFirmwareType
            DefaultOS = AutoDefaultOS
        else:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()
            self.defaultoschoice.Enable()
            self.bltimeoutspin.Enable()

        #Setup options again, but destroy a widget first so it isn't duplicated.
        self.instblchoice.Destroy()
        self.SetupOptions()

        #Update the BootloaderToInstall and FirmwareType text.
        self.UpdateBLOptsText()

        #Show OptionsDlg1.
        self.Show()

    def SaveOptions(self,e):
        #Save all options in this window here.
        global SaveOutput
        global FullVerbose
        global SaveOutput
        global BackupBootSector
        global BackupPartitionTable
        global MakeSystemSummary
        global Bootloader
        global PrevBootloaderSetting
        global DefaultOS
        global RootDevice
        global RootFS
        global BootloaderTimeout

        logger.info("OptionsWindow1().SaveOptions(): Saving Options...")
        
        #Checkboxes.

        #Create Log checkbox.
        if self.logoutputcb.IsChecked():
            SaveOutput = True
        else:
            SaveOutput = False
        logger.debug("OptionsWindow1().SaveOptions(): Value of SaveOutput is: "+str(SaveOutput))

        #Check FS cb
        if self.fullverbosecb.IsChecked():
            FullVerbose = True
        else:
            FullVerbose = False
        logger.debug("OptionsWindow1().SaveOptions(): Value of FullVerbose is: "+str(FullVerbose))

        #Remount FS CB
        if self.logoutputcb.IsChecked():
            SaveOutput = True
        else:
            SaveOutput = False
        logger.debug("OptionsWindow1().SaveOptions(): Value of SaveOutput is: "+str(SaveOutput))

        #Backup BootSector checkbox.
        if self.bkpbootsectcb.IsChecked():
            BackupBootSector = True
        else:
            BackupBootSector = False
        logger.debug("OptionsWindow1().SaveOptions(): Value of BackupBootSector is: "+str(BackupBootSector))

        #Backup Partition Table checkbox.
        if self.bkpparttablecb.IsChecked():
            BackupPartitionTable = True
        else:
            BackupPartitionTable = False
        logger.debug("OptionsWindow1().SaveOptions(): Value of BackupPartitionTable is: "+str(BackupPartitionTable))

        #Use chroot in operations checkbox
        if self.makesummarycb.IsChecked():
            MakeSystemSummary = True
        else:
            MakeSystemSummary = False
        logger.debug("OptionsWindow1().SaveOptions(): Value of MakeSystemSummary is: "+str(MakeSystemSummary))

        #ChoiceBoxes
        #Currently Installed Bootloader ChoiceBox
        PrevBootloaderSetting = Bootloader
        if self.instblchoice.GetSelection() != 0:
            Bootloader = self.instblchoice.GetStringSelection()
        else:
            #Set it to the auto value, using AutoBootloader
            Bootloader = AutoBootloader
        logger.debug("OptionsWindow1().SaveOptions(): Value of Bootloader is: "+Bootloader)

        #Default OS choicebox
        DefaultOS = self.defaultoschoice.GetStringSelection()
        logger.debug("OptionsWindow1().SaveOptions(): Value of DefaultOS is: "+DefaultOS)

        #Root Filesystem.
        RootFS = self.defaultoschoice.GetStringSelection().split()[-1]
        logger.debug("OptionsWindow1().SaveOptions(): Value of RootFS is: "+RootFS)

        #Root device ChoiceBox
        if self.rootdevchoice.GetSelection() != 0:
            RootDevice = self.rootdevchoice.GetStringSelection()            
        else:
            #Set it to the auto value, in case this has already been changed.
            RootDevice = AutoRootDevice
        logger.debug("OptionsWindow1().SaveOptions(): Value of RootDevice is: "+RootDevice)

        #Spinner
        BootloaderTimeout = int(self.bltimeoutspin.GetValue())
        logger.debug("OptionsWindow1().SaveOptions(): Value of BootloaderTimeout is: "+str(BootloaderTimeout))

        logger.info("OptionsWindow1().SaveOptions(): Saved options.")

    def CloseOpts(self,e):
        #Save the options first.
        self.SaveOptions("empty arg")

        #Send a message to mainwindow so it can refresh.
        wx.CallAfter(self.ParentWindow.RefreshMainWindow, "Closed")

        #Exit options window 1.
        logger.debug("OptionsWindow1().SaveOptions(): OptionsWindow1 is closing. Revealing MainWindow...")
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, parent=wx.GetApp().TopWindow, title="WxFixBoot - Bootloader Options", size=(450,330), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)
        self.SetClientSize(wx.Size(450,330))
        self.ParentWindow = ParentWindow

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

        logger.debug("OptionsWindow2().__init__(): OptionsWindow2 Started.")

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(370,290), size=(70,30))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace a UEFI bootloader with the BIOS equivalent", pos=(10,180))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace a BIOS bootloader with the UEFI equivalent", pos=(10,210))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Automatically determine the bootloader to install", pos=(10,240))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not install a new bootloader", pos=(10,270))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System", pos=(140,40))
        wx.StaticText(self.OptsPanel2, -1, "On "+RootDevice+":", pos=(163,57))
        wx.StaticText(self.OptsPanel2, -1, "Bootloader to install:", pos=(140,80))
        wx.StaticText(self.OptsPanel2, -1, "UEFI Partition:", pos=(140,120))
 
    def CreateRadios(self):
        #Create radio buttons.
        self.fwtyperadioauto = wx.RadioButton(self.OptsPanel2, -1, "Auto: "+AutoFirmwareType, pos=(10,60), style=wx.RB_GROUP)
        self.fwtyperadioUEFI = wx.RadioButton(self.OptsPanel2, -1, "EFI/UEFI", pos=(10,90))
        self.fwtyperadioBIOS = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(10,120))

    def CreateChoiceBs(self):
        #Make sure the right device's partition scheme is used here.
        tempnum = DeviceList.index(RootDevice)

        #Set up self.partitiontypechoice based on whether that value has been changed for this device.
        if PartSchemeList[tempnum] == AutoPartSchemeList[tempnum]:
            self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,39), choices=['Auto: '+PartSchemeList[tempnum], 'msdos', 'gpt'])
        else:
            self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,39), choices=['Auto: '+AutoPartSchemeList[tempnum], 'Manual Value: '+PartSchemeList[tempnum], 'msdos', 'gpt'])  
            self.partitiontypechoice.SetSelection(1)     

        #Disable UEFI bootloaders if there is no UEFI system partition.
        if UEFISystemPartition == "None":
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,74), choices=['Auto', 'GRUB2', 'LILO'])
        else:
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,74), choices=['Auto', 'GRUB-UEFI', 'GRUB2', 'ELILO', 'LILO'])

        self.bltoinstallchoice.SetSelection(0)
        self.efisyspchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,112), choices=FatPartitions) 

    def SetDefaults(self):
        global BootloaderToInstall
    
        logger.debug("OptionsWindow2().SetDefaults(): Setting up OptionsWindow2...")
        self.efisyspchoice.SetStringSelection(UEFISystemPartition)
        #Check if the dialog has already been run, or if the bootloader setting has changed (so it must discard the setting to avoid errors).
        if BLOptsDlgRun == False or Bootloader != PrevBootloaderSetting:
            #Use defaults.
            self.bltoinstallchoicelastvalue = "Auto"
            #If bootloader is to be reinstalled, updated, or if a UEFI partition isn't available, or if bootloader is grub-legacy, disable some stuff.
            if ReinstallBootloader == True or UpdateBootloader == True:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.bltoinstallchoice.Disable()
                self.unchangedcb.SetValue(True)
            elif UEFISystemPartition == "None":
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.unchangedcb.SetValue(True)
            elif Bootloader == "GRUB-LEGACY":
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
                self.unchangedcb.SetValue(True)
            else:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.unchangedcb.SetValue(True)
                self.fwtyperadioauto.SetValue(True)
                self.fwtyperadioUEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.partitiontypechoice.SetSelection(0)
        else:
            #Setup using the previous options.
            #First do options that will be set even if the current bootloader is to be reinstalled or updated.
            #Set up Firmware Type radio buttons.
            if FirmwareType == AutoFirmwareType:
                self.fwtyperadioUEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
            elif FirmwareType == "BIOS":
                self.fwtyperadioUEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(True)
                self.fwtyperadioauto.SetValue(False)
            elif FirmwareType == "UEFI":
                self.fwtyperadioUEFI.SetValue(True)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(False)

            #Bootloader To Install Choice
            if BootloaderToInstall not in ["None","Unknown"] and ReinstallBootloader == False and UpdateBootloader == False:
                self.bltoinstallchoice.Enable()
                self.bltoinstallchoice.SetStringSelection(BootloaderToInstall)
                self.bltoinstallchoicelastvalue = BootloaderToInstall
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
            elif ReinstallBootloader == True or UpdateBootloader == True:
                BootloaderToInstall = "None"
                self.bltoinstallchoice.SetSelection(0)
                self.bltoinstallchoicelastvalue = "Auto"
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")
                self.bltoinstallchoice.Disable()
            else:
                self.bltoinstallchoicelastvalue = "None"
                self.bltoinstallchoice.SetSelection(0)
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")

            self.partitiontypechoice.SetSelection(0)

        logger.debug("OptionsWindow2().SetDefaults(): OptionsDlg2 Set up!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CheckOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CheckOpts)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOptsforNoModification, self.unchangedcb)
        self.Bind(wx.EVT_CHOICE, self.BlToInstallChoiceChange, self.bltoinstallchoice)
        self.Bind(wx.EVT_CHOICE, self.UEFISysPChoiceChange, self.efisyspchoice) 
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforAutoFW, self.fwtyperadioauto)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforUEFIFW, self.fwtyperadioUEFI)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforBIOSFW, self.fwtyperadioBIOS)

    def ActivateOptsforAutoFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForAutoFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and UpdateBootloader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforUEFIFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForUEFIFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and Bootloader != "GRUB-LEGACY" and UpdateBootloader == False:
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(True)
            self.BIOStoUEFIcb.Enable()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
        elif Bootloader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforBIOSFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForBIOSFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and Bootloader != "GRUB-LEGACY" and UpdateBootloader == False:
            self.UEFItoBIOScb.SetValue(True)
            self.UEFItoBIOScb.Enable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
        elif Bootloader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforNoModification(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForNoModification() has been triggered...")
        if self.unchangedcb.IsChecked() and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and UpdateBootloader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
        elif ReinstallBootloader == False and UpdateBootloader == False:
            #In this circumstance, use the correct settings for the current firmware type selected.
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioUEFI.GetValue():
                self.ActivateOptsforUEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        else:
            self.unchangedcb.SetValue(True)
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()

    def BlToInstallChoiceChange(self,e):
        logger.debug("OptionsWindow2().BLToInstallChoiceChange() has been triggered...")
        if self.bltoinstallchoice.GetSelection() == 0 and self.bltoinstallchoicelastvalue != self.bltoinstallchoice.GetStringSelection():
            self.bltoinstallchoicelastvalue = self.bltoinstallchoice.GetStringSelection()
            self.unchangedcb.Enable()
            self.unchangedcb.SetValue(True)
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioUEFI.GetValue():
                self.ActivateOptsforUEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        elif self.bltoinstallchoice.GetSelection() != 0:
            self.bltoinstallchoicelastvalue = self.bltoinstallchoice.GetStringSelection()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.unchangedcb.SetValue(False)
            self.unchangedcb.Disable()

    def UEFISysPChoiceChange(self,e):
        #Function to handle selection of new UEFI system partition. It's pretty self-explanatory.
        global UEFISystemPartition
        logger.debug("OptionsWindow2().UEFISysPChoiceChange() has been triggered...")
        if self.efisyspchoice.GetStringSelection() == UEFISystemPartition:
            logger.debug("OptionsWindow2().UEFISysPChoiceChange(): No action required, UEFISystemPartition unchanged...")
        elif self.efisyspchoice.GetStringSelection() == "None":
            logger.debug("OptionsWindow2().UEFISysPChoiceChange(): UEFISystemPartition changed to None. Disabling UEFI Bootloader installation, rescanning for bootloaders, and exiting OptionsWindow2()...")
            UEFISystemPartition = self.efisyspchoice.GetStringSelection()

            wx.MessageDialog(self.OptsPanel2, "As you have selected no UEFI partition, WxFixBoot will disable UEFI bootloaders. Please wait a few seconds while your system is scanned for bootloaders. If none are found, you will be prompted to enter one manually. After that, you will be returned to the first options window with any new bootloader settings detected. Any other settings you have set here will be ignored, unless you go back and set them again.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            self.Hide()

            #Check for bootloaders on the suggested UEFI partition.
            InitThread(self,False)

        else:
            logger.debug("OptionsWindow2().UEFISysPChoiceChange(): UEFISystemPartition changed! Rescanning for UEFI bootloaders and exiting OptionsWindow2()...")
            UEFISystemPartition = self.efisyspchoice.GetStringSelection()

            wx.MessageDialog(self.OptsPanel2, "You have selected a different UEFI Partition. Please wait a few seconds while it is scanned for bootloaders. If none are found, you will be prompted to enter one manually. After that, you will be returned to the first options window with any new bootloader settings detected. Any other settings you have set here will be ignored, unless you go back and set them again.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            self.Hide()

            #Check for bootloaders on the suggested UEFI partition.
            InitThread(self,False)

    def UEFIPartitionScanned(self,msg):
        #Okay, the UEFI partition has been scanned, and the bootloader has been set, either manually or automatically.
        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

        #Exit.
        self.Destroy()

    def ShowThreadChoicedlg(self,msg,choices,title="WxFixBoot - Select an Option"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=<message>, title=<title>, choices=<data>)
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.OptsPanel2, msg, title, choices, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("InitialWindow().ShowThreadChoicedlg(): Result of InitThread choice dlg was: "+dlgResult)

    def CheckOpts(self,e):
        if self.unchangedcb.IsChecked() == False and self.UEFItoBIOScb.IsChecked() == False and self.useAutocb.IsChecked() == False and self.BIOStoUEFIcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0:
            #Do nothing, as settings are invalid.
            logger.error("OptionsWindow2().CheckOpts(): No options selected, although the 'do not modify' checkbox is unticked, or the options selected are invalid. Won't save options, waitng for user change...")
            wx.MessageDialog(self.OptsPanel2, "Your current selection suggests a modification will take place, but it doesn't specify which modification to do! Please select a valid modification to do.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        else:
            self.SaveBLOpts()

    def SaveBLOpts(self):
        #Save all selected Operations here.
        global BootloaderToInstall
        global PrevBootloaderSetting
        global PartSchemeList
        global Bootloader
        global FirmwareType
        global AutoFirmwareType

        logger.info("OptionsWindow2().SaveBLOpts(): Saving Options...")

        BootloaderList = ['GRUB-LEGACY', 'GRUB-UEFI','GRUB2','ELILO','LILO']

        #Partition scheme choice.
        if self.partitiontypechoice.GetStringSelection()[0:6] == "Manual":
            #No action required.
            logger.info("OptionsWindow2().SaveBLOpts(): No Change in any PartScheme values...")
        else:
            #Figure out which entry in PartSchemeList to change and then delete and recreate it using the options in the dlg (msdos, or gpt)
            tempnum = DeviceList.index(RootDevice)
            PartSchemeList.pop(tempnum)
            PartSchemeList.insert(tempnum, self.partitiontypechoice.GetStringSelection().split()[-1])
            if self.partitiontypechoice.GetStringSelection()[0:4] != "Auto":
                logger.info("OptionsWindow2().SaveBLOpts(): Changed value of PartScheme for device: "+RootDevice+" to: "+PartSchemeList[tempnum])
            else:
                logger.info("OptionsWindow2().SaveBLOpts(): Changed value of PartScheme for device: "+RootDevice+" to: "+PartSchemeList[tempnum]+" the default...")

        #Firmware Choice.
        if self.fwtyperadioUEFI.GetValue():
            FirmwareType = "UEFI"
        elif self.fwtyperadioBIOS.GetValue():
            FirmwareType = "BIOS"
        else:
            #Use auto value.
            FirmwareType = AutoFirmwareType
        logger.info("OptionsWindow2().SaveBLOpts(): Value of FirmwareType is: "+FirmwareType)

        #Bootloader to install choice.
        #Offer some warnings here if needed. This is a little complicated, but is still fairly easy to read.
        if self.bltoinstallchoice.GetStringSelection()[0:4] == "Auto" and ReinstallBootloader == False:
            #Use autodetect value
            if self.unchangedcb.IsChecked() == False:

                if self.UEFItoBIOScb.IsChecked():

                    if Bootloader in ['GRUB-UEFI', 'ELILO']:
                        #Find the BIOS/MBR equivalent to a UEFI bootloader.
                        bootloadernum = BootloaderList.index(Bootloader)
                        BootloaderToInstall = BootloaderList[bootloadernum+1] 
                    else:
                        #Do nothing, already using BIOS bootloader.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader with this window, or reinstall the bootoader using the selection in the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"

                elif self.BIOStoUEFIcb.IsChecked():

                    if UEFISystemPartition != "None" and Bootloader in ['GRUB2', 'LILO']:
                        #Find the EFI/UEFI equivalent to a BIOS bootloader, provided there is a UEFI partition.
                        bootloadernum = BootloaderList.index(Bootloader)
                        BootloaderToInstall = BootloaderList[bootloadernum-1]
                    elif UEFISystemPartition == "None":
                        #Refuse to install a UEFI bootloader, as there is no UEFI partition.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader to install requires a UEFI partition, which either doesn't exist or has not been selected. Please create or select a UEFI partition to install a UEFI bootloader or the operation will be cancelled.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"
                    else:
                        #Do nothing, already using EFI/UEFI bootloader.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader with this window, or reinstall the bootoader using the selection in the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"

                elif self.useAutocb.IsChecked():

                    bootloadernum = BootloaderList.index(Bootloader)

                    if FirmwareType == "BIOS" and Bootloader not in ['GRUB2', 'LILO', 'GRUB-LEGACY']:
                        #Find the BIOS/MBR equivalent to a UEFI bootloader.
                        BootloaderToInstall = BootloaderList[bootloadernum+1]

                    elif FirmwareType == "UEFI" and Bootloader not in ['GRUB-UEFI', 'ELILO', 'GRUB-LEGACY'] and UEFISystemPartition != "None":
                        #Find the EFI/UEFI equivalent to a BIOS bootloader, provided there is a UEFI partition, and it isn't GRUB-LEGACY
                        BootloaderToInstall = BootloaderList[bootloadernum-1]

                    elif FirmwareType == "BIOS" and Bootloader == "GRUB-LEGACY":
                        #Recommend GRUB2 for BIOS systems using GRUB-LEGACY
                        dlg = wx.MessageDialog(self.OptsPanel2, 'Seeing as your bootloader is grub legacy, and you use BIOS firmware, the recommended bootloader for your hardware is GRUB2. If you want to install a different bootloader, click no and return to this window to manually select your bootloader. Click yes to comfirm installing GRUB2.', 'WxFixBoot -- Comfirmation', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
                        if dlg == wx.ID_YES:
                            BootloaderToInstall = "GRUB2"
                        else:
                            #Do nothing
                            BootloaderToInstall = "None"

                    elif FirmwareType == "UEFI" and Bootloader == "GRUB-LEGACY":
                        #Suggest GRUB-UEFI for UEFI systems using GRUB-LEGACY
                        wx.MessageDialog(self.OptsPanel2, "You have a combination of UEFI firmware and grub legacy. This is an odd combination, and WxFixBoot doesn't know what to do. If you've imaged your HDD from another system, you probably want to install GRUB-UEFI manually by returning to this window after it closes. If you manually suggested you have grub legacy earlier, please double check that was correct.", "WxFixBoot - Warning!", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "Unknown"

                    elif FirmwareType == "UEFI" and UEFISystemPartition == "None":
                        #Refuse to install a UEFI bootloader, as there is no UEFI partition.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader to install requires a UEFI partition, which either doesn't exist or has not been selected. Please create or select a UEFI partition to install a UEFI bootloader or the operation will be cancelled.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"

                    else:
                        #Correct bootloader for firmware type.
                        BootloaderToInstall = "None"
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader with this window, or reinstall the bootoader using the selection in the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            else:
                #Do nothing.
                BootloaderToInstall = "None"

        elif self.unchangedcb.IsChecked() == False and ReinstallBootloader == False and UpdateBootloader == False:
            BootloaderToInstall = self.bltoinstallchoice.GetStringSelection()
        else:
            BootloaderToInstall = "None"

        if BootloaderToInstall == Bootloader:
            BootloaderToInstall = "None"
            wx.MessageDialog(self.OptsPanel2, "Your current bootloader is the same as the one you've selected to install! Please select 'Reinstall Bootloader' in the Main Window instead.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if BootloaderToInstall in ['LILO', 'ELILO']:  
            wx.MessageDialog(self.OptsPanel2, "Either, you've selected or WxFixBoot has autodetermined to use LILO or ELILO as the bootloader to install! Both ELILO and LILO can be a complete pain to set up and maintain. Please do not use either unless you know how to set up and maintain them, and you're sure you want them. If WxFixBoot recommended either of them to you, it's a good idea to select the equivalent GRUB version manually instead: GRUB-UEFI for ELILO, GRUB2 for LILO.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

            if GPTInAutoPartSchemeList == True and BootloaderToInstall == "LILO":
                wx.MessageDialog(self.OptsPanel2, "LILO is going to be installed, but at least one device connected to this computer uses an incompatble partition system! LILO will not boot from that device, so this may be a bad idea, in case you boot from it. Please consider installing GRUB2 instead as it will boot from that device.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        #Avoid an error situation.
        PrevBootloaderSetting = Bootloader

        logger.info("OptionsWindow2().SaveBLOpts(): Value of BootloaderToInstall is: "+BootloaderToInstall)
        logger.info("OptionsWindow2().SaveBLOpts(): Finished saving options.")

        self.CloseBLOpts()
        
    def CloseBLOpts(self):
        logger.debug("OptionsWindow2().CloseBLOpts(): OptionsWindow2 Closing.")
        #Save that this window has been run once, so it can update itself with the new info if it's started again.
        global BLOptsDlgRun
        BLOptsDlgRun = True

        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

        #Exit.
        self.Destroy()

#End Options window 2
#Begin Restore Window
class RestoreWindow(wx.Frame):
    def __init__(self,ParentWindow,Type):
        if Type == "BootSector":
            logger.debug("RestoreWindow().__init__(): Restore Boot Sector Window Started.")
            title = "WxFixBoot - Restore the Boot Sector"
        else:
            logger.debug("RestoreWindow().__init__(): Restore Partition Table Window Started.")
            title = "WxFixBoot - Restore the Partition Table"

        wx.Frame.__init__(self, parent=wx.GetApp().TopWindow, title=title, size=(400,200), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.RestorePanel = wx.Panel(self)
        self.SetClientSize(wx.Size(400,200))
        self.ParentWindow = ParentWindow
        self.Type = Type

        #Save the frame's width and height, making it easier to centre text.
        self.width, self.height = self.GetSizeTuple()

        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.CreateButtons()
        self.BindEvents()

        #Set up the window.
        self.SetupOptions()

    def CreateText(self):
        #Create text, and centre it.
        if self.Type == "BootSector":
            xpos = DetermineTextPosition(Panel=self.RestorePanel, text="What type of Boot Sector backup do you have?", PanelWidth=self.width)

            if str(xpos).isdigit() == False:
                #We need to resize the panel for the text to fit.
                self.width = xpos[0]
                self.SetClientSize(wx.Size(self.width, self.height))
                xpos = xpos[1]

            wx.StaticText(self.RestorePanel, -1, "What type of Boot Sector backup do you have?", pos=(xpos,40))
            xpos = DetermineTextPosition(Panel=self.RestorePanel, text="Easily restore your bootsector here!", PanelWidth=self.width)

            if str(xpos).isdigit() == False:
                #We need to resize the panel for the text to fit.
                self.width = xpos[0]
                self.SetClientSize(wx.Size(self.width, self.height))
                xpos = xpos[1]

            wx.StaticText(self.RestorePanel, -1, "Easily restore your bootsector here!", pos=(xpos,10))

        else:
            xpos = DetermineTextPosition(Panel=self.RestorePanel, text="What type of partition table backup do you have?", PanelWidth=self.width)

            if str(xpos).isdigit() == False:
                #We need to resize the panel for the text to fit.
                self.width = xpos[0]
                self.SetClientSize(wx.Size(self.width, self.height))
                xpos = xpos[1]

            wx.StaticText(self.RestorePanel, -1, "What type of partition table backup do you have?", pos=(xpos,40))
            xpos = DetermineTextPosition(Panel=self.RestorePanel, text="Easily restore your partition table here!", PanelWidth=self.width)

            if str(xpos).isdigit() == False:
                #We need to resize the panel for the text to fit.
                self.width = xpos[0] 
                self.SetClientSize(wx.Size(self.width, self.height))
                xpos = xpos[1]

            wx.StaticText(self.RestorePanel, -1, "Easily restore your partition table here!", pos=(xpos,10))

        wx.StaticText(self.RestorePanel, -1, "Backup file:", pos=(10,100))
        wx.StaticText(self.RestorePanel, -1, "Target Device:", pos=(230,100))

    def CreateRadios(self):
        #Create Radio Buttons
        self.autodetectradio = wx.RadioButton(self.RestorePanel, -1, "Autodetect", pos=(10,70), style=wx.RB_GROUP)
        self.msdosradio = wx.RadioButton(self.RestorePanel, -1, "MBR(msdos)", pos=(150,70))
        self.gptradio = wx.RadioButton(self.RestorePanel, -1, "GUID(gpt)", pos=(290,70))  

    def CreateChoiceBs(self):
        #Create ChoiceBoxes
        self.filechoice = wx.Choice(self.RestorePanel, -1, pos=(10,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])
        self.targetchoice = wx.Choice(self.RestorePanel, -1 , pos=(230,120), size=(150,30), choices=['-- Please Select --', 'Auto: '+AutoRootDevice]+DeviceList+['Specify Path...'])

    def CreateButtons(self):
        #Create Buttons
        self.exitbutton = wx.Button(self.RestorePanel, -1, "Close and Set Options", pos=(120,160))

    def BindEvents(self):
        #Bind events
        self.Bind(wx.EVT_BUTTON, self.ExitWindow, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitWindow)
        self.Bind(wx.EVT_CHOICE, self.SelectFile, self.filechoice)
        self.Bind(wx.EVT_CHOICE, self.SelectTargetDevice, self.targetchoice)

    def SetupOptions(self):
        #Set up the choiceboxes according to the values of the variables.
        if self.Type == "BootSector":
            File = BootSectorFile
            TargetDevice = BootSectorTargetDevice
        else:
            File = PartitionTableFile
            TargetDevice = PartitionTableTargetDevice

        #Image file choice.
        if File != "None":
            self.filechoice.Append(File)
            self.filechoice.SetStringSelection(File)
        else:
            self.filechoice.SetSelection(0)

        #Target device file choice.
        if TargetDevice != "None":
            self.targetchoice.Append(TargetDevice)
            self.targetchoice.SetStringSelection(TargetDevice)
        else:
            self.targetchoice.SetSelection(0)

    def SelectFile(self,e):
        #Grab Image path.
        logger.debug("RestoreWindow().SelectFile() has been triggered...")

        #Set up global variables.
        global BootSectorFile
        global RestoreBootSector
        global BootSectorBackupType
        global PartitionTableFile
        global RestorePartitionTable
        global PartitionTableBackupType

        File = self.filechoice.GetStringSelection()

        #Determine what to do here.
        if File == "-- Please Select --":
            File = "None"
            Restore = False

        elif File == "Specify File Path...":
            if self.Type == "BootSector":
                Dlg = wx.FileDialog(self.RestorePanel, "Select Boot Sector File...", wildcard="All Files/Devices (*)|*|GPT Backup File (*.gpt)|*.gpt|MBR Backup File (*.mbr)|*.mbr|IMG Image file (*.img)|*.img", style=wx.OPEN)
            else:
                Dlg = wx.FileDialog(self.RestorePanel, "Select Partition Table File...", wildcard="All Files/Devices (*)|*|GPT Backup File (*.gpt)|*.gpt|MBR Backup File (*.mbr)|*.mbr|IMG Image file (*.img)|*.img", style=wx.OPEN)

            if Dlg.ShowModal() == wx.ID_OK:
                Restore = True
                File = Dlg.GetPath()
                self.filechoice.Append(File)
                self.filechoice.SetStringSelection(File)
            else:
                File = "None"
                Restore = False
                self.filechoice.SetStringSelection("-- Please Select --")

        else:
            File = self.filechoice.GetStringSelection()
            Restore = True

        #Detect backup type, if files are selected.
        if File != "None" and Restore == True:
            #Use os.stat(filename).st_size, if bigger than 512 bytes (MBR bootsector), it's GPT
            Temp = os.stat(File).st_size
            if Temp < 512:
                #Bad file.
                wx.MessageDialog(self.RestorePanel, "The size of the selected file is less than 512 bytes! This is cannot be a backup file. Please select a new backup file.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                File = "None"
                Restore = "False"
                BackupType = "None"
                self.autodetectradio.SetValue(True)
                Temp = self.filechoice.GetSelection()
                self.filechoice.Delete(Temp)
                self.filechoice.SetStringSelection("-- Please Select --")
                return
            elif Temp == 512:
                #Backup is MBR(msdos)
                BackupType = "msdos"
                self.msdosradio.SetValue(True)
            elif Temp > 512 and Temp < 20000:
                #Backup is GPT  
                BackupType = "gpt"
                self.gptradio.SetValue(True)
            else:
                #Backup is *PROBABLY* GPT, but might not be a backup file! If this is the BootSector, it's fine, because for that we backup the UEFI partition.
                BackupType = "gpt"
                self.gptradio.SetValue(True)
                if self.Type == "PartTable":
                    wx.MessageDialog(self.RestorePanel, "Your backup file type is probably valid, but WxFixBoot isn't sure, as the file size is odd. Please ensure that this is your backup file!", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

            wx.MessageDialog(self.RestorePanel, "Your backup file type was detected as: "+BackupType+". If this is correct, then continuing is safe. If not, ensure you made the backup file with WxFixBoot and that it is the correct backup file, and manually set the right backup type. If you made the backup with another program, please use that program to restore it instead to avoid problems.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        else:
            BackupType = "None"
            self.autodetectradio.SetValue(True)

        #Save File, Restoring, and BackupType to the correct global variables, depending on which purpose this class is serving (Boot Sector Restoration Window, or Partition Table Restoration Window).
        logger.info("RestoreWindow().SelectFile(): Current config: File = "+File+", Restore = "+str(Restore)+", BackupType = "+BackupType+"...")

        if self.Type == "BootSector":
            BootSectorFile = File
            RestoreBootSector = Restore
            BootSectorBackupType = BackupType
        else:
            PartitionTableFile = File
            RestorePartitionTable = Restore
            PartitionTableBackupType = BackupType

    def SelectTargetDevice(self,e):
        #Grab Boot Sector Image path.
        logger.debug("RestoreWindow().SelectTargetDevice() has been triggered...")

        #Set up global variables.
        global BootSectorTargetDevice
        global PartitionTableTargetDevice

        TargetDevice = self.targetchoice.GetStringSelection()

        #Determine what to do here.
        if TargetDevice == "-- Please Select --":
            TargetDevice = "None"
        elif TargetDevice[0:4] == "Auto":
            TargetDevice = RootDevice
        elif TargetDevice == "Specify File Path...":
            Dlg = wx.FileDialog(self.RestorePanel, "Select Target Device...", wildcard="All Files/Devices (*)|*", defaultDir='/dev', style=wx.OPEN)
            if Dlg.ShowModal() == wx.ID_OK:
                TargetDevice = Dlg.GetPath()
                self.targetchoice.Append(TargetDevice)
                self.targetchoice.SetStringSelection(TargetDevice)
            else:
                TargetDevice = "None"
                self.targetchoice.SetStringSelection("-- Please Select --")
        else:
            TargetDevice = self.targetchoice.GetStringSelection()

        #Save TargetDevice to the correct global variable, depending on which purpose this class is serving (Boot Sector Restoration Window, or Partition Table Restoration Window).
        logger.info("RestoreWindow().SelectTargetDevice(): Current config: TargetDevice = "+TargetDevice+"...")

        if self.Type == "BootSector":
            BootSectorTargetDevice = TargetDevice
        else:
            PartitionTableTargetDevice = TargetDevice

    def ExitWindow(self,e):
        if self.Type == "BootSector":
            File = BootSectorFile
            Restore = RestoreBootSector
            TargetDevice = BootSectorTargetDevice
        else:
            File = PartitionTableFile
            Restore = RestorePartitionTable
            TargetDevice = PartitionTableTargetDevice

        if File != "None" and Restore == True and TargetDevice != "None":
            #Show an info message.
            dlg = wx.MessageDialog(self.RestorePanel, "Do you want to continue? This operation can cause data loss. Only continue if you are certain you've selected the right target device and backup file, and if the backup was created with WxFixBoot. If you restore a partition table or bootsector some options, such as installing a different bootloader and reinstalling or updating your bootloader will be disabled. If you want to change other settings, you can always restart WxFixBoot afterwards and then change them.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_EXCLAMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

        elif File != "None" or Restore == True or TargetDevice != "None":
            if self.Type == "Bootsector":
                wx.MessageDialog(self.RestorePanel, "You haven't entered all of the required settings! Please either enter all required settings to do this operation, or no settings at all to disable boot sector resoration.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

            else:
                wx.MessageDialog(self.RestorePanel, "You haven't entered all of the required settings! Please either enter all required settings to do this operation, or no settings at all to disable partition table restoration.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        else:
            dlg = wx.MessageDialog(self.RestorePanel, "Do you want to exit this window?", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_EXCLAMATION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_YES:
                logger.debug("RestoreWindow().ExitWindow(): Restore Boot Sector/Partion Table Window Closing.")
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

#End Restore Window
#Begin Progress Window
class ProgressWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, parent=None, title="WxFixBoot - Operations Progress", size=(500,300), style=wx.CAPTION|wx.MINIMIZE)
        self.ProgressPanel=wx.Panel(self)
        self.SetClientSize(wx.Size(500,300))

        global OutputLog
        OutputLog = ""

        #Save the frame's width and height, making it easier to centre text.
        self.width, self.height = self.GetSizeTuple()

        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBars()
        self.BindEvents()

        logger.debug("ProgressWindow().__init__(): Progress Window Started.")
        logger.debug("ProgressWindow().__init__(): Starting Main Backend Thread...")

        MainBackendThread(self)

    def CreateText(self):
        #Create Text, and centre it.
        xpos = DetermineTextPosition(Panel=self.ProgressPanel, text="WxFixBoot is performing operations... Please wait.", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.ProgressPanel, -1, "WxFixBoot is performing operations... Please wait.", pos=(xpos,10))
        xpos = DetermineTextPosition(Panel=self.ProgressPanel, text="Current Operation:", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.ProgressPanel, -1, "Current Operation:", pos=(xpos,40))
        xpos = DetermineTextPosition(Panel=self.ProgressPanel, text="Initializating...", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, "Initializating...", pos=(xpos,60))
        xpos = DetermineTextPosition(Panel=self.ProgressPanel, text="Current Operation Progress:", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.ProgressPanel, -1, "Current Operation Progress:", pos=(xpos,90))
        xpos = DetermineTextPosition(Panel=self.ProgressPanel, text="Overall Progress:", PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        wx.StaticText(self.ProgressPanel, -1, "Overall Progress:", pos=(xpos,160))

    def CreateButtons(self):
        #Create buttons.
        self.ShowOutputButton = wx.ToggleButton(self.ProgressPanel, -1, "Show Terminal output", pos=(330,220), size=(165,30))
        self.RestartButton = wx.Button(self.ProgressPanel, -1, "Restart WxFixBoot", pos=(10,220), size=(145,30))
        self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(209,260), size=(70,30))
        self.RestartButton.Disable()
        self.ExitButton.Disable()

    def CreateProgressBars(self):
        #Create the progress bar for the current operation.
        self.CurrentOpProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,120), size=(480,25))
        self.CurrentOpProgressBar.SetBezelFace(3)
        self.CurrentOpProgressBar.SetShadowWidth(3)
        self.CurrentOpProgressBar.SetValue(0)
        self.CurrentOpProgressBar.Show()

        #Create the progress bar for overall progress.
        self.TotalProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,190), size=(480,25))
        self.TotalProgressBar.SetBezelFace(3)
        self.TotalProgressBar.SetShadowWidth(3)
        self.TotalProgressBar.SetValue(0)
        self.TotalProgressBar.Show()

    def ShowThreadMsgdlg(self,msg,kind="info"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=<kind>, msg=<message>)
        global dlgClosed
        if kind == "info":
            title = "WxFixBoot - Information"
            style = wx.OK | wx.ICON_INFORMATION
        elif kind == "warning":
            title = "WxFixBoot - Warning"
            style = wx.OK | wx.ICON_EXCLAMATION
        elif kind == "error":
            title = "WxFixBoot - Error"
            style = wx.OK | wx.ICON_ERROR

        dlg = wx.MessageDialog(self.ProgressPanel, msg, title, style, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadYesNodlg(self,msg,title="WxFixBoot - Question"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=<message>, title=<title>)
        global dlgResult
        dlg = wx.MessageDialog(self.ProgressPanel, msg, title, wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("ProgressWindow().ShowThreadYesNodlg(): Result of MainBackendThread yesno dlg was: "+dlgResult)

    def ShowThreadChoicedlg(self,msg,choices,title="WxFixBoot - Select an Option"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=<message>, title=<title>, choices=<data>)
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.ProgressPanel, msg, title, choices, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("ProgressWindow().ShowThreadChoicedlg(): Result of MainBackendThread choice dlg was: "+dlgResult)

    def ShowThreadTextEntrydlg(self,msg,title="WxFixBoot - Text Entry"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=<message>, title=<title>)
        global dlgAnswer
        dlg = wx.TextEntryDialog(self.ProgressPanel, msg, title, "", style=wx.OK|wx.CANCEL, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetValue()
        else:
            dlgAnswer = "Clicked no..."
        logger.debug("ProgressWindow().ShowThreadTextEntrydlg(): Result of MainBackendThread text entry dlg was: "+dlgAnswer)

    def ShowThreadFiledlg(self,title="WxFixBoot - Select A File",wildcard="All Files/Devices (*)|*"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadFiledlg, title=<title>, wildcard=<wildcard>)
        global dlgAnswer
        dlg = wx.FileDialog(self.ProgressPanel, message=title, wildcard=wildcard, style=wx.SAVE)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetPath()
        else:
            dlgAnswer = "None"
        logger.debug("ProgressWindow().ShowThreadFiledlg(): Result of MainBackendThread file dlg was: "+dlgAnswer)

    def ShowOutput(self,e):
        #This now also works in openbox by resetting the minimum size too, forcing openbox to increase/decrease the size.
        logger.debug("ProgressWindow().ShowOutput() was Toggled to position: "+str(self.ShowOutputButton.GetValue())+", where True = Depressed and vice versa.")
        if self.ShowOutputButton.GetValue() == True:
            #Reset the frame size.
            #Catch an error if this is running on WxPython 2.8.
            try:
                self.SetMinClientSize(wx.Size(500,550))
            except AttributeError:
                self.SetMinSize(wx.Size(500,550))

            self.SetClientSize(wx.Size(500,550))

            #Create a text control for output.
            self.OutputBox = wx.TextCtrl(self.ProgressPanel, -1, "", pos=(10,260), size=(480,240), style=wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_WORDWRAP)
            self.OutputBox.SetBackgroundColour((0,0,0))
            self.OutputBox.SetDefaultStyle(wx.TextAttr(wx.WHITE))

            #Populate the outputbox with all the previous output.
            try:
                for line in OutputLog:
                    self.OutputBox.AppendText(line)
            except: pass
 
            #Move ExitButton, while preserving its enabled/disabled status.
            Temp = self.ExitButton.Enabled
            self.ExitButton.Destroy()
            self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(426,510), size=(70,30))

            if Temp == False:
                self.ExitButton.Disable()

            self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)     
        else:
            #Move ExitButton, while preserving its enabled/disabled status.
            Temp = self.ExitButton.Enabled
            self.ExitButton.Destroy()
            self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(209,260), size=(70,30))

            if Temp == False:
                self.ExitButton.Disable()
                PartitionTableFile = "None"

            self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)

            #Reset the frame size.
            #Catch an error if this is running on WxPython 2.8.
            try:
                self.SetMinClientSize(wx.Size(500,300))
            except AttributeError:
                self.SetMinSize(wx.Size(500,300))

            self.SetClientSize(wx.Size(500,300))
            self.OutputBox.Destroy()

    def UpdateOutputBox(self,msg):
        #Check if outputbox is enabled. Do nothing if it isn't.
        try:
            self.OutputBox.GetSelection()
        except: pass
        else:
            self.OutputBox.AppendText(msg)

    def UpdateCurrentProgress(self,msg):
        #Do current progress.
        #Called at various points during operation code.
        self.CurrentOpProgressBar.SetValue(int(msg))
        if self.CurrentOpProgressBar.GetValue() == 100:
            self.UpdateTotalProgress()
            #Stop this resetting when all operations are complete.
            if self.TotalProgressBar.GetValue() != 100:
                self.CurrentOpProgressBar.SetValue(0)

    def UpdateTotalProgress(self):
        #Do total progress.
        #This is called when self.CurrentOpProgressBar reaches 100 (aka full).
        if self.TotalProgressBar.GetValue() < 100:
            self.TotalProgressBar.SetValue(self.TotalProgressBar.GetValue()+(100/NumberOfOperationsToDo))

    def UpdateCurrentOpText(self,msg):
        #Function to keep the current operations status text up to date.
        #Create the Static Text, if it already exists, delete it.
        xpos = DetermineTextPosition(Panel=self.ProgressPanel, text=msg, PanelWidth=self.width)

        if str(xpos).isdigit() == False:
            #We need to resize the panel for the text to fit.
            self.width = xpos[0]
            self.SetClientSize(wx.Size(self.width, self.height))
            xpos = xpos[1]

        try:
            self.CurrentOpText
        except: pass
        else:
            self.CurrentOpText.Destroy()
        finally:
            self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, msg, pos=(xpos,60))

    def MainBackendThreadFinished(self):
        self.RestartButton.Enable()
        self.ExitButton.Enable()

    def RestartWxFixBoot(self,e):
        #Restart WxFixBoot
        logger.debug("ProgressWindow().RestartWxFixBoot(): Restarting WxFixBoot...")
        self.Hide()

        #Reset all settings to defaults, except ones like LiveDisk, which won't ever need to change.
        SetDefaults()

        global Bootloader
        global FirmwareType
        global RootFS
        global RootDevice
        global DefaultOS
        global PartScheme
        global UEFISystemPartition

        Bootloader = AutoBootloader
        FirmwareType = AutoFirmwareType
        RootFS = AutoRootFS
        RootDevice = AutoRootDevice
        DefaultOS = AutoDefaultOS
        PartSchemeList = AutoPartSchemeList
        UEFISystemPartition = AutoUEFISystemPartition

        #Show MainWindow
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        MainFrame.Show(True)

        #Destroy Progress Window.
        logger.debug("ProgressWindow().RestartWxFixBoot(): WxFixBoot has been reset and restarted, returning to MainWindow()")
        self.Destroy()

    def OnExit(self,e):
        #No need to check if operations are running, the button isn't clickable if any are.
        exitdlg = wx.MessageDialog(self.ProgressPanel, 'Are you sure you want to exit?', 'WxFixBoot -- Question!', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
        if exitdlg == wx.ID_YES:
            #Run the exit sequence
            logger.debug("ProgressWindow().OnExit(): User triggered exit sequence. Exiting...")
            if os.path.isdir("/tmp/wxfixboot"):
                shutil.rmtree('/tmp/wxfixboot')
            self.Destroy()

    def BindEvents(self):
        self.Bind(wx.EVT_TOGGLEBUTTON, self.ShowOutput, self.ShowOutputButton)
        self.Bind(wx.EVT_BUTTON, self.RestartWxFixBoot, self.RestartButton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

#End Progress Window
#Begin Main Backend Thread
class MainBackendThread(Thread):
    def __init__(self,ParentWindow):
        #Start the main part of this thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        self.start()

    def run(self):
        #Do setup
        self.templog = []
        time.sleep(1)

        #Log the MainBackendThread start event (in debug mode).
        logger.debug("MainBackendThread().run(): Started. Calculating Operations to do...")

        self.CountOperations()
        self.StartOperations()

    def CountOperations(self):
        #Count the number of operations to do.
        global NumberOfOperationsToDo

        #List to contain operations (and their functions) to run.
        self.OperationsToDo = []

        #Run a series of if loops to determine what operations to do, which order to do them in, and the total number to do.
        #Do essential processes first.
        if BackupPartitionTable == True:
            self.OperationsToDo.append(self.BackupPartitionTable)
            
            logger.info("MainBackendThread().CountOperations(): Added self.BackupPartitionTable to self.OperationsToDo...")

        if BackupBootSector == True:
            self.OperationsToDo.append(self.BackupBootSector)
            logger.info("MainBackendThread().CountOperations(): Added self.BackupBootSector to self.OperationsToDo...")

        if RestorePartitionTable == True:
            self.OperationsToDo.append(self.RestorePartitionTable)
            logger.info("MainBackendThread().CountOperations(): Added self.RestorePartitionTable to self.OperationsToDo...")

        if RestoreBootSector == True:
            self.OperationsToDo.append(self.RestoreBootSector)
            logger.info("MainBackendThread().CountOperations(): Added self.RestoreBootSector to self.OperationsToDo...")

        if QuickFSCheck == True:
            self.OperationsToDo.append(self.QuickFileSystemCheck)
            logger.info("MainBackendThread().CountOperations(): Added self.QuickFileSystemCheck to self.OperationsToDo...")

        if BadSectCheck == True:
            self.OperationsToDo.append(self.BadSectorCheck)
            logger.info("MainBackendThread().CountOperations(): Added self.BadSectorCheck to self.OperationsToDo...")

        #Now do other processes
        if BootloaderToInstall != "None":
            self.OperationsToDo.append(self.ManageBootloaders)
            logger.info("MainBackendThread().CountOperations(): Added self.ManageBootloaders to self.OperationsToDo...")

        if ReinstallBootloader == True:
            self.OperationsToDo.append(self.ReinstallBootloader)
            logger.info("MainBackendThread().CountOperations(): Added self.ReinstallBootloader to self.OperationsToDo...")

        if UpdateBootloader == True:
            self.OperationsToDo.append(self.UpdateBootloader)
            logger.info("MainBackendThread().CountOperations(): Added self.UpdateBootloader to self.OperationsToDo...")

        #Check if we need to prepare to install a new bootloader, and do so first if needed.
        for element in [self.ManageBootloaders, self.ReinstallBootloader, self.UpdateBootloader]:
            if element in self.OperationsToDo:
                self.OperationsToDo.insert(0, self.PrepareForBootloaderInstallation)

        NumberOfOperationsToDo = len(self.OperationsToDo)

        #Log gathered operations to do, and the number (verbose mode, default).
        logger.info("MainBackendThread().CountOperations(): Number of operations: "+str(NumberOfOperationsToDo))
        logger.info("MainBackendThread().CountOperations(): Starting Operation Running Code...")

    def StartOperations(self):
        #Start doing operations.
        global OutputLog
        OutputLog = []

        if NumberOfOperationsToDo == 0:
            self.ShowMsgDlg(Kind="error", Message="You didn't select any operations! Please restart WxFixBoot to select any operations you wish to perform.")
        else:
            self.ShowMsgDlg(Kind="info", Message="Please stay within sight of the system, as operations are not fully automated and you may be asked the occasional queston, or be shown warnings. You may also see the occasional file manager dialog pop up as well, so feel free to either close them or ignore them.")

            #Run functions to do operations.
            for function in self.OperationsToDo:
                function()

            logger.info("MainBackendThread().StartOperations(): Finished Operation Running Code.")

            #Save a system report if needed.
            if MakeSystemSummary == True:
                logger.info("MainBackendThread().StartOperations(): Generating System Report...")
                self.GenerateSystemReport()
                logger.info("MainBackendThread().StartOperations(): Done, finished all operations.")

            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished!")

            self.ShowMsgDlg(Kind="info", Message="Your operations are all done! Thank you for using WxFixBoot. If you performed any bootloader operations, please now reboot your system.")

        wx.CallAfter(self.ParentWindow.MainBackendThreadFinished)

    ####################Dialog functions to keep the code tidy.####################

    def ShowMsgDlg(self,Message,Kind="info"):
        #Method to handle showing thread message dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowMsgDlg(Kind=<kind>, Message=<message>)
        #Reset dlgClosed, avoiding errors.
        global dlgClosed
        dlgClosed = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=Kind, msg=Message)

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

    def ShowYesNoDlg(self,Message,Title="WxFixBoot - Question"):
        #Method to handle showing thread yes/no dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowYesNoDlg(Message=<message>, Title = <title>)
        #Reset dlgResult, avoiding errors.
        global dlgResult
        dlgResult = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=Message, title=Title)

        #Trap the thread until the user responds.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        #Return dlgResult directly potentially avoiding problems.
        return dlgResult

    def ShowChoiceDlg(self,Message,Title,Choices):
        #Method to handle showing thread choice dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowChoiceDlg(Message=<message>, Title=<title>, Choices=<choices>)
        while True:
            #Reset dlgResult, avoiding errors.
            global dlgResult
            dlgResult = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=Message, title=Title, choices=Choices)

            #Trap the thread until the user responds.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgResult == "" or dlgResult == "Clicked no...":
                self.ShowMsgDlg(Kind="warning", Message="Please make an appropriate selection.")
            else:
                #Return dlgResult directly potentially avoiding problems.
                return dlgResult

    def ShowTextEntryDlg(self,Message,Title="WxFixBoot - Text Entry"):
        #Method to handle showing thread text entry dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowTextEntryDlg(Message=<message>, Title=<title>)
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=Message, title=Title)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgAnswer == "":
                self.ShowMsgDlg(Kind="warning", Message="Please enter a value or click cancel.")
            else:
                #Return dlgAnswer directly potentially avoiding problems.
                return dlgAnswer

    def ShowFileDlg(self,Title="WxFixBoot - Select A File",Wildcard="All Files/Devices (*)|*"):
        #Method to handle showing thread file dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowFileDlg(Title=<title>, Wildcard=<wildcard>)
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadFiledlg, title=Title, wildcard=Wildcard)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgAnswer == "None":
                self.ShowMsgDlg(Kind="warning", Message="Please select a valid file.")
            else:
                #Return dlgAnswer directly potentially avoiding problems.
                return dlgAnswer

    ####################End of Dialog functions.####################
    ####################Core functions that are used all the time, kept here to avoid duplication.####################

    def StartThreadProcess(self, ExecCmds, Piping=False, ShowOutput=True, ReturnOutput=False):
        #Start a process given a list with commands to execute, specifically for this thread, as it also sends the output to self.UpdateOutputBox().
        #This now uses a set of default values, to keep it simple. It can be called with self.StartThreadProcess(ExecCmds=[], ShowOutput=True) etc. Only ExecCmds is compulsory.
        #Reset templog
        templog = []

        #Run the cmd.
        if Piping == False:
            logger.debug("MainBackendThread().StartThreadProcess(): Starting process: "+' '.join(ExecCmds))
            runcmd = subprocess.Popen(ExecCmds, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        else:
            logger.debug("MainBackendThread().StartThreadProcess(): Starting process: "+ExecCmds)
            runcmd = subprocess.Popen(ExecCmds, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)

        while runcmd.poll() == None:
            #Send given line to the outputbox and Log it too, if ShowOutput == True or if FullVerbose == True 
            line = runcmd.stdout.readline()
            templog.append(line)
            if ShowOutput == True or FullVerbose == True:
                self.UpdateOutputBox(line=line)
            else:
                OutputLog.append(line)

        #Save runcmd.stdout.readlines, and runcmd.returncode, as they tend to reset fairly quickly.
        output = runcmd.stdout.readlines()
        retval = int(runcmd.returncode)

        #Add any missing output (this is what templog is helpful for: it'll contain only output from this command).
        for line in output:
            if line not in templog:
                templog.append(line)
                if ShowOutput == True or FullVerbose == True:
                    self.UpdateOutputBox(line=line)
                else:
                    OutputLog.append(line)

        #Log this info in a debug message.
        try:
            if Piping == True:
                logger.debug("MainBackendThread().StartThreadProcess(): Process: "+ExecCmds+": Return Value: "+str(retval)+", Output: \"\n\n"+''.join(templog)+"\"\n")
            else:
                logger.debug("MainBackendThread().StartThreadProcess(): Process: "+' '.join(ExecCmds)+": Return Value: "+str(retval)+", Output: \"\n\n"+''.join(templog)+"\"\n")
        except UnicodeDecodeError:
	        #Skip logging the output, but do note we couldn't log the output.
            if Piping == True:
                logger.debug("MainBackendThread().StartThreadProcess(): Process: "+ExecCmds+": Return Value: "+str(retval)+", Output: \"\n\nCouldn't write data due to unicode decode error\"\n")
            else:
                logger.debug("MainBackendThread().StartThreadProcess(): Process: "+' '.join(ExecCmds)+": Return Value: "+str(retval)+", Output: \"\n\nCouldn't write data due to unicode decode error\"\n")

        if ReturnOutput == False:
            #Return the return code back to whichever function ran this process, so it can handle any errors.
            return retval
        else:
            #Return the return code, as well as the output.
            return [retval, ''.join(templog)]

    def UpdateOutputBox(self, line):
        #Send given line to the outputbox.
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, line)

        #Also, update the output log with this info.
        OutputLog.append(line)

    def RemountPartitionRW(self, Partition):
        #Remount a given FS (or mountpoint) read-write.
        logger.debug("MainBackendThread().RemountPartitionRW(): Preparing to remount partition: "+Partition)

        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            logger.debug("MainBackendThread().RemountPartitionRW(): Partition: "+Partition+" isn't mounted, so we'll mount it RW now...")
            retval = self.StartThreadProcess(ExecCmds=['mount', Partition], ShowOutput=False)
        else:
            logger.debug("MainBackendThread().RemountPartitionRW(): Remounting partition: "+Partition+"...")
            retval = self.StartThreadProcess(ExecCmds=['mount', '-o', 'remount,rw', Partition], ShowOutput=False)

        #Check that this worked okay.
        if retval != 0:
            #It didn't, for some strange reason.
            logger.warning("MainBackendThread().RemountPartitionRW(): Remounting partition: "+Partition+": Failed!")
        else:
            logger.info("MainBackendThread().RemountPartitionRW(): Remounting partition: "+Partition+": Success!")

        #Return the return value
        return retval

    def RemountPartitionRO(self, Partition):
        #Remount a given FS (or mountpoint) read-only.
        logger.debug("MainBackendThread().RemountPartitionRO(): Preparing to remount partition: "+Partition)

        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            logger.debug("MainBackendThread().RemountPartitionRO(): Partition: "+Partition+" isn't mounted, so we'll mount it RO now...")
            retval = self.StartThreadProcess(ExecCmds=['mount', '-o', 'ro', Partition], ShowOutput=False)
        else:
            logger.debug("MainBackendThread().RemountPartitionRO(): Remounting partition: "+Partition+"...")
            retval = self.StartThreadProcess(['mount', '-o', 'remount,ro', Partition], ShowOutput=False)

        #Check that this worked okay.
        if retval != 0:
            #It didn't, for some strange reason.
            logger.warning("MainBackendThread().RemountPartitionRO(): Remounting partition: "+Partition+": Failed!")
        else:
            logger.info("MainBackendThread().RemountPartitionRO(): Remounting partition: "+Partition+": Success!")

        #Return the return value
        return retval

    def UnmountPartition(self, Partition):
        #Unmount the given partition, or mountpoint.
        logger.debug("MainBackendThread().UnmountPartition(): Preparing to Unmount partition: "+Partition)

        #Check if it is mounted.
        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            #The Partition isn't mounted.
            #Set retval to 0 and log this.
            retval = 0
            logger.info("MainBackendThread().UnmountPartition(): Partition: "+Partition+" was not mounted. Continuing...")
        else:
            logger.debug("MainBackendThread().UnmountPartition(): Unmounting partition: "+Partition+"...")
            retval = self.StartThreadProcess(['umount', Partition], ShowOutput=False)

            #Check that this worked okay.
            if retval != 0:
                #It didn't, for some strange reason.
                logger.warning("MainBackendThread().UnmountPartition(): Unmounting partition: "+Partition+": Failed!")
            else:
                logger.info("MainBackendThread().UnmountPartition(): Unmounting partition: "+Partition+": Success!")
            
        #Return the return value
        return retval

    def SetUpChroot(self, MountPoint):
        #Function to set up a chroot for the given mountpoint.
        logger.debug("MainBackendThread().SetUpChroot(): Setting up chroot for MountPoint: "+MountPoint+"...")

        #Mount /dev, /dev/pts, /proc and /sys for the chroot. Return values and terminal output will be logged by self.StartThreadProcess().
        #We might also need internet access in chroot, so to do this first backup MountPoint/etc/resolv.conf to MountPoint/etc/resolv.conf.bak (if it's a link, this will also preserve it),
        #then copy current system's /etc/resolv.conf (the contents, not the link) to MountPoint/etc/resolv.conf, enabling internet access.

        Templist = [['mount', '--bind', '/dev', MountPoint+'/dev'], ['mount', '--bind', '/dev/pts', MountPoint+'/dev/pts'], ['mount', '--bind', '/proc', MountPoint+'/proc'], ['mount', '--bind', '/sys', MountPoint+'/sys'], ['mv', '-vf', MountPoint+'/etc/resolv.conf', MountPoint+'/etc/resolv.conf.bak'], ['cp', '-fv', '/etc/resolv.conf', MountPoint+'/etc/resolv.conf']] 

        for ExecList in Templist:
            Result = self.StartThreadProcess(ExecList, ShowOutput=False, ReturnOutput=True)
            output = Result[1]
            retval = Result[0]

            if retval != 0:
                logger.error("MainBackendThread().SetUpChroot(): Error: Failed to run command: "+', '.join(ExecList)+"! Chroot may not be set up properly!")

        self.UpdateChrootMtab(MountPoint=MountPoint)

        logger.debug("MainBackendThread().SetUpChroot(): Finished setting up chroot for MountPoint: "+MountPoint+"...")

    def TearDownChroot(self, MountPoint):
        #Function to remove a chroot at the given mountpoint.
        logger.debug("MainBackendThread().TearDownChroot(): Removing chroot at MountPoint: "+MountPoint+"...")

        #Unmount /dev/pts, /dev, /proc and /sys in the chroot. Return values and terminal output will be logged by self.StartThreadProcess().
        #We'll also need to replace the MountPoint/etc/resolv.conf with the backup file, MountPoint/etc/resolv.conf.bak. Do this last.

        Templist = [['umount', MountPoint+'/dev/pts'], ['umount', MountPoint+'/dev'], ['umount', MountPoint+'/proc'], ['umount', MountPoint+'/sys'], ['mv', '-vf', MountPoint+'/etc/resolv.conf.bak', MountPoint+'/etc/resolv.conf']]

        for ExecList in Templist:
            Result = self.StartThreadProcess(ExecList, ShowOutput=False, ReturnOutput=True)
            output = Result[1]
            retval = Result[0]

            if retval != 0:
                logger.error("MainBackendThread().TearDownChroot(): Failed to run command: "+', '.join(ExecList)+"! Chroot may not be removed properly!")

        logger.debug("MainBackendThread().TearDownChroot(): Finished removing chroot at MountPoint: "+MountPoint+"...")

    def UpdateChrootMtab(self, MountPoint):
        #Function to update /etc/mtab inside a chroot, so the list of mounted filesystems is always right.
        logger.debug("MainBackendThread().UpdateChrootMtab: Updating /etc/mtab for chroot at: "+MountPoint+"...")

        retval = self.StartThreadProcess(['cp', '-vf', '/proc/self/mounts', MountPoint+'/etc/mtab'], ShowOutput=False)

        if retval != 0:
            logger.error("MainBackendThread().UpdateChrootMtab(): Failed to run command: cp -vf /proc/self/mounts "+MountPoint+"/etc/mtab! Chroot may not set up properly! This *probably* doesn't matter, but in rare situations it could cause problems.")

        logger.debug("MainBackendThread().UpdateChrootMtab: Finished updating /etc/mtab for chroot at: "+MountPoint+".")

    def GetPartitionUUID(self, Partition):
        #Function to retrive a partition's UUID.
        logger.info("MainBackendThread().GetPartitionUUID(): Getting UUID for partition: "+Partition+"...")

        Temp = self.StartThreadProcess(['blkid', '-o', 'list'], ShowOutput=False, ReturnOutput=True)
        retval = Temp[0]
        output = Temp[1].split('\n')

        if retval != 0:
            #We couldn't find the UUID! Return "None".
            logger.warning("MainBackendThread().GetPartitionUUID(): Couldn't find UUID for partition: "+Partition+"! This may cause problems down the line.")
            return "None"
        else:
            #Try to get the UUID from blkid's output.
            UUID="None"

            for line in output:
                if Partition in line:
                    UUID=line.split()[-1]

            if UUID != "None":
                logger.info("MainBackendThread().GetPartitionUUID(): Found UUID ("+UUID+") for partition: "+Partition+"...")
            else:
                logger.warning("MainBackendThread().GetPartitionUUID(): Couldn't find UUID for partition: "+Partition+"! This may cause problems down the line.")

            return UUID

    def GetDeviceID(self, Device):
        #Function to retrive a partition's/device's ID.
        logger.info("MainBackendThread().GetDeviceID(): Getting ID for partition/device: "+Device+"...")

        Temp = self.StartThreadProcess(['ls', '-l', '/dev/disk/by-id/'], ShowOutput=False, ReturnOutput=True)
        retval = Temp[0]
        output = Temp[1].split('\n')

        if retval != 0:
            #We couldn't find the ID! Return "None".
            logger.warning("MainBackendThread().GetDeviceID(): Couldn't find ID for partition/device: "+Device+"! This may cause problems down the line.")
            return "None"
        else:
            #Try to get the ID from ls's output.
            ID = "None"

            for line in output:
                try:
                    SplitLine = line.split()
                    if "../../"+Device.split('/')[-1] == SplitLine[-1]:
                        ID = SplitLine[-3]
                except:
                    pass

            if ID != "None":
                logger.info("MainBackendThread().GetDeviceID(): Found ID ("+ID+") for partition/device: "+Device+"...")
            else:
                logger.warning("MainBackendThread().GetDeviceID(): Couldn't find ID for partition/device: "+Device+"! This may cause problems down the line.")

            return ID

    ####################End of Core functions.####################
    ####################Helper Functions that are used a few times by other functions.####################

    def CheckInternetConnection(self):
        #Function to check the internet connection.
        self.ShowMsgDlg(Kind="info", Message="Your internet connection will now be tested to ensure it's safe to do bootloader operations.")
        Retry = True

        logger.info("MainBackendThread().CheckInternetConnection(): Checking the Internet Connection...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Checking the Internet Connection...")
        self.UpdateOutputBox("\n###Checking the Internet Connection...###\n")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 5)
        DisableBLOps = "No"

        while True:
            #Test the internet connection by pinging an OpenDNS DNS server.
            PacketLoss = "100%"
            try:
                Temp = self.StartThreadProcess(['ping', '-c', '5', '-i', '0.5', '208.67.222.222'], ShowOutput=False, ReturnOutput=True)
                output = Temp[1]

                #Check if we got 0% packet loss.
                SplitOutput = output.split('\n')
    
                for line in SplitOutput:
                    if 'packet loss' in line:
                        PacketLoss = line.split()[-5]

            except IndexError:
                #This errored for some reason. Probably no internet connection.
                PacketLoss = "100%"

            if PacketLoss == "0%":
                #Good! We have a reliable internet connection.
                break
            else:
                #Uh oh! We DON'T have a reliable internet connection! Ask the user to either try again, or skip Bootloader operations.
                Result = self.ShowYesNoDlg(Message="Your Internet Connection failed the test! Without a working internet connection, you cannot perform bootloader operations! Click yes to try again, and click no to give up and skip bootloader operations.", Title="WxFixBoot - Disable Bootloader Operations?")

                if Result == "No":
                    DisableBLOps = "Yes"
                    break
                else:
                    #We'll just run the loop again.
                    pass

        #Exit, and return witha string stating whether or not to disable BL ops.
        return DisableBLOps

    def FindMissingFSCKModules(self):
        #Function to check for and return all missing fsck modules (fsck.vfat, fsck.minix, etc), based on the FS types in PartitionListWithFSType.
        logger.info("MainBackendThread().FindMissingFSCKModules(): Looking for missing FSCK modules to ignore...")
        failedlist = []

        for FSType in PartitionListWithFSType:
            #Check if we're looking at a FSType, not a device, and that we've not marked it "Unknown". Otherwise ignore it.
            if FSType[0] != "/" and FSType != "Unknown":
                try:
                    runcmd = subprocess.Popen(["fsck."+FSType], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    stdout, stderr = runcmd.communicate()
                except OSError:
                    #OS probably couldn't find it, add it to the failed list.
                    logger.warning("MainBackendThread().FindMissingFSCKModules(): Couldn't find FSCK module: fsck."+FSType+"! Adding it to the list of missing modules...")
                    failedlist.append("fsck."+FSType)
                else:
                    if str(stderr) != "None":
                        #It was found, but errored for an unknown reason. Add it to the failed list.
                        logger.warning("MainBackendThread().FindMissingFSCKModules(): Found FSCK module: fsck."+FSType+", but it errored for an unknown reason! Adding it to the list of missing modules...")
                        failedlist.append("fsck."+FSType)

        #Return the list, so FSCheck functions know which FSes to ignore.
        logger.info("MainBackendThread().FindMissingFSCKModules(): Done! Missing FSCK modules: "+', '.join(failedlist))
        return failedlist

    def LookForAPTOnPartition(self, APTExecList):
        #Look for apt using the command lists given (they include the partition, by the way).
        logger.debug("MainBackendThread().LookForAPTOnPartition() has been triggered...")

        #Check for APT
        try:
            subprocess.check_output(APTExecList)
        except:
            #Couldn't find apt!
            return "None"
        else:
            #Found APT!
            #Return 'APT'
            return "apt-get"

    def LookForBootloaderOnPartition(self, PackageManager, MountPoint, UsingChroot):
        #Look for the currently installed bootloader in the given mount point.
        logger.debug("MainBackendThread().LookForBootloaderOnPartition() has been triggered...")

        #Okay, let's run a command in the chroot that was set up in self.FindBootloaderRemovalOSs(), depending on which package manager this OS uses, and which bootloader is currently installed.
        #To do this, we need to tell self.StartThreadProcess() that we're going to be using pipes on the commandline, so we can use shell=True.

        if Bootloader == "GRUB-LEGACY":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep -w 'grub'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep -w 'grub'", Piping=True, ShowOutput=False)

        elif Bootloader == "GRUB2":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep 'grub-pc' | grep -w 'install'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep 'grub-pc' | grep -w 'install'", Piping=True, ShowOutput=False)

        elif Bootloader == "LILO":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep -w 'lilo' | grep -w 'install'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep -w 'lilo' | grep -w 'install'", Piping=True, ShowOutput=False)

        elif Bootloader == "GRUB-UEFI":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep 'grub-efi' | grep -w 'install'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep 'grub-efi' | grep -w 'install'", Piping=True, ShowOutput=False)

        elif Bootloader == "ELILO":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep  -w 'elilo' | grep -w 'install'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep -w 'elilo' | grep -w 'install'", Piping=True, ShowOutput=False)

        #Now we can check the return value. If it's 0, the bootloader is present in this OS. Otherwise, it isn't.
        if retval == 0:
            logger.info("MainBackendThread().LookForBootloaderOnPartition(): Found "+Bootloader+" in "+MountPoint+"...")
            return "Yes"
        else:
            logger.info("MainBackendThread().LookForBootloaderOnPartition(): Didn't find "+Bootloader+" in "+MountPoint+"...")
            return "No"

    def FindCheckableFileSystems(self):
        #Find all checkable filesystems, and then return them to self.BadSectorCheck()/self.QuickFSCheck()
        logger.info("MainBackendThread().FindCheckableFileSystems(): Finding and returning all filesystems/partitions that can be checked...")

        #Do setup.
        DoNotCheckList = []
        CheckList = []

        #Get a list of missing fsck modules (if any) based on the existing filesystems.
        MissingFSCKModules = self.FindMissingFSCKModules()

        #Determine checkable partitions.
        for Partition in PartitionListWithFSType:
            #Make sure we're looking at a partition, if not, ignore it.
            if Partition[0] == "/":
                #Find the FSType (the next element)
                FSType = PartitionListWithFSType[PartitionListWithFSType.index(Partition)+1]

                #Check if the required fsck module is present, and that the partition isn't RootFS
                if "fsck."+FSType not in MissingFSCKModules and FSType != "Unknown":
                    #If we're not running on a live disk, skip the filesystem if it's the same as RootFS (in which case checking it may corrupt data)
                    if LiveDisk == False and Partition == AutoRootFS:
                        CheckTheFS = "No"
                        RemountPartitionAfter = "No"
                        continue

                    #Check if the partition is mounted.
                    try:
                        Temp = subprocess.check_output("df | grep "+Partition, shell=True).split()[-1]
                    except subprocess.CalledProcessError:
                        #Not mounted.
                        CheckTheFS = "Yes"
                        RemountPartitionAfter = "No"
                    else:
                        #Unmount the FS temporarily, to avoid data corruption.
                        retval = self.UnmountPartition(Partition=Partition)

                        #Check that this worked okay.
                        if retval != 0:
                            #It didn't, for some strange reason. Log it.
                            logger.warning("MainBackendThread().FindCheckableFileSystems(): Failed to unmount the partition: "+Partition+", which is necessary for safe disk checking! Ignoring it, becuase it's probably a home directory (if running an OS on the HDD, and not a live disk) or an essential system dir...")
                            CheckTheFS = "No"
                            RemountPartitionAfter = "No"
                        else:
                            CheckTheFS = "Yes"
                            RemountPartitionAfter = "Yes"
                else:
                    CheckTheFS = "No"
                    RemountPartitionAfter = "No"

                if CheckTheFS == "No":
                    #Add it to the non-checkable list
                    DoNotCheckList.append(Partition+" with Filesystem: "+FSType)
                else:
                    #Add it to the list for checking.
                    CheckList.append(Partition+" "+FSType+" "+RemountPartitionAfter)

        #Report uncheckable partitions.
        if DoNotCheckList != []:
            #Some filesystems will not be checked. Tell the user.
            self.ShowMsgDlg(Kind="info", Message="The following filesystems will not be checked:\n\n"+'\n'.join(DoNotCheckList)+".\n\nThe most likely reason for this is that some of the filesystems are in use, or that the required filesystem checkers weren't found. WxFixBoot will now continue to check the remaining filesystems.")

        logger.info("MainBackendThread().FindCheckableFileSystems(): Done! Filesystems that won't be checked: "+'\n'.join(DoNotCheckList)+"...")
        return CheckList

    def HandleFilesystemCheckReturnValues(self, ExecList, retval, Partition):
        #Function to handle Filesystem Checker return codes, because it's more complicated than you'd think, and it simpifies the code.
        #Return values of 1,2 or 3 happen if errors were corrected.
        if retval in [1, 2, 3]:
            if ExecList[0] == "xfs_repair":
                #Fs Corruption Detected.
                logger.warning("MainBackendThread().HandleFilesystemCheckReturnValues(): xfs_repair detected filesystem corruption on FileSystem: "+Partition+". It's probably (and hopefully) been fixed, but we're logging this anyway.")
                self.ShowMsgDlg(Kind="warning", Message="Corruption was found on the filesystem: "+Partition+"! Fortunately, it looks like the checker utility has fixed the corruption. Click okay to continue.")
            elif ExecList[0] in ['fsck.jfs', 'fsck.minix', 'fsck.reiserfs', 'fsck.vfat', 'fsck.ext2', 'fsck.ex3', 'fsck.ext4', 'fsck.ext4dev']:
                #Fixed Errors.
                logger.info("MainBackendThread().HandleFilesystemCheckReturnValues(): "+ExecList[0]+" successfully fixed errors on the partition: "+Partition+". Continuing...")
                self.ShowMsgDlg(Kind="warning", Message="The filesystem checker found and successfully fixed errors on partition: "+Partition+". Click okay to continue.")
        else:
            #Something bad happened!
            logger.error("MainBackendThread().HandleFilesystemCheckReturnValues(): "+ExecList[0]+" Errored with exit value "+str(retval)+"! This could indicate filesystem corruption or bad sectors! Asking the user whether to skip any bootloader operations...")
            Result = self.ShowYesNoDlg(Message="Error! The filesystem checker gave exit value: "+str(retval)+"! This could indicate filesystem corruption, a problem with the filesystem checker, or bad sectors on partition: "+Partition+". If you perform bootloader operations on this partition, WxFixBoot could become unstable, and your system could become unbootable. Do you want to disable bootloader operations, as is strongly recommended?", Title="WxFixBoot - Disable Bootloader Operations?")

            if Result == "Yes":
                #A good choice. WxFixBoot will now disable any bootloader operations.
                logger.warning("MainBackendThread().HandleFilesystemCheckReturnValues(): User disabled bootloader operations as recommended, due to bad sectors/HDD problems/FS Checker problems...")
                global OSsForBootloaderRemoval
                global OSsForBootloaderInstallation
                OSsForBootloaderRemoval = []
                OSsForBootloaderInstallation = ["None,FSCKProblems"]
            else:
                #Seriously? Well, okay, we'll do it anyway... This is probably a very bad idea...
                logger.warning("MainBackendThread().HandleFilesystemCheckReturnValues(): User ignored the warning and went ahead with bootloader modifications (if any) anyway, even with possible HDD problems/Bad sectors! This is a REALLY bad idea, but we'll do it anyway, as requested...")

    def FindBootloaderRemovalOSs(self, OSListWithPackageManagers):
        #Function to find the OS(es) that currently have the bootloader installed, so we know where to remove it from.
        logger.info("MainBackendThread().FindBootloaderRemovalOSs(): Looking for Operating Systems that currently have the bootloader installed, to add to the removal list...")

        #Define a global var.
        global OSsForBootloaderRemoval
        OSsForBootloaderRemoval = []

        for OS in OSListWithPackageManagers:
            #Grab the Package Manager and the partition the OS resides on.
            PackageManager = OS.split()[-1]
            Partition = OS.split()[-5]
            MountPoint = "/mnt"+Partition

            #Run some different instructions depending on whether the partition = AutoRootFS or not.
            if LiveDisk == False and Partition == AutoRootFS:
                #It is! We can skip some steps!
                #Try to find if this OS has the bootloader installed in it.
                found = self.LookForBootloaderOnPartition(PackageManager=PackageManager, MountPoint=MountPoint, UsingChroot=False)

            else:
                #Do some additional steps if we're using
                #Mount the partition safely, using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, and skip the rest of the loop, as it's safer to do so.
                    logger.warning("MainBackendThread().FindBootloaderRemovalOSs(): Command: 'mount "+MountPoint+" /mnt/"+MountPoint+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                    continue

                #Set up a chroot.
                self.SetUpChroot(MountPoint=MountPoint)

                #Try to find if the OS has the bootloader installed in it.
                found = self.LookForBootloaderOnPartition(PackageManager=PackageManager, MountPoint=MountPoint, UsingChroot=True)
                
                #Tear down the chroot.
                self.TearDownChroot(MountPoint=MountPoint)

                #Unmount the partition.
                self.UnmountPartition(Partition=Partition)

            #Check if the bootloader was found on that partition. If it wasn't, don't do anything.
            if found == "Yes":
                #It was! Add it to the list.
                OSsForBootloaderRemoval.append(OS)
                logger.info("MainBackendThread().FindBootloaderRemovalOSs(): Found bootloader to remove: "+Bootloader+" On OS: "+OS+". Adding it to the list. Continuing...")

        #Return the list to self.PrepareForBootloaderInstallation()
        logger.info("MainBackendThread().FindBootloaderRemovalOSs(): Finished populating OSsForBootloaderRemoval. Contents: "+', '.join(OSsForBootloaderRemoval)+"...")
        return OSsForBootloaderRemoval

    def AskUserForBootloaderInstallationOSs(self, OSListWithPackageManagers):
        #Function to ask the user where the new bootloader is to be installed.
        global OSsForBootloaderInstallation
        OSsForBootloaderInstallation = []

        if len(OSListWithPackageManagers) == 1:
            if UpdateBootloader == True:
                self.ShowMsgDlg(Kind="info", Message="Your bootloader will be updated.")
            else:
                self.ShowMsgDlg(Kind="info", Message="Your bootloader will be removed from the following Operating Systems ("+', '.join(OSsForBootloaderRemoval)+").")

            OSsForBootloaderInstallation = OSListWithPackageManagers[:]
            logger.info("MainBackendThread().AskUserForInstallationOSs(): Installing the new bootloader in OS(s): "+', '.join(OSsForBootloaderInstallation))
        else:
            if UpdateBootloader == True or ReinstallBootloader == True:
                self.ShowMsgDlg(Kind="info", Message="Your bootloader will be updated or reinstalled in all Operating Systems it is installed in ("+', '.join(OSsForBootloaderRemoval)+"). Click okay to continue.")
                OSsForBootloaderInstallation = OSsForBootloaderRemoval[:]

            else:
                logger.info("MainBackendThread().AskUserForBootloaderInstallationOSs(): There is more than one Operating System with a supported package manager. Asking the user which ones to install the new bootloader in...")
                self.ShowMsgDlg(Kind="info", Message="Your bootloader will be removed in all Operating Systems it is installed in ("+', '.join(OSsForBootloaderRemoval)+"). You will now be asked which Operating Systems you want your new bootloader to be installed in. If you want to select more than one, you must select one at a time, click okay and in the following dialog say you want to install the bootloader to another OS as well.")

                while True:
                    #Make a list of candidates to install the bootloader in (only including OSes that will have their bootloaders removed).
                    BootloaderCandidatesList = []

                    for OS in OSListWithPackageManagers:
                        if OS not in OSsForBootloaderInstallation:
                            BootloaderCandidatesList.append(OS)

                    logger.debug("MainBackendThread().AskUserForBootloaderInstallationOSs(): Contents of BootloaderCandidatesList: "+', '.join(BootloaderCandidatesList))

                    if len(BootloaderCandidatesList) == 0:
                        #We've run out of OSs to add. Tell the user and break out of the loop.
                        logger.info("MainBackendThread().AskUserForBootloaderInstallationOSs(): Run out of OSs to add to OSsForBootloaderInstallation (contents: "+', '.join(OSsForBootloaderInstallation)+"). Continuing...") 
                        if UpdateBootloader == False:
                            self.ShowMsgDlg(Kind="info", Message="There are no more Operating Systems to add to the bootloader installation list. Click okay to continue.")
                        break

                    logger.info("MainBackendThread().AskUserForBootloaderInstallationOSs(): Asking the user which new OS to install the bootloader to...")

                    #Ask the user which candidate(s) to use for bootloader installation.
                    Result = self.ShowChoiceDlg(Message="Please select each OS you'd like to modify or install the bootloader to.\nIdeally, select the ones that you use most frequently.", Title="WxFixBoot - Select Operating Systems For Bootloader Installation", Choices=BootloaderCandidatesList)

                    logger.info("MainBackendThread().AskUserForBootloaderInstallationOSs(): User selected OS: "+Result+"...")

                    #Add the user's suggestion to the new list.
                    OSsForBootloaderInstallation.append(Result)

                    #If there are more OSes to add, ask the user if he/she wants to add any more.
                    if len(BootloaderCandidatesList) > 0:
                        logger.debug("MainBackendThread().AskUserForBootloaderInstallationOSs(): Asking the user whether to install the bootloader to another OS...")
                        Result = self.ShowYesNoDlg(Message="Do you want to modify or install the new bootloader in any other Operating Systems?", Title="WxFixBoot - Install or Modify Bootloader in other OSs?")

                        #Break out of the loop if the user said no.
                        if Result == "No":
                            logger.debug("MainBackendThread().AskUserForBootloaderInstallationOSs(): Asking the user which new OS to install the bootloader to... User said no. Terminating loop...")
                            break
                        else:
                            logger.debug("MainBackendThread().AskUserForBootloaderInstallationOSs(): Asking the user which new OS to install the bootloader to... User said yes. Continuing to loop...")

            logger.info("MainBackendThread().AskUserForInstallationOSs(): Finished selecting OSs! Modifying or Installing the new bootloader in: "+', '.join(OSsForBootloaderInstallation))

    def WriteFSTABEntryForUEFIPartition(self, MountPoint):
        #Write an /etc/fstab entry for the UEFI System Partition, if there isn't already one.
        logger.info("MainBackendThread().WriteFSTABEntryForUEFIPartition(): Preparing to write an fstab entries for the UEFI partition ("+UEFISystemPartition+")...")

        WriteEntry = True

        #Make the directory MountPoint/boot/efi if it doesn't already exist.
        if os.path.isdir(MountPoint+"/boot/efi") == False:
            os.makedirs(MountPoint+"/boot/efi")

        #Get the UEFI System Partition's UUID.
        UUID = self.GetPartitionUUID(UEFISystemPartition)

        #Open the MountPoint/etc/fstab file for reading. If we aren't using chroot, this'll just be /etc/fstab, otherwise, /mnt/dev/sdax/etc/fstab. Also, save its contents in a variable.
        fstab = open(MountPoint+"/etc/fstab", "r")
        NewFileContents = []

        for line in fstab:
            if UEFISystemPartition in line or "UUID="+UUID in line:
                #This fstab already has an entry for the UEFI System Partition!
                WriteEntry = False

            NewFileContents.append(line)

        #Check if we need to write the entry.
        if WriteEntry == False:
            #We don't!
            logger.info("MainBackendThread().WriteFSTABEntryForUEFIPartition(): fstab entry already present! Skipping...")
        else:
            #We do. If we can use the UUID, then we will, but otherwise we'll use the standard device name.
            logger.info("MainBackendThread().WriteFSTABEntryForUEFIPartition(): Writing fstab entry...")
            NewFileContents.append("\n#fstab entry for UEFI System Partition (Partition "+UEFISystemPartition+"), written by WxFixBoot.\n")

            if UUID != "None":
                logger.info("MainBackendThread().WriteFSTABEntryForUEFIPartition(): Found UUID for UEFI Partition: "+UEFISystemPartition+". We'll use it to prevent problems down the line...")
                NewFileContents.append("UUID="+UUID+" /boot/efi vfat defaults 0 2\n")
            else:
                logger.warning("MainBackendThread().WriteFSTABEntryForUEFIPartition(): The UUID for the UEFI Partition: "+UEFISystemPartition+" couldn't be found! This isn't good, and may cause problems down the line. Continuing anyway...")
                NewFileContents.append(UEFISystemPartition+" /boot/efi vfat defaults 0 2\n")

            #Write the finished lines to the file.
            fstab.close()
            fstab = open(MountPoint+"/etc/fstab", 'w')
            fstab.write(''.join(NewFileContents))
            fstab.close()

            logger.info("MainBackendThread().WriteFSTABEntryForUEFIPartition(): Done!")

    def FindLatestVersion(self, Directory, Type):
        #Try the find the latest kernel/initrd in the given directory.
        FileList = os.listdir(Directory)

        if Type == "Kernel":
            #Make a list of kernels.
            logger.info("MainBackendThread().FindLatestVersion(): Looking for latest kernel in "+Directory+"...")
            List = []
            for File in FileList:
                if 'vmlinu' in File:
                    List.append(File)
        else:
            #Make a list of initrds.
            logger.info("MainBackendThread().FindLatestVersion(): Looking for latest Initrd in "+Directory+"...")
            List = []
            for File in FileList:
                if 'initr' in File:
                    List.append(File)

        logger.debug("MainBackendThread().FindLatestVersion(): Contents of Kernel/Initrd list: "+', '.join(List))

        if len(List) == 0:
            #No kernels/initrds found.
            logger.warning("MainBackendThread().FindLatestVersion(): Found no Kernels/Initrds in "+Directory+"! This may indicate a bug in the program.") 
            return "None"
        elif len(List) == 1:
            #One kernel/initrd found, return it.
            logger.info("MainBackendThread().FindLatestVersion(): Found one Kernel/Initrd in "+Directory+"!") 
            return List[0]
        else:
            #Multiple kernels/initrds found!
            logger.info("MainBackendThread().FindLatestVersion(): Found multiple Kernels/Initrds in "+Directory+". Picking the one with the highest version number...")

            #Find the one with the highest version number.
            #Make a list of version numbers.
            Versions = []
            for Thing in List:
                Versions.append(Thing.split("-")[1])

            #Order them so that the last entry will have the latest version number.
            Versions = sorted(Versions, key=LooseVersion)

            #Save the kernel/initrd(s) that have the latest version number (the first element in the list).
            NewList = []
            for Thing in List:
                if Versions[-1] in Thing:
                    NewList.append(Thing)

            logger.debug("MainBackendThread().FindLatestVersion(): Contents of highest-version-number Kernel/Initrd list: "+', '.join(NewList))

            if len(NewList) == 1:
                #Good, there is only one kernel/initrd with that version number. Return it.
                logger.info("MainBackendThread().FindLatestVersion(): Found one Kernel/Initrd with the highest version number.")
                return NewList[0]
            else:
                #Multiple kernels/initrds with that version number.
                logger.info("MainBackendThread().FindLatestVersion(): Found multiple Kernels/Initrds with the highest version number! Picking the one with the highest revision number...")

                #Let's look at the revision number for every kernel/initrd in that list.
                Revs = []
                for Thing in NewList:
                    Revs.append(Thing.split("-")[2])

                #Order them so that the last entry will have the latest revision number.
                Revs = sorted(Revs, key=LooseVersion)

                #Save the kernels/initrd(s) that have that version number, and the latest revision number (the first element in the list).
                NewestList = []
                for Thing in NewList:
                    if Revs[-1] in Thing:
                        NewestList.append(Thing)

                logger.debug("MainBackendThread().FindLatestVersion(): Contents of highestrevision-number Kernel/Initrd list: "+', '.join(NewestList))

                if len(NewestList) == 1:
                    #Finally, we have the latest kernel/initrd! Return it.
                    logger.info("MainBackendThread().FindLatestVersion(): Yes! We found the latest Kernel/Initrd!")
                    return NewestList[0]
                else:
                    #Give up, this is getting impossible!
                    logger.error("MainBackendThread().FindLatestVersion(): Couldn't determine the newest kernel! This is either because multple Kernels/Initrds have the highest revision number (!) or an error occoured when determining the revision number...")
                    return "None"

    def BackupUEFIFiles(self, MountPoint):
        #Function to backup some .efi files, just in case something goes wrong.
        logger.info("MainBackendThread().BackupUEFIFiles(): Backing up UEFI Files...")
        #We'll backup /EFI/boot/bootx64.efi if it exists, and we'll also backup Windows's uefi files, if they exist.

        #First do /EFI/boot/bootx64.efi. Fortunately, the UEFI partition is always a fat32/fat16 filesystem, so case doesn't matter.
        if os.path.isfile(MountPoint+"/boot/efi/EFI/boot/boot*.efi"):
            retval = self.StartThreadProcess("cp -v "+MountPoint+"/boot/efi/EFI/boot/boot*.efi "+MountPoint+"/boot/efi/EFI/boot/bkpbootx64.efi", Piping=True, ShowOutput=False)
        else:
            #This doesn't exist. This doesn't matter then, so set retval to 0.
            retval = 0

        #Check the return value.
        if retval != 0:
            logger.error("MainBackendThread().BackupUEFIFiles(): Failed to backup failsafe UEFI boot file! Warning user and continuing...")
            self.ShowMsgDlg(Kind="error", Message="Error! WxFixBoot failed to save your UEFI boot files to the backup directory! This probably isn't very important. Click okay to continue.")

        #Now do Windows's files, if they exist.
        if os.path.isfile(MountPoint+"/boot/efi/EFI/Microsoft/boot/bootmgfw.efi"):
            retval = self.StartThreadProcess(['cp', '-v', MountPoint+'/boot/efi/EFI/Microsoft/boot/bootmgfw.efi', MountPoint+'/boot/efi/EFI/Microsoft/boot/bkpbootmgfw.efi'], ShowOutput=False)
        else:
            #This doesn't exist. This doesn't matter then, so set retval to 0.
            retval = 0

        logger.info("MainBackendThread().BackupUEFIFiles(): Done!")

        #Check the return value.
        if retval != 0:
            logger.error("MainBackendThread().BackupUEFIFiles(): Failed to backup Windows's UEFI boot files! Warning user and continuing...")
            self.ShowMsgDlg(Kind="error", Message="Warning: WxFixBoot failed to backup Windows's UEFI boot files! This probably isn't very important. Click okay to continue.")

    def CopyUEFIFiles(self, MountPoint):
        #Function to copy the new UEFI bootloader's files to default places in case of buggy firmware.
        logger.info("MainBackendThread().CopyUEFIFiles(): Copying UEFI Files to UEFIBootDir...")

        #First, let's check if EFI/boot already exists. This is a fat32/fat16 filesystem, so case doesn't matter.
        if os.path.isdir(MountPoint+"/boot/efi/EFI/boot"):
            UEFIBootDir = MountPoint+"/boot/efi/EFI/boot/"
        else:
            #It doesn't, so we'll create it.
            UEFIBootDir = MountPoint+"/boot/efi/EFI/boot/"
            os.mkdir(UEFIBootDir)

        #Do it differently depending on whether the now-installed UEFI bootloader is ELILO or GRUB-UEFI.
        if BootloaderToInstall == "ELILO":
            #We need to copy both elilo.efi, and elilo.conf to UEFIBootDir.
            retval = self.StartThreadProcess(['cp', '-v', MountPoint+'/boot/efi/EFI/ubuntu/elilo.efi', UEFIBootDir+'bootx64.efi'], ShowOutput=False)
            retval = self.StartThreadProcess(['cp', '-v', MountPoint+'/boot/efi/EFI/ubuntu/elilo.conf', UEFIBootDir], ShowOutput=False)
        elif BootloaderToInstall == "GRUB-UEFI":
            #We need to copy grub*.efi to UEFIBootDir.
            retval = self.StartThreadProcess("cp -v "+MountPoint+"/boot/efi/EFI/ubuntu/grub*.efi "+UEFIBootDir+"bootx64.efi", Piping=True, ShowOutput=False)
        else:
            #Something has gone badly wrong here! The variable showing the UEFI bootloader now installed has been reset. Warning the user and exiting!
            logger.critical("MainBackendThread().CopyUEFIFiles(): WxFixBoot's variable that contains the name of the (hopefully) now installed UEFI bootloader has been reset! It isn't safe to continue! Warning user and exiting...")
            self.ShowMsgDlg(Kind="error", Message="Error! WxFixBoot's variable that contains the name of the now installed UEFI bootloader has been reset! This is probably a bug. It isn't safe to continue! Your system may be left in an unbootable state. WxFixBoot will now exit to prevent further damage to your computer.")
            wx.Exit()
            sys.exit("CRITICAL ERROR: WxFixBoot's variable that contains the name of the (hopefully) now installed UEFI bootloader has been reset! It isn't safe to continue! Exiting...")

        logger.info("MainBackendThread().CopyUEFIFiles(): Done!")

        #Check the return value.
        if retval != 0:
            logger.error("MainBackendThread().CopyUEFIFiles(): Failed to copy the new bootloader's UEFI files to the failsafe directory! This could potentially be a serious problem! If the system doesn't start, this could be the reason why it doesn't start. Warning user and continuing...")
            self.ShowMsgDlg(Kind="error", Message="Error: WxFixBoot failed to copy the new bootloader's UEFI files to the backup directory! This could potentially be a problem. If your system doesn't start, this could be the reason why it doesn't start. Click okay to continue.")

    ####################End of Helper Functions.####################
    ####################Essential Functions, that must be run before doing bootloader oparations.####################

    def BackupPartitionTable(self):
        #Function to backup the partition table.
        #For GPT disks, backup with sgdisk -b/--backup=<file> <SOURCEDIRVE>.
        #For MBR disks, backup with dd if=/dev/sdX of=<somefile> bs=512 count=1.
        global PartitionTableBackupFile

        #We need to find RootDevice's partition scheme from the PartSchemeList here.
        tempnum = DeviceList.index(RootDevice)
        PartScheme = PartSchemeList[tempnum]

        logger.info("MainBackendThread().BackupPartitionTable(): Preparing to backup the partition table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to backup the Partition Table...")
        self.UpdateOutputBox("\n###Preparing to Backup the Partition Table...###\n")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)

        if PartScheme == "msdos":
            #Let's backup the MBR, but we need to ask where to back it up first.
            PartitionTableBackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Partition Table Backup Target File", Wildcard="MBR Backup File (*.mbr)|*.mbr|IMG Image file (*.img)|*.img|All Files/Devices (*)|*")

            #Make sure the backup file always has the correct file extension on it.
            if PartitionTableBackupFile[-4:] != ".mbr":
                PartitionTableBackupFile = PartitionTableBackupFile+".mbr"

            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up Partition Table...")
            self.UpdateOutputBox("\n###Backing up the Partition Table...###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)

            #Backup the MBR of RootDevice.
            logger.info("MainBackendThread().BackupPartitionTable(): Backing up MBR partition table to file: "+PartitionTableBackupFile+", from device: "+RootDevice+"...")
            retval = self.StartThreadProcess(['dd', 'if='+RootDevice, 'of='+PartitionTableBackupFile, 'bs=512', 'count=1'], ShowOutput=False)
        else:
            #Let's backup the GPT, but we need to ask where to back it up first.
            PartitionTableBackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Partition Table Backup Target File", Wildcard="GPT Backup File (*.gpt)|*.gpt|IMG Image file (*.img)|*.img|All Files/Devices (*)|*")

            #Make sure the backup file always has the correct file extension on it.
            if PartitionTableBackupFile[-4:] != ".gpt":
                PartitionTableBackupFile = PartitionTableBackupFile+".gpt"

            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up Partition Table...")
            self.UpdateOutputBox("\n###Backing up the Partition Table...###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)

            #Backup the GPT.
            logger.info("MainBackendThread().BackupPartitionTable(): Backing up GPT partition table to file: "+PartitionTableBackupFile+", from device: "+RootDevice+"...")
            retval = self.StartThreadProcess(['sgdisk', '--backup='+PartitionTableBackupFile, RootDevice], ShowOutput=False)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Backing up Partition Table!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        self.UpdateOutputBox("\n###Finished Backing up the Partition Table!###\n")
        logger.info("MainBackendThread().BackupPartitionTable(): Finished Backing up Partition Table! Exit code: "+str(retval))

    def BackupBootSector(self):
        #Function to backup the bootsector.
        #For GPT disks, backup UEFI System Partition.
        #For MBR disks, backup with dd if=/dev/sdX of=<somefile> bs=512 count=1.
        global BootSectorBackupFile

        #We need to find RootDevice's partition scheme from the PartSchemeList here.
        tempnum = DeviceList.index(RootDevice)
        PartScheme = PartSchemeList[tempnum]

        logger.info("MainBackendThread().BackupPartitionTable(): Preparing to backup the boot sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to backup the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        self.UpdateOutputBox("\n###Preparing to Backup the Boot Sector...###\n")

        if PartScheme == "msdos":
            #Let's backup the MBR, but we need to ask where to back it up first.
            BootSectorBackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Bootsector Backup Target File", Wildcard="IMG Image file (*.img)|*.img|All Files/Devices (*)|*")

            #Make sure the backup file always has the correct file extension on it.
            if BootSectorBackupFile[-4:] != ".img":
                BootSectorBackupFile = BootSectorBackupFile+".img"

            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up the Boot Sector...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)
            self.UpdateOutputBox("\n###Backing up the Boot Sector...###\n")

            #Backup the MBR of RootDevice.
            logger.info("MainBackendThread().BackupBootSector(): Backing up MBR bootsector to file: "+BootSectorBackupFile+", from device: "+RootDevice+"...")
            retval = self.StartThreadProcess(['dd', 'if='+RootDevice, 'of='+BootSectorBackupFile, 'bs=512', 'count=1'], ShowOutput=False)
        else:
            #Let's backup the UEFISystemPartition, but check there is one first.
            if UEFISystemPartition == "None":
                logger.error("MainBackendThread().BackupBootSector(): Failed to backup UEFI Partition, because there isn't one!")
                self.ShowMsgDlg(Kind="error", Message="You have no UEFI Partition, so WxFixBoot couldn't backup your bootsector! Click okay to skip this operation.")
            else:
                #We need to ask where to back it up to.
                BootSectorBackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Bootsector Backup Target File", Wildcard="IMG Image file (*.img)|*.img|All Files/Devices (*)|*")

                #Make sure the backup file always has the correct file extension on it.
                if BootSectorBackupFile[-4:] != ".img":
                    BootSectorBackupFile = BootSectorBackupFile+".img"

                wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up the Boot Sector...")
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)

                #Backup the UEFISystemPartition.
                logger.info("MainBackendThread().BackupBootSector(): Backing up UEFI System Partition ("+UEFISystemPartition+") to file: "+BootSectorBackupFile+"...")
                retval = self.StartThreadProcess(['dd', 'if='+UEFISystemPartition, 'of='+BootSectorBackupFile], ShowOutput=False)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Backing up the Boot Sector!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        self.UpdateOutputBox("\n###Finished Backing up the Boot Sector!###\n")
        logger.info("MainBackendThread().BackupBootSector(): Finished backing up Boot Sector! Exit code: "+str(retval))

    def RestorePartitionTable(self):
        #Function to restore the partition table.
        #Use sgdisk for GPT disks, restore with sgdisk -l/--load-backup=<file> <TARGETDEVICE>
        #Use dd for MBR disks, restore with dd if=<somefile> of=/dev/sdX bs=1 count=64 skip=446 seek=446

        logger.info("MainBackendThread().RestorePartitionTable(): Preparing to restore the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to restore the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        self.UpdateOutputBox("\n###Preparing to restore the Partition Table...###\n")

        #We need to check if PartitionTableFile is on a different partition or device, so we can make sure it's available.
        if "/mnt/" in PartitionTableFile:
            #It is! Determine which partition we need to mount.
            Temp = PartitionTableFile.split('/')
            PartitionToMount = "/"+'/'.join(Temp[2:4])

            #Mount it, and set a variable so we can unmount it afterwards.
            MountPartitionSafely(Partition=PartitionToMount, MountPoint="/mnt"+PartitionToMount)
            MountedFS = PartitionToMount
            logger.info("MainBackendThread().RestorePartitionTable(): Okay. Mounted the partition: "+MountedFS+" that houses the file. Now let's restore the Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)
        else:
            #Nope, it's on this partition.
            MountedFS = "None"
            logger.info("MainBackendThread().RestorePartitionTable(): Okay. Now let's restore the Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Restoring the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)
        self.UpdateOutputBox("\n###Restoring the Partition Table...###\n")

        if PartitionTableBackupType == "msdos":
            #Let's restore the MBR Partition Table.
            logger.info("MainBackendThread().RestorePartitionTable(): Restoring MBR partition table from file: "+PartitionTableFile+" to device: "+PartitionTableTargetDevice+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            retval = self.StartThreadProcess(['dd', 'if='+PartitionTableFile, 'of='+PartitionTableTargetDevice, 'bs=1', 'count=64', 'skip=446', 'seek=446'], ShowOutput=False)
        else:
            #Let's restore the GPT.
            retval = self.StartThreadProcess(['sgdisk', '--load-backup='+PartitionTableFile, PartitionTableTargetDevice], ShowOutput=False)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            logger.info("MainBackendThread().RestorePartitionTable(): Restoring GPT partition table from file: "+PartitionTableFile+" to device: "+PartitionTableTargetDevice+"...")

        #Unmount the partition containing the file, if there is one.
        if MountedFS != "None":
            logger.info("MainBackendThread().RestorePartitionTable(): Unmounting partition: "+MountedFS+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 85)
            self.UnmountPartition(Partition=MountedFS)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Restoring the Partition Table!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        self.UpdateOutputBox("\n###Finished Restoring the Partition Table!###\n")
        logger.info("MainBackendThread().RestorePartitionTable(): Finished Restoring the Partition Table!")

    def RestoreBootSector(self):
        #Function to restore the bootsector‎.
        #For GPT disks, restore with dd.
        #For MBR disks, restore with dd if=<somefile> of=/dev/sdX bs=446 count=1

        logger.info("MainBackendThread().RestoreBootSector(): Preparing to restore the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to restore the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        self.UpdateOutputBox("\n###Preparing to restore the Boot Sector...###\n")

        #We need to check if BootSectorFile is on a different partition or device, so we can make sure it's available.
        if "/mnt/" in BootSectorFile:
            #It is! Determine which partition we need to mount.
            Temp = BootSectorFile.split('/')
            PartitionToMount = "/"+'/'.join(Temp[2:4])

            #Mount it, and set a variable so we can unmount it afterwards.
            MountPartitionSafely(Partition=PartitionToMount, MountPoint="/mnt"+PartitionToMount)
            MountedFS = PartitionToMount
            logger.info("MainBackendThread().RestoreBootSector(): Okay. Mounted the partition: "+MountedFS+" that houses the file. Now let's restore the Boot Sector...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)
        else:
            #Nope, it's on this partition.
            MountedFS = "None"
            logger.info("MainBackendThread().RestoreBootSector(): Okay. Now let's restore the Boot Sector...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Restoring the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)
        self.UpdateOutputBox("\n###Restoring the Boot Sector...###\n")

        if BootSectorBackupType == "msdos":
            #Let's restore the MBR bootsector.
            logger.info("MainBackendThread().RestoreBootSector(): Restoring MBR boot sector from file: "+BootSectorFile+" to device: "+BootSectorTargetDevice+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            self.StartThreadProcess(['dd', 'if='+BootSectorFile, 'of='+BootSectorTargetDevice, 'bs=446', 'count=1'], ShowOutput=False)
        else:
            #Restore the UEFISystemPartition.
            logger.info("MainBackendThread().RestoreBootSector(): Restoring UEFI Partition ("+UEFISystemPartition+") from file: "+BootSectorFile+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            self.StartThreadProcess(['dd', 'if='+BootSectorFile, 'of='+UEFISystemPartition], ShowOutput=False)

        #Unmount the partition containing the file, if there is one.
        if MountedFS != "None":
            logger.info("MainBackendThread().RestoreBootSector(): Unmounting partition: "+MountedFS+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 85)
            self.UnmountPartition(Partition=MountedFS)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Restoring the Boot Sector!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        self.UpdateOutputBox("\n###Finished Restoring the Boot Sector...###\n")
        logger.info("MainBackendThread().RestoreBootSector(): Finished restoring the boot sector!")

    def QuickFileSystemCheck(self):
        #Function to quickly check all filesystems.
        logger.debug("MainBackendThread().QuickFileSystemCheck(): Starting...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing for Quick Filesystem Check...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        self.UpdateOutputBox("\n###Preparing to do the Quick Filesystem Check...###\n")

        #Determine which partitions are to be checked.
        CheckList = self.FindCheckableFileSystems()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30)

        #Find the length of the list (this is needed to update the progressbars).
        CheckListLength = len(CheckList)

        self.ShowMsgDlg(Kind="info", Message="WxFixBoot will now perform the disk check. Do not be alarmed by on-screen inactivity, even in the terminal output box, as this operation could take a long time to complete.")

        #Run the check on the checkable partitions
        for Element in CheckList:
            #Gather info.
            SplitElement = Element.split()
            Partition = SplitElement[0]
            FSType = SplitElement[1]
            RemountPartitionAfter = SplitElement[2]

            logger.info("MainBackendThread().QuickFileSystemCheck(): Checking Partition: "+Partition+"...")
            self.UpdateOutputBox("\n###Checking Partition: "+Partition+"###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Checking Partition: "+Partition)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30+((50/CheckListLength)*(CheckList.index(Element)+1)))

            time.sleep(1)

            #Create a command list that will work based on the fstype of this partition. If there aren't any use cases for the fstype, display a message to the user and skip it.
            if FSType == "jfs":
                ExecList = ['fsck.jfs', '-vf', Partition]
            elif FSType == "minix":
                ExecList = ['fsck.minix', '-avf', Partition]
            elif FSType == "reiserfs":
                ExecList = ['fsck.reiserfs', '-apf', Partition]
            elif FSType == "xfs":
                ExecList = ['xfs_repair', '-Pvd', Partition]
            elif FSType == "vfat":
                ExecList = ['fsck.vfat', '-yv', Partition]
            elif FSType in ['ext2', 'ext3', 'ext4', 'ext4dev']:
                ExecList = ['fsck.'+FSType, '-yvf', Partition]
            else:
                ExecList = ['None']
                logger.warning("MainBackendThread().QuickFileSystemCheck(): Skipping Partition: "+Partition+", as WxFixBoot doesn't support checking it yet...")
                self.ShowMsgDlg(Kind="error", Message="The filesystem on partition: "+Partition+" could not be checked, as WxFixBoot doesn't support checking it yet. "+Partition+" will now be skipped.")

            #Run the command with Piping = False, if ExecList != ['None'], otherwise do nothing, but do remount the partition if needed.
            if ExecList != ['None']:
                retval = self.StartThreadProcess(ExecList)

                #Check the return values, and run the handler if needed.
                if retval == 0:
                    #Success.
                    logger.info("MainBackendThread().QuickFileSystemCheck(): Checked partition: "+Partition+" No Errors Found!")
                else:
                    self.HandleFilesystemCheckReturnValues(ExecList=ExecList, retval=retval, Partition=Partition)

            if RemountPartitionAfter == "Yes":
                logger.debug("MainBackendThread().QuickFileSystemCheck(): Remounting Partition: "+Partition+" Read-Write...")
                retstr = MountPartitionSafely(Partition=Partition, MountPoint="/mnt"+Partition)

                #Check if it worked.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Log it.
                    logger.warning("MainBackendThread().BadSectorCheck(): Failed to remount partition: "+Partition+" after check. We probably need to reboot first. Never mind...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Quick Filesystem Check!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        self.UpdateOutputBox("\n###Finished Quick Filesystem Check!###\n")
            
    def BadSectorCheck(self):
        #Function to check all filesystems for bad sectors.
        logger.debug("MainBackendThread().BadSectorCheck(): Starting...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing for Bad Sector Check...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        self.UpdateOutputBox("\n###Preparing to do the Bad Sector Check...###\n")

        #Determine which partitions are to be checked.
        CheckList = self.FindCheckableFileSystems()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30)

        #Find the length of the list (this is needed to update the progressbars).
        CheckListLength = len(CheckList)

        self.ShowMsgDlg(Kind="info", Message="WxFixBoot will now perform the disk check. Do not be alarmed by on-screen inactivity, even in the terminal output box, as this operation could take a long time to complete.")

        #Run the check on the checkable partitions
        for Element in CheckList:
            #Gather info.
            SplitElement = Element.split()
            Partition = SplitElement[0]
            FSType = SplitElement[1]
            RemountPartitionAfter = SplitElement[2]

            logger.info("MainBackendThread().BadSectorCheck(): Checking Partition: "+Partition+"...")
            self.UpdateOutputBox("\n###Checking Partition: "+Partition+"###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Checking Partition: "+Partition)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30+((50/CheckListLength)*(CheckList.index(Element)+1)))

            time.sleep(1)

            #Run a command that will work based on the fstype of this partition. If there aren't any use cases for the fstype, display a message to the user and skip it. Ignore return values.
            if FSType == "jfs":
                #No support for bad sector check in jfs. Notify the user and do a normal check instead.
                self.ShowMsgDlg(Kind="info", Message="The filesystem type on partition: "+Partition+" (jfs) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['fsck.jfs', '-vf', Partition]
            elif FSType == "minix":
                self.ShowMsgDlg(Kind="info", Message="The filesystem type on partition: "+Partition+" (minix) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['fsck.minix', '-avf', Partition]
            elif FSType == "reiserfs":
                self.ShowMsgDlg(Kind="info", Message="The filesystem type on partition: "+Partition+" (reiserfs) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['fsck.reiserfs', '-apf', Partition]
            elif FSType == "xfs":
                self.ShowMsgDlg(Kind="info", Message="The filesystem type on partition: "+Partition+" (xfs) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['xfs_repair', '-Pvd', Partition]
            elif FSType == "vfat":
                ExecList = ['fsck.vfat', '-yvt', Partition]
            elif FSType in ['ext2', 'ext3', 'ext4', 'ext4dev']:
                ExecList = ['fsck.'+FSType, '-yvcf', Partition]
            else:
                ExecList = ['None']
                self.ShowMsgDlg(Kind="info", Message="The filesystem on partition: "+Partition+" could not be checked, as WxFixBoot doesn't support checking it yet. "+Partition+" will now be skipped.")

            #Run the command with Piping = False, if ExecList != ['None'], otherwise do nothing, but do remount the partition if needed.
            if ExecList != ['None']:
                retval = self.StartThreadProcess(ExecList)

                #Check the return values, and run the handler if needed.
                if retval == 0:
                    #Success.
                    logger.info("MainBackendThread().QuickFileSystemCheck(): Checked partition: "+Partition+" No Errors Found!")
                else:
                    self.HandleFilesystemCheckReturnValues(ExecList=ExecList, retval=retval, Partition=Partition)

            if RemountPartitionAfter == "Yes":
                logger.debug("MainBackendThread().BadSectorCheck(): Remounting Partition: "+Partition+" Read-Write...")
                retstr = MountPartitionSafely(Partition=Partition, MountPoint="/mnt"+Partition)

                #Check if it worked.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Log it.
                    logger.warning("MainBackendThread().BadSectorCheck(): Failed to remount partition: "+Partition+" after check. We probably need to reboot first. Never mind...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Bad Sector Check!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        self.UpdateOutputBox("\n###Finished Bad Sector Check!###\n")

    ####################End of Essential Functions.####################
    ####################Start Of Bootloader Operation functions.####################

    def PrepareForBootloaderInstallation(self):
        #Function to run checks, gather information, and prepare for bootloader operations.
        global OSsForBootloaderRemoval
        global OSsForBootloaderInstallation

        #First, check the Internet connection.
        DisableBLOps = self.CheckInternetConnection()

        if DisableBLOps == "Yes":
            #Disable bootloader operations.
            OSsForBootloaderRemoval = []
            OSsForBootloaderInstallation = []
            self.UpdateOutputBox("\n###Bootloader Operations Disabled.###\n") 

        else:
            #Determine all the package managers on the system, including all OSs and the OS running, but not the live disk (if there is one).
            logger.debug("MainBackendThread().PrepareForBootloaderInstallation(): Determining package managers for all Linux OSs...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing for bootloader operations...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
            self.UpdateOutputBox("\n###Preparing for bootloader operations...###\n")

            OSListWithPackageManagers = []
        
            #Use OSList to find all partitions with Linux OSs on them.
            #Start of for loop.
            for OS in OSList:
                #Get the partition that each OS is on.
                Partition = OS.split()[-1]

                #If not on a live disk, and this OS is the one running, skip some stuff.
                if LiveDisk == False and Partition == AutoRootFS:
                    #Find the package manager on this partition, if one exists.
                    #This is the RootFS, so don't use chroot in the given command lists.
                    Result = self.LookForAPTOnPartition(APTExecList=["apt-get", "-h"])

                    #Add the OS and its package manager to the list, if there is one.
                    if Result != "None":
                       logger.info("MainBackendThread().PrepareForBootloaderInstallation(): Found possible package management candidate: "+OS+" with Package Manager "+Result)
                       OSListWithPackageManagers.append(OS+" with Package Manager "+Result)
                            
                    #Skip the rest of the for loop.
                    continue

                #Mount the partition safely, using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint="/mnt"+Partition)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, as it's safer to do so.
                    logger.warning("MainBackendThread().PrepareForBootloaderInstallation(): Command: 'mount "+Partition+" /mnt/"+Partition+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                else:
                    #Find the package manager on this partition, if one exists.
                    #This isn't the RootFS, so use chroot in the given command lists.
                    Result = self.LookForAPTOnPartition(APTExecList=["chroot", "/mnt"+Partition, "apt-get", "-h"])

                    #Add the OS and its package manager to the list, if there is one.
                    if Result != "None":
                        logger.info("MainBackendThread().PrepareForBootloaderInstallation(): Found possible package management candidate: "+OS+" with Package Manager "+Result)
                        OSListWithPackageManagers.append(OS+" with Package Manager "+Result)

            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 70)

            #Check if there are any candidates for bootloader installation/removal. Hopefully there are!
            if OSListWithPackageManagers == []:
                #Oh dear... There aren't.
                logger.error("MainBackendThread().PrepareForBootloaderInstallation(): Couldn't find an OS with APT! Will have to disable some operations!")
                self.ShowMsgDlg(Kind="error", Message="No supported package managers could be found on any of your operating systems! At the moment, APT is supported, which covers most Linux Operating Systems. WxFixBoot will have to skip all operations that require a package manager, such as installing, removing and reinstalling the bootloader. In a later release WxFixBoot will likely support another package manager, such as Slackware's system. If you think you do have an OS with a supported package manager, please report a bug or email me directly via my Launchpad page, so I can try to help. In the meantime, you can probably follow some online instructions for your operating system.")

                #Set these to "None", so the packagemanager-dependant code can skip itself.
                OSsForBootloaderRemoval == []
                OSsForBootloaderInstallation = []

                #Update Current Operation Text.
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
            else:
                #Very good! There is at least one candidate.
                logger.info("MainBackendThread().PrepareForBootloaderInstallation(): Found at least one candidate for installing and removing bootloaders! Continuing...")

                #Also, we need to find which OS(es) installed the bootloader (or have it installed currently), and ask the user which OS to install the bootloader with.
                OSsForBootloaderRemoval = self.FindBootloaderRemovalOSs(OSListWithPackageManagers)
                logger.info("MainBackendThread().PrepareForBootloaderInstallation(): List of OSs to have the bootloader removed: "+', '.join(OSsForBootloaderRemoval)+"...")

                #Update Current Operation Text.
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 85)
                self.AskUserForBootloaderInstallationOSs(OSListWithPackageManagers)
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

            self.UpdateOutputBox("\n###Done!###\n") 

    def ManageBootloaders(self):
        #Function to manage the installation and removal of bootloaders.
        global DisableBootloaderOperations
        DisableBootloaderOperations = False

        #First, we need to check that these operations haven't been disabled.
        if OSsForBootloaderInstallation in [["None,FSCKProblems"], []]:
            #These operations have been disabled. Notify the user and skip them.
            self.ShowMsgDlg(Kind="warning", Message="Bootloader operations have been disabled, or the required information wasn't found! This operation will now be skipped. Click okay to continue.")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
            DisableBootloaderOperations = True

        else:
            #First remove the old bootloader, then install the new one.
            self.GetOldBootloaderConfig()
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 25)
            self.RemoveOldBootloader()
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 50)
            BLInstallFailure = self.InstallNewBootloader()

            if BLInstallFailure == "No":
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 75)
                self.SetNewBootloaderConfig()
            else:
                #Bootloader installation failed for at least one OS!
                Result = self.ShowYesNoDlg(Message="Bootloader Installation failed for at least one OS! Do you want to continue and configure the new bootloader(s), or skip the rest of the bootloader operation? You proabably want to configure the bootloader anyway.", Title="WxFixBoot - Configure Bootloader(s)?")

                if Result == "Yes":
                    #Continue and configure bootloaders. Otherwise, do nothing.
                    wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 75)
                    self.SetNewBootloaderConfig()

            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

    def ReinstallBootloader(self):
        #Function to reinstall/fix the bootloader.
        global DisableBootloaderOperations
        DisableBootloaderOperations = False

        logger.info("MainBackendThread().ReinstallBootloader(): Preparing to reinstall the bootloader...")
        self.UpdateOutputBox("\n###Preparing to reinstall the bootloader...###\n")

        if OSsForBootloaderInstallation in [["None,FSCKProblems"], []]:
            #These operations have been disabled. Notify the user and skip them.
            self.ShowMsgDlg(Kind="warning", Message="Bootloader operations have been disabled, or the required information wasn't found! This operation will now be skipped. Click okay to continue.")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
            self.UpdateOutputBox("\n###Bootloader Operations Disabled.###\n") 
            DisableBootloaderOperations = True

        else:
            #Set BootloaderToInstall as the current bootloader to allow this to work properly.
            global BootloaderToInstall
            BootloaderToInstall = Bootloader

            #Call self.ManageBootloaders to perform the reinstallation safely.
            logger.info("MainBackendThread().ReinstallBootloader(): Reinstalling the Bootloader...")
            self.UpdateOutputBox("\n###Reinstalling the Bootloader...###\n")
            self.ManageBootloaders()
            logger.info("MainBackendThread().ReinstallBootloader(): Done!")

    def UpdateBootloader(self):
        #Function to update bootloader menu and config
        global DisableBootloaderOperations
        DisableBootloaderOperations = False
        logger.info("MainBackendThread().UpdateBootloader(): Preparing to update the bootloader...")
        self.UpdateOutputBox("\n###Preparing to update the bootloader...###\n")

        if OSsForBootloaderInstallation in [["None,FSCKProblems"], []]:
            #These operations have been disabled. Notify the user and skip them.
            self.ShowMsgDlg(Kind="warning", Message="Bootloader operations have been disabled, or the required information wasn't found! This operation will now be skipped. Click okay to continue.")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
            self.UpdateOutputBox("\n###Bootloader Operations Disabled.###\n") 
            DisableBootloaderOperations = True

        else:
            #Set BootloaderToInstall as the current bootloader to allow this to work properly.
            global BootloaderToInstall
            BootloaderToInstall = Bootloader
            logger.info("MainBackendThread().UpdateBootloader(): Updating the bootloader's config...")
            self.UpdateOutputBox("\n###Preparing to update the bootloader's configuration...###\n")

            #Get the bootloader's config.
            self.GetOldBootloaderConfig()
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 50)

            #Set the bootloaders new config.
            self.SetNewBootloaderConfig()
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

            logger.info("MainBackendThread().UpdateBootloader(): Done!")

    ####################Start Of Bootloader Configuration Obtaining Functions.####################

    def GetOldBootloaderConfig(self):
        #Get the old bootloader's config before removing it, so we can reuse it (if possible) with the new one.
        logger.debug("MainBackendThread().GetOldBootloaderConfig(): Preparing to get bootloader config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to get bootloader config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 2)
        self.UpdateOutputBox("\n###Preparing to get old bootloader config...###\n")

        #Define gloabal vars
        global BootloaderTimeout
        global KernelOptions

        #Use two lists for global kernel options and timeouts, so if they differ for each instance of the bootloader (assuming there is more than one), we can ask the user which is best, or go with WxFixBoot's default (timeout=10, kopts="quiet splash nomodeset")
        KernelOptsList = []
        TimeoutsList = []

        #Set two temporary vars.
        timeout = ""
        kopts = ""

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Getting old bootloader config...")
        self.UpdateOutputBox("\n###Getting old bootloader config...###\n")

        #Loop through each OS in OSsForBootloaderRemoval, and provide information to the function that gets the configuration.
        logger.info("MainBackendThread().GetOldBootloaderConfig(): Looking for configuration in OSs marked for bootloader removal...")
        for OS in OSsForBootloaderRemoval:
            #Grab the OS's partition.
            Partition = OS.split()[-5]
            logger.debug("MainBackendThread().GetOldBootloaderConfig(): Looking for config in OS: "+OS+"...")

            #Check if the Partition is AutoRootFS, if we're not on a live disk.
            if LiveDisk == False and Partition == AutoRootFS:
                #If so, make sure this will work for this OS too, and avoid setting mountpoint, so the config instructions below look in the right place for the config files.
                MountPoint = ""
            else:
                #If not, set mountpoint to the actual mountpoint.
                MountPoint = "/mnt"+Partition

                #Mount it safely using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, and skip the rest of the loop, as it's safer to do so.
                    logger.warning("MainBackendThread().GetOldBootloaderConfig(): Command: 'mount "+MountPoint+" /mnt/"+MountPoint+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                    continue

            #Look for the configuration file, based on which GetConfig() function we're about to run.
            if Bootloader == "GRUB-LEGACY":
                #Check MountPoint/boot/grub/menu.lst exists.
                if os.path.isfile(MountPoint+"/boot/grub/menu.lst"):
                    #It does, we'll run the function to find the config now.
                    Temp = self.GetGRUBLEGACYConfig(filetoopen=MountPoint+"/boot/grub/menu.lst")
                    timeout = Temp[0]

            elif Bootloader in ['GRUB2', 'GRUB-UEFI']:
                #Check MountPoint/etc/default/grub exists, which should be for either GRUB2 or GRUB-UEFI.
                if os.path.isfile(MountPoint+"/etc/default/grub"):
                    #It does, we'll run the function to find the config now.
                    Temp = self.GetGRUB2Config(filetoopen=MountPoint+"/etc/default/grub")
                    timeout = Temp[0]
                    kopts = Temp[1]

            elif Bootloader in ['LILO', 'ELILO']:
                #Check the config file exists for both lilo and elilo.
                if Bootloader == "LILO" and os.path.isfile(MountPoint+"/etc/lilo.conf"):
                    #It does, we'll run the function to find the config now.
                    Temp = self.GetLILOConfig(filetoopen=MountPoint+"/etc/lilo.conf")
                    timeout = Temp[0]
                    kopts = Temp[1]
                elif Bootloader == "ELILO" and os.path.isfile(MountPoint+"/etc/elilo.conf"):
                    #It does, we'll run the function to find the config now.
                    Temp = self.GetLILOConfig(filetoopen=MountPoint+"/etc/elilo.conf")
                    timeout = Temp[0]
                    kopts = Temp[1]

            #Unmount the partition, if needed.
            if MountPoint != "":
                self.UnmountPartition(Partition=MountPoint)

            #Now we have the config, let's add it to the list, if it's unique. This will also catch the NameError excetpion created if the bootloader's config file wasn't found. 
            #First do timeout.
            if timeout != "":
                try:
                    TimeoutsList.index(timeout)
                except ValueError:
                    #It's unique.
                    TimeoutsList.append(timeout)
                except NameError: pass

            if kopts != "":
                #Now kopts.
                try:
                    KernelOptsList.index(kopts)
                except ValueError:
                    #It's unique.
                    KernelOptsList.append(kopts)
                except NameError: pass

            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 2+(14/len(OSsForBootloaderRemoval)))

        #We're finished getting the config.
        logger.info("MainBackendThread().GetOldBootloaderConfig(): Finished looking for configuration in OSs marked for bootloader removal.")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Determining configuration to use...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 14)

        #Now let's check how many options there are in each of these lists, and run different code accordingly.
        #First TimeoutsList, but only if we aren't using a preset value for BootloaderTimeout.
        if BootloaderTimeout == -1:
            if len(TimeoutsList) == 0:
                #No timeout was found!
                Temp = self.ShowTextEntryDlg(Message="WxFixBoot couldn't find the currently installed bootloader's timeout value. Please enter a value, or use WxFixBoot's default (10).", Title="WxFixBoot - Enter timeout value")
                BootloaderTimeout = int(Temp)
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using user's bootloader timeout value: "+str(BootloaderTimeout))
            elif len(TimeoutsList) == 1:
                #As there is one, do what the user said, and set it directly.
                BootloaderTimeout = int(TimeoutsList[0])
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using only bootloader timeout value found: "+str(BootloaderTimeout))
            else:
                #Ask the user which timeout to use, as there are more than one.
                TimeoutsList.append("WxFixBoot's Default (10)")
                Result = self.ShowChoiceDlg(Message="WxFixBoot found multiple timeout settings. Please select the one you want.", Title="WxFixBoot -- Select Timeout Setting", Choices=TimeoutsList)

                #Save it.
                if Result == "WxFixBoot's Default (10)":
                    BootloaderTimeout = 10
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default bootloader timeout value: 10")
                else:
                    BootloaderTimeout = int(Result)
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using user chosen bootloader timeout value: "+str(BootloaderTimeout))

        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 21)

        #Now do the kernel options.
        if len(KernelOptsList) == 0:
            #No kernel options were found!
            #Ask the user to use WxFixBoot's default, or do manual config.
            Result = self.ShowYesNoDlg(Message="WxFixBoot couldn't find the current bootloader's default kernel options. Do you want to use WxFixBoot's default options? You should click yes and use the defaults, which are almost always fine. However, if you know exactly what you're doing, you can click no, and modify them yourself.", Title="WxFixBoot - Use Default Kernel Options?")

            if Result == "Yes":
                KernelOptions = "quiet splash nomodeset"
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default kernel options: 'quiet splash nomodeset'")
            else:
                #Ask the user for the kernel options to use.
                Result = self.ShowTextEntryDlg(Message="WxFixBoot's default kernel options are: 'quiet splash nomodeset'. If you've changed your mind, click cancel, and the defaults will be used.", Title="WxFixBoot - Enter Kernel Options")

                if Result == "Clicked no...":
                    KernelOptions = "quiet splash nomodeset"
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default kernel options: 'quiet splash nomodeset'")
                else:
                    KernelOptions = Result
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using user defined kernel options: '"+KernelOptions+"'")

        elif len(KernelOptsList) == 1:
            #Use the single set of options found.
            KernelOptions = KernelOptsList[0]
            logger.info("MainBackendThread().GetOldBootloaderConfig(): Using only kernel options found: "+KernelOptions)
        else:
            #Ask the user which timeout to use, as there are more than one.
            KernelOptsList.append("WxFixBoot's Default ('quiet splash nomodeset')")
            Result = self.ShowChoiceDlg(Message="WxFixBoot found multiple kernel options. Please select the one you want.", Title="WxFixBoot -- Select Kernel Options", Choices=KernelOptsList)

            #Save it.
            if Result == "WxFixBoot's Default ('quiet splash nomodeset')":
                KernelOptions = "quiet splash nomodeset"
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default kernel options: 'quiet splash nomodeset'")
            else:
                KernelOptions = Result
                logger.warning("MainBackendThread().GetOldBootloaderConfig(): Using user entered kernel options: "+KernelOptions)

        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 25)

    def GetGRUBLEGACYConfig(self, filetoopen):
        #Function to get important bits of config from grub-legacy before removing it.
        #In this case, the only useful info is the timeout, so just get this.
        #Set temporary vars
        Timeout = ""

        #Open the file in read mode, so we can save the important bits of config.
        infile = open(filetoopen, 'r')

        #Look for the timeout setting.
        for line in infile:
            if 'timeout' in line and 'sec' not in line:
                #Found it! Save it to BootloaderTimeout, but only if BootloaderTimeout = -1 (we aren't changing the timeout).
                if BootloaderTimeout == -1:
                    Temp = line.split()[1].replace('\n', '')
                    if Temp.isdigit():
                        #Great! We got it.
                        Timeout = int(Temp)
                    #Exit the loop to save time.
                    break

        #Close the file.
        infile.close()

        return [Timeout]

    def GetGRUB2Config(self, filetoopen):
        #Function to get important bits of config from grub2 (MBR or UEFI) before removing it.
        #Set temporary vars
        Timeout = ""
        Kopts = ""

        #Open the file in read mode, so we can save the important bits of config.
        infile = open(filetoopen, 'r')

        #Loop through each line in the file, paying attention only to the important ones.
        for line in infile:
            #Look for the timeout setting.
            if 'GRUB_TIMEOUT' in line and '=' in line:
                #Found it! Save it to BootloaderTimeout, but only if BootloaderTimeout = -1 (we aren't changing the timeout).
                if BootloaderTimeout == -1:
                    #Save it, carefully avoiding errors.
                    junk, sep, Temp = line.partition('=')
                    Temp = Temp.replace(' ','').replace('\n', '').replace("\'", "")
                    if Temp.isdigit():
                        #Great! We got it.
                        Timeout = int(Temp)

            #Look for kernel options used globally in all the boot options.
            elif 'GRUB_CMDLINE_LINUX_DEFAULT' in line and '=' in line:
                #Found them! Save it to GlobalKernelOptions
                junk, sep, Temp = line.partition('=')
                Kopts = Temp.replace('\"', '').replace("\'", "").replace("\n", "")

        #Close the file.
        infile.close()

        #Return these values to self.RemoveOldBootloader()
        return [Timeout, Kopts]

    def GetLILOConfig(self, filetoopen):
        #Function to get important bits of config from lilo before removing it.
        #Set temporary vars
        Timeout = ""
        Kopts = ""

        #Open the file in read mode, so we can save the important bits of config.
        infile = open(filetoopen, 'r')

        #Loop through each line in the file, paying attention only to the important ones.
        for line in infile:
            #Look for the delay/timeout setting.
            if ('delay' in line or 'timeout' in line) and '=' in line:
                #Found it! Save it to BootloaderTimeout, but only if BootloaderTimeout = -1 (we aren't changing the timeout).
                if BootloaderTimeout == -1:
                    #Save it, carefully avoiding errors.
                    junk, sep, Temp = line.partition('=')
                    Temp = Temp.replace(' ','').replace('\n', '')
                    if Temp.isdigit():
                        #Great! We got it.
                        #However, because lilo and elilo save this in 10ths of a second, divide it by ten first.
                        Timeout = int(Temp)/10

            #Look for kernel options used globally in all the boot options.
            elif 'append' in line and '=' in line:
                #Found them! Save it to GlobalKernelOptions
                junk, sep, Temp = line.partition('=')
                Kopts = Temp.replace('\"', '').replace("\'", "").replace("\n", "")

        #Close the file.
        infile.close()

        #Return these values to self.RemoveOldBootloader()
        return [Timeout, Kopts]

    ####################End Of Bootloader Configuration Obtaining Functions.####################
    ####################Start Of Bootloader Removal Functions.####################

    def RemoveOldBootloader(self):
        #Remove the currently installed bootloader.
        logger.debug("MainBackendThread().RemoveOldBootloader(): Preparing to remove old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Removing old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 27)
        self.UpdateOutputBox("\n###Removing old bootloaders...###\n")

        #Loop through each OS in OSsForBootloaderRemoval, and provide information to the function that will remove the bootloader.
        for OS in OSsForBootloaderRemoval:
            #For each OS that needs the bootloader removed, grab the partition, and the package manager.
            Partition = OS.split()[-5]
            PackageManager = OS.split()[-1]

            logger.info("MainBackendThread().RemoveOldBootloader(): Removing "+Bootloader+" from OS: "+OS+"...")
            self.UpdateOutputBox("\n###Removing the old bootloader from OS: "+OS+"...###\n")

            #Grab the architecture.
            Arch = OS.split()[-8]
            if Arch == "64-bit":
                Arch = "x86_64"
            else:
                Arch = "i686"
            
            #If we're not on a live disk, and the partition is AutoRootFS, let the remover function know that we aren't using chroot.
            if LiveDisk == False and Partition == AutoRootFS:
                if Bootloader == "GRUB-LEGACY":
                    retval = self.RemoveGRUBLEGACY(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "GRUB2":
                    retval = self.RemoveGRUB2(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "LILO":
                    retval = self.RemoveLILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "GRUB-UEFI":
                    retval = self.RemoveGRUBUEFI(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "ELILO":
                    retval = self.RemoveELILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)

            #Otherwise, setup the chroot and everything else first, and tell it we are using chroot, and pass the mountpoint to it.
            else:
                #Mount the partition using the global mount function.
                MountPoint = "/mnt"+Partition
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check this worked okay, and issue an error if it didn't.
                if retstr not in ['Succeeded', 'Already Mounted']:
                    logger.error("MainBackendThread().RemoveOldBootloader(): Failed to remount partition: "+Partition+"! Warn the user and skip this OS.")
                    self.ShowMsgDlg(Kind="error", Message="WxixBoot failed to mount the partition containing: "+OS+"! This OS will now be skipped.")
                else:
                    #Set up chroot.
                    self.SetUpChroot(MountPoint=MountPoint)

                    #If there's a seperate /boot partition for this OS, make sure it's mounted.
                    self.StartThreadProcess(['chroot', MountPoint, 'mount', '-av'], ShowOutput=False)

                    #Remove the bootloader.
                    if Bootloader == "GRUB-LEGACY":
                        retval = self.RemoveGRUBLEGACY(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "GRUB2":
                        retval = self.RemoveGRUB2(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "LILO":
                        retval = self.RemoveLILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "GRUB-UEFI":
                        retval = self.RemoveGRUBUEFI(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "ELILO":
                        retval = self.RemoveELILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)

                    #Tear down chroot.
                    self.TearDownChroot(MountPoint=MountPoint)

            self.UpdateOutputBox("\n###Finished removing the old bootloader from OS: "+OS+"...###\n")

            if retval != 0:
                #Something went wrong! Log it and notify the user.
                logger.error("MainBackendThread().RemoveOldBootloader(): Failed to remove "+Bootloader+" from OS: "+OS+"! We'll continue anyway. Warn the user.")
                self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to remove "+Bootloader+" from: "+OS+"! This probably doesn't matter; when we install the new bootloader, it should take precedence over the old one anyway. Make sure you check that OS after WxFixBoot finishes its operations.")

            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 27+(22/len(OSsForBootloaderRemoval)))

        #Log and notify the user that we're finished remving bootloaders.
        logger.info("MainBackendThread().RemoveOldBootloader(): Finished removing bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished removing old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 50)
        self.ShowMsgDlg(Kind="info", Message="Finished removing old bootloaders! WxFixBoot will now install your new bootloader to: "+', '.join(OSsForBootloaderInstallation)+".")

    def RemoveGRUBLEGACY(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove GRUB-LEGACY.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'grub', 'grub-legacy-doc', 'grub-common'], ShowOutput=False)
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'grub', 'grub-legacy-doc', 'grub-common'], ShowOutput=False)
        
        #Return the return value.
        return retval

    def RemoveGRUB2(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove GRUB2.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'grub-pc', 'grub-pc-bin', 'grub-common'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'grub-pc', 'grub-pc-bin', 'grub-common'])
        
        #Return the return value.
        return retval

    def RemoveLILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove lilo.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'lilo'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'lilo'])
        
        #Return the return value.
        return retval

    def RemoveGRUBUEFI(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove GRUB-UEFI.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'grub-efi', 'grub-efi-amd64', 'grub-efi-amd64-bin', 'grub-efi-ia32', 'grub-efi-ia32-bin', 'grub-common', 'grub2-common'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'grub-efi', 'grub-efi-amd64', 'grub-efi-amd64-bin', 'grub-efi-ia32', 'grub-efi-ia32-bin', 'grub-common', 'grub2-common'])
        
        #Return the return value.
        return retval

    def RemoveELILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove ELILO.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'elilo'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'elilo'])
        
        #Return the return value.
        return retval

    ####################End Of Bootloader Removal Functions.####################
    ####################Start Of Bootloader Installation Functions.####################

    def InstallNewBootloader(self):
        #Function to install a new bootloader.
        #Install the new bootloader on the chosen OS.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to install the new bootloader(s)...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 52)  
        BLInstallFailure = "No"     

        #Loop through OSsForBootloaderInstallation, and provide information to the function that will install the bootloader.
        for OS in OSsForBootloaderInstallation:
            #For each OS that needs the new bootloader installed, grab the partition, and the package manager.
            Partition = OS.split()[-5]
            PackageManager = OS.split()[-1]

            logger.info("MainBackendThread().InstallNewBootloader(): Preparing to install the new bootloader "+BootloaderToInstall+" in OS: "+OS+"...")
            self.UpdateOutputBox("\n###Preparing to install the new bootloader in OS: "+OS+"...###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to install the new bootloader(s)...")

            #Grab the architecture.
            Arch = OS.split()[-8]
            if Arch == "64-bit":
                Arch = "x86_64"
            else:
                Arch = "i686"

            #If we're not on a live disk, and the partition is AutoRootFS, let the installer function know that we aren't using chroot.
            if LiveDisk == False and Partition == AutoRootFS:
                #Update the package lists.
                retval = self.UpdatePackageLists(PackageManager=PackageManager, UseChroot=False)

                wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Installing the new bootloader(s)...")
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)       
                self.UpdateOutputBox("\n###Installing the new bootloader in OS: "+OS+"...###\n")

                if BootloaderToInstall == "GRUB2":
                    retval = self.InstallGRUB2(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif BootloaderToInstall == "LILO":
                    retval = self.InstallLILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif BootloaderToInstall == "GRUB-UEFI":
                    #Mount the UEFI partition at /boot/efi.
                    #Unmount it first though, in case it's already mounted.
                    self.UnmountPartition(Partition=UEFISystemPartition)
                    MountPartitionSafely(Partition=UEFISystemPartition, MountPoint="/boot/efi")

                    retval = self.InstallGRUBUEFI(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif BootloaderToInstall == "ELILO":
                    #Unmount the UEFI Partition now.
                    self.UnmountPartition(Partition=UEFISystemPartition)

                    retval = self.InstallELILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)

            #Otherwise, setup the chroot and everything else first, and tell it we are using chroot, and pass the mountpoint to it.
            else:
                #Mount the partition using the global mount function.
                MountPoint = "/mnt"+Partition
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check this worked okay, and issue an error if it didn't.
                if retstr not in ['Succeeded', 'Already Mounted']:
                    logger.error("MainBackendThread().InstallNewBootloader(): Failed to remount partition: "+Partition+"! Warn the user and skip this OS.")
                    self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to mount the partition containing: "+OS+"! Bootloader installation cannot continue! This may leave your system, or this OS, in an unbootable state. It is recommended to do a Bad Sector check, and then try again.")
                else:
                    #Set up chroot.
                    self.SetUpChroot(MountPoint=MountPoint)

                    #If there's a seperate /boot partition for this OS, make sure it's mounted.
                    self.StartThreadProcess(['chroot', MountPoint, 'mount', '-av'], ShowOutput=False)

                    #Update the package lists.
                    retval = self.UpdatePackageLists(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint)

                    wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Installing the new bootloader(s)...")
                    wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)       
                    self.UpdateOutputBox("\n###Installing the new bootloader in OS: "+OS+"...###\n")

                    #Install the bootloader.
                    if BootloaderToInstall == "GRUB2":
                        retval = self.InstallGRUB2(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif BootloaderToInstall == "LILO":
                        retval = self.InstallLILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif BootloaderToInstall == "GRUB-UEFI":
                        #Mount the UEFI partition at MountPoint/boot/efi.
                        #Unmount it first though, in case it's already mounted.
                        self.UnmountPartition(Partition=UEFISystemPartition)
                        MountPartitionSafely(Partition=UEFISystemPartition, MountPoint=MountPoint+"/boot/EFI")
                        retval = self.InstallGRUBUEFI(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif BootloaderToInstall == "ELILO":
                        #Unmount the UEFI Partition now, and update the mtab inside chroot.
                        self.UnmountPartition(Partition=UEFISystemPartition)
                        self.UpdateChrootMtab(MountPoint=MountPoint)

                        retval = self.InstallELILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)

                    #If there's a seperate /boot partition for this OS, make sure it's unmounted before removing the chroot.
                    self.StartThreadProcess(['chroot', MountPoint, 'umount', '/boot'], ShowOutput=False)

                    #Tear down chroot.
                    self.TearDownChroot(MountPoint=MountPoint)

            if retval != 0:
                #Something went wrong! Log it and notify the user.
                BLInstallFailure = "Yes"
                logger.error("MainBackendThread().InstallNewBootloader(): Failed to install "+BootloaderToInstall+" in OS: "+OS+"! This may mean the system (or this OS) is now unbootable! We'll continue anyway. Warn the user.")
                self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to install "+BootloaderToInstall+" in: "+OS+"! This may leave your system, or this OS, in an unbootable state. It is recommended to do a Bad Sector check, unplug any non-essential devices, and then try again.")

            self.UpdateOutputBox("\n###Finished installing the new bootloader in OS: "+OS+"...###\n")

        #Log and notify the user that we're finished removing bootloaders.
        logger.info("MainBackendThread().InstallNewBootloader(): Finished Installing bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Installing bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 75)
        return BLInstallFailure

    def UpdatePackageLists(self, PackageManager, UseChroot, MountPoint="None"):
        #Function to update thpackage lists so the required packages can always be found.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get update", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" sh -c 'DEBIAN_FRONTEND=noninteractive apt-get update'", Piping=True)
        
        #Return the return value.
        return retval

    def InstallGRUB2(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to install GRUB2.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get install -y grub-pc os-prober", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" sh -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y grub-pc os-prober'", Piping=True)
        
        #Return the return value.
        return retval

    def InstallLILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to install LILO.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get install -y lilo", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" sh -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y lilo'", Piping=True)
        
        #Return the return value.
        return retval

    def InstallGRUBUEFI(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to Install GRUB-UEFI.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get install -y grub-efi os-prober", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" sh -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y grub-efi os-prober'", Piping=True)
        
        #Return the return value.
        return retval

    def InstallELILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to install ELILO.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get install -y elilo", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" sh -c 'DEBIAN_FRONTEND=noninteractive apt-get install -y elilo'", Piping=True)
        
        #Return the return value.
        return retval

    ####################End Of Bootloader Installation Functions.####################
    ####################Start Of Bootloader Configuration Setting Functions.####################

    def SetNewBootloaderConfig(self):
        #Function to manage setting new bootloader config.
        logger.debug("MainBackendThread().SetNewBootloaderConfig(): Preparing to set bootloader config in OS(s): "+', '.join(OSsForBootloaderInstallation)+"...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to set the new bootloaders' config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 77)

        #Loop through OSsForBootloaderInstallation, and provide information to the function that will set the bootloaders' config.
        for OS in OSsForBootloaderInstallation:
            #For each OS that needs the new bootloader configured, grab the partition, and the package manager.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting the new bootloader config for OS: "+OS+"...")

            #Grab the OS's partition and package manager.
            Partition = OS.split()[-5]
            PackageManager = OS.split()[-1]

            self.UpdateOutputBox("\n###Preparing to set the new bootloaders' config for OS: "+OS+"...###\n")

            #Grab the architecture.
            Arch = OS.split()[-8]
            if Arch == "64-bit":
                Arch = "x86_64"
            else:
                Arch = "i686"

            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Setting the new bootloader's config...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 79)
            self.UpdateOutputBox("\n###Setting the new bootloader's config for OS: "+OS+"...###\n")

            #Check if the Partition is AutoRootFS, if we're not on a live disk.
            if LiveDisk == False and Partition == AutoRootFS:
                #If so, make sure this will work for this OS too, and avoid setting mountpoint, so the config instructions below look in the right place for the config files.
                MountPoint = ""
            else:
                #If not, set mountpoint to the actual mountpoint.
                MountPoint = "/mnt"+Partition

                #Mount it safely using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, and skip the rest of the loop, as it's safer to do so.
                    logger.warning("MainBackendThread().SetNewBootloaderConfig(): Command: 'mount "+MountPoint+" /mnt/"+MountPoint+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                    continue
                else:
                    #Set up chroot.
                    self.SetUpChroot(MountPoint=MountPoint)

                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 81)

            #Look for the configuration file, based on which SetConfig() function we're about to run.
            if BootloaderToInstall == "GRUB2":
                #Check MountPoint/etc/default/grub exists.
                if os.path.isfile(MountPoint+"/etc/default/grub"):
                    #It does, we'll run the function to set the config now.
                    logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2-BIOS Configuration...")
                    self.SetGRUB2Config(filetoopen=MountPoint+"/etc/default/grub")

                #Now Install GRUB2 to the MBR.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing GRUB2 to MBR...")
                self.InstallGRUB2ToMBR(PackageManager=PackageManager, MountPoint=MountPoint)

                #Update GRUB.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Updating GRUB2 Configuration...")
                self.UpdateGRUB2(PackageManager=PackageManager, MountPoint=MountPoint)

                #Set the default OS.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2 Default OS...")
                self.SetGRUB2DefaultOS(OS=OS, PackageManager=PackageManager, MountPoint=MountPoint)

            elif BootloaderToInstall == "GRUB-UEFI":
                #Check MountPoint/etc/default/grub exists.
                if os.path.isfile(MountPoint+"/etc/default/grub"):
                    #It does, we'll run the function to set the config now.
                    logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2-UEFI Configuration...")
                    self.SetGRUB2Config(filetoopen=MountPoint+"/etc/default/grub")

                #Mount the UEFI partition at MountPoint/boot/efi.
                MountPartitionSafely(Partition=UEFISystemPartition, MountPoint=MountPoint+"/boot/efi")

                #Now Install GRUB-UEFI to the UEFI Partition.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing GRUB2 to UEFISystemPartition...")
                self.InstallGRUBUEFIToPartition(PackageManager=PackageManager, MountPoint=MountPoint, UEFISystemPartitionMountPoint=MountPoint+"/boot/efi", Arch=Arch)

                #Update GRUB.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Updating GRUB2 Configuration...")
                self.UpdateGRUB2(PackageManager=PackageManager, MountPoint=MountPoint)

                #Make an entry in fstab for the UEFI Partition, if needed.
                self.WriteFSTABEntryForUEFIPartition(MountPoint=MountPoint)

                #Copy and backup EFI files where needed.
                self.BackupUEFIFiles(MountPoint=MountPoint)
                self.CopyUEFIFiles(MountPoint=MountPoint)

                #Set the default OS.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2 Default OS...")
                self.SetGRUB2DefaultOS(OS=OS, PackageManager=PackageManager, MountPoint=MountPoint)

            elif BootloaderToInstall == "LILO":
                #Make LILO's config file.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Making LILO's configuration file...")
                if MountPoint == "":
                    self.StartThreadProcess(['liloconfig', '-f'], ShowOutput=False)
                else:
                    self.StartThreadProcess(['chroot', MountPoint, 'liloconfig', '-f'], ShowOutput=False)

                #Check the config file exists for lilo
                if os.path.isfile(MountPoint+"/etc/lilo.conf"):
                    #It does, we'll run the function to set the config now.
                    logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting LILO Configuration...")
                    self.SetLILOConfig(filetoopen=MountPoint+"/etc/lilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)
    
                    #Also, set the OS entries.
                    logger.info("MainBackendThread().SetNewBootloaderConfig(): Creating LILO OS Entries...")
                    self.MakeLILOOSEntries(filetoopen=MountPoint+"/etc/lilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)

                #Now Install LILO to the MBR.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing LILO to the MBR...")
                self.InstallLILOToMBR(PackageManager=PackageManager, MountPoint=MountPoint)

            elif BootloaderToInstall == "ELILO":
                #Unmount the UEFI Partition now, and update mtab in the chroot.
                self.UnmountPartition(Partition=UEFISystemPartition)
                self.UpdateChrootMtab(MountPoint=MountPoint)

                #Make ELILO's config file.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Making ELILO's configuration file...")
                if MountPoint == "":
                    self.StartThreadProcess(['elilo', '-b', UEFISystemPartition, '--autoconf'], ShowOutput=False)
                else:
                    self.StartThreadProcess(['chroot', MountPoint, 'elilo', '-b', UEFISystemPartition, '--autoconf'], ShowOutput=False)

                #Check elilo's config file exists.
                if os.path.isfile(MountPoint+"/etc/elilo.conf"):
                    #It does, we'll run the function to set the config now.
                    logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting ELILO Configuration...")
                    self.SetELILOConfig(filetoopen=MountPoint+"/etc/elilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)

                    #Also, set the OS entries.
                    logger.info("MainBackendThread().SetNewBootloaderConfig(): Creating ELILO OS Entries...")
                    self.MakeLILOOSEntries(filetoopen=MountPoint+"/etc/elilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)

                #Now Install ELILO to the UEFI Partition.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing ELILO to UEFISystemPartition...")
                self.InstallELILOToPartition(PackageManager=PackageManager, MountPoint=MountPoint, UEFISystemPartitionMountPoint=MountPoint+"/boot/efi", Arch=Arch)

                #Mount the UEFI partition at MountPoint/boot/efi.
                MountPartitionSafely(Partition=UEFISystemPartition, MountPoint=MountPoint+"/boot/efi")

                #Copy and backup UEFI files where needed.
                self.BackupUEFIFiles(MountPoint=MountPoint)
                self.CopyUEFIFiles(MountPoint=MountPoint)

            #Unmount the partition, if needed.
            if MountPoint != "":
                #Tear down chroot.
                self.TearDownChroot(MountPoint=MountPoint)
                self.UnmountPartition(Partition=MountPoint)

            self.UpdateOutputBox("\n###Finished setting the new bootloader's config for OS: "+OS+"...###\n")

        logger.debug("MainBackendThread().SetNewBootloaderConfig(): Finished setting bootloader config.")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished setting the new bootloader's config!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

    ####################Start Of GRUB Bootloader Configuration Setting Functions.####################

    def SetGRUB2Config(self, filetoopen):
        #Function to set GRUB2 config.
        SetTimeout = False
        SetKOpts = False
        SetDefault = False

        #Open the file in read mode, so we can find the new config that needs setting. Also, use a list to temporarily store the modified lines.
        ConfigFile = open(filetoopen, 'r')
        NewFileContents = []

        #Loop through each line in the file, paying attention only to the important ones.
        for line in ConfigFile:
            #Look for the timeout setting.
            if 'GRUB_TIMEOUT' in line and '=' in line:
                #Found it! Set the value to the current value of BootloaderTimeout.
                SetTimeout = True
                head, sep, Temp = line.partition('=')
                Temp = str(BootloaderTimeout)

                #Reassemble the line.
                line = head+sep+Temp+"\n"

            #Look for kernel options setting.
            elif 'GRUB_CMDLINE_LINUX_DEFAULT' in line and '=' in line:
                #Found it! Set it to the options in KernelOptions, carefully making sure we aren't double-quoting it.
                SetKOpts = True
                head, sep, Temp = line.partition('=')

                #Reassemble the line.
                line = head+sep+"'"+KernelOptions+"'"+"\n"

            #Look for the "GRUB_DEFAULT" setting.
            elif "GRUB_DEFAULT" in line and '=' in line:
                #Found it. Set it to 'saved', so we can set the default bootloader.
                SetDefault = True
                head, sep, Temp = line.partition('=')
                Temp = "saved"

                #Reassemble the line.
                line = head+sep+Temp+"\n"

            #Comment out the GRUB_HIDDEN_TIMEOUT line.
            elif 'GRUB_HIDDEN_TIMEOUT' in line and 'GRUB_HIDDEN_TIMEOUT_QUIET' not in line and '=' in line and '#' not in line:
                line = "#"+line

            NewFileContents.append(line)

        #Check that everything was set. If not, write that config now.
        if SetTimeout == False:
            NewFileContents.append("GRUB_TIMEOUT="+str(BootloaderTimeout)+"\n")

        if SetKOpts == False:
            Temp = KernelOptions.replace('\"', '').replace("\'", "").replace("\n", "")
            NewFileContents.append("GRUB_CMDLINE_LINUX_DEFAULT='"+Temp+"'\n")

        if SetDefault == False:
            NewFileContents.append("GRUB_DEFAULT=saved")

        #Write the finished lines to the file.
        ConfigFile.close()
        ConfigFile = open(filetoopen, 'w')
        ConfigFile.write(''.join(NewFileContents))
        ConfigFile.close()

    def InstallGRUB2ToMBR(self, PackageManager, MountPoint):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the MBR.
        #Use --force to make sure grub installs itself, even on a GPT disk with no bios boot partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['grub-install', '--force', RootDevice], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'grub-install', '--force', RootDevice], ShowOutput=False)

        #Return the return value.
        return retval

    def InstallGRUBUEFIToPartition(self, PackageManager, MountPoint, UEFISystemPartitionMountPoint, Arch):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the UEFI partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['grub-install', '--efi-directory='+UEFISystemPartitionMountPoint, '--target='+Arch+'-efi'], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'grub-install', '--efi-directory=/boot/efi', '--target='+Arch+'-efi'], ShowOutput=False)

        #Return the return value.
        return retval

    def UpdateGRUB2(self, PackageManager, MountPoint):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the UEFI partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['update-grub'], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'update-grub'], ShowOutput=False)

        #Return the return value.
        return retval

    def SetGRUB2DefaultOS(self, OS, PackageManager, MountPoint):
        #Now we need to set the default os.
        #I couldn't find a reliable way of doing this automatically, so give the user a choice box instead.
        global DefaultOS

        #Make a list of OSs grub2 found (hopefully all of them).
        if MountPoint == "":
            if PackageManager == "apt-get":
                Temp = self.StartThreadProcess(["grep", '-w', "menuentry", "/boot/grub/grub.cfg"], ShowOutput=False, ReturnOutput=True)
                retcode = Temp[0]
                GrubMenuEntries = Temp[1]
        else:
            if PackageManager == "apt-get":
                Temp = self.StartThreadProcess(["grep", '-w', "menuentry", MountPoint+"/boot/grub/grub.cfg"], ShowOutput=False, ReturnOutput=True)
                retcode = Temp[0]
                GrubMenuEntries = Temp[1]

        if retcode != 0:
            #Don't set the default OS.
            self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to set the default OS. This doesn't really matter. Click okay to continue.")
        else:
            #Now finally make the list of grub's OS names.
            GRUBOSNameList = []

            #Split with each newline character found in the returned string.
            GrubMenuEntriesList = GrubMenuEntries.split('\n')
            for OSName in GrubMenuEntriesList:
                #Get each OS name, removing all of the unneeeded characters.
                junk,sep,info = OSName.partition("'")
                info,sep,junk = info.partition("'")
                GRUBOSNameList.append(info)

            #Now ask the user to select the correct one.
            DefaultOS = self.ShowChoiceDlg(Message="Please select the OS you want to use as "+BootloaderToInstall+"'s Default OS. You are setting configuration for: "+OS, Title="WxFixBoot - Select Default OS", Choices=GRUBOSNameList)

            #Use the user's selection to set the default OS.
            if LiveDisk == False and MountPoint == "":
                #If the OS is AutoRootFS, and we're not on a live disk, do it differently.
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess(["grub-set-default", DefaultOS], ShowOutput=False)
                else:
                    retval = self.StartThreadProcess(["grub2-set-default", DefaultOS], ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess(["chroot", MountPoint, "grub-set-default", DefaultOS], ShowOutput=False)
                else:
                    retval = self.StartThreadProcess(["chroot", MountPoint, "grub2-set-default", DefaultOS], ShowOutput=False)

            #Return the return value.
            return retval

    ####################End Of GRUB Bootloader Configuration Setting Functions.####################
    ####################Start Of LILO and ELILO Bootloader Configuration Setting Functions.####################

    def SetLILOConfig(self, filetoopen, PackageManager, MountPoint):
        #Function to set LILO config.
        SetTimeout = False
        SetBootDevice = False

        #Open the file in read mode, so we can find the important bits of config to edit. Also, use a list to temporarily store the modified lines.
        ConfigFile = open(filetoopen, 'r')
        NewFileContents = []

        #Loop through each line in the file, paying attention only to the important ones.
        for line in ConfigFile:
            #Look for the timeout setting.
            if 'timeout' in line and '=' in line and '#' not in line:
                #Found it! Set it to our value.
                SetTimeout = True

                #Save it, carefully avoiding errors.
                head, sep, Temp = line.partition('=')
                Temp = str(BootloaderTimeout*10)

                #Reassemble the line.
                line = "timeout"+sep+Temp+"\n"

            #Look for the 'boot' setting.
            elif 'boot' in line and '=' in line and '#' not in line and 'map' not in line: 
                #Found it, seperate the line.
                SetBootDevice = True
                head, sep, Temp = line.partition('=')

                #Now let's find the ID of RootDevice.
                ID = self.GetDeviceID(Device=RootDevice)
                if ID != "None":
                    #Good, we've got the ID.
                    #Set it to RootDevice's ID.                    
                    Temp = "/dev/disk/by-id/"+ID
                else:
                    #Not so good... We'll have to use the device name, which may change, especially if we're using chroot.
                    Temp = RootDevice

                #Reassemble the line.
                line = head+sep+Temp+"\n"

            NewFileContents.append(line)

        #Check that everything was set. If not, write that config now.
        if SetTimeout == False:
            NewFileContents.append("timeout="+str(BootloaderTimeout)+"\n")

        if SetBootDevice == False:
            #Now let's find the ID of RootDevice.
            ID = self.GetDeviceID(Device=RootDevice)
            if ID != "None":
                #Good, we've got the ID.
                #Set it to RootDevice's ID.                    
                Temp = "/dev/disk/by-id/"+ID
            else:
                #Not so good... We'll have to use the device name, which may change, especially if we're using chroot.
                Temp = RootDevice

            NewFileContents.append("boot="+Temp+"\n")

        #Write the finished lines to the file.
        ConfigFile.close()
        ConfigFile = open(filetoopen, 'w')
        ConfigFile.write(''.join(NewFileContents))
        ConfigFile.close()

    def SetELILOConfig(self, filetoopen, PackageManager, MountPoint):
        #Function to set ELILO config.
        SetTimeout = False
        SetUEFIPart = False

        #Open the file in read mode, so we can find the important bits of config to edit. Also, use a list to temporarily store the modified lines.
        ConfigFile = open(filetoopen, 'r')
        NewFileContents = []

        #Loop through each line in the file, paying attention only to the important ones.
        for line in ConfigFile:
            #Look for the delay setting.
            if 'delay' in line and '=' in line and '#' not in line:
                #Found it! Set it to our value.
                SetTimeout = True

                #Save it, carefully avoiding errors.
                head, sep, Temp = line.partition('=')
                Temp = str(BootloaderTimeout*10)

                #Reassemble the line.
                line = head+sep+Temp+"\n"

            #Look for the 'boot' setting.
            elif 'boot' in line and '=' in line and '#' not in line:
                #Found it, seperate the line.
                SetUEFIPart = True
                head, sep, Temp = line.partition('=')

                #Now let's find the ID of UEFISystemPartition.
                ID = self.GetDeviceID(Device=UEFISystemPartition)

                if ID != "None":
                    #Good, we've got the ID.
                    #Set it to UEFISystemPartition's ID.                    
                    Temp = "/dev/disk/by-id/"+ID
                else:
                    #Not so good... We'll have to use the partition's name, which may change, especially if we're using chroot.
                    Temp = UEFISystemPartition

                #Reassemble the line.
                line = head+sep+Temp+"\n"

            #Get rid of any boot entries.
            elif 'image=' in line or '\t' in line:
                #Skip this line, and don't append it to the list.
                continue

            NewFileContents.append(line)

        #Check that everything was set. If not, write that config now.
        if SetTimeout == False:
            NewFileContents.append("delay="+str(BootloaderTimeout)+"\n")

        if SetUEFIPart == False:
            #Now let's find the ID of UEFISystemPartition.
            ID = self.GetDeviceID(Device=UEFISystemPartition)
            if ID != "None":
                #Good, we've got the ID.
                #Set it to UEFISystemPartition's ID.                    
                Temp = "/dev/disk/by-id/"+ID
            else:
                #Not so good... We'll have to use the device name, which may change, especially if we're using chroot.
                Temp = UEFISystemPartition

            NewFileContents.append("boot="+Temp+"\n")

        #Write the finished lines to the file.
        ConfigFile.close()
        ConfigFile = open(filetoopen, 'w')
        ConfigFile.write(''.join(NewFileContents))
        ConfigFile.close()

    def MakeLILOOSEntries(self, filetoopen, PackageManager, MountPoint):
        #Okay, we've saved the kopts, timeout, and the boot device in the list.
        #Now we'll set the OS entries, and then the default OS.
        #Open the file, and add each entry to a temporary list, which will be written to the file later.
        ConfigFile = open(filetoopen, 'r')
        NewFileContents = []

        #First, make sure everything else comes first, because LILO and ELILO are picky with the placement of the image files (they must be at the end of the file).
        #We'll also make a placeholder for the default OS, so it comes before the image entries too.
        Temp = False
        for line in ConfigFile:
            if 'default' in line and '=' in line and '#' not in line:
                #The place holder already exists. Set a variable so we don't make one.
                Temp = True

            NewFileContents.append(line)

        #If there isn't a placeholder, make one now.
        if Temp == False:
            NewFileContents.append("default=setthis\n")

        #Make the OS entries.
        if BootloaderToInstall == "ELILO":
            NewFileContents.append("#################### ELILO per-image section ####################")

        #As we make these entries, we'll record which ones were actually made, as the user can cancel them if it looks like it won't work.
        CompletedEntriesList = []

        for OS in OSList:
            logger.info("MainBackendThread().MakeLILOOSEntries(): Preparing to make an entry for: "+OS)

            #Names in LILO are not allowed to have spaces, so let's grab the names and remove the spaces from them.
            #If this OS is the currently running one, we'll need to access a different part of the element.
            if OS.split()[-5] == "OS)":
                OSName = ''.join(OS.split()[0:-6])
            else:
                OSName = ''.join(OS.split()[0:-4])

            #Remove all the spaces from the OS's name.
            OSName = OSName.replace(' ','')

            #Grab the OS's partition.
            Partition = OS.split()[-1]

            #Check that the name is no longer than 15 characters.
            if len(OSName) > 15:
                #The name is too long! Truncate it to 15 characters.
                logger.warning("MainBackendThread().MakeLILOOSEntries(): Truncating OS Name: "+OSName+" to 15 characters...")
                OSName = OSName[0:15]

            #Now let's make the entries.
            logger.debug("MainBackendThread().MakeLILOOSEntries(): Checking for /vmlinuz and /initrd.img...")

            if OS[-5] == "OS)":
                CurrentOS = True
            else:
                CurrentOS = False

            #Check that MountPoint/vmlinuz and MountPoint/initrd.img exist. (If this is the current OS, MountPoint = "", and so doesn't get in the way).
            if os.path.isfile(MountPoint+"/vmlinuz"):
                #Good, add this to the file. (It's local to the partition, so we don't need to include MountPoint in the path)
                logger.info("MainBackendThread().MakeLILOOSEntries(): Found /vmlinuz! Adding it to the config file...")
                NewFileContents.append("\nimage=/vmlinuz\n")
            else:
                #Not so good... This probably means changing LILO's config each time we do a kernel update... Let's ask the user if we should still add it.
                logger.warning("MainBackendThread().MakeLILOOSEntries(): Couldn't find /vmlinuz for: "+OS+"! Asking the user if we should search for vmlinuz and make an entry anyway...")

                Result = self.ShowYesNoDlg(Message="Warning: /vmlinuz (shortcut to the latest kernel) wasn't found for: "+OS+"! Your new bootloader will still work, but this might mean you'll have to manaully change its config file each time you update your kernel on this OS. You can do this with WxFixBoot, but that won't stop it from being annoying and introducing security risks if you forget. However, this OS will be unbootable if you don't add it to the boot menu. Do you want to add it to the boot menu anyway?", Title="WxFixBoot - Add OS to boot menu?")

                if Result == "No":
                    #Okay, go back to the start of the loop.
                    logger.warning("MainBackendThread().MakeLILOOSEntries(): Not making an entry for "+OS+"! Skipping this OS...")
                    continue
                else:
                    #Right, we'll have to hunt out the Kernel.
                    logger.warning("MainBackendThread().MakeLILOOSEntries(): Okay, we'll make an entry for "+OS+" anyway. Now let's try and find the latest Kernel...")
                    Kernel = self.FindLatestVersion(Directory=MountPoint+"/boot", Type="Kernel")

                    #Check if we found it.
                    if Kernel == "None":
                        #We didn't! Tell the user, and skip this OS.
                        logger.error("MainBackendThread().MakeLILOOSEntries(): Couldn't find the latest kernel for "+OS+"! This OS will now be skipped!") 
                        self.ShowMsgDlg(Kind="error", Message="WxFixBoot couldn't find the latest kernel for this OS. This OS will now be skipped.")
                        continue
                    else:
                        #We did! Add it to the file. (It's local to the partition, so we don't need to include MountPoint in the path)
                        logger.info("MainBackendThread().MakeLILOOSEntries(): Found the latest kernel at: "+Kernel+"! Adding it to the config file...")
                        NewFileContents.append("\nimage=/boot/"+Kernel+"\n")

            if os.path.isfile(MountPoint+"/initrd.img"):
                #Good, add this to the file. (It's local to the partition, so we don't need to include MountPoint in the path)
                logger.info("MainBackendThread().MakeLILOOSEntries(): Found /initrd.img! Adding it to the config file...")
                NewFileContents.append("\tinitrd=/initrd.img\n")
            else:
                #Not so good... This probably means changing LILO's config each time we do a kernel update... Let's ask the user if we should still add it.
                logger.warning("MainBackendThread().MakeLILOOSEntries(): Couldn't find /initrd.img for "+OS+"! Asking the user if we should search for initrd.img and make an entry anyway...")

                Result = self.ShowYesNoDlg(Message="Warning: /initrd.img (shortcut to the latest Initial Filesystem) wasn't found for: "+OS+"! Your new bootloader will still work, but this might mean you'll have to manaully change its config file each time you update your kernel on this OS. You can do this with WxFixBoot, but that won't stop it from being annoying and introducing security risks if you forget. Do you want to add it to the boot menu anyway?", Title="WxFixBoot - Add OS to boot menu?")

                if Result == "No":
                    #Okay, delete the last entry, so we don't have an unconfigured image, and then go back to the start of the loop.
                    logger.warning("MainBackendThread().MakeLILOOSEntries(): Not making an entry for "+OS+"! Deleting the unconfigured image, and skipping this OS...")
                    Temp = NewFileContents.pop()
                    continue
                else:
                    #Right, we'll have to hunt out the Initrd/Initramfs.
                    logger.warning("MainBackendThread().MakeLILOOSEntries(): Okay, we'll make an entry for "+OS+" anyway. Now let's try and find the latest Initrd...")
                    Initrd = self.FindLatestVersion(Directory=MountPoint+"/boot", Type="Initrd")

                    #Check if we found it.
                    if Initrd == "None":
                        #We didn't! Tell the user, delete the unconfigured image entry (logically there must be one), and skip this OS.
                        logger.error("MainBackendThread().MakeLILOOSEntries(): Couldn't find the latest Initrd for "+OS+"! This OS will now be skipped, and the unconfigured image deleted!") 
                        self.ShowMsgDlg(Kind="error", Message="WxFixBoot couldn't find the latest initrd.img for this OS. This OS will now be skipped.")
                        Temp = NewFileContents.pop()
                        continue
                    else:
                        #We did! Add it to the file. (It's local to the partition, so we don't need to include MountPoint in the path)
                        logger.info("MainBackendThread().MakeLILOOSEntries(): Found the latest Initrd at: "+Initrd+"! Adding it to the config file...")
                        NewFileContents.append("\tinitrd=/boot/"+Initrd+"\n")

            #Set the root device.
            #Use UUID's here if we can.
            UUID = self.GetPartitionUUID(Partition)
            if UUID == "None":
                NewFileContents.append("\troot="+Partition+"\n")
            else:
                #If we're using ELILO, we have to do this differently.
                if BootloaderToInstall == "ELILO":
                    NewFileContents.append("\troot=UUID="+UUID+"\n")
                else:
                    NewFileContents.append("\troot=\"UUID="+UUID+"\"\n")

            #Set the label.
            NewFileContents.append("\tlabel="+OSName+"\n")

            #Set the kernel options.
            NewFileContents.append("\tappend=\""+KernelOptions+"\"\n")

            #Set one other necessary boot option.
            NewFileContents.append("\tread-only\n")

            #Add this OS to the Completed Entries List, because if we got this far it's done and added.
            CompletedEntriesList.append(OSName)

        #Now set the default OS.
        #First, write the semi-finished lines to the file.
        ConfigFile.close()
        ConfigFile = open(filetoopen, 'w')
        ConfigFile.write(''.join(NewFileContents))
        ConfigFile.close()

        #Open the file again, with the new files written.
        ConfigFile = open(filetoopen, 'r')
        NewFileContents = []

        #Get the OS name and truncate it if necessary.
        logger.info("MainBackendThread().MakeLILOOSEntries(): Getting and truncating the default OS's name...")

        #If DefaultOS is the currently running one, we'll need to access a different part of the variable.
        if DefaultOS.split()[-5] == "OS)":
            OSName = ''.join(DefaultOS.split()[0:-6])
        else:
            OSName = ''.join(DefaultOS.split()[0:-4])

        #Remove all of the spaces.
        DefaultOSName = OSName.replace(' ','')

        #Check that the name is no longer than 15 characters.
        if len(DefaultOSName) > 15:
            #The name is too long! Truncate it to 15 characters.
            logger.warning("MainBackendThread().MakeLILOOSEntries(): Truncating OS Name: "+DefaultOSName+" to 15 characters...")
            DefaultOSName = DefaultOSName[0:15]

        #Now, check if its entry was added to the file, and ask the user for a new one if it wasn't.
        if DefaultOSName not in CompletedEntriesList:
            logger.info("MainBackendThread().MakeLILOOSEntries(): Default OS not in the Completed Entries List! Asking the user for a new one...")

            if len(CompletedEntriesList) <= 0:
                #Something went wrong here! No OSs appear to have been added to the list. Warn the user.
                logger.error("MainBackendThread().MakeLILOOSEntries(): CompletedEntriesList is empty! This suggests that no OSs have been added to the list! Warn the user, and skip this part of the operation.")
                self.ShowMsgDlg(Kind="error", Message="No Operating Systems have had entries created for them! If you canceled creating the entries, please reboot WxFixBoot and select only the option 'Update Bootloader Config'. If you didn't do that, and WxFixBoot either couldn't create them, or you see this error with no previous warnings, you may have to create your own bootloader config. Don't worry, this isn't too difficult, and you can search for tutorials for this on the internet. If WxFixBoot couldn't create your entries, or you are seeing this message with no previous warnings, please also email me directly via my Launchpad page with the contents of /var/log/wxfixboot.log and I'll try to help you.")
            else:
                #Ask the user for a new default OS.
                DefaultOSName = self.ShowChoiceDlg(Message="The OS you previously selected as the default wasn't added to the boot menu. Please an new OS you want to use as "+Bootloader+"'s Default OS. You are setting configuration for: "+OS, Title="WxFixBoot - Select Default OS", Choices=CompletedEntriesList)
                logger.info("MainBackendThread().MakeLILOOSEntries(): User selected new default OS: "+DefaultOSName+"...")

        #Make the entry for the default OS.
        logger.info("MainBackendThread().MakeLILOOSEntries(): Setting default OS...")
        SetDefaultOS = False

        for line in ConfigFile:
            if 'default' in line and '=' in line and '#' not in line:
                #Get the LILO name for DefaultOS.
                SetDefaultOS = True

                #Set default to the name.
                line = "default="+DefaultOSName+"\n"

            NewFileContents.append(line)

        #Check that everything was set. If not, write that config now.
        if SetDefaultOS == False:
            NewFileContents.append("default="+DefaultOSName+"\n")

        #Write the finished lines to the file.
        ConfigFile.close()
        ConfigFile = open(filetoopen, 'w')
        ConfigFile.write(''.join(NewFileContents))
        ConfigFile.close()

    def InstallLILOToMBR(self, PackageManager, MountPoint):
        #Install lilo to the MBR of RootDev.
        if MountPoint == "":
            retval = self.StartThreadProcess(['lilo'], ShowOutput=False)
        else:
            retval = self.StartThreadProcess(['chroot', MountPoint, 'lilo'], ShowOutput=False)

        #Return the return value.
        return retval

    def InstallELILOToPartition(self, PackageManager, MountPoint, UEFISystemPartitionMountPoint, Arch):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the UEFI partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['elilo', '-b', UEFISystemPartition, '--efiboot'], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'elilo', '-b', UEFISystemPartition, '--efiboot'], ShowOutput=False)

        #Return the return value.
        return retval

    ####################End Of LILO and ELILO Bootloader Configuration Setting Functions.####################
    ####################End Of Bootloader Configuration Setting Functions.####################
    ####################End Of Bootloader Operation functions.####################
    ####################Start of system report generation function.####################
    def GenerateSystemReport(self):
        #Function to create a system report, containing various information helpful for debugging and fixing problems. It's pretty much like a bootinfo summary.
        self.ShowMsgDlg(Kind="info", Message="WxFixBoot will now create your system report. Click okay to continue.")

        #Ask the user where to save the file.
        ReportFile = self.ShowFileDlg(Title="WxFixBoot - Select System Report File", Wildcard="Text Files|*.txt|Log Files|*.log|All Files/Devices (*)|*")

        #Write everything directly to the file.
        ReportList = open(ReportFile, 'w')
        ReportList.write("This system report was created with WxFixBoot version 1.0.2. It can be used like a bootinfo summary.\n\n")

        #Do OS Information.
        ReportList.write("\n##########OS Information##########\n")
        ReportList.write("Detected Operating Systems: "+', '.join(OSList)+"\n")
        ReportList.write("Currently running OS is on Live Disk: "+str(LiveDisk)+"\n")

        #Do Firmware Information.
        ReportList.write("\n##########Firmware Information##########\n")
        ReportList.write("Detected firmware type: "+AutoFirmwareType+"\n")
        ReportList.write("Selected Firmware Type: "+FirmwareType+"\n")
        ReportList.write("UEFI System Partition (UEFI Bootloader target): "+UEFISystemPartition+"\n")

        if FirmwareType == "UEFI":
            ReportList.write("Found UEFI Variables: "+str(UEFIVariables)+"\n")

        #Do Bootloader information
        ReportList.write("\n##########BootLoader Information##########\n")
        ReportList.write("Detected Bootloader: "+AutoBootloader+"\n")
        ReportList.write("Selected Bootloader: "+Bootloader+"\n")

        if BootloaderToInstall != "None":
            #Display specific information depending on the operation to be done (if we're update/reinstalling bootloaders, don't make it look like we're doing something else).
            ReportList.write("Disabled Bootloader Operations: "+str(DisableBootloaderOperations)+"\n")

            if DisableBootloaderOperations == False:
                if ReinstallBootloader == True:
                    ReportList.write("Reinstall/Fix The Current BootLoader: "+str(ReinstallBootloader)+"\n")
                    ReportList.write("Selected Bootloader To Reinstall/Fix: "+BootloaderToInstall+"\n")
                    ReportList.write("Reinstall/Fix bootloader in: "+', '.join(OSsForBootloaderInstallation)+"\n")
                    ReportList.write("\nBootloader's New Configuration:"+"\n")
                    ReportList.write("\tDefault OS: "+DefaultOS+"\n")
                    ReportList.write("\tTimeout: "+str(BootloaderTimeout)+" seconds"+"\n")
                    ReportList.write("\tGlobal Kernel Options: "+KernelOptions+"\n")

                elif UpdateBootloader == True:
                    ReportList.write("Update The Current BootLoader's Config: "+str(UpdateBootloader)+"\n")
                    ReportList.write("Selected Bootloader To Update: "+BootloaderToInstall+"\n")
                    ReportList.write("Update Bootloader in: "+', '.join(OSsForBootloaderInstallation)+"\n")
                    ReportList.write("\nBootloader's New Configuration:"+"\n")
                    ReportList.write("\tDefault OS: "+DefaultOS+"\n")
                    ReportList.write("\tTimeout: "+str(BootloaderTimeout)+" seconds"+"\n")
                    ReportList.write("\tGlobal Kernel Options: "+KernelOptions+"\n")

                else:
                    #We must be installing a new bootloader.
                    ReportList.write("Selected Bootloader To Install: "+BootloaderToInstall+"\n")
                    ReportList.write("Remove Old Bootloader from: "+', '.join(OSsForBootloaderRemoval)+"\n")
                    ReportList.write("Install New Bootloader to: "+', '.join(OSsForBootloaderInstallation)+"\n")
                    ReportList.write("\nNew Bootloader's Configuration:"+"\n")
                    ReportList.write("\tDefault OS: "+DefaultOS+"\n")
                    ReportList.write("\tTimeout: "+str(BootloaderTimeout)+" seconds"+"\n")
                    ReportList.write("\tGlobal Kernel Options: "+KernelOptions+"\n")

        #Do Disk Information
        ReportList.write("\n##########Disk Information##########\n")
        ReportList.write("Detected Linux Partitions: "+', '.join(LinuxPartList)+"\n")
        ReportList.write("Detected Root Filesystem (MBR bootloader target): "+AutoRootFS+"\n")
        ReportList.write("Selected Root Filesystem (MBR bootloader target): "+RootFS+"\n")
        ReportList.write("Detected Root Device (MBR Bootloader Target): "+AutoRootDevice+"\n")
        ReportList.write("Selected Root Device (MBR Bootloader Target): "+RootDevice+"\n")
        ReportList.write("Partition Scheme List (In the same order as Detected Linux Partitions): "+', '.join(PartSchemeList)+"\n")
        ReportList.write("List of partitions with their filesystem types following: "+', '.join(PartitionListWithFSType)+"\n")

        #Do Boot Sector Information.
        ReportList.write("\n##########Boot Sector Information##########\n")
        ReportList.write("Backup Boot Sector: "+str(BackupBootSector)+"\n")
        if BackupBootSector == True:
            ReportList.write("\n\tBacked up Boot Sector From: "+RootDevice+"\n")
            ReportList.write("\tTarget Boot Sector File: "+BootSectorBackupFile+"\n\n")

        ReportList.write("Restore Boot Sector: "+str(RestoreBootSector)+"\n")
        if RestoreBootSector == True:
            ReportList.write("\n\tBoot Sector Backup File: "+BootSectorFile+"\n")
            ReportList.write("\tBoot Sector Target Device: "+BootSectorTargetDevice+"\n")
            ReportList.write("\tBoot Sector Backup Type: "+BootSectorBackupType+"\n") 

        #Do Partition Table Information.
        ReportList.write("\n##########Partition Table Information##########\n")
        ReportList.write("Backup Partition Table: "+str(BackupPartitionTable)+"\n")
        if BackupPartitionTable == True:
            ReportList.write("\n\tBacked up Partition Table from: "+RootDevice+"\n")
            ReportList.write("\tTarget Partition Table File: "+PartitionTableBackupFile+"\n\n")

        ReportList.write("Restore Partition Table: "+str(RestorePartitionTable)+"\n")
        if RestorePartitionTable == True:
            ReportList.write("\n\tPartition Table Backup File: "+PartitionTableFile+"\n")
            ReportList.write("\tPartition Table Target Device: "+PartitionTableTargetDevice+"\n")
            ReportList.write("\tPartition Table Backup Type: "+PartitionTableBackupType+"\n")

        #Do WxFixBoot's settings.
        ReportList.write("\n##########Other WxFixBoot Settings##########\n")
        ReportList.write("Do Quick Filesystem Check: "+str(QuickFSCheck)+"\n")
        ReportList.write("Do Bad Sector Check: "+str(BadSectCheck)+"\n")
        ReportList.write("Show Diagnostic Terminal Output: "+str(FullVerbose)+"\n")
        ReportList.write("Save System Report To File: "+str(MakeSystemSummary)+"\n")

        if MakeSystemSummary == True:
            ReportList.write("\n\tSave Terminal Output in Report: "+str(SaveOutput)+"\n")
            ReportList.write("\tSystem Report Target File: "+ReportFile+"\n\n")

        ReportList.write("Number of operations to do: "+str(NumberOfOperationsToDo)+"\n")

        #Save terminal output.
        if SaveOutput == True:
            ReportList.write("\n##########Terminal Output##########\n")
            for line in OutputLog:
                ReportList.write(line)

        #Save Log File.
        ReportList.write("\n##########WxFixBoot's Log File##########\n")
        logfile = open("/var/log/wxfixboot.log", "r")
        for line in logfile:
            ReportList.write(line)
        logfile.close()
 
#End Main Backend Thread
app = WxFixBoot(False)
app.MainLoop()
