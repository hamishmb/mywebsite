#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 1.0rc1
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
import wx
import sys
from wx.lib.wordwrap import wordwrap
from wx.lib.pubsub import Publisher
from threading import Thread
import time
import os
import shutil
import subprocess

#If this isn't running as root, exit immediately
if not os.geteuid()==0:
    sys.exit("\nSorry, this program must be run with root privileges.\nWill now exit")

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen(["/usr/share/wxfixboot/listdevices.sh"]).wait()

    #Create/Update a list
    devicelist = []

    #New more efficent way of putting everything in one list.
    with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
        idedevicesfile = idedevicessource.readlines()
        if idedevicesfile != []:
            devicelist = devicelist + idedevicesfile
            devicelist.append('IDE/ATA Devices:')

    with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
        cddvddevicesfile = cddvddevicessource.readlines()
        if cddvddevicesfile != []:
            devicelist.append('CD/DVD Devices:')
            devicelist = devicelist + cddvddevicesfile

    with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
        usbsatadevicesfile = usbsatadevicessource.readlines()
        if usbsatadevicesfile != []:
            devicelist.append('USB or SATA Devices:')
            devicelist = devicelist + usbsatadevicesfile

    #Remove newline chars.
    return [(el.strip()) for el in devicelist]

def GetPBlockSize(device):
    #Run a quick script to retrive the block size of the given device.
    global RootFSBSZ
    RootFSBSZ = subprocess.check_output(["blockdev", "--getss", device])

#Starter Class
class MyApp(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = "/usr/share/wxfixboot/splash.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

        #Make sure it's painted, which fixes the problem with the previous temperamental splash screen on DDRescue-GUI <= 1.2
        wx.Yield()

    def OnExit(self,e):
        #Start the init Frame.
        self.Hide()
        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True
            InitFrame = InitialWindow()
            app.SetTopWindow(InitFrame)
            InitFrame.Show(True)
            #Skip the event so the init frame starts.
            e.Skip()

#End splash screen
#Begin Initialization frame
class InitialWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc1 is preparing to start...",size=(400,300),style=wx.CAPTION)
        self.InitPanel = wx.Panel(self)

        print "WxFixBoot Version 1.0~rc1 experimental Starting..."
        print "None of the option are yet operational, and debugging output is also included to show where anything may've gone wrong."
        print "Do not use this on ANY production machine!"

        wx.MessageDialog(None, "Do NOT use this experimental version on ANY production machine! It is highly untested, and is only suitable for testing in VMs, as it can potentially destroy data. If you're running this on a production machine, please now kill this process in a task manager!", "WxFixBoot - WARNING", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()

        self.CreateText()

        #Create a progressbar.
        global InitProgressBar
        InitProgressBar = wx.Gauge(self.InitPanel, -1, 100, (10,270), (380,25))
        InitProgressBar.SetBezelFace(3)
        InitProgressBar.SetShadowWidth(3)
        InitProgressBar.SetValue(0)
        InitProgressBar.Show()

        #Set up threading
        Publisher().subscribe(self.ShowThreadYesNodlg, "showyesnodlg")
        Publisher().subscribe(self.ShowThreadInfodlg, "showinfodlg")
        Publisher().subscribe(self.UpdateDetectPartText, "LinuxPartUpdate")
        Publisher().subscribe(self.UpdateDetectOSesText, "LinuxOSesUpdate")
        Publisher().subscribe(self.UpdateRootFSText, "RootFSUpdate")
        Publisher().subscribe(self.UpdateFWTypeText, "FWTypeUpdate")
        Publisher().subscribe(self.UpdatePartSchemeText, "PartSchemeUpdate")
        Publisher().subscribe(self.UpdateBootLoaderText, "BootLoaderUpdate")

        #Start the Initalization Thread.
        InitThread()       

    def CreateText(self):
        #Temporary method.
        wx.StaticText(self.InitPanel, -1, "Dependency check... Skipped", pos=(10,20))
        self.DetectPartText = wx.StaticText(self.InitPanel, -1, "Detecting Linux and EFI Partitions...", pos=(10,40))
        self.RootFSText = wx.StaticText(self.InitPanel, -1, "Determining Root Filesystem...", pos=(10,60))
        self.DetectOSesText = wx.StaticText(self.InitPanel, -1, "Detecting Linux OSes...", pos=(10,80))
        self.FWTypeText = wx.StaticText(self.InitPanel, -1, "Determining Firmware Type...", pos=(10,100))
        self.PartSchemeText = wx.StaticText(self.InitPanel, -1, "Determining Partition Scheme...", pos=(10,120))
        self.BootLoaderText = wx.StaticText(self.InitPanel, -1, "Determining Boot Loader...", pos=(10,140))
        wx.StaticText(self.InitPanel, -1, "Checking Filesystems... Skipped", pos=(10,160))
        wx.StaticText(self.InitPanel, -1, "Unmounting Filesystems... Skipped", pos=(10,180))
        wx.StaticText(self.InitPanel, -1, "Final check... Skipped", pos=(10,200))

        #Create a temporary button.
        self.tempbutton = wx.Button(self.InitPanel, -1, "Start", pos=(150,235), size=(100,30))
        self.Bind(wx.EVT_BUTTON, self.FinishedInitConf, self.tempbutton)

    def ShowThreadYesNodlg(self,msg):
        global dlgResult
        dlg = wx.MessageDialog(None, msg.data, 'WxFixBoot - Question', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
        if dlg == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"

    def ShowThreadInfodlg(self,msg):
        global dlgClosed
        dlg = wx.MessageDialog(None, msg.data, "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def UpdateDetectPartText(self,msg):
        self.DetectPartText.SetLabel(msg.data) 

    def UpdateDetectOSesText(self,msg):
        self.DetectOSesText.SetLabel(msg.data) 

    def UpdateRootFSText(self,msg):
        self.RootFSText.SetLabel(msg.data)

    def UpdateFWTypeText(self,msg):
        self.FWTypeText.SetLabel(msg.data)

    def UpdatePartSchemeText(self,msg):
        self.PartSchemeText.SetLabel(msg.data)

    def UpdateBootLoaderText(self,msg):
        self.BootLoaderText.SetLabel(msg.data)

    def FinishedInitConf(self,e):
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        self.Destroy()
        MainFrame.Show(True)    

#End Initalization Frame
#Begin Initaization Thread.
class InitThread(Thread):
    def __init__(self):
        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it.
        if os.path.exists("/tmp/wxfixboot"):
            shutil.rmtree("/tmp/wxfixboot")
        os.mkdir("/tmp/wxfixboot")

        #Initialize and start the thread.
        Thread.__init__(self)
        self.start()

    def run(self):
        #Run some startup scripts.
        #Detect Linux Partitions.
        self.DetectLinuxPartitions()
        InitProgressBar.SetValue(11)
        time.sleep(1)
  
        #Get the root filesystem, if not running from a livecd.
        self.GetRootFS()
        InitProgressBar.SetValue(22)
        time.sleep(1)

        #Get a list of Linux OSes.
        self.GetLinuxOSes()
        InitProgressBar.SetValue(33)
        time.sleep(1)

        #Get the firmware type.
        self.GetFirmwareType()
        InitProgressBar.SetValue(44)
        time.sleep(1)

        #Get the root device's partition scheme (GPT/MBR)
        self.GetRootDevPartScheme()
        InitProgressBar.SetValue(55)
        time.sleep(1)

        #Get the BootLoader.
        self.GetBootLoader()
        InitProgressBar.SetValue(66)
        time.sleep(1)

    def DetectLinuxPartitions(self):
        #Get a list of partitions of type ext (2,3 or 4)
        global LinuxPartList
        LinuxPartList = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'ext'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').replace('\n','').split()
        wx.CallAfter(Publisher().sendMessage, "LinuxPartUpdate", "Detecting Linux and EFI Partitions... Done")


    def GetRootFS(self):
        #Determine RootFS
        #Set some global vars
        global dlgResult
        global dlgClosed
        global RootFS
        global RootDev
        global LiveDisk
        dlgResult = "Unknown"
        dlgClosed = "Unknown"

        wx.CallAfter(Publisher().sendMessage, "showyesnodlg", "Is WxFixBoot being run on a live disk? (***in this experimental version, you must now select no to continue***)")

        #Trap the thread until the user answers.
        while dlgResult == "Unknown":
            time.sleep(0.5)
        
        if dlgResult == "Yes":
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "You would now be asked to select your root device (in a friendly way) from a list showing the operating system on each partition. This isn't done yet, so wxfixboot will now be unceremoniously aborted.")

            wx.Exit() #*******************************************

            #Trap the thread until the diaog is dismissed.
            while dlgClosed == "Unknown":
                time.sleep(0.5)
            
            RootFS = "/dev/sda6" #*********************** ASK HERE IN A DIALOG **************************
            LiveDisk = True
            wx.CallAfter(Publisher().sendMessage, "RootFSUpdate", "Determining Root Filesystem... Skipped")
        else:
            RootFS = subprocess.check_output("df -k / | grep -v 'Filesystem'", shell=True).split()[0]
            RootDev = RootFS[0:8]
            LiveDisk = False
            wx.CallAfter(Publisher().sendMessage, "RootFSUpdate", "Determining Root Filesystem... Success: "+RootFS)

    def GetLinuxOSes(self):
        #Get the names of all Linux OSes on the HDDs.
        global OSList
        OSList = []
        try:
            for element in LinuxPartList:
                if '/dev/'+element == RootFS:
                    #The element is the root partition.
                    #Run the command
                    currentoslist = subprocess.check_output("lsb_release -d", shell=True).split()
                    currentos = ' '.join(currentoslist[1:])
    
                    #Add this information to the OSList
                    OSList.append(currentos+' on device '+RootFS+' (Current)')
                elif element[0:2] == "sd" or element[0:2] == "hd":
                    #We're interested in this element, because it's a HDD or usb disk.
                    #Make a temporary mountpoint in /mnt, to keep out of the way of any OS running.
                    os.makedirs("/mnt/"+element)
    
                    #Mount the device to the mount point.
                    subprocess.Popen("mount /dev/"+element+" /mnt/"+element, shell=True).wait()

                    try:
                        #Run a command in chroot to determine the OS
                        elementoslist = subprocess.check_output("chroot '/mnt/"+element+"' lsb_release -d", shell=True).split()
                        elementos = ' '.join(elementoslist[1:])
                    except:
                        print "No OS here..."
                    else:
                        #Add this information to the OSList
                        OSList.append(elementos+' on device /dev/'+element)
                    finally:
                        #Clean up.
                        #Unmount the filesystem.
                        subprocess.check_output("umount /mnt/"+element, shell=True).wait()

                        #Remove the temporary mountpoint
                        os.rmdir("/mnt/"+element)
    
                    
                else:
                    #We aren't interested, as this is probably a listing for the FS type.
                    pass
        except:
            print "UNHANDLED ERROR. Exiting.."
            wx.Exit()
        wx.CallAfter(Publisher().sendMessage, "LinuxOSesUpdate", "Detecting Linux OSes... Done")

    def GetFirmwareType(self):
        global FWType
        FWDump = subprocess.check_output("dmidecode -q | grep 'UEFI'", shell=True)
        if FWDump == "":
            FWType = "BIOS/CSM"
        else:
            FWType = "EFI/UEFI"
        wx.CallAfter(Publisher().sendMessage, "FWTypeUpdate", "Determining Firmware Type... Success: "+FWType)

    def GetRootDevPartScheme(self):
        global PartScheme
        PartScheme = subprocess.check_output("parted "+RootDev+" print | grep 'Partition Table'", shell=True).split()[2]
        wx.CallAfter(Publisher().sendMessage, "PartSchemeUpdate", "Determining Partition Scheme... Success: "+PartScheme)

    def GetBootLoader(self):
        global BootLoader
        global EFISYSP
        #Determine the current bootloader. 
        #Run some inital scripts
        subprocess.check_call("dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect", shell=True)

        #Wrap this in a loop, so once a BootLoader is found, searching can stop.
        while True:
            #Check for BIOS/CSM bootloaders here.
            #Check for GRUB in the MBR
            BootLoader = self.CheckForGRUBMBR()
            if BootLoader == "GRUB(BIOS/CSM)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Check for LILO in MBR
            BootLoader = self.CheckForLILOMBR()
            if BootLoader == "LILO(BIOS/CSM)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Check for an EFI system partition.
            EFISYSP = self.CheckForEFIPartition()
            if EFISYSP[0:7] != "/dev/sd" and EFISYSP[0:7] != "/dev/hd":
                #There is no EFI partition.
                wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Boot Loader autodetection failed, no EFI partition was found. So you'd be asked to enter your bootloader from a list here now.")
                break

            #Mount (or check if mounted) the EFI partition.
            EFISYSPMountPoint = self.CheckandMountEFIPartition(EFISYSP)
            print EFISYSPMountPoint

            #Attempt to figure out which bootloader is present.
            #Check for GRUB-EFI
            BootLoader = self.CheckForGRUBEFI(EFISYSPMountPoint)
            if BootLoader == "GRUB(EFI/UEFI)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Check for ELILO
            BootLoader = self.CheckForLILOEFI(EFISYSPMountPoint)
            if BootLoader == "LILO(EFI/UEFI)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Obviously, no bootloader has been found.
            #Give up.
            BootLoader = "-- Please Select --"
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Boot Loader autodetection failed, so you'd be asked to enter your bootloader from a list here now.")
            break

    def CheckForGRUBMBR(self):
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'GRUB'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            temp = "NULL"

        print temp # ***
        if temp == "Binary file (standard input) matches":
            #BootLoader is GRUB MBR
            return "GRUB(BIOS/CSM)"
        else:
            return "Not GRUB MBR"

    def CheckForLILOMBR(self):
        #Check for LILO in MBR
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'LILO'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            temp = "NULL"

        if temp == "Binary file (standard input) matches":
            #BootLoader is LILO in MBR
            return "LILO(BIOS/CSM)"
        else:
            return "Not LILO MBR"

    def CheckForEFIPartition(self):
        if LiveDisk == False:
            try:
                EFISYSP = "/dev/"+subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep '/boot'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
            except subprocess.CalledProcessError:
                try:
                    print "s"
                    #Try a second way to get the EFI system partition.
                    EFISYSP = subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep 'ESP'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
                    print EFISYSP
                except:
                    print "except..."
                    return "Not Found"
            finally:
                print EFISYSP
                return EFISYSP
            
        else:
             pass # ********************************** Possibly mount all FS before if on live disk. ***************************

    def CheckandMountEFIPartition(self,EFISYSP): 
        global ManuallyMounted
        #Get the EFI partition's current mountpoint, if it is mounted.
        try:
            EFISYSPMountPoint = subprocess.check_output("df | grep '"+EFISYSP+"'", shell=True).split()[-1]
        except subprocess.CalledProcessError:
            #It isn't mounted, mount it.
            EFISYSPMountPoint = "/tmp/wxfixboot/mountpoint1"
            os.mkdir(MountPoint)
            subprocess.check_call(['mount', EFISYSP, MountPoint])
            ManuallyMounted = True
            print "sucess"
        else:
            #It's mounted, so nevermind.
            ManuallyMounted = False
            print ManuallyMounted
        finally:
            print EFISYSPMountPoint
            return EFISYSPMountPoint

    def CheckForGRUBEFI(self,EFISYSPMountPoint):
        global ManuallyMounted
        temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*grub*'", shell=True).replace('\n', '')
        print temp

        #Look for GRUB-EFI.
        if temp != "":
            print "GRuB-EFI"
            #Bootloader is GRUB-EFI.
            if ManuallyMounted == True:
                subprocess.call(['umount', EFISYSP])
                ManuallyMounted = None
            BootLoader = "GRUB(EFI/UEFI)"
        else:
            BootLoader = "Not GRUB-EFI"

        return BootLoader

    def CheckForLILOEFI(self,EFISYSPMountPoint):
        temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*elilo*'", shell=True).replace('\n', '')
        print temp

        #Look for ELILO.
        if temp != "":
            #Bootloader is ELILO.
            if ManuallyMounted == True:
                subprocess.call(['umount', EFISYSP])
                ManuallyMounted = None
            BootLoader = "LILO(EFI/UEFI)"
        else:
            BootLoader = "Not ELILO"

        return BootLoader
                    
#End Initalization Thread.
#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc1 (25/2/14)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        GetDevInfo()

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Bind all events.
        self.BindEvents() 

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        
    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text
        welcometext = wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(125,15))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(120,220))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply Quick Operations + Operations set in options dialog", pos=(20,180))

    def CreateCBs(self):
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall Bootloader", (10,100), (170,20))
        self.updteblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Bootloader", (10,130), (150,20))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", (10,70), (240,20))
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorugh)", (10,40), (250,20))

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_ANY, "&Options", "General settings used during the fix")

        #Creating the menubar.
        self.menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        self.menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        self.menuBar.Append(editmenu,"&Edit") # Adding the "editmenu" to the MenuBar
        self.menuBar.Append(viewmenu,"&View") # Adding the "viewmenu" to the MenuBar
        self.menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar 

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(self.menuBar)

    def Opts(self,e):
        OptionsWindow1().Show()

    def DevInfo(self,e): 
        # Use a seperate bash script and zenity for this dialog
        DevInfoDlg = DevInfoWindow().Show()

    def OnAbout(self,e):
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot Experimental"
        aboutbox.Version = "1.0~rc1"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = wordwrap(
"Utility to quickly fix the bootloader on a computer",250,wx.ClientDC(self.MainPanel))
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.License = wordwrap("WxFixBoot is released under the GNU GPL v3",500,wx.ClientDC(self.MainPanel))
        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def OnExit(self,e):
        #Shut down.
        self.Close(True)

#End Main window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):

    title = "WxFixBoot - Options" 

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)

        self.CreateButtons()
        self.CreateText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.SetDefaults()
        self.BindEvents()

    def CreateButtons(self):
        self.SaveSettings = wx.Button(self.OptsPanel1, -1, "Apply these Settings", pos=(10,320))
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Close", pos=(500,320))
        self.fwOptsButton = wx.Button(self.OptsPanel1, -1, "View Firmware settings", pos=(310,80), size=(250,30))

    def CreateText(self):
        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Changing the advanced settings is not recommended.", (50,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", (10,50))
        wx.StaticText(self.OptsPanel1, -1, "Installed BootLoader:", (10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", (10,110))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader timeout value:", (10,260))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", (10,280)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", (310,50))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", (310,130))

    def CreateCBs(self):
        #Basic settings
        self.showprogresscb = wx.CheckBox(self.OptsPanel1, -1, "Show Progress during operations", pos=(10,140), size=(300,20))
        self.warnusbcb = wx.CheckBox(self.OptsPanel1, -1, "Warn about disconnecting usb devices", pos=(10,170), size=(305,20))
        self.warnprogscb = wx.CheckBox(self.OptsPanel1, -1, "Warn to close all other programs", pos=(10,200), size=(295,20))
        self.createlogcb = wx.CheckBox(self.OptsPanel1, -1, "Create a logfile containing all output", pos=(10,230), size=(295,20))

        #Advanced settings
        self.chkfscb = wx.CheckBox(self.OptsPanel1, -1, "Quickly check Filesystems on startup", pos=(310,160), size=(315,20))
        self.remntfscb = wx.CheckBox(self.OptsPanel1, -1, "Mount all Filesystems as read-only", pos=(310,190), size=(315,20))
        self.bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector", pos=(310,220), size=(250,20))
        self.bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table", pos=(310,250), size=(290,20))
        self.chrootcb = wx.CheckBox(self.OptsPanel1, -1, "Use chroot to reinstall bootloader", pos=(310,280), size=(315,20))       

    def CreateChoiceBs(self):
        #Basic settings
        instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+BootLoader, 'GRUB', 'GRUB-EFI', 'LILO', 'ELILO'])
        defaultoschoice = wx.Choice(self.OptsPanel1, -1, pos=(150,103), size=(140,30), choices=OSList)

        #Advanced settings
        rootdevchoice = wx.Choice(self.OptsPanel1, -1, (440,123), choices=["Auto: "+RootFS, 'Ask me', '/dev/sda', '/dev/sdb', 'etc...'])

    def CreateSpinners(self):
        self.bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", (190,257))
        self.bltimeoutspin.SetRange(-1,100)
        self.bltimeoutspin.SetValue(-1)

    def SetDefaults(self):
        #Set Basic settings.
        self.showprogresscb.SetValue(1)
        self.warnusbcb.SetValue(1)
        self.warnprogscb.SetValue(1)
        self.createlogcb.SetValue(1)

        #Set advanced settings.
        self.chkfscb.SetValue(1)
        self.remntfscb.SetValue(0)
        self.bkpbootsectcb.SetValue(1)
        self.bkpparttablecb.SetValue(0)
        self.chrootcb.SetValue(1)

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchfwOpts, self.fwOptsButton)

    def LaunchfwOpts(self,e):
        OptionsWindow2().Show()

    def CloseOpts(self,e):
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):

    title = "WxFixBoot - Firmware Settings"

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(310,270))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace UEFI bootloader with BIOS version", pos=(10,160), size=(290,20))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace BIOS bootloader with UEFI version", pos=(10,190), size=(290,20))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Modify bootloader type based on detected Firmware type", pos=(10,220), size=(375,20))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not change the bootloader's firmware type", pos=(10,250), size=(330,20))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Reinstall BootLoader in:", pos=(130,50))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System:", pos=(130,85))
        wx.StaticText(self.OptsPanel2, -1, "BootLoader to install:", pos=(130,120))
 
    def CreateRadios(self):
        #Have a system to determine which options to enable based on whether fwtyperadioauto is 'Auto (BIOS)' or 'Auto (UEFI)' ***
        self.fwtyperadioauto = wx.RadioButton(self.OptsPanel2, -1, "Auto: "+FWType, pos=(7,50), style=wx.RB_GROUP)
        self.fwtyperadioEFI = wx.RadioButton(self.OptsPanel2, -1, "EFI/UEFI", pos=(7,80))
        self.fwtyperadioBIOS = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(7,110))

    def CreateChoiceBs(self):
        self.instbldestchoice = wx.Choice(self.OptsPanel2, -1, pos=(275,44), choices=['Ask me', 'Root Device: '+RootDev, '/dev/sda', '/dev/sdb', 'etc...'])
        self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(275,79), choices=['Auto: '+PartScheme, 'MBR(msdos)', 'GPT'])
        self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(275,114), choices=['Current', 'Ask me', 'GRUB', 'LILO'])

    def SetDefaults(self):
        self.UEFItoBIOScb.Disable()
        self.BIOStoUEFIcb.Disable()
        self.useAutocb.Disable()
        self.useAutocb.SetValue(False)
        self.unchangedcb.SetValue(True)
        self.fwtyperadioauto.SetValue(True)
        self.fwtyperadioEFI.SetValue(False)
        self.fwtyperadioBIOS.SetValue(False)
        self.instbldestchoice.SetSelection(0)
        self.partitiontypechoice.SetSelection(0)

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.OnClose, self.exitbutton)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOptsforNoModification, self.unchangedcb)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforAutoFW, self.fwtyperadioauto)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforEFIFW, self.fwtyperadioEFI)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforBIOSFW, self.fwtyperadioBIOS)

    def ActivateOptsforAutoFW(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()
        self.partitiontypechoice.SetSelection(0)

    def ActivateOptsforEFIFW(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.UEFItoBIOScb.Enable()
        self.partitiontypechoice.SetSelection(2)

    def ActivateOptsforBIOSFW(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.UEFItoBIOScb.Disable()
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Enable()
        self.partitiontypechoice.SetSelection(1)

    def ActivateOptsforNoModification(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked():
            self.UEFItoBIOScb.Disable()
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
        else:
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")

    def OnClose(self,e):
        self.Destroy()

#Begin Device Info Window
class DevInfoWindow(wx.Frame):

    title = "WxFixBoot - Device Information"

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", (30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(330,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(60,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)

    def UpdDevInfo(self,e):
        #Generate device data.
        devicelist = GetDevInfo()

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        self.Destroy()

#End Device Info Window
app = MyApp(False)
app.MainLoop()
