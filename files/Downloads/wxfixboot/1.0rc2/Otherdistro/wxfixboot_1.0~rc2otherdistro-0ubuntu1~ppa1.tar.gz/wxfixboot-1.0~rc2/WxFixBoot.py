#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 1.0rc2
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
import wx
import sys
from wx.lib.wordwrap import wordwrap
from wx.lib.pubsub import Publisher
from threading import Thread
import time
import os
import shutil
import subprocess

#If this isn't running as root, exit immediately
if not os.geteuid()==0:
    sys.exit("\nSorry, this program must be run with root privileges.\nWill now exit")

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen(["/usr/share/wxfixboot/listdevices.sh"]).wait()

    #Create/Update a list
    devicelist = []

    #New more efficent way of putting everything in one list.
    with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
        idedevicesfile = idedevicessource.readlines()
        if idedevicesfile != []:
            devicelist = devicelist + idedevicesfile
            devicelist.append('IDE/ATA Devices:')

    with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
        cddvddevicesfile = cddvddevicessource.readlines()
        if cddvddevicesfile != []:
            devicelist.append('CD/DVD Devices:')
            devicelist = devicelist + cddvddevicesfile

    with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
        usbsatadevicesfile = usbsatadevicessource.readlines()
        if usbsatadevicesfile != []:
            devicelist.append('USB or SATA Devices:')
            devicelist = devicelist + usbsatadevicesfile

    #Remove newline chars.
    return [(el.strip()) for el in devicelist]

def GetPBlockSize(device):
    #Run a quick script to retrive the block size of the given device.
    global RootFSBSZ
    RootFSBSZ = subprocess.check_output(["blockdev", "--getss", device])

#Starter Class
class MyApp(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = "/usr/share/wxfixboot/splash.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

        #Make sure it's painted, which fixes the problem with the previous temperamental splash screen on DDRescue-GUI <= 1.2
        wx.Yield()

    def OnExit(self,e):
        #Start the init Frame.
        self.Hide()
        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True
            InitFrame = InitialWindow()
            app.SetTopWindow(InitFrame)
            InitFrame.Show(True)
            #Skip the event so the init frame starts.
            e.Skip()

#End splash screen
#Begin Initialization frame
class InitialWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc1 is preparing to start...",size=(400,300),style=wx.CAPTION)
        self.InitPanel = wx.Panel(self)

        print "WxFixBoot Version 1.0~rc2 unstable Starting..."
        print "None of the options are yet operational, and debugging output is also included to show where anything may've gone wrong."
        print "Do not use this on ANY production machine!"

        wx.MessageDialog(None, "Do NOT use this development version on ANY production machine! It is highly untested, and is only suitable for testing in VMs, as it can potentially destroy data. If you're running this on a production machine, please now kill this process in a task manager!", "WxFixBoot - WARNING", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()

        self.CreateText()

        #Create a progressbar.
        global InitProgressBar
        InitProgressBar = wx.Gauge(self.InitPanel, -1, 100, (10,270), (380,25))
        InitProgressBar.SetBezelFace(3)
        InitProgressBar.SetShadowWidth(3)
        InitProgressBar.SetValue(0)
        InitProgressBar.Show()

        #Set up threading
        #Respond to dialog messages.
        Publisher().subscribe(self.ShowThreadYesNodlg, "showyesnodlg")
        Publisher().subscribe(self.ShowThreadInfodlg, "showinfodlg")
        Publisher().subscribe(self.ShowThreadChoicedlg, "showchoicedlg")

        #Update the text on the main GUI when asked.
        Publisher().subscribe(self.UpdateDependsCheckText, "DependsUpdate")
        Publisher().subscribe(self.UpdateMountFSText, "MountFSUpdate")
        Publisher().subscribe(self.UpdateDetectPartText, "LinuxPartUpdate")
        Publisher().subscribe(self.UpdateDetectOSesText, "LinuxOSesUpdate")
        Publisher().subscribe(self.UpdateRootFSText, "RootFSUpdate")
        Publisher().subscribe(self.UpdateFWTypeText, "FWTypeUpdate")
        Publisher().subscribe(self.UpdatePartSchemeText, "PartSchemeUpdate")
        Publisher().subscribe(self.UpdateBootLoaderText, "BootLoaderUpdate")
        Publisher().subscribe(self.UpdateUnmountFSText, "UnmountFSUpdate")
        Publisher().subscribe(self.UpdateCheckFSText, "CheckFSUpdate")
        Publisher().subscribe(self.UpdateFinalCheckText, "FinalCheckUpdate")

        #Start the Initalization Thread.
        InitThread()       

    def CreateText(self):
        #Temporary method.
        self.DependsCheckText = wx.StaticText(self.InitPanel, -1, "Dependency check...", pos=(10,20))
        self.MountFSText = wx.StaticText(self.InitPanel, -1, "Mounting all Filesystems...", pos=(10,40))
        self.DetectPartText = wx.StaticText(self.InitPanel, -1, "Detecting Linux Partitions...", pos=(10,60))
        self.RootFSText = wx.StaticText(self.InitPanel, -1, "Determining Root Filesystem...", pos=(10,80))
        self.DetectOSesText = wx.StaticText(self.InitPanel, -1, "Detecting Linux OSes...", pos=(10,100))
        self.FWTypeText = wx.StaticText(self.InitPanel, -1, "Determining Firmware Type...", pos=(10,120))
        self.PartSchemeText = wx.StaticText(self.InitPanel, -1, "Determining Partition Scheme...", pos=(10,140))
        self.BootLoaderText = wx.StaticText(self.InitPanel, -1, "Determining Boot Loader...", pos=(10,160))
        self.UnmountFSText = wx.StaticText(self.InitPanel, -1, "Unmounting Filesystems...", pos=(10,180))
        self.CheckFSText = wx.StaticText(self.InitPanel, -1, "Checking Filesystems...", pos=(10,200))
        self.FinalCheckText= wx.StaticText(self.InitPanel, -1, "Final check...", pos=(10,220))

        #Create a temporary button.
        self.tempbutton = wx.Button(self.InitPanel, -1, "Start", pos=(150,235), size=(100,30))
        self.Bind(wx.EVT_BUTTON, self.FinishedInitConf, self.tempbutton)

    def ShowThreadYesNodlg(self,msg):
        global dlgResult
        dlg = wx.MessageDialog(None, msg.data, 'WxFixBoot - Question', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
        if dlg == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"

    def ShowThreadInfodlg(self,msg):
        global dlgClosed
        dlg = wx.MessageDialog(None, msg.data, "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadChoicedlg(self,msg):
        #************************ This needs a system to check the user has selected a proper device, probably a while loop *************
        global dlgResult
        data = msg.data.split('arg')
        dlg = wx.SingleChoiceDialog(None, data[0], data[1], data[2:], pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."

    def UpdateDependsCheckText(self,msg):
        self.DependsCheckText.SetLabel(msg.data)

    def UpdateMountFSText(self,msg):
        self.MountFSText.SetLabel(msg.data)

    def UpdateDetectPartText(self,msg):
        self.DetectPartText.SetLabel(msg.data) 

    def UpdateDetectOSesText(self,msg):
        self.DetectOSesText.SetLabel(msg.data) 

    def UpdateRootFSText(self,msg):
        self.RootFSText.SetLabel(msg.data)

    def UpdateFWTypeText(self,msg):
        self.FWTypeText.SetLabel(msg.data)

    def UpdatePartSchemeText(self,msg):
        self.PartSchemeText.SetLabel(msg.data)

    def UpdateBootLoaderText(self,msg):
        self.BootLoaderText.SetLabel(msg.data)

    def UpdateUnmountFSText(self,msg):
        self.UnmountFSText.SetLabel(msg.data)

    def UpdateCheckFSText(self,msg):
        self.CheckFSText.SetLabel(msg.data)

    def UpdateFinalCheckText(self,msg):
        self.FinalCheckText.SetLabel(msg.data)

    def FinishedInitConf(self,e):
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        self.Destroy()
        MainFrame.Show(True)    

#End Initalization Frame
#Begin Initaization Thread.
class InitThread(Thread):
    def __init__(self):
        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it.
        #However, only delete it if no partitions are mounted in it. Otherwise exit.
        try:
            subprocess.check_output("mount | grep '/tmp/wxfixboot'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            if os.path.exists("/tmp/wxfixboot"):
                shutil.rmtree("/tmp/wxfixboot")
            os.mkdir("/tmp/wxfixboot")
        else:
            wx.Exit()
            sys.exit("ERROR! Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage.")

        #Initialize and start the thread.
        Thread.__init__(self)
        self.start()

    def run(self):
        #Run some startup scripts.
        GetDevInfo()

        #wait for GUI to initialize.
        time.sleep(1)

        #Check for dependencies
        self.CheckDepends()
        InitProgressBar.SetValue(10)
        time.sleep(0.5)

        #Mount all filesystems.
        self.MountAllFS()
        InitProgressBar.SetValue(20)
        time.sleep(0.5)

        #Detect Linux Partitions.
        self.DetectLinuxPartitions()
        InitProgressBar.SetValue(30)
        time.sleep(0.5)
  
        #Get the root filesystem.
        self.GetRootFS()
        InitProgressBar.SetValue(40)
        time.sleep(0.5)

        #Get a list of Linux OSes (if LiveDisk = True, this has already been run).
        if LiveDisk == False:
            self.GetLinuxOSes()
        InitProgressBar.SetValue(50)
        time.sleep(0.5)

        #Get the firmware type.
        self.GetFirmwareType()
        InitProgressBar.SetValue(60)
        time.sleep(0.5)

        #Get the root device's partition scheme (GPT/MBR)
        self.GetRootDevPartScheme()
        InitProgressBar.SetValue(70)
        time.sleep(0.5)

        #Get the BootLoader.
        self.GetBootLoader()
        InitProgressBar.SetValue(80)
        time.sleep(0.5)

        #Attempt unmount of all filesystems.
        self.UnmountAllFS()
        InitProgressBar.SetValue(90)
        time.sleep(0.5)

        #Check filesystems.
        self.CheckFS()
        InitProgressBar.SetValue(100)
        time.sleep(0.5)

        #Perform final check.
        self.FinalCheck()
        time.sleep(2)

    def CheckDepends(self):
        #This is a dependency checking function, will will show a message and kill the app if the dependencies are not met.
        try:
            #Check for all dependencies.
            subprocess.check_output(['mount', '-V'])
            subprocess.check_output(['umount', '-V'])
            subprocess.check_output(['parted' ,'-v'])
            subprocess.check_output(['lsb_release'])
            subprocess.check_output(['dmidecode', '-V'])
            subprocess.check_output(['parted' ,'-v'])
            subprocess.check_output(['grep', '-V'])
            subprocess.check_output(['lsblk'])
            subprocess.check_output(['df'])
            subprocess.check_output(['chroot', '--version'])
            subprocess.check_output(['dd', '--version'])
            subprocess.check_output(['find', '--version'])
        except subprocess.CalledProcessError:
            #Missing dependencies
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "One or more required dependencies were not found! Please check that you've satified all the dependencies and try again.")
            raise
            wx.Exit()
            sys.exit("Missing dependencies! Exiting...")
        else:
            wx.CallAfter(Publisher().sendMessage, "DependsUpdate", "Dependency check... Passed!")

    def MountAllFS(self):
        global dlgClosed
        dlgClosed = "Unknown"

        #Warn about removing devices.
        wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Please now remove all unnecessary devices connected to your computer, and then click okay.")

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

        #Mount everything in /etc/fstab
        subprocess.check_output(['mount', '-a'])

        wx.CallAfter(Publisher().sendMessage, "MountFSUpdate", "Mounting all Filesystems... Done")

    def DetectLinuxPartitions(self):
        #Get a list of partitions of type ext (2,3 or 4)
        global LinuxPartList
        LinuxPartList = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'ext'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').replace('\n','').split()
        wx.CallAfter(Publisher().sendMessage, "LinuxPartUpdate", "Detecting Linux Partitions... Done")

    def GetRootFS(self):
        #Determine RootFS
        #Set some global vars
        global dlgResult
        global dlgClosed
        global RootFS
        global RootDev
        global LiveDisk
        dlgResult = "Unknown"
        dlgClosed = "Unknown"

        wx.CallAfter(Publisher().sendMessage, "showyesnodlg", "Is WxFixBoot being run on a live disk?")

        #Trap the thread until the user answers.
        while dlgResult == "Unknown":
            time.sleep(0.5)
        
        if dlgResult == "Yes":
            LiveDisk = True
            dlgResult = "Unknown"

            #Make an early call to GetLinuxOSes()
            self.GetLinuxOSes()

            #Create a temporary list from OSList
            templist = []
            for element in OSList:
                templist.append("arg"+element)

            #'arg' seperates elements in a list that will be created in the display method.
            wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "Please select the Linux Operating System you normally boot.argWxFixBoot - Select Operating System"+' '.join(templist))

            #Trap the thread until the diaog is dismissed.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            if dlgResult == "Clicked no..." or dlgResult == "":
                wx.Exit()
                sys.exit("No RootFS selected. Exiting...")
            else:
                RootFS = dlgResult.split()[-1]
                RootDev = RootFS[0:8]
                LiveDisk = True
                wx.CallAfter(Publisher().sendMessage, "RootFSUpdate", "Determining Root Filesystem... Success: "+RootFS)
        else:
            RootFS = subprocess.check_output("df -k / | grep -v 'Filesystem'", shell=True).split()[0]
            RootDev = RootFS[0:8]
            LiveDisk = False
            wx.CallAfter(Publisher().sendMessage, "RootFSUpdate", "Determining Root Filesystem... Success: "+RootFS)

    def GetLinuxOSes(self):
        #Get the names of all Linux OSes on the HDDs.
        global OSList
        OSList = []
        try:
            for element in LinuxPartList:
                #Reset the Skip value to False.
                Skip = False

                if LiveDisk == False:
                    #Only check if a partition equals the root partiton if not running from a live disk.
                    if '/dev/'+element == RootFS:
                        #The element is the root partition, tell the next if loop to not run.
                        Skip = True
                        try:
                            #Run the command to get the OS.
                            currentoslist = subprocess.check_output("lsb_release -d", shell=True).split()
                            currentos = ' '.join(currentoslist[1:])
                        except:
                            pass
                        else:
                            #Add this information to the OSList
                            OSList.append(currentos+' (Current) on device '+RootFS)

                if element[0:2] == "sd" or element[0:2] == "hd":
                    #We're interested in this element, because it's a HDD or usb disk.
                    #Go back to the start if this has already ben determined as RootFS
                    if Skip == True:
                        continue

                    #Make a temporary mountpoint in /mnt, to keep out of the way of any OS running.
                    os.makedirs("/mnt/"+element)
    
                    #Mount the device to the mount point.
                    subprocess.Popen("mount /dev/"+element+" /mnt/"+element, shell=True).wait()

                    try:
                        #Run a command in chroot to determine the OS
                        elementoslist = subprocess.check_output("chroot '/mnt/"+element+"' lsb_release -d", shell=True).split()
                        elementos = ' '.join(elementoslist[1:])
                    except:
                        pass
                    else:
                        #Add this information to the OSList
                        OSList.append(elementos+' on device /dev/'+element)
                    finally:
                        #Clean up.
                        Skip = None

                        #Unmount the filesystem.
                        subprocess.check_output("umount /mnt/"+element, shell=True)

                        #Remove the temporary mountpoint
                        os.rmdir("/mnt/"+element)     
                else:
                    #We aren't interested, as this is probably a listing for the FS type.
                    pass
        except:
            print "UNHANDLED ERROR. Exiting.."
            raise
            wx.Exit()
        wx.CallAfter(Publisher().sendMessage, "LinuxOSesUpdate", "Detecting Linux OSes... Done")

    def GetFirmwareType(self):
        global FWType
        try:
            subprocess.check_output("dmidecode -q | grep 'UEFI'", shell=True)
        except subprocess.CalledProcessError:
            FWType = "BIOS/CSM"
        else:
            FWType = "EFI/UEFI"
        wx.CallAfter(Publisher().sendMessage, "FWTypeUpdate", "Determining Firmware Type... Success: "+FWType)

    def GetRootDevPartScheme(self):
        global PartScheme
        PartScheme = subprocess.check_output("parted "+RootDev+" print | grep 'Partition Table'", shell=True).split()[2]
        wx.CallAfter(Publisher().sendMessage, "PartSchemeUpdate", "Determining Partition Scheme... Success: "+PartScheme)

    def GetBootLoader(self):
        global dlgResult
        global BootLoader
        global EFISYSP
        #Determine the current bootloader. 
        #Run some inital scripts
        subprocess.check_call("dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect", shell=True)

        #Wrap this in a loop, so once a BootLoader is found, searching can stop.
        while True:
            #Check for BIOS/CSM bootloaders here.
            #Check for GRUB in the MBR
            BootLoader = self.CheckForGRUBMBR()
            if BootLoader == "GRUB(BIOS/CSM)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Check for LILO in MBR
            BootLoader = self.CheckForLILOMBR()
            if BootLoader == "LILO(BIOS/CSM)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Check for an EFI system partition.
            EFISYSP = self.CheckForEFIPartition()
            if EFISYSP[0:7] != "/dev/sd" and EFISYSP[0:7] != "/dev/hd":
                #There is no EFI partition.
                #Do a manual selection of bootloader.
                BootLoader = self.ManualBootLoaderSelect()

                #The program exits if nothing was chosen, so if it executes this, the bootloader has been set.
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Mount (or check if mounted) the EFI partition.
            EFISYSPMountPoint = self.CheckandMountEFIPartition(EFISYSP)
            print EFISYSPMountPoint

            #Attempt to figure out which bootloader is present.
            #Check for GRUB-EFI
            BootLoader = self.CheckForGRUBEFI(EFISYSPMountPoint)
            if BootLoader == "GRUB(EFI/UEFI)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Check for ELILO
            BootLoader = self.CheckForLILOEFI(EFISYSPMountPoint)
            if BootLoader == "ELILO(EFI/UEFI)":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
                break

            #Obviously, no bootloader has been found.
            #Do a manual selection.
            BootLoader = self.ManualBootLoaderSelect()

            #The program exits if nothing was chosen, so if it executes this, the bootloader has been set.
            wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+BootLoader)
            break

    def CheckForGRUBMBR(self):
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'GRUB'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            temp = "NULL"

        print temp # ***
        if temp == "Binary file (standard input) matches":
            #BootLoader is GRUB MBR
            return "GRUB(BIOS/CSM)"
        else:
            return "Not GRUB MBR"

    def CheckForLILOMBR(self):
        #Check for LILO in MBR
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'LILO'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            temp = "NULL"

        if temp == "Binary file (standard input) matches":
            #BootLoader is LILO in MBR
            return "LILO(BIOS/CSM)"
        else:
            return "Not LILO MBR"

    def CheckForEFIPartition(self):
        global dlgResult
        dlgResult = "Unknown"
        if LiveDisk == False:
            try:
                EFISYSP = "/dev/"+subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep '/boot'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
            except subprocess.CalledProcessError:
                try:
                    print "s"
                    #Try a second way to get the EFI system partition.
                    EFISYSP = subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep 'ESP'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
                    print EFISYSP
                except subprocess.CalledProcessError:
                    print "except..."
                    return "Not Found"
            finally:
                print EFISYSP
                return EFISYSP
        else:
            #Get a list of partitions of type vfat
            templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'vfat'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').replace('\n','').split()

            #Create another list.
            templist2 = []
            for element in templist:
                if element[0:2] == "sd" or element[0:2] == "hd":
                    templist2.append("arg/dev/"+element)
                else:
                    #We aren't interested, as this is probably a listing for the FS type.
                    pass

            if templist2 != []:
                #'arg' seperates elements in a list that will be created in the display method.
                wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "Please select your EFI partition. Click no if you don't have an EFI partition.argWxFixBoot - Select EFI Partition"+' '.join(templist2))
                #Trap the thread until the diaog is dismissed.
                while dlgResult == "Unknown":
                    time.sleep(0.5)

                if dlgResult == "Clicked no...":
                    return "No EFI partition..."
                else:
                    return dlgResult
                    
    def CheckandMountEFIPartition(self,EFISYSP): 
        global ManuallyMounted
        #Get the EFI partition's current mountpoint, if it is mounted.
        try:
            EFISYSPMountPoint = subprocess.check_output("df | grep '"+EFISYSP+"'", shell=True).split()[-1]
        except subprocess.CalledProcessError:
            #It isn't mounted, mount it.
            EFISYSPMountPoint = "/tmp/wxfixboot/mountpoint1"
            os.mkdir(MountPoint)
            subprocess.check_call(['mount', EFISYSP, MountPoint])
            ManuallyMounted = True
            print "success"
        else:
            #It's mounted, so nevermind.
            ManuallyMounted = False
            print ManuallyMounted
        finally:
            print EFISYSPMountPoint
            return EFISYSPMountPoint

    def CheckForGRUBEFI(self,EFISYSPMountPoint):
        global ManuallyMounted
        temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*grub*'", shell=True).replace('\n', '')
        print temp

        #Look for GRUB-EFI.
        if temp != "":
            print "GRUB-EFI"
            #Bootloader is GRUB-EFI.
            if ManuallyMounted == True:
                subprocess.call(['umount', EFISYSP])
                ManuallyMounted = None
            BootLoader = "GRUB(EFI/UEFI)"
        else:
            BootLoader = "Not GRUB-EFI"

        return BootLoader

    def CheckForLILOEFI(self,EFISYSPMountPoint):
        temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*elilo*'", shell=True).replace('\n', '')
        print temp

        #Look for ELILO.
        if temp != "":
            #Bootloader is ELILO.
            if ManuallyMounted == True:
                subprocess.call(['umount', EFISYSP])
                ManuallyMounted = None
            BootLoader = "ELILO(EFI/UEFI)"
        else:
            BootLoader = "Not ELILO"

        return BootLoader

    def ManualBootLoaderSelect(self):
        global dlgResult
        dlgResult = "Unknown"
        wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.argWxFixBoot - Select BootloaderargGRUB(BIOS/CSM)argGRUB(EFI/UEFI)argLILO(BIOS/CSM)argELILO(EFI/UEFI)")

        #Trap the thread until the user answers.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        if dlgResult == "Clicked no...":
            #Quit.
            wx.Exit()
            sys.exit("No bootloader found...")
        else:
            print "Success!"
            return dlgResult

    def UnmountAllFS(self):
        #Attempt unmount of all filesystems, ignoring failed unmounts.
        try:
            subprocess.check_output(['umount', '-ad'])
        except subprocess.CalledProcessError:
            pass
        finally:
            wx.CallAfter(Publisher().sendMessage, "UnmountFSUpdate", "Unmounting Filesystems... Success")

    def CheckFS(self):
        #Check all non-mounted filesystems.
        subprocess.check_output(['fsck', '-AR'])
        wx.CallAfter(Publisher().sendMessage, "CheckFSUpdate", "Checking Filesystems... Success")

    def FinalCheck(self):
        #Check for any conflicting options, and that each variable is set.
        global dlgClosed
        global RootFS
        global LiveDisk
        global OSList
        global FWType
        global PartScheme
        global EFISYSP
        global BootLoader
        
        #Check each variable is set.
        try:
            temp = RootFS
            temp = LiveDisk
            temp = OSList
            temp = FWType
            temp = PartScheme
            temp = EFISYSP
            temp = BootLoader
        except NameError:
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "One or more required settings have not been set! WxFixBoot will now shut down to prevent damage to your system.")
            raise
            wx.Exit()
            sys.exit("Incorrectly set settings! Exiting...")

        #Check and warn about conflicting settings.
        #Firmware type warnings.
        if FWType == "BIOS/CSM" and (BootLoader == "GRUB(EFI/UEFI)" or BootLoader == "ELILO(EFI/UEFI)"):
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your computer uses BIOS firmware (or is booted in CSM mode), but you're using an EFI-enabled bootloader! BIOS firmware does not support booting EFI-enabled bootloaders, so it is recommended to install a BIOS-enabled legacy bootloader instead. If you're booting using CSM mode, you can safely ignore this message.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)

            dlgClosed == "Unknown"
        if FWType == "BIOS/CSM" and PartScheme == "gpt":
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your computer uses BIOS firmware (or is booted in CSM mode), but you're using a gpt(GUID)-style partition scheme on your root device! BIOS firmware will likely fail to boot your operating system, so a repartition may be necessary. If you're booting in CSM mode, you can safely ignore this message.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)

            dlgClosed == "Unknown"
        #Partition scheme warnings.
        if PartScheme == "msdos" and (BootLoader == "GRUB(EFI/UEFI)" or BootLoader == "ELILO(EFI/UEFI)"):
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your partition type on your root device is msdos(MBR), but you're using an EFI-enabled bootloader! Some firmware may not support this setup, so it is recommended to install a BIOS-enabled legacy bootloader instead.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)
        elif PartScheme == "gpt" and (BootLoader == "GRUB(BIOS/CSM)" or BootLoader == "LILO(BIOS/CSM)"):
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your partition type on your root device is gpt(GUID), but you're using an BIOS-enabled bootloader! Almost all firmware won't support this setup, so it is advised to install a EFI-enabled bootloader instead.")

        #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)

        wx.CallAfter(Publisher().sendMessage, "FinalCheckUpdate", "Final check... All Okay!")        

#End Initalization Thread.
#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc2 (7/3/14)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Bind all events.
        self.BindEvents() 

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        
    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text
        welcometext = wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(125,15))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(120,220))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply All Operations", pos=(125,180))

    def CreateCBs(self):
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall Bootloader", pos=(10,100))
        self.updteblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Bootloader", pos=(10,130))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", pos=(10,70))
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorugh)", pos=(10,40))

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_ANY, "&Options", "General settings used during the fix")

        #Creating the menubar.
        self.menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        self.menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        self.menuBar.Append(editmenu,"&Edit") # Adding the "editmenu" to the MenuBar
        self.menuBar.Append(viewmenu,"&View") # Adding the "viewmenu" to the MenuBar
        self.menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar 

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(self.menuBar)

    def Opts(self,e):
        OptionsWindow1().Show()

    def DevInfo(self,e): 
        # Use a seperate bash script and zenity for this dialog
        DevInfoDlg = DevInfoWindow().Show()

    def OnAbout(self,e):
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot"
        aboutbox.Version = "1.0~rc2"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = wordwrap(
"Utility to quickly fix the bootloader on a computer",250,wx.ClientDC(self.MainPanel))
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.License = wordwrap("WxFixBoot is released under the GNU GPL v3",500,wx.ClientDC(self.MainPanel))
        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def OnExit(self,e):
        #Shut down.
        self.Destroy()
        wx.Exit()

#End Main window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):

    title = "WxFixBoot - Options" 

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)

        self.CreateButtons()
        self.CreateText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.SetDefaults()
        self.BindEvents()

    def CreateButtons(self):
        self.SaveSettings = wx.Button(self.OptsPanel1, -1, "Apply these Settings", pos=(10,320))
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Close", pos=(500,320))
        self.fwOptsButton = wx.Button(self.OptsPanel1, -1, "View Firmware settings", pos=(310,80), size=(250,30))

    def CreateText(self):
        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Changing the advanced settings is not recommended.", (50,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", (10,50))
        wx.StaticText(self.OptsPanel1, -1, "Installed BootLoader:", (10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", (10,110))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader timeout value:", (10,260))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", (10,280)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", (310,50))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", (310,130))

    def CreateCBs(self):
        #Basic settings
        self.showprogresscb = wx.CheckBox(self.OptsPanel1, -1, "Show Progress during operations", pos=(10,140), size=(300,20))
        self.warnusbcb = wx.CheckBox(self.OptsPanel1, -1, "Warn about disconnecting usb devices", pos=(10,170), size=(305,20))
        self.warnprogscb = wx.CheckBox(self.OptsPanel1, -1, "Warn to close all other programs", pos=(10,200), size=(295,20))
        self.createlogcb = wx.CheckBox(self.OptsPanel1, -1, "Create a logfile containing all output", pos=(10,230), size=(295,20))

        #Advanced settings
        self.chkfscb = wx.CheckBox(self.OptsPanel1, -1, "Quickly check Filesystems on startup", pos=(310,160), size=(315,20))
        self.remntfscb = wx.CheckBox(self.OptsPanel1, -1, "Mount all Filesystems as read-only", pos=(310,190), size=(315,20))
        self.bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector", pos=(310,220), size=(250,20))
        self.bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table", pos=(310,250), size=(290,20))
        self.chrootcb = wx.CheckBox(self.OptsPanel1, -1, "Use chroot to reinstall bootloader", pos=(310,280), size=(315,20))       

    def CreateChoiceBs(self):
        #Basic settings
        instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+BootLoader, 'GRUB', 'GRUB-EFI', 'LILO', 'ELILO'])
        defaultoschoice = wx.Choice(self.OptsPanel1, -1, pos=(150,103), size=(140,30), choices=OSList)

        #Advanced settings
        rootdevchoice = wx.Choice(self.OptsPanel1, -1, (440,123), choices=["Auto: "+RootFS, 'Ask me', '/dev/sda', '/dev/sdb', 'etc...'])

    def CreateSpinners(self):
        self.bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", (190,257))
        self.bltimeoutspin.SetRange(-1,100)
        self.bltimeoutspin.SetValue(-1)

    def SetDefaults(self):
        #Set Basic settings.
        self.showprogresscb.SetValue(1)
        self.warnusbcb.SetValue(1)
        self.warnprogscb.SetValue(1)
        self.createlogcb.SetValue(1)

        #Set advanced settings.
        self.chkfscb.SetValue(1)
        self.remntfscb.SetValue(0)
        self.bkpbootsectcb.SetValue(1)
        self.bkpparttablecb.SetValue(0)
        self.chrootcb.SetValue(1)

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchfwOpts, self.fwOptsButton)

    def LaunchfwOpts(self,e):
        OptionsWindow2().Show()

    def CloseOpts(self,e):
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):

    title = "WxFixBoot - Firmware Settings"

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(450,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(360,270))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace UEFI bootloader with BIOS version", pos=(10,160))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace BIOS bootloader with UEFI version", pos=(10,190))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Modify bootloader type based on detected Firmware type", pos=(10,220))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not change the bootloader's firmware type", pos=(10,250))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Reinstall BootLoader in:", pos=(140,50))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System:", pos=(140,85))
        wx.StaticText(self.OptsPanel2, -1, "BootLoader to install:", pos=(140,120))
 
    def CreateRadios(self):
        #Have a system to determine which options to enable based on whether fwtyperadioauto is 'Auto (BIOS)' or 'Auto (UEFI)' ***
        self.fwtyperadioauto = wx.RadioButton(self.OptsPanel2, -1, "Auto: "+FWType, pos=(7,50), style=wx.RB_GROUP)
        self.fwtyperadioEFI = wx.RadioButton(self.OptsPanel2, -1, "EFI/UEFI", pos=(7,80))
        self.fwtyperadioBIOS = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(7,110))

    def CreateChoiceBs(self):
        self.instbldestchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,44), choices=['Ask me', 'Root Device: '+RootDev, '/dev/sda', '/dev/sdb', 'etc...'])
        self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,79), choices=['Auto: '+PartScheme, 'MBR(msdos)', 'GPT'])
        self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,114), choices=['Current', 'Ask me', 'GRUB', 'LILO'])

    def SetDefaults(self):
        self.UEFItoBIOScb.Disable()
        self.BIOStoUEFIcb.Disable()
        self.useAutocb.Disable()
        self.useAutocb.SetValue(False)
        self.unchangedcb.SetValue(True)
        self.fwtyperadioauto.SetValue(True)
        self.fwtyperadioEFI.SetValue(False)
        self.fwtyperadioBIOS.SetValue(False)
        self.instbldestchoice.SetSelection(0)
        self.partitiontypechoice.SetSelection(0)

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.OnClose, self.exitbutton)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOptsforNoModification, self.unchangedcb)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforAutoFW, self.fwtyperadioauto)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforEFIFW, self.fwtyperadioEFI)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforBIOSFW, self.fwtyperadioBIOS)

    def ActivateOptsforAutoFW(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()
        self.partitiontypechoice.SetSelection(0)

    def ActivateOptsforEFIFW(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.UEFItoBIOScb.Enable()
        self.partitiontypechoice.SetSelection(2)

    def ActivateOptsforBIOSFW(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked() == False:
            self.UEFItoBIOScb.Disable()
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Enable()
        self.partitiontypechoice.SetSelection(1)

    def ActivateOptsforNoModification(self,e):
        #These must be updated as the GUI progresses***
        if self.unchangedcb.IsChecked():
            self.UEFItoBIOScb.Disable()
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
        else:
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")

    def OnClose(self,e):
        self.Destroy()

#Begin Device Info Window
class DevInfoWindow(wx.Frame):

    title = "WxFixBoot - Device Information"

    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title=self.title, size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", (30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(330,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(60,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)

    def UpdDevInfo(self,e):
        #Generate device data.
        devicelist = GetDevInfo()

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        self.Destroy()

#End Device Info Window
app = MyApp(False)
app.MainLoop()
