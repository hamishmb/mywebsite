#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 1.0rc4
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# WxFixBoot is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
from __future__ import division
import wx
import sys
from threading import Thread
import time
import os
import shutil
import subprocess
import logging
import getopt

def usage():
    print "\nUsage: WxFixBoot.py [OPTION]\n"
    print "       -h, --help:                   Show this help message"
    print "       -q, --quiet:                  Show only warning, error and critial messages in the log file."
    print "       -v, --verbose:                The default setting when no options are passed. Enable logging of info messages, as well as warnings, errors and critical errors."
    print "       -d, --debug:                  Log lots of very boring debug messages, usually used for diagnostic purposes, may result in very large log files\n"
    print "WxFixBoot 1.0rc4 is released under the GNU GPL Version 3"
    print "Copyright (C) Hamish McIntyre-Bhatty 2013-2014"

#If this isn't running as root, relaunch
if not os.geteuid() == 0:
    subprocess.Popen(["/usr/share/wxfixboot/runasroot.sh"])
    sys.exit("\nSorry, this program must be run with root privileges.\nRestarting as Root...")

#Set up logging.
logger = logging.getLogger('WxFixBoot')
logging.basicConfig(filename='/var/log/wxfixboot.log', format='%(asctime)s %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p')
logger.setLevel(logging.INFO)

#Set up according to cmdline options.
try:
    opts, args = getopt.getopt(sys.argv[1:], "hqvd", ["help", "quiet", "verbose", "debug"])
except getopt.GetoptError as err:
    #Invalid option. Show the help message and then exit.
    #Show the error.
    print str(err)
    usage()
    sys.exit(2)

#Determine the option given.
for o, a in opts:
    if o in ("-q", "--quiet"):
        logger.setLevel(logging.WARNING)
    elif o in ("-v", "--verbose"):
        logger.setLevel(logging.INFO)
    elif o in ("-d", "--debug"):
        logger.setLevel(logging.DEBUG)
    elif o in ("-h", "--help"):
        usage()
        sys.exit()
    else:
        assert False, "unhandled option"

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen(["/usr/share/wxfixboot/listdevices.sh"]).wait()

    #Create/Update a device list
    devicelist = []

    #New more efficent way of putting everything in one list.
    with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
        idedevicesfile = idedevicessource.readlines()
        if idedevicesfile != []:
            devicelist = devicelist + idedevicesfile
            devicelist.append('IDE/ATA Devices:')

    with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
        cddvddevicesfile = cddvddevicessource.readlines()
        if cddvddevicesfile != []:
            devicelist.append('CD/DVD Devices:')
            devicelist = devicelist + cddvddevicesfile

    with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
        usbsatadevicesfile = usbsatadevicessource.readlines()
        if usbsatadevicesfile != []:
            devicelist.append('USB or SATA Devices:')
            devicelist = devicelist + usbsatadevicesfile

    #Remove newline chars.
    return [(el.strip()) for el in devicelist]

def SetDefaults():
    #Options in MainWindow
    global ReinstallBootLoader
    global UpdateBootLoader
    global QuickFSCheck
    global BadSectCheck
    ReinstallBootLoader = False
    UpdateBootLoader = False 
    QuickFSCheck = False
    BadSectCheck = False

    #Options in Optionsdlg1
    global CreateLog
    global FullVerbose
    global Verify
    global BkpBootSect
    global BackupPartTable
    global MakeSystemSummary
    global BootLoaderTimeOut

    #Set them up for default settings.
    CreateLog = True
    FullVerbose = False
    Verify = True
    BkpBootSect = False
    BackupPartTable = False
    MakeSystemSummary = True
    BootLoaderTimeOut = -1 #Don't change the timeout by default.

    #Options in Bootloader Options dlg
    global BootLoaderToInstall
    global BootLoaderDestination
    global BLOptsDlgRun
    BootLoaderToInstall = "None"
    BootLoaderDestination = "None"
    BLOptsDlgRun = False

    #Options in Restore dlgs
    global RestoreBootSector
    global BootSectFile
    global BootSectorTargetDevice
    global RestorePartTable
    global PartTableFile
    global PartitionTableTargetDevice
    RestoreBootSector = False
    BootSectFile = "None"
    BootSectorTargetDevice = "None"
    RestorePartTable = False
    PartTableFile = "None"
    PartitionTableTargetDevice = "None"

    #Other Options
    global OptionsDlg1Run
    OptionsDlg1Run = False

def MountDeviceSafely(Device, MountPoint):
    #Safely Mount Device here, as the code was getting duplicated.
    #Also, check if it isn't already present, and that nothing's already mounted there.
    try:
        temp = subprocess.check_output("df | grep "+MountPoint, shell=True).split()[-1]
    except subprocess.CalledProcessError:
        #Nothing mounted there.
        pass
    else:
        #Unmount the partition, and continue.
        logger.warning("MountDeviceSafely: Warning: Unmounting filesystem in the way at "+MountPoint+"...")
        runcmd = subprocess.Popen(['umount', MountPoint], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, stderr = runcmd.communicate()
        logger.debug("MountDeviceSafely: Command: umount "+MountPoint+" stdout: "+str(stdout)+", stderr: "+str(stderr))

    #Creating the dir if needed.
    if os.path.exists(MountPoint) == False:
        os.makedirs(MountPoint)
    
    #Mount the device to the mount point. No worries if it's already mounted, as any kernel of 2.x or newer supports mounting FSes twice, and otherwise it'll give an error anyway, which'll be caught and handled.
    runcmd = subprocess.Popen(["mount", Device, MountPoint], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    stdout, stderr = runcmd.communicate()

    if str(stderr) == "None":
        return "Succeeded"
    else:
        return str(stdout)

#Starter Class
class WxFixBoot(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = "/usr/share/wxfixboot/splash.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnCloseSplash)

        #Make sure it's painted, which fixes the problem with the previous temperamental splash screen on DDRescue-GUI <= 1.2
        wx.Yield()

    def OnCloseSplash(self,e):
        #Start the init Frame.
        self.Hide()
        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True

            #Warn the user about running in a VM 
            dlg = wx.MessageDialog(None, "Welcome to WxFixBoot Version 1.3rc4! As this is a development version, please check the log file at '/var/log/wxfixboot.log' for any errors. There is also debug output included if the --debug or -d options are passed on the commandline. This version isn't fully tested, and probably shouldn't be used in anything except a VM to prevent data loss (unless you're feeling brave!). Please click no to close the program if you aren't running this in a VM.", "WxFixBoot - Warning", style=wx.YES_NO | wx.ICON_ERROR, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                pass
            else:
                wx.Exit()
                sys.exit("User aborted the program.")

            #Reset the top window and start InitFrame()
            InitFrame = InitialWindow()
            app.SetTopWindow(InitFrame)
            InitFrame.Show(True)

            #Skip the event so the init frame starts.
            e.Skip()

#End splash screen
#Begin Initialization frame
class InitialWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc4 is preparing to start...",size=(400,300),style=wx.CAPTION)
        self.InitPanel = wx.Panel(self)

        print "WxFixBoot Version 1.0~rc4 development Starting..."
        logger.warn("WxFixBoot Version 1.0~rc4 development Starting...")
        logger.warn("Do not use this on ANY production machine!")

        #Create GUI elements
        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBar()

        #Start the Initalization Thread, which performs all necessary startup scripts and checks, and let it know this is the first start.
        logger.debug("Starting Initial thread...")
        InitThread(self,True)       

    def CreateText(self):
        self.DependsCheckText = wx.StaticText(self.InitPanel, -1, "Dependency check...", pos=(10,10))
        self.UnmountFSText = wx.StaticText(self.InitPanel, -1, "Unmounting all unneeded Filesystems...", pos=(10,30))
        self.CheckFSText = wx.StaticText(self.InitPanel, -1, "Quickly Checking Filesystems in fstab...", pos=(10,50))
        self.MountFSText = wx.StaticText(self.InitPanel, -1, "Mounting all Filesystems in fstab as read-only...", pos=(10,70))
        self.DetectDevsPartsPartSchemesText = wx.StaticText(self.InitPanel, -1, "Detecting Devices, Partitions, and Partition Schemes...", pos=(10,90))
        self.DetectPartText = wx.StaticText(self.InitPanel, -1, "Detecting Linux Partitions...", pos=(10,110))
        self.RootFSText = wx.StaticText(self.InitPanel, -1, "Determining Root Filesystem and Root Device...", pos=(10,130))
        self.DetectOSesText = wx.StaticText(self.InitPanel, -1, "Detecting Linux OSes...", pos=(10,150))
        self.FWTypeText = wx.StaticText(self.InitPanel, -1, "Determining Firmware Type...", pos=(10,170))
        self.BootLoaderText = wx.StaticText(self.InitPanel, -1, "Determining Boot Loader...", pos=(10,190))
        self.FinalCheckText= wx.StaticText(self.InitPanel, -1, "Final check...", pos=(10,210))

    def CreateButtons(self):
        #Create a button.
        self.startbutton = wx.Button(self.InitPanel, -1, "Start", pos=(150,235), size=(100,30))
        self.startbutton.Disable()

        #Bind it to an event here.
        self.Bind(wx.EVT_BUTTON, self.FinishedInitConf, self.startbutton)

    def CreateProgressBar(self):
        #Create a progressbar.
        self.InitProgressBar = wx.Gauge(self.InitPanel, -1, 100, pos=(10,270), size=(380,25))
        self.InitProgressBar.SetBezelFace(3)
        self.InitProgressBar.SetShadowWidth(3)
        self.InitProgressBar.SetValue(0)
        self.InitProgressBar.Show()

    def UpdateProgressBar(self,msg):
        self.InitProgressBar.SetValue(int(msg))

    def ShowThreadYesNodlg(self,msg):
        global dlgResult
        dlg = wx.MessageDialog(self.InitPanel, msg, 'WxFixBoot - Question', wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("Init Window: Result of InitThread yesno dlg was: "+dlgResult)

    def ShowThreadInfodlg(self,msg):
        global dlgClosed
        dlg = wx.MessageDialog(self.InitPanel, msg, "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadChoicedlg(self,msg):
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.InitPanel, data[0], data[1], data[2:], pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("Init Window: Result of InitThread choice dlg was: "+dlgResult)

    def ShowThreadTextEntrydlg(self,msg):
        global dlgAnswer
        dlg = wx.TextEntryDialog(self.InitPanel, msg, "WxFixBoot - Text Entry", "", style=wx.OK|wx.CANCEL, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetValue()
        else:
            dlgAnswer = "Clicked no..."
        logger.debug("Init Window: Result of InitThread text entry dlg was: "+dlgAnswer)

    def UpdateDependsCheckText(self,msg):
        self.DependsCheckText.SetLabel(msg)

    def UpdateUnmountFSText(self,msg):
        self.UnmountFSText.SetLabel(msg)

    def UpdateMountFSText(self,msg):
        self.MountFSText.SetLabel(msg)

    def UpdateDetectDevsPartsPartSchemesText(self,msg):
        self.DetectDevsPartsPartSchemesText.SetLabel(msg)

    def UpdateDetectPartText(self,msg):
        self.DetectPartText.SetLabel(msg) 

    def UpdateDetectOSesText(self,msg):
        self.DetectOSesText.SetLabel(msg) 

    def UpdateRootFSText(self,msg):
        self.RootFSText.SetLabel(msg)

    def UpdateFWTypeText(self,msg):
        self.FWTypeText.SetLabel(msg)

    def UpdatePartSchemeText(self,msg):
        self.PartSchemeText.SetLabel(msg)

    def UpdateBootLoaderText(self,msg):
        self.BootLoaderText.SetLabel(msg)

    def UpdateCheckFSText(self,msg):
        self.CheckFSText.SetLabel(msg)

    def UpdateFinalCheckText(self,msg):
        self.FinalCheckText.SetLabel(msg)
        self.startbutton.Enable()

    def FinishedInitConf(self,e):
        logger.info("Closing Initial Window and Starting Main Window...")
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        self.Destroy()
        MainFrame.Show(True)    

#End Initalization Frame
#Begin Initaization Thread.
class InitThread(Thread):
    def __init__(self, ParentWindow, Starting):
        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it, unless this isn't first run.
        #However, only delete it if no partitions are mounted in it. This has been done before during testing. Otherwise exit.
        self.Starting = Starting
        if self.Starting == True:
            try:
                subprocess.check_output("mount | grep '/tmp/wxfixboot'", shell=True).replace('\n', '')
            except subprocess.CalledProcessError:
                if os.path.exists("/tmp/wxfixboot"):
                    shutil.rmtree("/tmp/wxfixboot")
                    logger.debug("Cleared wxfixboot's temporary folder. Most of the time this doesn't need to be done, but it's probably not a problem. Logging this purely for paranoia's sake :)")
                os.mkdir("/tmp/wxfixboot")
            else:
                logger.critical("ERROR: Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage. Exiting now...")
                wx.Exit()
                sys.exit("ERROR! Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage.")

        #Initialize the thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        logger.debug("Started Init Thread...")

        self.start()

    def run(self):
        if self.Starting == True:
            #Set some default settings and wait for the GUI to initialize.
            logger.debug("Initial Thread: Setting up global variables...")

            #Wait.
            time.sleep(1)

            #Check for dependencies
            logger.info("Initial Thread: Checking For Dependencies...")
            self.CheckDepends()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "10")
            logger.info("Initial Thread: Done Checking For Dependencies!")

            #Unmount all filesystems, to avoid any (highly unlikely) data corruption.
            logger.info("Initial Thread: Unmounting Filesystems...")
            self.UnmountAllFS()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "20")
            logger.info("Initial Thread: Done Unmounting Filsystems!")

            #Check filesystems.
            logger.info("Initial Thread: Checking Filesystems...")
            self.CheckFS()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "30")
            logger.info("Initial Thread: Filesystems Checked!")

            #Mount all filesystems.
            logger.info("Initial Thread: Mounting Filesystems...")
            self.MountAllFS()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "40")
            logger.info("Initial Thread: Done Mounting Filsystems!")

            #Detect Devices, Partitions, and Partition Schemes
            logger.info("Initial Thread: Detecting Devices, Partitions, and PartSchemes...")
            self.DetectDevicesPartitionsAndPartSchemes()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "50")
            logger.info("Initial Thread: Finished Detecting Devices, Partitions, and PartSchemes!")

            #Detect Linux Partitions.
            logger.info("Initial Thread: Detecting Linux Partitions...")
            self.DetectLinuxPartitions()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "60")
            logger.info("Initial Thread: Finished Detecting Linux Partitions!")
  
            #Get the root filesystem and root device.
            logger.info("Initial Thread: Determining Root Filesystem and Root Device...")
            self.GetRootFSandRootDev()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "70")
            logger.info("Initial Thread: Determined Root Filesystem as: "+RootFS+ " , Root Device as "+RootDev)

            #Get a list of Linux OSes (if LiveDisk = True, this has already been run).
            logger.info("Initial Thread: Finding Linux OSes...")
            if LiveDisk == False:
                self.GetLinuxOSes()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "80")
            logger.info("Initial Thread: Found all Linux OSes. Default: "+DefaultOS)

            #Get the firmware type.
            logger.info("Initial Thread: Determining Firmware Type...")
            self.GetFirmwareType()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "90")
            logger.info("Initial Thread: Determined Firmware Type as: "+FWType)

            #Get the BootLoader.
            logger.info("Initial Thread: Determining The BootLoader...")
            self.GetBootLoader()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "100")
            logger.info("Initial Thread: BootLoader is: "+BootLoader)

            #Perform final check.
            logger.info("Initial Thread: Doing Final Check for error situations...")
            self.FinalCheck()
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "100")
            logger.info("Initial Thread: Done Final Check!")
            logger.info("Initial Thread: Finished Determining Settings. Exiting Initial Thread...")
        else:
            #Get the BootLoader. It reads self.Starting for itself.
            logger.info("Initial Thread: Determining The BootLoader...")
            self.GetBootLoader()
            logger.info("Initial Thread: BootLoader is: "+BootLoader)

    def ShowInfoDlg(self,msg):
        #Method to handle showing thread message dialogs, reducing code duplication and compilications and errors.
        #Reset dlgClosed, avoiding errors.
        global dlgClosed
        dlgClosed = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadInfodlg, msg)

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

    def ShowYesNoDlg(self,msg):
        #Method to handle showing thread yes/no dialogs, reducing code duplication and compilications and errors.
        #Reset dlgResult, avoiding errors.
        global dlgResult
        dlgResult = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg)

        #Trap the thread until the user responds.
        while dlgResult == "Unknown":
            time.sleep(0.5)

    def ShowChoiceDlg(self,msg):
        #Method to handle showing thread choice dialogs, reducing code duplication and compilications and errors.
        while True:
            #Reset dlgResult, avoiding errors.
            global dlgResult
            dlgResult = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg)

            #Trap the thread until the user responds.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            if dlgResult == "" or dlgResult == "Clicked no...":
                self.ShowInfoDlg("Please make a valid selection.")
            else:
                break

    def ShowTextEntryDlg(self,msg):
        #Method to handle showing thread text entry dialogs, reducing code duplication and compilications and errors.
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            if dlgAnswer == "":
                self.ShowInfoDlg("Please enter a value or click cancel.")
            else:
                break

    def CheckDepends(self):
        #This is a dependency checking function, will will show a message and kill the app if the dependencies are not met.
        #Create a temporary list to allow wxfixboot to notify of particular unmet dependencies.
        templist = ['mount', '-V', 'umount', '-V', 'parted' ,'-v', 'lsb_release', '-v', 'dmidecode', '-V', 'grep', '-V', 'lsblk', '--help', 'df', '--version', 'chroot', '--version', 'dd', '--version', 'find', '--version']

        #Create a list to contain names of failed commands.
        failedlist = []
        for command in templist:
            #If the command does not start with '-', run it as it isn't just a argument.
            if command[0] != "-":
                argument = templist[templist.index(command)+1]
                try:
                    #Run the command and log the output (if in debug mode)
                    runcmd = subprocess.Popen([command, argument], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    stdout, stderr = runcmd.communicate()
                    logger.debug("Initial Thread: Dependency check: Command: "+command+" stdout: "+str(stdout)+", stderr: "+str(stderr))
                except (subprocess.CalledProcessError, OSError) as e:
                    logger.error("Initial Thread: Dependency problems! Command: "+command+" failed to execute or wasn't found.")
                    logger.error("Initial Thread: The error was: "+str(e))
                    failedlist.append(command)

        #Check if any commands failed.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("Initial Thread: Dependencies missing! WxFixBoot will exit. The missing dependencies are: "+', '.join(failedlist)+"Exit.")
            self.ShowInfoDlg("The following dependencies were not found on your system: "+', '.join(failedlist)+"\nPlease install the missing dependencies. WxFixBoot will now exit.")

            wx.Exit()
            sys.exit("Missing dependencies: "+', '.join(failedlist)+" Exiting...")
        else:
            wx.CallAfter(self.ParentWindow.UpdateDependsCheckText, "Dependency check... Passed!")

    def UnmountAllFS(self):
        #Unmount any unnecessary filesystems, to prevent the very unlikely case of data corruption.
        #Warn about removing devices.
        self.ShowInfoDlg("Any unnecessary filesystems will now be unmounted. Please now remove all unneeded devices connected to your computer, and close any other running programs, and then click okay.")

        #Attempt unmount of all filesystems, attempting to mount read-only upon failed unmounts.
        try:
            runcmd = subprocess.Popen(['umount', '-adr'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout, stderr = runcmd.communicate()
            logger.debug("Initial Thread: UnmountAllFS: Command: 'umount -ad' stdout: "+str(stdout)+", stderr: "+str(stderr))
        except subprocess.CalledProcessError:
            pass
        finally:
            wx.CallAfter(self.ParentWindow.UpdateUnmountFSText, "Unmounting all unneeded Filesystems... Success")

    def CheckFS(self):
        #Check all non-mounted filesystems.
        runcmd = subprocess.Popen(['fsck', '-ARMp'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, stderr = runcmd.communicate()
        logger.debug("Initial Thread: CheckFS: Command: 'fsck -ARMp' stdout: "+str(stdout)+", stderr: "+str(stderr))
        wx.CallAfter(self.ParentWindow.UpdateCheckFSText, "Quickly Checking Filesystems in fstab... Success")

    def MountAllFS(self):
        #Mount filsystems defined in the /etc/fstab of the current operating system.
        #All other filesystems will be mounted when/as needed.
        runcmd = subprocess.Popen(['mount', '-avr'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, stderr = runcmd.communicate()
        logger.debug("Initial Thread: MountAllFS: Command: 'mount -a' stdout: "+str(stdout)+", stderr: "+str(stderr))
        
        logger.debug("Initial Thread: 'mount -a' ran fine, continuing...")

        wx.CallAfter(self.ParentWindow.UpdateMountFSText, "Mounting all Filesystems in fstab as read-only... Done")

    def DetectDevicesPartitionsAndPartSchemes(self):
        #Detect all devices, partitions, and their partition schemes.
        #Define Global Variables.
        global PartitionListWithFSType
        global DeviceList
        global PartSchemeList
        global AutoPartSchemeList
        global GPTInAutoPartSchemeList
        global MBRInAutoPartSchemeList

        #Create a list for the devices.
        DeviceList = []

        #Create a list for Partition Schemes.
        AutoPartSchemeList = []

        #Create a list for the partitions.
        PartitionListWithFSType = []

        templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep -v 'NAME'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()

        #Populate the device list, and the Partition List including FS Type.
        for element in templist:

            #Check if the element is a device, and doesn't end with a digit (isn't a partition).
            if (element[-3:-1] == 'sd' or element[-3:-1] == 'hd') and element[-1].isdigit() == False:

                #First AutoPartSchemeList
                try:
                    #Check if the element is already in DeviceList, as if it is, it won't be duplicated in AutoPartSchemeList either this way.
                    DeviceList.index('/dev/'+element[-3:])
                except ValueError:
                    #It isn't, add it.
                    PartScheme = self.GetDevPartScheme('/dev/'+element)
                    AutoPartSchemeList.append(PartScheme)
                else:
                    #It is, ignore it.
                    pass

                #Now DeviceList
                try:
                    #Check if the element is already in DeviceList.
                    DeviceList.index(element[-3:])
                except ValueError:
                    #It isn't, add it.
                    DeviceList.append('/dev/'+element[-3:])
                else:
                    #It is, ignore it.
                    pass

            #If instead the partition is not a device, but instead a partition of any type, add it to the Partition List with FSType, along with the next element, if it is not a device or partition.
            elif (element[-4:-2] == 'sd' or element[-4:-2] == 'hd') and element[-1].isdigit() == True:

                PartitionListWithFSType.append('/dev/'+element[-4:])
                temp = templist[templist.index(element)+1]

                if temp[-3:-1] != 'sd' and temp[-3:-1] != 'hd' and temp[-4:-2] != 'sd' and temp[-4:-2] != 'hd':
                    PartitionListWithFSType.append(temp)
                else:
                    PartitionListWithFSType.append("Ignore")

        #Now set PartSchemeList the same as AutoPartSchemeList.
        PartSchemeList = AutoPartSchemeList[:]

        logger.debug("Initial Thread: DeviceList, PartitionListWithFSType and PartSchemeList Populated okay. Contents (respectively): "+' '.join(DeviceList)+" and: "+' '.join(PartitionListWithFSType)+" and: "+' '.join(PartSchemeList))

        #Finally, save two variables showing whether there are any mbr or gpt entries on the disk.
        #GPT
        try:
            PartSchemeList.index("gpt")
        except ValueError:
            GPTInAutoPartSchemeList = False
        else:
            GPTInAutoPartSchemeList = True

        #MBR(MSDOS)
        try:
            PartSchemeList.index("msdos")
        except ValueError:
            MBRInAutoPartSchemeList = False
        else:
            MBRInAutoPartSchemeList = True

        wx.CallAfter(self.ParentWindow.UpdateDetectDevsPartsPartSchemesText, "Detecting Devices, Partitions, and Partition Schemes... Done")

    def DetectLinuxPartitions(self):
        #Get a list of partitions of type ext (2,3 or 4) / btrfs / xfs / jfs / zfs.
        global LinuxPartList

        try:
            templist = []
            templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'ext\|btrfs\|xfs\|jfs\|zfs'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()
        except subprocess.CalledProcessError as e:
            #There are none, exit.
            logger.critical("No Linux Partitions of type ext(1,2,3,4), btrfs, xfs, jfs or zfs found!")
            logger.critical("The error was: "+str(e)+". Exiting...")
            self.ShowInfoDlg("You don't appear to have any Linux partitions. The supported filesystems are ext (any version), btrfs, xfs, jfs and zfs. If you do have Linux partitions, but wxfixboot hasn't found them, please file a bug or ask a question on wxfixboot's launchpad page. If you're using Windows or Mac OS X, then sorry as wxfixboot has no support for non-Linux operating systems and bootloaders, and you could instead use the tools provided by Microsoft and Apple to fix issues with your computer. WxFixBoot will now exit.")

            #Exit.
            wx.Exit()
            sys.exit("Fatal! No supported Linux filesystems found. Will now exit...")
        LinuxPartList = []

        #Check if there are any linux partitions.
        if templist == []:
            #There are none, exit.
            logger.critical("No Linux Partitions of type ext(1,2,3,4), btrfs, xfs, jfs or zfs found! Exiting...")
            self.ShowInfoDlg("You don't appear to have any Linux partitions. The supported filesystems are ext (any version), btrfs, xfs, jfs and zfs. If you do have Linux partitions, but wxfixboot hasn't found them, please file a bug or ask a question on wxfixboot's launchpad page. If you're using Windows or Mac OS X, then sorry as wxfixboot has no support for non-Linux operating systems and bootloaders, and you could instead use the tools provided by Microsoft and Apple to fix issues with your computer. WxFixBoot will now exit.")

            #Exit.
            wx.Exit()
            sys.exit("Fatal! No supported Linux filesystems found. Will now exit...")

        #Create a list of the partitions.
        for element in templist:
            if element[-4:-2] == 'sd' or element[-4:-2] == 'hd':
                LinuxPartList.append('/dev/'+element[-4:])

        logger.debug("Initial Thread: LinuxPartList Populated okay. Contents: "+' '.join(LinuxPartList))

        wx.CallAfter(self.ParentWindow.UpdateDetectPartText, "Detecting Linux Partitions... Done")

    def GetRootFSandRootDev(self):
        #Determine RootFS, and RootDev
        #Setup some global vars
        global AutoRootFS
        global RootFS
        global AutoRootDev
        global RootDev
        global LiveDisk
        global DefaultOS
        global AutoDefaultOS

        self.ShowYesNoDlg("Is WxFixBoot being run on a live disk, such as Parted Magic?")
        
        if dlgResult == "Yes":
            logger.warning("Initial Thread: User reported WxFixBoot is on a live disk...")
            LiveDisk = True

            #Make an early call to GetLinuxOSes()
            self.GetLinuxOSes()

            #'&' seperates elements in a list that will be created in the display method.
            self.ShowChoiceDlg("Please select the Linux Operating System you normally boot.&WxFixBoot - Select Operating System&"+'&'.join(OSList))

            if dlgResult == "Clicked no..." or dlgResult == "":
                logger.critical("Initial Thread: User didn't select a default Linux Operating System! The RootFS cannot be determined; Cannot continue; Exiting...")
                wx.Exit()
                sys.exit("No RootFS selected. Exiting...")
            else:
                logger.info("Initial Thread: User selected default Linux OS of: "+dlgResult+". Continuing...")
                DefaultOS = dlgResult
                AutoDefaultOS = DefaultOS
                RootFS = dlgResult.split()[-1]
                AutoRootFS = RootFS
                RootDev = RootFS[0:8]
                AutoRootDev = RootDev 
                LiveDisk = True
                wx.CallAfter(self.ParentWindow.UpdateRootFSText, "Determining Root Filesystem and Root Device... Done!")
        else:
            logger.warning("Initial Thread: User reported WxFixBoot isn't on a live disk...")

            self.ShowInfoDlg("Your currently booted OS will then be taken as the default OS. You can reset this later if you wish.")

            RootFS = subprocess.check_output("df -k / | grep -v 'Filesystem'", shell=True).split()[0]
            AutoRootFS = RootFS
            RootDev = RootFS[0:8]
            AutoRootDev = RootDev
            LiveDisk = False
            wx.CallAfter(self.ParentWindow.UpdateRootFSText, "Determining Root Filesystem and Root Device... Done!")

    def GetLinuxOSes(self):
        #Get the names of all Linux OSes on the HDDs.
        global OSList
        global DefaultOS
        global AutoDefaultOS
        OSList = []

        #Get Linux OSes.
        logger.debug("Initial Thread: Populating OSList...")
        for partition in LinuxPartList:
            #Reset the Skip value to False.
            Skip = False

            if LiveDisk == False:
                #Only check if a partition equals the root partiton if not running from a live disk.

                if partition == RootFS:
                    #The element is the root partition, tell the next if loop to not run.
                    Skip = True
                    try:
                        #Run the command to get the OS.
                        currentoslist = subprocess.check_output(["lsb_release", "-d"]).split()
                        currentos = ' '.join(currentoslist[1:])
                    except:
                        currentos = self.AskForOS(partition)
                        if currentos == "None":
                            pass
                        else:
                            #Add this information to the OSList, and set it as the default OS
                            DefaultOS = currentos+' (Current) on partition '+RootFS
                            AutoDefaultOS = DefaultOS
                            OSList.append(DefaultOS)

                    else:
                        #Add this information to the OSList, and set it as the default OS
                        DefaultOS = currentos+' (Current) on partition '+RootFS
                        AutoDefaultOS = DefaultOS
                        OSList.append(currentos+' (Current) on partition '+RootFS)

            if partition[0:7] == "/dev/sd" or partition[0:7] == "/dev/hd":
                #We're interested in this element, because it's an HDD or usb disk partition.
                #Go back to the start if this has already been determined as RootFS
                if Skip == True:
                    continue
                
                #Mount the device safely, using the global mount function.
                retstr = MountDeviceSafely(partition, "/mnt"+partition)

                #Check if anything went wrong.
                if retstr != "Succeeded":
                    #Probably already mounted on a very old linux kernel, just ignore it, as it's safer to do so.
                    logger.warning("Initial Thread: GetLinuxOSes: Command: 'mount "+partition+" /mnt"+partition+" -r' errored with stderr: "+retstr+"! Ignoring it, as it's safer using a very old linux kernel.")
                else:
                    try:
                        #Run a command in chroot to determine the OS
                        partitionoslist = subprocess.check_output(["chroot", "/mnt"+partition, "lsb_release", "-d"]).split()
                        partitionos = ' '.join(partitionoslist[1:])
                    except:
                        partitionos = self.AskForOS(partition)
                        if partitionos == "None":
                            pass
                        else:
                            #Add this information to the OSList
                            OSList.append(partitionos+' on partition '+partition)
                    else:
                        #Add this information to the OSList
                        OSList.append(partitionos+' on partition '+partition)

                #Clean up.
                Skip = None

                #Unmount the filesystem.
                time.sleep(0.2)
                subprocess.check_output(["umount", "/mnt"+partition])

                #Remove the temporary mountpoint
                os.rmdir("/mnt/"+partition)

        logger.debug("Initial Thread: OSList Populated okay. Contents: "+' '.join(OSList))

        wx.CallAfter(self.ParentWindow.UpdateDetectOSesText, "Detecting Linux OSes... Done")

    def AskForOS(self,element):
        #Ask the user if an OS exists on the given partition.
        #This might not be a Linux Operating System, or it might be a very old one.
        self.ShowYesNoDlg("WxFixBoot couldn't determine the Linux operating system on one of the detected Linux partitions, "+element+", though it's likely there is one.\n If you belive it contains no recent Linux operating system, click no. If you believe it does contain a recent Linux operating system, click yes.")

        if dlgResult == "No":
            logger.debug("Initial Thread: User reported no Linux OS in "+element)
            #User reported no OS in this partition, ignore it.
            return "None"
        else:
            logger.debug("Initial Thread: User reported Linux OS in "+element+". Asking name of OS...")
            #User reported that an OS is here.
            self.ShowTextEntryDlg("Please enter the name of the operating system that is on "+element+".\nIf this is an old Linux distribution, it's probably better to click no here and ignore it for safety reasons.\nThe name you specify will be listed in the options dialog.")

            if dlgAnswer == "Clicked no...":
                logger.debug("Initial Thread: User reported old or or no OS in "+element+". Continuing...")
                #User reported no OS (or old OS) in this partition, ignore it.
                return "None"
            else:
                return dlgAnswer

    def GetFirmwareType(self):
        #Get the firmware type.
        global FWType
        global AutoFWType
        global EFIVars

        #Set EFIVars to prevent an error on BIOS systems.
        EFIVars = "None"

        try:
            subprocess.check_output("dmidecode -q | grep 'UEFI'", shell=True)
        except subprocess.CalledProcessError:
            logger.info("Initial Thread: Detected Firmware Type as BIOS...")
            FWType = "BIOS"
            AutoFWType = "BIOS"
        else:
            logger.info("Initial Thread: Detected Firmware Type as UEFI. Looking for EFI Variables...")
            FWType = "UEFI"
            AutoFWType = "UEFI"

            #Also, look for EFI variables.
            #Make sure efivars module is loaded. If it doesn't exist, continue anyway.
            runcmd = subprocess.Popen("modprobe efivars", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout, stderr = runcmd.communicate()
            logger.debug("Initial Thread: GetFirmwareType: Command: 'modprobe efivars' stdout: "+str(stdout)+", stderr: "+str(stderr))

            if os.path.exists("/sys/firmware/efi/vars"):
                EFIVars = True
                logger.info("Initial Thread: Found EFI Variables at /sys/firmware/efi/vars...")
            elif os.path.exists("/sys/firmware/efi/efivars"):  
                EFIVars = True
                logger.info("Initial Thread: Found EFI Variables at /sys/firmware/efi/efivars...")
            else:
                logger.warning("Initial Thread: EFI vars not found in /sys/firmware/efi/vars or /sys/firmware/efi/efivars. Attempt manual mount...")
                #Attempt to manually mount the efi vars.
                try:
                    if not os.path.exists("/sys/firmware/efi/vars"):
                        os.mkdir("/sys/firmware/efi/vars")
                    subprocess.check_output(['mount', '-t', 'efivarfs', 'efivarfs', '/sys/firmware/efi/vars'])
                    EFIVars = True
                    logger.debug("Initial Thread: Mounted EFI Variables at: /sys/firmware/efi/vars. Continuing...")
                except (OSError, subprocess.CalledProcessError) as e:
                    logger.warning("Initial Thread: Failed to mount EFI vars! Warning user. Ignoring and continuing.")
                    #EFI vars not available or couldn't be mounted.
                    self.ShowInfoDlg("Warning: Your computer uses EFI firmware, but the efi variables couldn't be mounted or weren't found. Please insure you've booted in EFI mode rather than legacy or CSM mode to enable access to the EFI variables. You can attempt installing an EFI bootloader without them, but it may not work as expected, and isn't recommended.")

        wx.CallAfter(self.ParentWindow.UpdateFWTypeText, "Determining Firmware Type... Success: "+AutoFWType)

    def GetDevPartScheme(self,Device):
        #Get the partition type on the given Device, and return it.
        return subprocess.check_output("parted "+Device+" print | grep 'Partition Table'", shell=True).split()[2]

    def GetBootLoader(self):
        #Determine the current bootloader.
        global BootLoader
        global AutoBootLoader
        global PrevBootLoaderSetting
        global AutoEFISYSP
        global EFISYSP
        global ManuallyMountedEFISYSP
        global OSList
        global HelpfulEFIPartition
        global FatPartitions
        if self.Starting == True:
            HelpfulEFIPartition = False
            PrevBootLoaderSetting = "None"
            EFISYSP = "None"
            AutoEFISYSP = "None"
            ManuallyMountedEFISYSP = "None"
            FatPartitions=['None']

        #Run some inital scripts
        logger.debug("Initial Thread: Copying MBR bootsector to /tmp/wxfixboot/mbrbootsect...")
        runcmd = subprocess.Popen("dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
        stdout, stderr = runcmd.communicate()
        logger.debug("Initial Thread: GetBootLoader: Command: 'dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect' stdout: "+str(stdout)+", stderr: "+str(stderr))
        
        logger.debug("Initial Thread: Copied MBR bootsector to file.")

        #Wrap this in a loop, so once a BootLoader is found, searching can stop.
        while True:
            #Check for BIOS/CSM bootloaders here, but only if this is the first run.
            #Otherwise, skip some stuff.
            if self.Starting == True:
                #Check for GRUB in the MBR
                logger.debug("Initial Thread: Checking for GRUB in bootsector...")
                AutoBootLoader = self.CheckForGRUBMBR()
                if AutoBootLoader == "GRUB-MBR":
                    #Check if the system is using grub-legacy.
                    #Run a command to print grub's version.
                    runcmd = subprocess.Popen("grub-install --version", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
                    stdout, stderr = runcmd.communicate()
                    logger.debug("Initial Thread: GetBootLoader: Command: 'grub-install --version' stdout: "+str(stdout)+", stderr: "+str(stderr))

                    #Try to grab the first number in the list, getting rid of the brackets.
                    temp = "empty"
                    stdout = stdout.replace("(", "").replace(")", "")
                    for version in stdout.split():
                        try:
                            float(version)
                        except ValueError: pass
                        else:
                            temp = version
                            break

                    #Check if there is a version number found. If not, it's grub2.
                    if temp == "empty":
                        logger.debug("Initial Thread: Found GRUB2 in MBR (Shown as GRUB-MBR in GUI). Continuing...")
                        AutoBootLoader = "GRUB-MBR"
                    else:
                        #If a number was found, check if it's lower than or equal to 1.97 (aka it's grub legacy)
                        if float(temp) <= 1.97:
                            AutoBootLoader = "GRUB-LEGACY"
                            logger.warning("Initial Thread: Found GRUB-LEGACY in MBR! Some options will be disabled, as grub legacy isn't fully supported because it is obsolete. Continuing...")
                        else:
                            logger.debug("Initial Thread: Found GRUB2 in MBR (Shown as GRUB-MBR in GUI). Continuing...")
                            AutoBootLoader = "GRUB-MBR"

                    wx.CallAfter(self.ParentWindow.UpdateBootLoaderText, "Determining Boot Loader... Success: "+AutoBootLoader)
                    break

                #Check for LILO in MBR
                logger.debug("Initial Thread: Checking for LILO in bootsector...")
                AutoBootLoader = self.CheckForLILOMBR()
                if AutoBootLoader == "LILO-MBR":
                    wx.CallAfter(self.ParentWindow.UpdateBootLoaderText, "Determining Boot Loader... Success: "+AutoBootLoader)
                    break

                #Check for an EFI system partition.
                logger.debug("Initial Thread: Checking For an EFI Partition...")
                AutoEFISYSP = self.CheckForEFIPartition()
                EFISYSP = AutoEFISYSP

            #If there is no EFI partition, exit now.
            if EFISYSP[0:7] != "/dev/sd" and EFISYSP[0:7] != "/dev/hd":
                #There is no EFI partition.
                #Do a manual selection of bootloader.
                logger.warning("Initial Thread: Asking user what the bootloader is, as neither GRUB nor LILO was detected in MBR, and no EFI partition was found...")
                AutoBootLoader = self.ManualBootLoaderSelect()

                #The program exits if nothing was chosen, so if it executes this, the bootloader has been set.
                wx.CallAfter(self.ParentWindow.UpdateBootLoaderText, "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Mount (or skip if mounted) the EFI partition.
            logger.info("Initial Thread: Attempting to mount the EFI partition (if it isn't already)...")
            EFISYSPMountPoint = self.MountEFIPartition(EFISYSP)
            logger.info("Initial Thread: EFI Partition mounted at: "+EFISYSPMountPoint+". Continuing to look for EFI bootloaders...")

            #Attempt to figure out which bootloader is present.
            #Check for GRUB-EFI
            logger.debug("Initial Thread: Checking for GRUB-EFI in EFI Partition...")
            AutoBootLoader = self.CheckForGRUBEFI(EFISYSPMountPoint)
            if AutoBootLoader == "GRUB-EFI":
                wx.CallAfter(self.ParentWindow.UpdateBootLoaderText, "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Check for ELILO
            logger.debug("Initial Thread: Checking for LILO-EFI (ELILO) in EFI Partition...")
            AutoBootLoader = self.CheckForLILOEFI(EFISYSPMountPoint)
            if AutoBootLoader == "LILO-EFI":
                wx.CallAfter(self.ParentWindow.UpdateBootLoaderText, "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Obviously, no bootloader has been found.
            #Do a manual selection.
            logger.warning("Initial Thread: Asking user what the bootloader is, as no bootloader was found...")
            AutoBootLoader = self.ManualBootLoaderSelect()

            #The program exits if nothing was chosen, so if it executes this, the bootloader has been set.
            wx.CallAfter(self.ParentWindow.UpdateBootLoaderText, "Determining Boot Loader... Success: "+AutoBootLoader)
            break

        #Set the default bootloader value.
        BootLoader = AutoBootLoader

        #If this was started after selecting a new bootloader, send a message to OptionsWindow2, so the program continues.
        if self.Starting == False:
            wx.CallAfter(self.ParentWindow.EFIPartitionScanned, AutoBootLoader)

    def CheckForGRUBMBR(self):
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'GRUB'", shell=True).replace('\n', '') #*** This could be done in pure python ***
        except subprocess.CalledProcessError:
            temp = "NULL"

        if temp == "Binary file (standard input) matches":
            #BootLoader is GRUB MBR
            return "GRUB-MBR"
        else:
            return "Not GRUB MBR"

    def CheckForLILOMBR(self):
        #Check for LILO in MBR
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'LILO'", shell=True).replace('\n', '') #*** This could be done in pure python ***
        except subprocess.CalledProcessError:
            temp = "NULL"

        if temp == "Binary file (standard input) matches":
            #BootLoader is LILO in MBR
            return "LILO-MBR"
        else:
            return "Not LILO MBR"

    def CheckForEFIPartition(self):
        global FatPartitions
        FatPartitions = ['None']

        #Get a list of partitions of type vfat, if any.
        try:
            templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'vfat'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').replace('\n','').split()
        except: templist = []

        #Create another list of only the devices.
        for element in templist:
            if element[-4:-2] == "sd" or element[-4:-2] == "hd":
                FatPartitions.append("/dev/"+element[-4:])
            else:
                #We aren't interested, as this is probably a listing for the FS type.
                pass

        if LiveDisk == False:
            try:
                EFISYSP = "/dev/"+subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep '/boot'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
            except subprocess.CalledProcessError:
                try:
                    logger.warning("Initial Thread: Failed to find the EFI Partition. Trying another way...")
                    #Try a second way to get the EFI system partition.
                    EFISYSP = "/dev/"+subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep 'ESP'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
                except subprocess.CalledProcessError:
                    #Ask the user where it is.
                    logger.warning("Initial Thread: Couldn't autodetermine EFI Partition. Asking the user instead...")
                    AskForEFIPartition = True
                else:
                    logger.debug("Initial Thread: Found EFI Partition at: "+EFISYSP)
                    return EFISYSP
            else:
                logger.info("Initial Thread: Found EFI Partition at: "+EFISYSP)
                return EFISYSP

        if LiveDisk == True or AskForEFIPartition == True:
            logger.warning("Initial Thread: Asking user where EFI Partition is. If you're running from a live disk, ignore this warning.")
            if FatPartitions != ['None']:
                #'&' seperates elements in a list that will be created in the display method.
                self.ShowChoiceDlg("Please select your EFI partition. You can change this later in the settings if you change your mind, or if it's wrong.\nClick no if you don't have an EFI partition.&WxFixBoot - Select EFI Partition&"+'&'.join(FatPartitions))

                if dlgResult == "Clicked no...":
                    logger.warning("Initial Thread: User said no EFI Partition exists. Continuing...")
                    return "None"
                else:
                    logger.debug("Initial Thread: User reported EFI partition at: "+dlgResult+". Continuing...")
                    return dlgResult
            else:
                return "None"
                    
    def MountEFIPartition(self,EFISYSP):
        global ManuallyMountedEFISYSP
        #Get the EFI partition's current mountpoint, if it is mounted.
        logger.debug("Initial Thread: Preparing to mount EFI system Partition...")
        try:
            EFISYSPMountPoint = subprocess.check_output("df | grep '/boot/efi'", shell=True).split()[-1]
        except subprocess.CalledProcessError:
            #It isn't mounted, mount it, and also create the directory if needed.
            #Creating the dir is okay, because we've already checked if anything is mounted there, and if we're at this point, there isn't.
            logger.debug("Initial Thread: Mounting EFI Partition at /boot/efi...")
            EFISYSPMountPoint = "/boot/efi"
            if os.path.exists("/boot/efi") == False:
                os.mkdirs(EFISYSPMountPoint)
            subprocess.check_call(['mount', EFISYSP, EFISYSPMountPoint])
            ManuallyMountedEFISYSP = True
            logger.info("Initial Thread: Successfully Mounted EFI Partition...")
        else:
            #Check if this is the same EFI partition as suspected.
            try:
                EFISYSPMountPoint = subprocess.check_output("df | grep '"+EFISYSP+"'", shell=True).split()[-1]
            except subprocess.CalledProcessError:
                #It isn't! Unmount it, and the mount the suspected one.
                logger.warning("Initial Thread: Warning: Unmounting filesystem in the way at /boot/efi...")
                runcmd = subprocess.Popen(['umount', '/boot/efi'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                stdout, stderr = runcmd.communicate()
                logger.debug("Initial Thread: Command: umount /boot/efi stdout: "+str(stdout)+", stderr: "+str(stderr))

                #Mount the suspected one.
                subprocess.check_call(['mount', EFISYSP, EFISYSPMountPoint])
                ManuallyMountedEFISYSP = True
                logger.info("Initial Thread: Successfully Mounted EFI Partition...")
            else:
                #It's mounted, so nevermind.
                #We probably got it right :)
                logger.info("Initial Thread: EFI Partition is already mounted at: "+EFISYSPMountPoint)
                ManuallyMountedEFISYSP = False
        finally:
            return EFISYSPMountPoint

    def CheckForGRUBEFI(self,EFISYSPMountPoint):
        global ManuallyMountedEFISYSP
        global HelpfulEFIPartition
        #Look for GRUB's EFI file.
        try:
            temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*grub*'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            BootLoader = "Not GRUB-EFI"
            HelpfulEFIPartition = False
        else:
            #Look for GRUB-EFI.
            if temp != "":
                #Bootloader is GRUB-EFI.
                BootLoader = "GRUB-EFI"
                HelpfulEFIPartition = True
            else:
                BootLoader = "Not GRUB-EFI"
                HelpfulEFIPartition = False

        return BootLoader

    def CheckForLILOEFI(self,EFISYSPMountPoint):
        global ManuallyMountedEFISYSP
        global HelpfulEFIPartition
        #Look for LILO's EFI file.
        try:
            temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*elilo*'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            BootLoader = "Not ELILO"
            HelpfulEFIPartition = False
        else:
            #Look for ELILO.
            if temp != "":
                #Bootloader is ELILO.
                BootLoader = "LILO-EFI"
                HelpfulEFIPartition = True
            else:
                BootLoader = "Not ELILO"
                HelpfulEFIPartition = False

        return BootLoader

    def ManualBootLoaderSelect(self):
        logger.debug("Initial Thread: Manually selecting bootloader...")
        if EFISYSP == "Not Found" and FWType == "UEFI":
            logger.warning("Initial Thread: Only listing BIOS bootloaders, as there is no EFI partition.")
            self.ShowChoiceDlg("WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.&WxFixBoot - Select Bootloader&GRUB-LEGACY/I don't know&GRUB-MBR&LILO-MBR")

        elif EFISYSP != "Not Found" and FWType == "UEFI":
            self.ShowChoiceDlg("WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.&WxFixBoot - Select Bootloader&GRUB-LEGACY/I don't know&GRUB-MBR&GRUB-EFI&LILO-MBR&LILO-EFI")

        else:
            logger.info("Initial Thread: Only listing BIOS bootloaders, as this is a BIOS system.")
            self.ShowChoiceDlg("WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.&WxFixBoot - Select Bootloader&GRUB-LEGACY/I don't know&GRUB-MBR&LILO-MBR")

        if dlgResult == "Clicked no...":
            #Quit.
            logger.critical("Initial Thread: User didn't manaully select a bootloader! There is no apparent bootloader; Cannot continue; Exiting...")
            wx.Exit()
            sys.exit("No bootloader found...")
        else:
            if dlgResult != "GRUB-LEGACY/I don't know":
                logger.debug("Initial Thread: User reported bootloader is: "+dlgResult+". Continuing...")
                return dlgResult
            else:
                logger.debug("Initial Thread: User reported bootloader is: GRUB-LEGACY. User didn't know so selected failsafe GRUB-LEGACY. Continuing...")
                return "GRUB-LEGACY"

    def FinalCheck(self):
        #Check for any conflicting options, and that each variable is set.
        #Create a temporary list containing all variables to be checked, and a list to contain failed variables.
        templist = ['LiveDisk', 'PartitionListWithFSType', 'LinuxPartList', 'DeviceList', 'AutoRootFS', 'RootFS', 'AutoRootDev', 'RootDev', 'LiveDisk', 'DefaultOS', 'AutoDefaultOS', 'OSList', 'FWType', 'AutoFWType', 'EFIVars', 'PartSchemeList', 'AutoPartSchemeList', 'GPTInAutoPartSchemeList', 'MBRInAutoPartSchemeList', 'BootLoader', 'AutoBootLoader', 'PrevBootLoaderSetting', 'EFISYSP', 'ManuallyMountedEFISYSP']
        failedlist = []

        #Check each variable is set.
        for var in templist:
            if var in globals():
                if var != None:
                    #This is set okay.
                    pass
                else:
                    #It isn't.                    
                    logger.warning("Initial Thread: Error! Variable "+var+" hasn't been set, adding it to the failed list...")
                    failedlist.append(var)
            else:
                #It isn't.                    
                logger.warning("Initial Thread: Error! Variable "+var+" hasn't been assigned to, adding it to the failed list...")
                failedlist.append(var)

        #Check if any variables weren't set.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("Initial Thread: Critical! Required Settings: "+', '.join(failedlist)+" have not been Determined! This is probably a bug in the program! Exiting...")
            self.ShowInfoDlg("The required variables: "+', '.join(failedlist)+", have not been set! WxFixBoot will now shut down to prevent damage to your system. This is probably a bug in the program. Check the log file at /var/log/wxfixboot.log")

            wx.Exit()
            sys.exit("Incorrectly set settings:"+', '.join(failedlist)+" Exiting...")

        #Set some other variables to default values, avoiding problems down the line.
        SetDefaults()

        #Check and warn about conflicting settings.
        #Firmware type warnings.
        if FWType == "BIOS/CSM" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            logger.warning("Initial Thread: BootLoader is EFI-type, but system firmware is BIOS! Odd, perhaps a migrated drive? Continuing...")
            self.ShowInfoDlg("Warning: Your computer uses BIOS firmware, but you're using an EFI-enabled bootloader! BIOS firmware does not support booting EFI-enabled bootloaders, so it is recommended to install a BIOS-enabled legacy bootloader instead, such as GRUB2. You can safely ignore this message if your firmware type has been misdetected.")

        if FWType == "BIOS/CSM" and GPTInAutoPartSchemeList == True:
            logger.warning("Initial Thread: Firmware is BIOS, but at least on device on the system is using a gpt partition table! This device probably won't be bootable. WxFixBoot suggests repartitioning, if you intend to boot from that device.")
            self.ShowInfoDlg("Warning: Your computer uses BIOS firmware, but you're using a gpt(GUID)-style partition scheme on at least one device! BIOS firmware will likely fail to boot your operating system, if it resides on that device, so a repartition may be necessary. You can safely ignore this message if your firmware type has been misdetected.")

        #Partition scheme warnings.
        if MBRInAutoPartSchemeList == True and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            logger.warning("Initial Thread: MBR partition table on at least one device, and an EFI bootloader is in use! This might not work properly. WxFixBoot suggests repartitioning.")
            self.ShowInfoDlg("Warning: Your partition type on at least one device is msdos(MBR), but you're using an EFI-enabled bootloader! Some firmware may not support this setup, especially if the EFI sysptem partition resides on this device, so it is recommended to install a BIOS-enabled legacy bootloader instead, or repartition.")

        if GPTInAutoPartSchemeList == True and (BootLoader == "GRUB-MBR" or BootLoader == "LILO-MBR"):
            logger.warning("Initial Thread: GPT Partition table on at least one device with msdos bootloader! Most BIOS firmware cannot read GPT disks. WxFixBoot suggests repartitioning.")
            self.ShowInfoDlg("Warning: Your partition type on at least one device is gpt(GUID), but you're using an BIOS-enabled bootloader! Almost all firmware won't support this setup, assuming the bootloader uses that device to boot from, except very recent BIOS systems, so it is advised to install a EFI-enabled bootloader instead, or repartition.")

        #BootLoader warnings.
        if EFISYSP == "None" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            logger.error("Initial Thread: Error: EFI bootloader without an EFI partition is a logical impossibility! WxFixBoot will not install an EFI bootloader without an EFI partition.")
            self.ShowInfoDlg("Warning: You're using an EFI-enabled bootloader, but don't have an EFI/UEFI system partition! Your computer may be unable to boot unless you create an EFI system partition. You'll have to do this with a partitioning tool like gparted. WxFixBoot will refuse to install an EFI-enabled bootloader without an EFI system partition.")

        elif HelpfulEFIPartition == False and EFISYSP != "None":
            logger.error("Initial Thread: Error: EFI bootloader with an empty EFI partition is a logical impossibility! WxFixBoot will not install an EFI bootloader without an EFI partition.")
            self.ShowInfoDlg("Warning: Your EFI system partition is empty or doesn't contain any detected bootloaders! If you just created your EFI system partition, please insure it's formatted as fat32 (in Linux, vfat), and then you may continue to install an EFI bootloader on it. If WxFixBoot didn't detect your EFI-enabled bootloader, then that's okay, it's still perfectly safe to perform operations on it.")

        wx.CallAfter(self.ParentWindow.UpdateFinalCheckText, "Final check... All Okay!")        

#End Initalization Thread.
#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc4 (3/7/2014)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        wx.MessageDialog(self.MainPanel, "Note: To avoid confusion when using this program, please be aware that EFI and UEFI are used interchangeably at various points to avoid discrepancies between the names of programs. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Set up checkboxes
        self.OnCheckBox(False)

        #Bind all events.
        self.BindEvents()

        logger.debug("MainWindow Started. Waiting for events...")
        
    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text
        wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(125,15))
        wx.StaticText(self.MainPanel, -1, "Please set the basic settings here first.", pos=(70,35))

        #Add an image.
        img = wx.Image("/usr/share/pixmaps/wxfixboot.png", wx.BITMAP_TYPE_PNG)
        wx.StaticBitmap(self.MainPanel, -1, wx.BitmapFromImage(img), pos=(270,70))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(120,220))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply All Operations", pos=(125,180))

    def CreateCBs(self):
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorough)", pos=(10,60))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", pos=(10,90))
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall Current Bootloader", pos=(10,120))
        self.updateblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Current Bootloader", pos=(10,150))

        #If bootloader is grub legacy, disable some options.
        if BootLoader == "GRUB-LEGACY":
            self.DisableBLOptsGrubLegacy()

    def DisableBLOptsGrubLegacy(self):
        self.reinstblcb.Disable()
        self.updateblcb.Disable()

    def EnableBLOptsNoGrubLegacy(self):
        self.reinstblcb.Enable()
        self.reinstblcb.SetValue(False)
        self.updateblcb.Enable()
        self.updateblcb.SetValue(False)

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_PREFERENCES, "&Options", "General settings used to modify your system")

        #Creating the menubar.
        menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        menuBar.Append(filemenu,"&File")
        menuBar.Append(editmenu,"&Edit")
        menuBar.Append(viewmenu,"&View")
        menuBar.Append(helpmenu,"&Help")

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(menuBar)

    def OnCheckBox(self,e):
        #Make sure conflicting options can never be set.
        logger.debug("MainWindow().OnCheckBox() has been triggered.")

        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
        else:
            self.chkfscb.Enable()

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
        else:
            self.badsectcheckcb.Enable()

        #Reinstall BootLoader Choicebox
        if self.reinstblcb.IsChecked() and (BootLoader != "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True):
            self.updateblcb.SetValue(0)
            self.updateblcb.Disable()
        elif self.reinstblcb.IsChecked() == False and BootLoader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.updateblcb.Enable()
        else:
            self.reinstblcb.SetValue(0)

        #Update BootLoader Choicebox
        if self.updateblcb.IsChecked() and (BootLoader != "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True):
            self.reinstblcb.SetValue(0)
            self.reinstblcb.Disable()
        elif self.updateblcb.IsChecked() == False and BootLoader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.reinstblcb.Enable()
        else:
            self.updateblcb.SetValue(0)

    def Opts(self,e):
        global OptionsDlg1Run
        logger.debug("Starting Options Window 1 and hiding MainWindow...")
        temp = self.SaveMainOpts(False)
        if temp == "Continue":
            if EFISYSP == "None":
                wx.MessageDialog(self.MainPanel, "Seeing as you have no EFI partition, you will be unable to select an EFI bootloader to install, or as your current bootloader. NB: In the bootloader options window, you can select a new EFI partition.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
            elif HelpfulEFIPartition == False:
                wx.MessageDialog(self.MainPanel, "No bootloaders were found on your EFI partition, and no MBR bootloaders were found either. However, you will still be able to select an EFI bootloader to install, or as your current bootloader, as EFI bootloader detection is a lttle bit sketchy. NB: In the bootloader options window, you can select a new EFI partition.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            wx.MessageDialog(self.MainPanel, "Make sure you set the Root Device correctly here! Chances are, you won't need to change it, but it always needs to be set to the device your default OS boots off. You can see this information in the default OS selection in the following window. For example if your OS boots off /dev/sdc3, the root device should be set to /dev/sdc. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            OptionsDlg1Run = True
            self.Hide()
            OptionsWindow1(self).Show()

    def DevInfo(self,e):
        logger.debug("Starting Device Info Window...")
        DevInfoWindow(self).Show()

    def ProgressWindow(self,e):
        if OptionsDlg1Run == True:
            logger.debug("Starting Progress Window...")
            temp = self.SaveMainOpts(True)
            if temp == "Continue":
                ProgressFrame = ProgressWindow()
                app.SetTopWindow(ProgressFrame)
                ProgressFrame.Show(True)
                self.Destroy()
        else:
            wx.MessageDialog(self.MainPanel, "Please check the settings in Options Window 1 before continuing! Preferably, also check the BootLoader Options Window.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()

    def RefreshMainWindow(self,msg):
        #Refresh the main window to reflect changes in the options, or after a restart.
        logger.debug("Refreshing MainWindow...")
            
        #Bootloader options. Also check if the partition table or boot sector are to be restored
        if BootLoader == "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True:
            self.DisableBLOptsGrubLegacy()
        else:
            self.EnableBLOptsNoGrubLegacy()

        #Set settings up how they were when MainWindow was hidden earlier, if possible.
        if BootLoader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.reinstblcb.SetValue(ReinstallBootLoader)
            self.updateblcb.SetValue(UpdateBootLoader)

        self.chkfscb.SetValue(QuickFSCheck)
        self.badsectcheckcb.SetValue(BadSectCheck)

        #Enable and Disable Checkboxes as necessary
        self.OnCheckBox("Empty arg")

        #Reveal MainWindow
        self.Show()

    def OnAbout(self,e):
        logger.debug("Showing About Box")
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot"
        aboutbox.Version = "1.0~rc4"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = "Utility to quickly fix the bootloader on\na computer"
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.License = "WxFixBoot is released under the GNU GPL v3,and as such has ABSOLUTELY NO WARRANTY.\nYou are allowed to copy, redistribute, and modify this open-source program only if you do so under the terms of the GNU GPL v3.\nFor more information, visit: http://www.gnu.org/licenses/"
        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_CLOSE, self.OnExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        self.Bind(wx.EVT_BUTTON, self.ProgressWindow, self.applyopts)

        #Checkboxes on the main window.
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.reinstblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.updateblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.chkfscb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.badsectcheckcb)

    def SaveMainOpts(self, StartingOps):
        #Save all options here.
        logger.debug("Saving Options on MainWindow...")
        global BootLoaderToInstall
        global BootLoaderDestination
        global BootSectFile
        global RestoreBootSector
        global PartTableFile
        global RestorePartTable
        global ReinstallBootLoader
        global UpdateBootLoader
        global QuickFSCheck
        global BadSectCheck
        global BootLoader

        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
            BadSectCheck = True
        else:
            self.chkfscb.Enable()
            BadSectCheck = False

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
            QuickFSCheck = True
        else:
            self.badsectcheckcb.Enable()
            QuickFSCheck = False

        #Reinstall BootLoader Choicebox
        if self.reinstblcb.IsChecked():
            #Show an info message.
            if StartingOps == False:
                dlg = wx.MessageDialog(self.MainPanel, "Do you want to continue? If you reinstall your bootloader, some options, such as installing a different bootloader, and restoring backups of the bootsector and partition table, will be reset and disabled. If you want to change other settings, you can always do it after restarting wxfixboot.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            else:
                dlg = wx.MessageDialog(self.MainPanel, "Selecting the wrong options can stop your operating system from booting. Do you want to continue?", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_YES:
                ReinstallBootLoader = True

                #Disable some stuff
                BootLoaderToInstall = "None"
                BootLoaderDestination = "None"
                BootSectFile = "None"
                RestoreBootSector = False
                PartTableFile = "None"
                RestorePartTable = False
            else:
                return "Stop"
        else:
            ReinstallBootLoader = False

        #Update BootLoader Choicebox
        if self.updateblcb.IsChecked():
            #Show an info message.
            if StartingOps == False:
                dlg = wx.MessageDialog(None, "Do you want to continue? If you update your bootloader, some options, such as installing a different bootloader, and restoring backups of the bootsector and partition table, will be reset and disabled. If you want to change other settings, you can always do it after restarting wxfixboot.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            else:
                dlg = wx.MessageDialog(self.MainPanel, "Selecting the wrong options can stop your operating system from booting. Do you want to continue?", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_YES:
                UpdateBootLoader = True

                #Disable some stuff
                BootLoaderToInstall = "None"
                BootLoaderDestination = "None"
                BootSectFile = "None"
                RestoreBootSector = False
                PartTableFile = "None"
                RestorePartTable = False
                return "Continue"
            else:
                return "Stop"
        else:
            UpdateBootLoader = False
            return "Continue"
        logger.debug("MainWindow options saved!")

    def OnExit(self,e):
        #Shut down.
        logger.debug("User triggered exit sequence. Exiting...")
        self.Destroy()

#End Main window
#Begin Device Info Window
class DevInfoWindow(wx.Frame):
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Device Information", size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)
        self.ParentWindow = ParentWindow

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", pos=(30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(330,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(70,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitDevInfoDlg)

        logger.debug("Device Info Window Started.")

    def UpdDevInfo(self,e):
        #Generate device data.
        devicelist = GetDevInfo()

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        logger.debug("Device Info Window Closing.")

        #Exit.
        self.Destroy()

#End Device Info Window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):
    def __init__(self, ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Options", size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)
        self.ParentWindow = ParentWindow

        self.CreateButtons()
        self.CreateText()
        self.UpdateBLOptsText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.SetupOptions()
        self.BindEvents()

        #Paint the lines on the Window
        wx.CallLater(200, self.DrawLines, "Empty arg")

        logger.debug("OptionsWindow1 Started.")

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Apply these Settings and Close", pos=(180,320))
        self.blOptsButton = wx.Button(self.OptsPanel1, -1, "View BootLoader Options", pos=(210,260))
        self.restorebootsectbutton = wx.Button(self.OptsPanel1, -1, "Restore Boot Sector", pos=(10,320))
        self.restoreparttablebutton = wx.Button(self.OptsPanel1, -1, "Restore Partition Table", pos=(427,320))

    def CreateText(self):
        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Please give all the settings a once-over", pos=(90,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", pos=(10,50))
        wx.StaticText(self.OptsPanel1, -1, "Installed BootLoader:", pos=(10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", pos=(10,110))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader timeout value:", pos=(10,200))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", pos=(10,220)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", pos=(310,50))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", pos=(340,80))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader To Install:", pos=(30,255))
        wx.StaticText(self.OptsPanel1, -1, "Selected Firmware Type:", pos=(420,255))

    def CreateCBs(self):
        #Basic settings
        self.fullverbosecb = wx.CheckBox(self.OptsPanel1, -1, "Show diagnostic terminal output", pos=(10,140), size=(270,20))
        self.createlogcb = wx.CheckBox(self.OptsPanel1, -1, "Log and save output of all operations", pos=(10,170), size=(270,20))

        #Advanced settings
        self.verifycb = wx.CheckBox(self.OptsPanel1, -1, "Verify Everything after Operations", pos=(340,120), size=(315,20))
        self.makesummarycb = wx.CheckBox(self.OptsPanel1, -1, "Save System Information To File", pos=(340,150), size=(315,20))
        self.bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector", pos=(340,180), size=(250,20))
        self.bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table", pos=(340,210), size=(290,20))

    def CreateChoiceBs(self):
        #Basic settings
        self.defaultoschoice = wx.Choice(self.OptsPanel1, -1, pos=(150,103), size=(140,30), choices=OSList)

        #Advanced settings
        self.rootdevchoice = wx.Choice(self.OptsPanel1, -1, pos=(470,73), choices=["Auto: "+AutoRootDev]+DeviceList)

    def CreateSpinners(self):
        #Basic option here.
        self.bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", pos=(190,197))
        self.bltimeoutspin.SetRange(-1,100)
        self.bltimeoutspin.SetValue(-1)

    def SetupOptions(self):
        #Load all Options here.
        logger.debug("Setting up options in OptionsDlg1...")
        #Boot Loader Time Out
        self.bltimeoutspin.SetValue(BootLoaderTimeOut)

        #Checkboxes
        #Create Log checkbox.
        if CreateLog == True:
            self.createlogcb.SetValue(True)
        else:
            self.createlogcb.SetValue(False)

        #Diagnostic output checkbox.
        if FullVerbose == True:
            self.fullverbosecb.SetValue(True)
        else:
            self.fullverbosecb.SetValue(False)

        #Verify checkbox
        if Verify == True:
            self.verifycb.SetValue(True)
        else:
            self.verifycb.SetValue(False)

        #Backup Boot Sector CheckBox
        if BkpBootSect == True:
            self.bkpbootsectcb.SetValue(True)
        else:
            self.bkpbootsectcb.SetValue(False)

        #Backup Partion Table CheckBox
        if BackupPartTable == True:
            self.bkpparttablecb.SetValue(True)
        else:
            self.bkpparttablecb.SetValue(False)

        #Use Chroot checkBox
        if MakeSystemSummary == True:
            self.makesummarycb.SetValue(True)
        else:
            self.makesummarycb.SetValue(False)

        if EFISYSP == "None":
            self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+AutoBootLoader, 'GRUB-LEGACY', 'GRUB-MBR', 'LILO-MBR'])
        else:
            self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+AutoBootLoader, 'GRUB-LEGACY', 'GRUB-MBR', 'GRUB-EFI', 'LILO-MBR', 'LILO-EFI'])

        #Installed BootLoader
        if BootLoader != AutoBootLoader:
            self.instblchoice.SetStringSelection(BootLoader)

        #Default OS
        self.defaultoschoice.SetStringSelection(DefaultOS)
        
        #Root Device
        if RootDev != AutoRootDev:
            self.rootdevchoice.SetStringSelection(RootDev)

        if RestoreBootSector == True or RestorePartTable == True:
            #Disable some options.
            self.blOptsButton.Disable()
            self.instblchoice.Disable()

            #Reset some settings.
            global BootLoaderToInstall
            global BootLoaderDestination
            BootLoaderToInstall = "None"
            BootLoaderDestination = "None"
        else:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()

        if ReinstallBootLoader == True or UpdateBootLoader == True:
            self.blOptsButton.Disable()
            self.restorebootsectbutton.Disable()
            self.restoreparttablebutton.Disable()

        logger.debug("Options in OptionsDlg1 setup!")

    def DrawLines(self,e):
        #Create some border lines on the panel.
        logger.debug("OptionsWindow1.().DrawLines() has been triggered.")
        dc = wx.PaintDC(self.OptsPanel1)
        dc.DrawLine(0, 67, 600, 67)
        dc.DrawLine(315, 67, 315, 245)
        dc.DrawLine(0, 245, 600, 245)
        dc.DrawLine(0, 300, 600, 300)

    def UpdateBLOptsText(self):
        #Set up the Device Context first.
        logger.debug("Updating Bootloader Options text in OptionsDlg1...")
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        font = self.OptsPanel1.GetFont()
        dc = wx.WindowDC(self.OptsPanel1)
        dc.SetFont(font)

        #Do the BootLoader to install text first.
        width, height = dc.GetTextExtent(BootLoaderToInstall)
        try:
            self.BootLoaderToInstallText
        except: pass
        else:
            self.BootLoaderToInstallText.Destroy()
        finally:
            self.BootLoaderToInstallText = wx.StaticText(self.OptsPanel1, -1, BootLoaderToInstall, pos=((200-int(width))/2,275), size=(int(width),int(height)))

        #Do the FWTypeText now.
        width, height = dc.GetTextExtent(FWType)
        try:
            self.FWTypeText
        except: pass
        else:
            self.FWTypeText.Destroy()
        finally:
            self.FWTypeText = wx.StaticText(self.OptsPanel1, -1, FWType, pos=(((200-int(width))/2)+395,275), size=(int(width),int(height)))

        logger.debug("BootLoader Options text in OptionsDlg1 updated!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CloseOpts)
        self.Bind(wx.EVT_BUTTON, self.LaunchblOpts, self.blOptsButton)
        self.Bind(wx.EVT_BUTTON, self.LaunchBootSectWindow, self.restorebootsectbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchPartTableWindow, self.restoreparttablebutton)
        self.Bind(wx.EVT_PAINT, self.DrawLines)

    def LaunchblOpts(self,e):
        #Safeguard program reliability (and continuity) by saving the settings in optionswindow1 first.
        self.SaveOptions("Empty arg")

        #Give some warnings here if needed.
        #Tell the user some options will be disabled if the bootloader is to be reinstalled or updated.
        if ReinstallBootLoader == True or UpdateBootLoader == True:
            wx.MessageDialog(self.OptsPanel1, "Your current bootloader is to be reinstalled/updated, therefore almost all bootloader-related options here will be disabled. If you want to install a different bootloader, please uncheck the reinstall/update bootloader option on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a MBR bootloader on BIOS systems.
        if AutoFWType == "BIOS":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is BIOS. Unless you're sure WxFixBoot has misdetected this, and it's actually UEFI, it's recommended that you install an MBR bootloader, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a EFI boot loader on UEFI systems.
        elif AutoFWType == "UEFI":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is UEFI. Unless you're sure WxFixBoot has misdetected this, and it's actually BIOS, it's recommended that you install an EFI bootloader, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if EFISYSP == "Not Found" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            wx.MessageDialog(self.OptsPanel1, "You have a UEFI Bootloader, but no EFI Partition! Something has gone seriously wrong here! WxFixBoot will not install a UEFI bootloader without an EFI partition (as it's impossible), and those options will now be disabled.", "WxFixBoot - ERROR", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        elif EFISYSP == "Not Found":
            wx.MessageDialog(self.OptsPanel1, "You have no EFI Partition. If you wish to install an EFI bootloader, you'll need to create one first. WxFixBoot will not install a UEFI bootloader without an EFI partition (as it's impossible), and those options will now be disabled.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        wx.MessageDialog(self.OptsPanel1, "Most of the settings in the following dialog do not need to be and shouldn't be touched, with the exception of autodetermining the bootloader, or manually selecting one. The firmware type and partition schemes should not normally be changed. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Open the Firmware Options window
        logger.debug("Starting Options Window 2 (aka BootLoader Options Dlg)...")
        self.Hide()
        OptionsWindow2(self).Show()

    def LaunchBootSectWindow(self,e):
        logger.debug("Starting Restore BootSector dialog...")
        self.Hide()
        RestBootSectorWindow(self).Show()

    def LaunchPartTableWindow(self,e):
        logger.debug("Starting Restore PartTable dialog...")
        self.Hide()
        RestPartTableWindow(self).Show()

    def RefreshOptionsDlg1(self,msg):
        #Check if the partition table or boot sector are to be restored. Ignore NameError errors.
        logger.debug("Refreshing OptionsDlg1...")
        try:
            if RestorePartTable == True or RestoreBootSector == True:
                #Disable some options.
                self.blOptsButton.Disable()
                self.instblchoice.Disable()

                #Reset some settings.
                global BootLoaderToInstall
                global BootLoaderDestination
                global FWType
                BootLoaderToInstall = "None"
                BootLoaderDestination = "None"
                FWType = AutoFWType
            else:
                #Enable some options.
                self.blOptsButton.Enable()
                self.instblchoice.Enable()
        except NameError:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()

        #Setup options again, but destroy a widget first so it isn't duplicated.
        self.instblchoice.Destroy()
        self.SetupOptions()

        #Update the BootLoaderToInstall and FWType text.
        self.UpdateBLOptsText()

        #Show OptionsDlg1.
        self.Show()

        #Paint the lines on the Window again.
        wx.CallLater(200, self.DrawLines, "Empty arg")

    def SaveOptions(self,e):
        #Save all options in this dialog here.
        global CreateLog
        global FullVerbose
        global Verify
        global BkpBootSect
        global BackupPartTable
        global MakeSystemSummary
        global BootLoader
        global PrevBootLoaderSetting
        global DefaultOS
        global RootDev
        global RootFS
        global BootLoaderTimeOut

        logger.info("OptionsWindow1: Saving Options...")
        
        #Checkboxes.

        #Create Log checkbox.
        if self.createlogcb.IsChecked():
            CreateLog = True
        else:
            CreateLog = False
        logger.debug("OptionsWindow1: Saving Options: Value of CreateLog is: "+str(CreateLog))

        #Check FS cb
        if self.fullverbosecb.IsChecked():
            FullVerbose = True
        else:
            FullVerbose = False
        logger.debug("OptionsWindow1: Saving Options: Value of FullVerbose is: "+str(FullVerbose))

        #Remount FS CB
        if self.verifycb.IsChecked():
            Verify = True
        else:
            Verify = False
        logger.debug("OptionsWindow1: Saving Options: Value of Verify is: "+str(Verify))

        #Backup BootSector checkbox.
        if self.bkpbootsectcb.IsChecked():
            BkpBootSect = True
        else:
            BkpBootSect = False
        logger.debug("OptionsWindow1: Saving Options: Value of BkpBootSect is: "+str(BkpBootSect))

        #Backup Partition Table checkbox.
        if self.bkpparttablecb.IsChecked():
            BackupPartTable = True
        else:
            BackupPartTable = False
        logger.debug("OptionsWindow1: Saving Options: Value of BackupPartTable is: "+str(BackupPartTable))

        #Use chroot in operations checkbox
        if self.makesummarycb.IsChecked():
            MakeSystemSummary = True
        else:
            MakeSystemSummary = False
        logger.debug("OptionsWindow1: Saving Options: Value of MakeSystemSummary is: "+str(MakeSystemSummary))

        #ChoiceBoxes
        #Currently Installed BootLoader ChoiceBox
        PrevBootLoaderSetting = BootLoader
        if self.instblchoice.GetSelection() != 0:
            BootLoader = self.instblchoice.GetStringSelection()
        else:
            #Set it to the auto value, using AutoBootLoader
            BootLoader = AutoBootLoader
        logger.debug("OptionsWindow1: Saving Options: Value of BootLoader is: "+BootLoader)

        #Default OS choicebox ***** THIS NEEDS TO HAVE A SYSTEM TO SET THE BOOTLOADER'S DEFAULT OS. THIS CAN BE VERY DIFFICULT *****
        DefaultOS = self.defaultoschoice.GetStringSelection()
        logger.debug("OptionsWindow1: Saving Options: Value of DefaultOS is: "+DefaultOS)

        #Root Filesystem.
        RootFS = self.defaultoschoice.GetStringSelection().split()[-1]
        logger.debug("OptionsWindow1: Saving Options: Value of RootFS is: "+RootFS)

        #Root device ChoiceBox
        if self.rootdevchoice.GetSelection() != 0:
            RootDev = self.rootdevchoice.GetStringSelection()            
        else:
            #Set it to the auto value, in case this has already been changed.
            RootDev = AutoRootDev
        logger.debug("OptionsWindow1: Saving Options: Value of RootDev is: "+RootDev)

        #Spinner
        BootLoaderTimeOut = int(self.bltimeoutspin.GetValue())
        logger.debug("OptionsWindow1: Saving Options: Value of BootLoaderTimeOut is: "+str(BootLoaderTimeOut))

        logger.info("OptionsWindow1: Saved options.")

    def CloseOpts(self,e):
        #Save the options first.
        self.SaveOptions("empty arg")

        #Send a message to mainwindow so it can refresh.
        wx.CallAfter(self.ParentWindow.RefreshMainWindow, "Closed")

        #Exit options window 1.
        logger.debug("OptionsWindow1 is closing. Revealing MainWindow...")
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - BootLoader Options", size=(450,350), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)
        self.ParentWindow = ParentWindow

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

        logger.debug("OptionsWindow2 Started.")

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(355,310))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace UEFI bootloader with BIOS version", pos=(10,200))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace BIOS bootloader with UEFI version", pos=(10,230))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Automatically modify the bootloader", pos=(10,260))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not modify the bootloader", pos=(10,290))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Install BootLoader in:", pos=(140,50))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System", pos=(140,80))
        wx.StaticText(self.OptsPanel2, -1, "On "+RootDev+":", pos=(165,97))
        wx.StaticText(self.OptsPanel2, -1, "BootLoader to install:", pos=(140,120))
        wx.StaticText(self.OptsPanel2, -1, "EFI Partition:", pos=(140,160))
 
    def CreateRadios(self):
        self.fwtyperadioauto = wx.RadioButton(self.OptsPanel2, -1, "Auto: "+AutoFWType, pos=(10,60), style=wx.RB_GROUP)
        self.fwtyperadioEFI = wx.RadioButton(self.OptsPanel2, -1, "EFI/UEFI", pos=(10,90))
        self.fwtyperadioBIOS = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(10,120))

    def CreateChoiceBs(self):
        self.instbldestchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,44), size=(150,30), choices=['Root Device: '+RootDev]+DeviceList)

        #Make sure the right device's partition scheme is used here.
        tempnum = DeviceList.index(RootDev)

        if PartSchemeList[tempnum] == AutoPartSchemeList[tempnum]:
            self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,79), choices=['Auto: '+PartSchemeList[tempnum], 'msdos', 'gpt'])
        else:
            self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,79), choices=['Auto: '+AutoPartSchemeList[tempnum], 'Manual Value: '+PartSchemeList[tempnum], 'msdos', 'gpt'])  
            self.partitiontypechoice.SetSelection(1)     

        if EFISYSP == "Not Found":
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,114), choices=['Auto', 'GRUB-MBR', 'LILO-MBR'])
        else:
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,114), choices=['Auto', 'GRUB-EFI', 'GRUB-MBR', 'LILO-EFI', 'LILO-MBR'])
        self.efisyspchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,152), choices=FatPartitions) 

    def SetDefaults(self):
        logger.debug("Setting up OptionsDlg2...")
        self.efisyspchoice.SetStringSelection(EFISYSP)
        #Check if the dialog has already been run, or if the bootloader setting has changed (so it must discard the setting to avoid errors).
        if BLOptsDlgRun == False or BootLoader != PrevBootLoaderSetting:
            #Use defaults.
            self.bltoinstallchoicelastvalue = "Auto"
            #If bootloader is to be reinstalled, updated, or if an EFI partition isn't available, or if bootloader is grub-legacy, disable some stuff.
            if ReinstallBootLoader == True or UpdateBootLoader == True:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.instbldestchoice.Disable()
                self.bltoinstallchoice.Disable()
                self.unchangedcb.SetValue(True)
            elif EFISYSP == "Not Found":
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.unchangedcb.SetValue(True)
                wx.MessageDialog(self.OptsPanel1, "You don't appear to have an EFI partiion. If you want to install an EFI-enabled bootloader, you'll need to create an EFI partition first. You must manaully select a BIOS (MBR) bootloader now.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
            elif BootLoader == "GRUB-LEGACY":
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
                self.unchangedcb.SetValue(True)
            else:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.unchangedcb.SetValue(True)
                self.fwtyperadioauto.SetValue(True)
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.instbldestchoice.SetSelection(0)
                self.partitiontypechoice.SetSelection(0)
        else:
            #Setup using the previous options.
            global BootLoaderToInstall
            #First do options that will be set even if the current bootloader is to be reinstalled or updated.
            #Set up Firmware Type radio buttons.
            if FWType == AutoFWType:
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
            elif FWType == "BIOS":
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(True)
                self.fwtyperadioauto.SetValue(False)
            elif FWType == "UEFI":
                self.fwtyperadioEFI.SetValue(True)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(False)

            #BootLoader To Install Choice
            if BootLoaderToInstall != "None" and BootLoaderToInstall != "Unknown" and ReinstallBootLoader == False and UpdateBootLoader == False:
                self.instbldestchoice.Enable()
                self.bltoinstallchoice.Enable()
                self.bltoinstallchoice.SetStringSelection(BootLoaderToInstall)
                self.bltoinstallchoicelastvalue = BootLoaderToInstall
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
            elif ReinstallBootLoader == True or UpdateBootLoader == True:
                BootLoaderToInstall = "None"
                self.bltoinstallchoice.SetSelection(0)
                self.bltoinstallchoicelastvalue = "Auto"
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")
                self.instbldestchoice.Disable()
                self.bltoinstallchoice.Disable()
            else:
                self.bltoinstallchoicelastvalue = "None"
                self.bltoinstallchoice.SetSelection(0)
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")

            if ReinstallBootLoader == False and UpdateBootLoader == False:
                #Bootloader Destination choice.
                if BootLoaderDestination == RootDev:
                    self.instbldestchoice.SetSelection(0)
                else:
                    self.instbldestchoice.SetStringSelection(BootLoaderDestination)

        logger.debug("OptionsDlg2 Set up!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CheckOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CheckOpts)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOptsforNoModification, self.unchangedcb)
        self.Bind(wx.EVT_CHOICE, self.BlToInstallChoiceChange, self.bltoinstallchoice)
        self.Bind(wx.EVT_CHOICE, self.EFISysPChoiceChange, self.efisyspchoice) 
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforAutoFW, self.fwtyperadioauto)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforEFIFW, self.fwtyperadioEFI)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforBIOSFW, self.fwtyperadioBIOS)

    def ActivateOptsforAutoFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForAutoFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and UpdateBootLoader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforEFIFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForEFIFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and BootLoader != "GRUB-LEGACY" and UpdateBootLoader == False:
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(True)
            self.BIOStoUEFIcb.Enable()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
        elif BootLoader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforBIOSFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForBIOSFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and BootLoader != "GRUB-LEGACY" and UpdateBootLoader == False:
            self.UEFItoBIOScb.SetValue(True)
            self.UEFItoBIOScb.Enable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
        elif BootLoader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforNoModification(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForNoModification() has been triggered...")
        if self.unchangedcb.IsChecked() and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and UpdateBootLoader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
        elif ReinstallBootLoader == False and UpdateBootLoader == False:
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        else:
            self.unchangedcb.SetValue(True)
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()

    def BlToInstallChoiceChange(self,e):
        logger.debug("OptionsWindow2().BLToInstallChoiceChange() has been triggered...")
        if self.bltoinstallchoice.GetSelection() == 0 and self.bltoinstallchoicelastvalue != self.bltoinstallchoice.GetStringSelection():
            self.bltoinstallchoicelastvalue = self.bltoinstallchoice.GetStringSelection()
            self.unchangedcb.Enable()
            self.unchangedcb.SetValue(True)
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        elif self.bltoinstallchoice.GetSelection() != 0:
            self.bltoinstallchoicelastvalue = self.bltoinstallchoice.GetStringSelection()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.unchangedcb.SetValue(False)
            self.unchangedcb.Disable()

    def EFISysPChoiceChange(self,e):
        global EFISYSP
        logger.debug("OptionsWindow2().EFISysPChoiceChange() has been triggered...")
        if self.efisyspchoice.GetStringSelection() == EFISYSP:
            logger.debug("OptionsWindow2().EFISysPChoiceChange(): No action required, EFISYSP unchanged...")
        elif self.efisyspchoice.GetStringSelection() == "None":
            logger.debug("OptionsWindow2().EFISysPChoiceChange(): EFISYSP changed to None. Disabling EFI Bootloader installation and exiting OptionsWindow2()...")
            EFISYSP = self.efisyspchoice.GetStringSelection()

            dlg = wx.MessageDialog(self.OptsPanel2, "As you have selected no EFI partition, WxFixBoot will disable EFI bootloaders and bring you back to the first options window", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            #Send a message to OptionsDlg1, so it can show itself again.
            wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

            #Exit.
            self.Destroy()

        else:
            logger.debug("OptionsWindow2().EFISysPChoiceChange(): EFISYSP changed! Rescanning for EFI bootloaders and exiting OptionsWindow2()...")
            EFISYSP = self.efisyspchoice.GetStringSelection()
            dlg = wx.MessageDialog(self.OptsPanel2, "You have selected a different EFI Partition. Please wait a few seconds while it is mounted and scanned for bootloaders. If none are found, you will be prompted to enter one manually. After that, you will be returned to the first options window, with any new bootloader settings detected. Any settings you have set here will be ignored and reset, unless you go back and set them again.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
            self.Hide()

            #Check for bootloaders on the suggested EFI partition.
            InitThread(self,False)

    def ShowThreadChoicedlg(self,msg):
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.OptsPanel2, data[0], data[1], data[2:], pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("OptionsWindow1: Result of InitThread choice dlg was: "+dlgResult)

    def UpdateBootLoaderText(self,msg): pass #Dummy function so EFI partition rescanning works.

    def EFIPartitionScanned(self,msg):
        #Okay, the bootloader has been set, either manually or automatically.
        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

        #Exit.
        self.Destroy()

    def CheckOpts(self,e):
        if self.unchangedcb.IsChecked() == False and self.UEFItoBIOScb.IsChecked() == False and self.useAutocb.IsChecked() == False and self.BIOStoUEFIcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0:
            #Do nothing, as settings are invalid.
            logger.error("OptionsWindow2: No options selected, although no modification checkbox is unticked, or invalid options. Won't save options, waitng for user change...")
            wx.MessageDialog(self.OptsPanel2, "Your current selection suggests a modification will take place, but doesn't specify which modification to do! Please select a valid operation (or, alternatively, none).", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        else:
            self.SaveBLOpts()

    def SaveBLOpts(self):
        #Save all selected Operations here.
        global BootLoaderToInstall
        global BootLoaderDestination
        global PrevBootLoaderSetting
        global PartSchemeList
        global BootLoader
        global FWType
        global AutoFWType

        logger.info("OptionsWindow2: Saving Options...")

        templist = ['GRUB-LEGACY', 'GRUB-EFI','GRUB-MBR','LILO-EFI','LILO-MBR']
        
        #Bootloader Destination choice.
        if self.instbldestchoice.GetStringSelection()[0:4] == "Root" or ReinstallBootLoader == True or UpdateBootLoader == True:
            BootLoaderDestination = RootDev
        else:
            BootLoaderDestination = self.instbldestchoice.GetStringSelection()
        logger.debug("OptionsWindow2: Saving Options: Value of BootLoaderDestination is: "+BootLoaderDestination)

        #Partition scheme choice.
        if self.partitiontypechoice.GetStringSelection()[0:6] == "Manual":
            #No action required.
            logger.debug("OptionsWindow2: Saving Options: No Change in any PartScheme values...")
        else:
            #Figure out which entry in PartSchemeList to change and then delete and recreate it using the options in the dlg (msdos, or gpt)
            tempnum = DeviceList.index(RootDev)
            PartSchemeList.pop(tempnum)
            PartSchemeList.insert(tempnum, self.partitiontypechoice.GetStringSelection().split()[-1])
            if self.partitiontypechoice.GetStringSelection()[0:4] != "Auto":
                logger.debug("OptionsWindow2: Saving Options: Changed value of PartScheme for device: "+RootDev+" to: "+PartSchemeList[tempnum])
            else:
                logger.debug("OptionsWindow2: Saving Options: Changed value of PartScheme for device: "+RootDev+" to: "+PartSchemeList[tempnum]+" the default...")

        #Firmware Choice.
        if self.fwtyperadioEFI.GetValue():
            FWType = "UEFI"
        elif self.fwtyperadioBIOS.GetValue():
            FWType = "BIOS"
        else:
            #Use given value
            FWType = AutoFWType
        logger.debug("OptionsWindow2: Saving Options: Value of FWType is: "+FWType)

        #BootLoader to install choice.
        #Offer some warnings here if needed. This is a little complicated.
        if self.bltoinstallchoice.GetStringSelection()[0:4] == "Auto" and ReinstallBootLoader == False:
            #Use autodetect value
            if self.unchangedcb.IsChecked() == False:

                if self.UEFItoBIOScb.IsChecked():

                    if BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI":
                        #Find the BIOS/MBR equivalent to an EFI bootloader.
                        bootloadernum = templist.index(BootLoader)
                        BootLoaderToInstall = templist[bootloadernum+1] 
                    else:
                        #Do nothing, already using BIOS bootloader.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "None"

                elif self.BIOStoUEFIcb.IsChecked():

                    if EFISYSP != "None" and (BootLoader == "GRUB-MBR" or BootLoader == "LILO-MBR"):
                        #Find the EFI/UEFI equivalent to a BIOS bootloader, provided there is an EFI partition.
                        bootloadernum = templist.index(BootLoader)
                        BootLoaderToInstall = templist[bootloadernum-1]
                    elif EFISYSP == "None":
                        #Refuse to install an EFI bootloader, as there is no EFI partition.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader to install requires an EFI partition, which either doesn't exist or has been selected as None. Please create or select an EFI partition to install an EFI bootloader.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "None"
                    else:
                        #Do nothing, already using EFI/UEFI bootloader.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "None"

                elif self.useAutocb.IsChecked():

                    bootloadernum = templist.index(BootLoader)

                    if FWType == "BIOS" and BootLoader != "GRUB-MBR" and BootLoader != "LILO-MBR" and BootLoader != "GRUB-LEGACY":
                        #Find the BIOS/MBR equivalent to an EFI bootloader.
                        BootLoaderToInstall = templist[bootloadernum+1]

                    elif FWType == "UEFI" and BootLoader != "GRUB-EFI" and BootLoader != "LILO-EFI" and BootLoader != "GRUB-LEGACY" and EFISYSP != "None":
                        #Find the EFI/UEFI equivalent to a BIOS bootloader, provided there is an EFI partition, and it isn't GRUB-LEGACY
                        BootLoaderToInstall = templist[bootloadernum-1]

                    elif FWType == "BIOS" and BootLoader == "GRUB-LEGACY":
                        #Recommend GRUB2 for BIOS systems using GRUB-LEGACY
                        dlg = wx.MessageDialog(self.OptsPanel2, 'Seeing as your bootloader is grub legacy, and you use BIOS firmware, the recommended bootloader for your hardware is grub2 (listed as GRUB-MBR), if at least oone of your  operating systems supports it. If you want to install a different bootloader, click no and return to the firmware settings dialog to manually select your bootloader. Click yes to comfirm installing grub2, click no to do nothing.', 'WxFixBoot -- Comfirmation', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
                        if dlg == wx.ID_YES:
                            BootLoaderToInstall = "GRUB-MBR"
                        else:
                            #Do nothing
                            BootLoaderToInstall = "None"

                    elif FWType == "UEFI" and BootLoader == "GRUB-LEGACY":
                        #Suggest GRUB-EFI for UEFI systems using GRUB-LEGACY
                        wx.MessageDialog(self.OptsPanel2, "You have a combination of UEFI firmware and grub legacy. This is an odd combination, and WxFixBoot doesn't know what to do. If you've imaged your HDD from another system, you probably want to install grub-efi manually by returning to the firmware options dialog. If you manually suggested you have grub legacy earlier, please double check. Perhaps you want to install GRUB-EFI? If so, please manually select it in the BootLoader options dlg.", "WxFixBoot - Warning!", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "Unknown"

                    elif FWType == "UEFI" and EFISYSP == "None":
                        #Refuse to install an EFI bootloader, as there is no EFI partition.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader to install requires an EFI partition, which either doesn't exist or has been selected as None. The current bootloader to install has been reset. Please create or select an EFI partition to install an EFI bootloader.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "None"

                    else:
                        #Correct bootloader for firmware type.
                        BootLoaderToInstall = "None"
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            else:

                #Do nothing.
                BootLoaderToInstall = "None"

        elif self.unchangedcb.IsChecked() == False and ReinstallBootLoader == False and UpdateBootLoader == False:
            BootLoaderToInstall = self.bltoinstallchoice.GetStringSelection()
        else:
            BootLoaderToInstall = "None"

        if BootLoaderToInstall == BootLoader:
            BootLoaderToInstall = "None"
            wx.MessageDialog(self.OptsPanel2, "Your current bootloader is the same as the one you've selected to install! Please select 'Reinstall Bootloader' on the Main Window instead.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if BootLoaderToInstall == "LILO-MBR" or BootLoaderToInstall == "LILO-EFI":  
            wx.MessageDialog(self.OptsPanel2, "You've selected/WxFixBoot has autodetermined to use LILO-MBR or LILO-EFI as the bootloader to install! Note: LILO-EFI and LILO-MBR packages don't exist in some Linux Distributions (Redhat, and anything based on it, for example), and both can be a complete pain to set up/maintain. Please do not use either unless you know how to do that. If WxFixBoot recommended either to you, it's recommended to select the equivalent GRUb version: GRUB-EFI for LILO-EFI, GRUB-MBR for LILO-MBR.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        #Avoid an error situation.
        PrevBootLoaderSetting = BootLoader

        logger.debug("OptionsWindow2: Saving Options: Value of BootLoader (which shouldn't have changed since options window 1) is: "+BootLoader)
        logger.debug("OptionsWindow2: Saving Options: Value of BootLoaderToInstall is: "+BootLoaderToInstall)

        self.CloseBLOpts()
        
    def CloseBLOpts(self):
        logger.debug("OptionsWindow2 Closing.")
        #Save that this has been run once, so it can update itself with new info if it's started again.
        global BLOptsDlgRun
        BLOptsDlgRun = True

        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

        #Exit.
        self.Destroy()

#End Options window 2
#Begin Restore Boot Sector Window
#For GPT disks, backup EFI System Partition, and restore with dd.
#For MBR disks, backup with dd if=/dev/sdX of=<somefile> bs=512 count=1 , restore with dd if=<somefile> of=/dev/sdX bs=446 count=1
class RestBootSectorWindow(wx.Frame): #*** THIS NEEDS TO HAVE A WAY OF DETERMINING THE BACKUP TYPE IN THE FINAL VERSION, USE os.stat(filename).st_size, if bigger than 512 bytes (MBR bootsector), it's GPT ***
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Restore a Boot Sector", size=(400,200), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.BootSectPanel = wx.Panel(self)
        self.ParentWindow = ParentWindow

        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.CreateButtons()
        self.BindEvents()

        #Set up the window.
        self.SetupOptions()

        logger.debug("Restore Boot Sector Window Started.")

    def CreateText(self):
        #Create text
        wx.StaticText(self.BootSectPanel, -1, "Easily restore your bootsector here!", pos=(80,10))
        wx.StaticText(self.BootSectPanel, -1, "What type of Boot Sector backup do you have?", pos=(40,40))
        wx.StaticText(self.BootSectPanel, -1, "Backup file:", pos=(40,100))
        wx.StaticText(self.BootSectPanel, -1, "Target Device:", pos=(260,100))

    def CreateRadios(self):
        #Create Radio Buttons
        self.autodetectradio = wx.RadioButton(self.BootSectPanel, -1, "Autodetect", pos=(10,70), style=wx.RB_GROUP)
        self.msdosradio = wx.RadioButton(self.BootSectPanel, -1, "MBR(msdos)", pos=(150,70))
        self.gptradio = wx.RadioButton(self.BootSectPanel, -1, "GUID(gpt)", pos=(290,70))  
        self.autodetectradio.Disable()
        self.msdosradio.SetValue(True)

    def CreateChoiceBs(self):
        #Create ChoiceBoxes
        self.bsfilechoice = wx.Choice(self.BootSectPanel, -1, pos=(10,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])
        self.targetchoice = wx.Choice(self.BootSectPanel, -1 , pos=(230,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])

    def CreateButtons(self):
        #Create Buttons
        self.exitbutton = wx.Button(self.BootSectPanel, -1, "Close and Set Options", pos=(120,160))

    def BindEvents(self):
        #Bind events
        self.Bind(wx.EVT_BUTTON, self.ExitWindow, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitWindow)
        self.Bind(wx.EVT_CHOICE, self.SelectBootSectorImage, self.bsfilechoice)
        self.Bind(wx.EVT_CHOICE, self.SelectTargetDevice, self.targetchoice)

    def SetupOptions(self):
        #Set up the choiceboxes according to the values of the variables.
        #Boot Sector file choice.
        if BootSectFile != "None":
            self.bsfilechoice.Append(BootSectFile)
            self.bsfilechoice.SetStringSelection(BootSectFile)

        #Target device file choice.
        if BootSectorTargetDevice != "None":
            self.targetchoice.Append(BootSectorTargetDevice)
            self.targetchoice.SetStringSelection(BootSectorTargetDevice)

    def SelectBootSectorImage(self,e):
        #Grab Boot Sector Image path.
        #Set up global variables.
        global BootSectFile
        global RestoreBootSector

        BootSectFile = self.bsfilechoice.GetStringSelection()

        #Determine what to do here.
        if BootSectFile == "-- Please Select --":
            BootSectFile = "None"
            RestoreBootSector = False
        elif BootSectFile == "Specify File Path...":
            Dlg = wx.FileDialog(self.BootSectPanel, "Select Boot Sector File...", wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            if Dlg.ShowModal() == wx.ID_OK:
                RestoreBootSector = True
                BootSectFile = Dlg.GetPath()
                self.bsfilechoice.Append(BootSectFile)
                self.bsfilechoice.SetStringSelection(BootSectFile)
            else:
                BootSectFile = "None"
                RestoreBootSector = False
                self.bsfilechoice.SetStringSelection("-- Please Select --")
        else:
            BootSectFile = self.bsfilechoice.GetStringSelection()
            RestoreBootSector = True

    def SelectTargetDevice(self,e):
        #Grab Boot Sector Image path.
        #Set up global variables.
        global BootSectorTargetDevice

        BootSectorTargetDevice = self.targetchoice.GetStringSelection()

        #Determine what to do here.
        if BootSectorTargetDevice == "-- Please Select --":
            BootSectorTargetDevice = "None"
        elif BootSectorTargetDevice == "Specify File Path...":
            Dlg = wx.FileDialog(self.BootSectPanel, "Select Boot Sector File...", wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            if Dlg.ShowModal() == wx.ID_OK:
                BootSectorTargetDevice = Dlg.GetPath()
                self.targetchoice.Append(BootSectorTargetDevice)
                self.targetchoice.SetStringSelection(BootSectorTargetDevice)
            else:
                BootSectorTargetDevice = "None"
                self.targetchoice.SetStringSelection("-- Please Select --")
        else:
            BootSectorTargetDevice = self.targetchoice.GetStringSelection()

    def ExitWindow(self,e):
        logger.debug("Restore Boot Sector Window Closing.")
        global BootSectFile
        global RestoreBootSector
        global BootSectorTargetDevice

        if BootSectFile != "None" and RestoreBootSector != False and BootSectorTargetDevice != "None":
            #Show an info message.
            dlg = wx.MessageDialog(self.BootSectPanel, "Do you want to continue? This operation can cause data loss. Only continue if you are certain you've selected the right target device and backup file, and if the backup was created with WxFixBoot. If you restore a partition table or bootsector, some options, such as installing a different bootloader, and reinstalling/updating your bootloader, will be disabled. Settings such as the new bootloader to install (if any) will also be reset and disabled. If you want to change other settings, you can always restart WxFixBoot afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

        elif BootSectFile != "None" or RestoreBootSector != False or BootSectorTargetDevice != "None":
            wx.MessageDialog(self.BootSectPanel, "You haven't entered all of the required settings! Please either enter all required settings, or none of them, to disable boot sector restoration.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        else:
            dlg = wx.MessageDialog(self.BootSectPanel, "Do you want to exit this Window, without setting any settings (and unsetting current settings)?", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

#End Restore Boot Sector Window
#Begin Restore Partition Table Window
#Use sgdisk for GPT disks, backup with sgdisk -b/--backup=<file> <SOURCEDIRVE>, restore with -l/--load-backup=<file> <TARTGETDEVICE> ***
#Use dd for MBR disks, backup with sfdisk -d /dev/sdX > backup-sdX.sf, restore with sfdisk /dev/sdX < backup-sdX.sf ***
class RestPartTableWindow(wx.Frame): #*** THIS NEEDS TO HAVE A WAY OF DETERMINING THE BACKUP TYPE IN THE FINAL VERSION, USE os.stat(filename).st_size, if bigger than 512 bytes (MBR bootsector), it's GPT ***
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Restore the Partition Table", size=(400,200), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.PartTablePanel = wx.Panel(self)
        self.ParentWindow = ParentWindow

        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.CreateButtons()
        self.BindEvents()

        #Set up the window.
        self.SetupOptions()

        logger.debug("Restore Partition Table Window Started.")

    def CreateText(self):
        #Create text
        wx.StaticText(self.PartTablePanel, -1, "Easily restore your partition table here!", pos=(60,10))
        wx.StaticText(self.PartTablePanel, -1, "What type of partition table backup do you have?", pos=(30,40))
        wx.StaticText(self.PartTablePanel, -1, "Backup file:", pos=(40,100))
        wx.StaticText(self.PartTablePanel, -1, "Target Device:", pos=(260,100))

    def CreateRadios(self):
        #Create Radio Buttons
        self.autodetectradio = wx.RadioButton(self.PartTablePanel, -1, "Autodetect", pos=(10,70), style=wx.RB_GROUP)
        self.msdosradio = wx.RadioButton(self.PartTablePanel, -1, "MBR(msdos)", pos=(150,70))
        self.gptradio = wx.RadioButton(self.PartTablePanel, -1, "GUID(gpt)", pos=(290,70))  
        self.autodetectradio.Disable()
        self.msdosradio.SetValue(True)

    def CreateChoiceBs(self):
        #Create ChoiceBoxes
        self.ptfilechoice = wx.Choice(self.PartTablePanel, -1, pos=(10,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])
        self.targetchoice = wx.Choice(self.PartTablePanel, -1 , pos=(230,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])

    def CreateButtons(self):
        #Create Buttons
        self.exitbutton = wx.Button(self.PartTablePanel, -1, "Close and Set Options", pos=(120,160))

    def BindEvents(self):
        #Bind events
        self.Bind(wx.EVT_BUTTON, self.ExitWindow, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitWindow)
        self.Bind(wx.EVT_CHOICE, self.SelectPartitionTableImage, self.ptfilechoice)
        self.Bind(wx.EVT_CHOICE, self.SelectTargetDevice, self.targetchoice)

    def SetupOptions(self):
        #Set up the choiceboxes according to the values of the variables.
        #Partition Table file choice.
        if PartTableFile != "None":
            self.ptfilechoice.Append(PartTableFile)
            self.ptfilechoice.SetStringSelection(PartTableFile)

        #Target device file choice.
        if PartitionTableTargetDevice != "None":
            self.targetchoice.Append(PartitionTableTargetDevice)
            self.targetchoice.SetStringSelection(PartitionTableTargetDevice)

    def SelectPartitionTableImage(self,e):
        #Get Partition Table Image path.
        #Set up global variables.
        global PartTableFile
        global RestorePartTable

        PartTableFile = self.ptfilechoice.GetStringSelection()

        #Determine what to do here.
        if PartTableFile == "-- Please Select --":
            PartTableFile = "None"
            RestorePartTable = False
        elif PartTableFile == "Specify File Path...":
            dlg = wx.FileDialog(self.PartTablePanel, "Select Partition Table File...", wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            if dlg.ShowModal() == wx.ID_OK:
                RestorePartTable = True
                PartTableFile = dlg.GetPath()
                self.ptfilechoice.Append(PartTableFile)
                self.ptfilechoice.SetStringSelection(PartTableFile)
            else:
                PartTableFile = "None"
                RestorePartTable = False
                self.ptfilechoice.SetStringSelection("-- Please Select --")
        else:
            PartTableFile = self.ptfilechoice.GetStringSelection()
            RestorePartTable = True

    def SelectTargetDevice(self,e):
        #Grab Partition Table Image path.
        #Set up global variables.
        global PartitionTableTargetDevice

        PartitionTableTargetDevice = self.targetchoice.GetStringSelection()

        #Determine what to do here.
        if PartitionTableTargetDevice == "-- Please Select --":
            PartitionTableTargetDevice = "None"
        elif PartitionTableTargetDevice == "Specify File Path...":
            dlg = wx.FileDialog(self.PartTablePanel, "Select Boot Sector File...", wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            if dlg.ShowModal() == wx.ID_OK:
                PartitionTableTargetDevice = dlg.GetPath()
                self.targetchoice.Append(PartitionTableTargetDevice)
                self.targetchoice.SetStringSelection(PartitionTableTargetDevice)
            else:
                PartitionTableTargetDevice = "None"
                self.targetchoice.SetStringSelection("-- Please Select --")
        else:
            PartitionTableTargetDevice = self.targetchoice.GetStringSelection()

    def ExitWindow(self,e):
        logger.debug("Restore Partition Table Window Closing.")
        global PartTableFile
        global RestorePartTable
        global PartitionTableTargetDevice

        if PartTableFile != "None" and RestorePartTable != False and PartitionTableTargetDevice != "None":
            #Show an info message.
            dlg = wx.MessageDialog(self.PartTablePanel, "Do you want to continue? This operation can cause data loss. Only continue if you are certain you've selected the right target device and backup file, and if the backup was created with WxFixBoot. If you restore a partition table or bootsector, some options, such as installing a different bootloader, and reinstalling/updating your bootloader, will be disabled. Settings such as the new bootloader to install (if any) will also be reset and disabled. If you want to change other settings, you can always restart WxFixBoot afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

        elif PartTableFile != "None" or RestorePartTable != False or PartitionTableTargetDevice != "None":
            wx.MessageDialog(self.PartTablePanel, "You haven't entered all of the required settings! Please either enter all required settings, or none of them, to disable boot sector restoration.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        else:
            dlg = wx.MessageDialog(self.PartTablePanel, "Do you want to exit this Window, without setting any settings (and unsetting current settings)?", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

#End Restore Partition Table Window
#Begin Progress Window
class ProgressWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, None, title="WxFixBoot - Operations Progress", size=(400,300), style=wx.CAPTION|wx.MINIMIZE)
        self.ProgressPanel=wx.Panel(self)

        global OutputLog
        OutputLog = ""

        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBars()
        self.BindEvents()

        logger.debug("Progress Window Started.")
        logger.debug("Starting Main Backend Thread...")

        MainBackendThread(self)

    def CreateText(self):
        #Create Text.
        wx.StaticText(self.ProgressPanel, -1, "WxFixBoot is performing operations... Please wait.", pos=(40,10))
        wx.StaticText(self.ProgressPanel, -1, "Current Operation:", pos=(132,40))
        self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, "Initializating...", pos=(140,60))
        wx.StaticText(self.ProgressPanel, -1, "Current Operation Progress:", pos=(100,90))
        wx.StaticText(self.ProgressPanel, -1, "Overall Progress:", pos=(140,160))

    def CreateButtons(self):
        #Create buttons.
        self.ShowOutputButton = wx.ToggleButton(self.ProgressPanel, -1, "Show Terminal output", pos=(245,220))
        self.RestartButton = wx.Button(self.ProgressPanel, -1, "Restart WxFixBoot", pos=(10,220))
        self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(145,260))
        self.RestartButton.Disable()
        self.ExitButton.Disable()

    def CreateProgressBars(self):
        #Create the progress bar for the current operation.
        self.CurrentOpProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,120), size=(380,25))
        self.CurrentOpProgressBar.SetBezelFace(3)
        self.CurrentOpProgressBar.SetShadowWidth(3)
        self.CurrentOpProgressBar.SetValue(0)
        self.CurrentOpProgressBar.Show()

        #Create the progress bar for overall progress.
        self.TotalProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,190), size=(380,25))
        self.TotalProgressBar.SetBezelFace(3)
        self.TotalProgressBar.SetShadowWidth(3)
        self.TotalProgressBar.SetValue(0)
        self.TotalProgressBar.Show()

        #Set up progress monitoring.
        global TotalProgress
        global CurrentProgress

    def ShowThreadYesNodlg(self,msg):
        global dlgResult
        dlg = wx.MessageDialog(self.ProgressPanel, msg, 'WxFixBoot - Question', wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("Progress Window: Result of MainBackendThread yesno dlg was: "+dlgResult)

    def ShowThreadInfodlg(self,msg):
        global dlgClosed
        dlg = wx.MessageDialog(self.ProgressPanel, msg, "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadChoicedlg(self,msg):
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.ProgressPanel, data[0], data[1], data[2:], pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = ""
        logger.debug("Progress Window: Result of MainBackendThread choice dlg was: "+dlgResult)

    def ShowOutput(self,e):
        #This now also works in openbox by resetting the minimum size too, forcing openbox to increase/decrease the size.
        logger.debug("ProgressWindow().ShowOutput() was Toggled to position: "+str(self.ShowOutputButton.GetValue())+", where True = Depressed and vice versa.")
        if self.ShowOutputButton.GetValue() == True:
            #Reset the frame size.
            self.SetMinSize(wx.Size(400,450))

            #Create a text control for output.
            self.OutputBox = wx.TextCtrl(self.ProgressPanel, -1, "", pos=(10,260), size=(380,140), style=wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_WORDWRAP)
            self.OutputBox.SetBackgroundColour((0,0,0))
            self.OutputBox.SetDefaultStyle(wx.TextAttr(wx.WHITE))

            #Populate the outputbox with all the previous output.
            try:
                for line in OutputLog:
                    self.OutputBox.AppendText(line)
            except: pass
 
            #Move ExitButton, while preserving its enabled/disabled status.
            temp = self.ExitButton.Enabled
            self.ExitButton.Destroy()
            self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(306,410))

            if temp == False:
                self.ExitButton.Disable()

            self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)     
        else:
            #Move ExitButton, while preserving its enabled/disabled status.
            temp = self.ExitButton.Enabled
            self.ExitButton.Destroy()
            self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(145,260))

            if temp == False:
                self.ExitButton.Disable()

            self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)

            #Reset the frame size.
            self.SetMinSize(wx.Size(400,300))
            self.SetSize(wx.Size(400,300))
            self.OutputBox.Destroy()

    def UpdateOutputBox(self,msg):
        #Check if outputbox is enabled. Do nothing if it isn't.
        print msg
        try:
            self.OutputBox.GetSelection()
        except: pass
        else:
            self.OutputBox.AppendText(msg)

    def UpdateCurrentProgress(self,msg):
        #Do current progress.
        #Called at various points during operation code.
        self.CurrentOpProgressBar.SetValue(self.CurrentOpProgressBar.GetValue()+int(msg))
        if self.CurrentOpProgressBar.GetValue() == 100:
            self.CurrentOpProgressBar.SetValue(0)
            self.UpdateTotalProgress()

    def UpdateTotalProgress(self):
        #Do total progress.
        #This is called when self.CurrentOpProgressBar reaches 100 (aka full).
        if self.TotalProgressBar.GetValue() < 100:
            self.TotalProgressBar.SetValue(self.TotalProgressBar.GetValue()+100/NoOfOps)

    def UpdateCurrentOpText(self,msg):
        #Calculate length (in pixels) of string given, and then where on the x-axis to place it.
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        font = self.ProgressPanel.GetFont()
        dc = wx.WindowDC(self.ProgressPanel)
        dc.SetFont(font)
        width, height = dc.GetTextExtent(msg)

        #Create the Static Text, if it already exists, delete it.
        try:
            self.CurrentOpText
        except: pass
        else:
            self.CurrentOpText.Destroy()
        finally:
            self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, msg, pos=((400-int(width))/2,60), size=(int(width),int(height)))

    def MainBackendThreadFinished(self,msg):
        self.RestartButton.Enable()
        self.ExitButton.Enable()

    def RestartWxFixBoot(self,e):
        #Restart WxFixBoot
        logger.debug("Restarting WxFixBoot...")
        self.Hide()

        #Reset all settings to defaults, except ones like LiveDisk, which won't change.
        SetDefaults()

        global BootLoader
        global FWType
        global RootFS
        global RootDev
        global DefaultOS
        global PartScheme
        global EFISYSP

        BootLoader = AutoBootLoader
        FWType = AutoFWType
        RootFS = AutoRootFS
        RootDev = AutoRootDev
        DefaultOS = AutoDefaultOS
        PartSchemeList = AutoPartSchemeList
        EFISYSP = AutoEFISYSP

        wx.MessageDialog(self.ProgressPanel, "Okay! WxFixBoot has reset all of its settings. You should now be returned to the Main Window, and everything should be it was when you first started WxFixBoot.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Show MainWindow
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        MainFrame.Show(True)

        #Hide Progress Window.
        self.Destroy()

    def OnExit(self,e):
        #No need to check if operations are running, the button isn't clickable if any are.
        #Shut down.
        logger.debug("User triggered exit sequence. Exiting...")
        self.Destroy()

    def BindEvents(self):
        self.Bind(wx.EVT_TOGGLEBUTTON, self.ShowOutput, self.ShowOutputButton)
        self.Bind(wx.EVT_BUTTON, self.RestartWxFixBoot, self.RestartButton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

#End Progress Window
#Begin Main Backend Thread
class MainBackendThread(Thread):
    def __init__(self,ParentWindow):
        #Start the main part of this thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        self.start()

    def run(self):
        #Do setup
        time.sleep(1)

        #Bin all of this global <var> stuff, when I'm finished with programming this thread. ***
        #Helpful info collected in the startup scripts, and during use of the GUI.
        global LinuxPartList
        global RootFS
        global RootDev
        global LiveDisk
        global OSList
        global FWType
        global PartSchemeList
        global BootLoader
        global EFISYSP
        global ManuallyMountedEFISYSP
        global PartitionListWithFSType

        #Quick operations on the main window.
        global ReinstallBootloader
        global UpdateBootLoader
        global QuickFSCheck
        global BadSectCheck

        #Advanced options in Optionsdlg1
        global FullVerbose
        global Verify
        global BkpBootSect
        global BackupPartTable
        global MakeSystemSummary
        global CreateLog
        global DefaultOS
        global BootLoaderTimeOut

        #Options in BootLoader Options dlg
        global BootLoaderToInstall
        global BootLoaderDestination

        #Options in Restore dlgs
        global RestoreBootSector
        global BootSectFile
        global BootSectorTargetDevice
        global RestorePartTable
        global PartTableFile
        global PartitionTableTargetDevice

        #Log the MainBackendThread start event (in debug mode).
        logger.debug("MainBackendThread() Started. Calculating Operations to do...")

        self.OperationCounter()

    def OperationCounter(self):
        #Count the number of operations to do.
        global NoOfOps
        NoOfOps = 0

        #List to contain operations (and their functions) to run.
        self.OperationsToDo = []

        #Run a series of if loops to determine what operations to do, which order to do them in, and the total number to do.
        #Do essential processes first.
        if RestorePartTable == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.RestorePartitionTable)

        if RestoreBootSector == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.RestoreBootSector)

        if QuickFSCheck == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.QuickFileSystemCheck)

        if BadSectCheck == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.BadSectorCheck)

        if BkpBootSect == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.BackupBootSector)

        if BackupPartTable == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.BackupPartitionTable)

        #Now do other processes
        if BootLoaderToInstall != "None":
            NoOfOps += 1
            self.OperationsToDo.append(self.InstNewBL)

        if ReinstallBootLoader == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.ReInstBL)

        if UpdateBootLoader == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.UpdBootLoader)

        #Log gathered operations to do, and the number (verbose mode, default).
        logger.info("Number of operations: "+str(NoOfOps))
        logger.info("Starting to-be Operation Running Code...")

        self.StartOperations()

    def StartOperations(self):
        #Start doing operations.
        global PerformingOps
        global OutputLog
        OutputLog = []

        self.ShowInfoDlg("The required operations will now be performed. Wait 5 seconds after you see no more activity to enable restarting/exiting wxfixboot.")

        #Run the functions in the autodetermined list, and start operations.
        PerformingOps = True
        OutputBoxThread(self.ParentWindow)
        time.sleep(1)

        #Check if we need to determine the package manager, do so first if needed.
        for element in [self.InstNewBL,self.ReInstBL]:
            if element in self.OperationsToDo:
                self.OperationsToDo.insert(0, self.DeterminePackageManagers)

        #Run functions to do operations. *** Make sure packagemanager-dependant code skips itself if PackageManager or PartitionWithPackageManager equals "None" ***
        for function in self.OperationsToDo:
            function()

        logger.info("Finished Operation Running Code.") 
        time.sleep(2)
        PerformingOps = False
        wx.CallAfter(self.ParentWindow.MainBackendThreadFinished, "Main Backend Thread Finished")

    def ShowInfoDlg(self,msg):
        #Method to handle showing thread message dialogs, reducing code duplication and compilications and errors.
        #Reset dlgClosed, avoiding errors.
        global dlgClosed
        dlgClosed = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadInfodlg, msg)

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

    def ShowYesNoDlg(self,msg):
        #Method to handle showing thread yes/no dialogs, reducing code duplication and compilications and errors.
        #Reset dlgResult, avoiding errors.
        global dlgResult
        dlgResult = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg)

        #Trap the thread until the user responds.
        while dlgResult == "Unknown":
            time.sleep(0.5)

    def ShowChoiceDlg(self,msg):
        #Method to handle showing thread choice dialogs, reducing code duplication and compilications and errors.
        while True:
            #Reset dlgResult, avoiding errors.
            global dlgResult
            dlgResult = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg)

            #Trap the thread until the user responds.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            if dlgResult == "Clicked no..." or dlgResult == "":
                self.ShowInfoDlg("Please make a valid selection.")
            else:
                break

    def ShowTextEntryDlg(self,msg):
        #Method to handle showing thread text entry dialogs, reducing code duplication and compilications and errors.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            if dlgAnswer == "":
                self.ShowInfoDlg("Please enter a value or click cancel.")
            else:
                break

    def DeterminePackageManagers(self):
        global PackageManager
        global PartitionWithPackageManager
        global OSList
        OSListWithPackageManagers = []
        #Determine all the package managers on the system, including all OSes and the OS running, but not the live disk.
        #Use OSList to find all partitions with Linux OSes on them.
        #Start of for loop.
        for OS in OSList:
            #Get the partition that each OS is on.
            OSPartition = OS.split()[-1]

            #If not on a live disk, check if this OS is the one running.
            if LiveDisk == False:
                if OSPartition == RootFS:
                    try:
                        #Run a command in chroot to determine the Package Manager
                        #Check for APT
                        subprocess.check_output(["apt-get", "-h"])
                    except:
                        #Okay, no APT for this OS, look for YUM instead.
                        try:
                            subprocess.check_output(["yum", "-h"])
                        except:
                            #Couldn't find a package manager!
                            #Strange, add nothing to OSListWithPackageManagers, and ignore this OS.
                            pass
                        else:
                            #Found YUM!
                            #Add it and the OS to the list of candidates.
                            OSListWithPackageManagers.append(OS+" with Package Manager YUM")
                    else:
                        #Found APT!
                        #Add it and the OS to the list of candidates.
                        OSListWithPackageManagers.append(OS+" with Package Manager APT")
                #Skip the rest of the for loop.
                continue

            #Mount the device safely, using the global mount function.
            retstr = MountDeviceSafely(OSPartition, "/mnt"+OSPartition)

            #Check if anything went wrong.
            if retstr != "Succeeded":
                #Probably already mounted on a very old linux kernel, just ignore it, as it's safer to do so.
                logger.warning("Main Backend Thread: DeterminePackageManagers: Command: 'mount "+OSPartition+" /mnt/"+OSPartition+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer using a very old linux kernel.")
            else:
                try:
                    #Run a command in chroot to determine the Package Manager
                    #Check for APT
                    subprocess.check_output(["chroot", "/mnt"+OSPartition, "apt-get", "-h"])
                except:
                    #Okay, no APT for this OS, look for YUM instead.
                    try:
                        subprocess.check_output(["chroot", "/mnt"+OSPartition, "yum", "-h"])
                    except:
                        #Couldn't find a package manager of YUM or APT!
                        #Strange, add nothing to OSListWithPackageManagers, and ignore this OS.
                        pass
                    else:
                        #Found YUM!
                        #Add it and the OS to the list of candidates.
                        OSListWithPackageManagers.append(OS+" with Package Manager YUM")
                else:
                    #Found APT!
                    #Add it and the OS to the list of candidates.
                    OSListWithPackageManagers.append(OS+" with Package Manager APT")

        #Check if there are any candidates. Hopefully there are!
        if OSListWithPackageManagers == []:
            #Oh dear... There aren't.
            logger.error("Main Backend Thread: DeterminePackageManagers: Couldn't find an OS with a supported package manager of YUM or APT! Will have to disable some operations!")
            self.ShowInfoDlg("Sorry! No supported package managers could be found on any of your operating systems! At the moment, YUM and APT are supported, which covers the majority of Linux Operating Systems. WxFixBoot will have to skip some operations that require a package manager, such as installing/reinstalling the bootloader.")

            #Set these to "None", so the packagemanager-dependant code can skip itself.
            PackageManager = "None"
            PartitionWithPackageManager = "None"
        elif len(OSListWithPackageManagers) == 1:
            #Good, there is one candidate, use it.
            logger.info("Main Backend Thread: DeterminePackageManagers: Using: "+OSListWithPackageManagers[0]+" for options requiring a package manager.")
            self.ShowInfoDlg("The OS: "+OSListWithPackageManagers[0]+" will be used for operations requiring a package manager.")
            PackageManager = OSListWithPackageManagers[0].split()[-1]
            PartitionWithPackageManager = OSPartition
        else:
            #Very good! There are many (more than one) candidates
            logger.info("Main Backend Thread: DeterminePackageManagers: Found many candidates for options requiring a package manager. Asking the user...")

            #Ask the user which one to use.
            self.ShowChoiceDlg("Please select the OS you'd like to use to do options requiring a package manager, such as reinstalling/installing a bootloader.\nIdeally, select the one that installed the bootloader (probaby the most recently installed OS).&WxFixBoot - Select OS&"+'&'.join(OSListWithPackageManagers))

            #Use the user's suggestion.
            logger.info("Main Backend Thread: DeterminePackageManagers: Using: "+dlgResult+" for options requiring a package manager.")
            PackageManager = dlgResult.split()[-1]
            PartitionWithPackageManager = OSPartition

    def FindMissingFSCKModules(self): # ** FIX THIS
        #Function to check for and return all missing fsck modules (fsck.vfat, fsck.minix, etc), based on the FS types in PartitionListWithFSType.
        logger.debug("Main Backend Thread: self.FindMissingFSCKModules(): Looking for missing FSCK modules to ignore...")
        templist = []

        for FSType in PartitionListWithFSType:
            #Check if we're looking at a FSType, not a device, and that we've not marked it "Ignore" aka "Unknown". Otherwise ignore it.
            if FSType[0] != "/" and FSType != "Ignore":
                try:
                    runcmd = subprocess.Popen(["fsck."+FSType], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    stdout, stderr = runcmd.communicate()
                except OSError:
                    #OS probably couldn't find it, add it to the list.
                    templist.append("fsck."+FSType)
                else:
                    if str(stderr) != "None":
                        #It did, add it to the failed list.
                        templist.append("fsck."+FSType)
                    else:
                        #It didn't, don't add it to the list.
                        pass

        #Return the list, so FSCheck functions know which FSes to ignore.
        return templist

    def RestorePartitionTable(self):
        #Use sgdisk for GPT disks, backup with sgdisk -b/--backup=<file> <SOURCEDIRVE>, restore with -l/--load-backup=<file> <TARTGETDEVICE> ***
        #Use dd for MBR disks, backup with sfdisk -d /dev/sdX > backup-sdX.sf, restore with sfdisk /dev/sdX < backup-sdX.sf ***
        pass

    def RestoreBootSector(self):
        #For GPT disks, backup EFI System Partition, and restore with dd.
        #For MBR disks, backup with dd if=/dev/sdX of=<somefile> bs=512 count=1 , restore with dd if=<somefile> of=/dev/sdX bs=446 count=1
        pass

    def QuickFileSystemCheck(self): #Needs refactoring, combine parts of this and BadSectorCheck **
        #Function to quickly check all filesystems.
        logger.debug("Main Backend Thread: Starting self.QuickFileSystemCheck...")
        global PartitionListWithFSType

        #Get a list of missing fsck modules (if any) based on the existing filesystems.
        MissingFSCKModules = self.FindMissingFSCKModules()

        for Partition in PartitionListWithFSType:
            time.sleep(0.5)
            #Make sure we're looking at a Device, if not, ignore it.
            if Partition[0] == "/":
                #We are looking at a partition. 
                #Find the FSType (the next element)
                FSType = PartitionListWithFSType[PartitionListWithFSType.index(Partition)+1]

                #Check if the required fsck module is present, and that the partition isn't RootFS *** In future, list partitions that won't be checked and show the user.
                if "fsck."+FSType not in MissingFSCKModules and FSType != "Ignore" and Partition != RootFS:
                    #It is! Check if the partition is mounted.
                    try:
                        temp = subprocess.check_output("df | grep "+Partition, shell=True).split()[-1]
                    except subprocess.CalledProcessError:
                        #Nothing mounted there. Set stderr here to avoid errors.
                        stderr = "(None, '')"
                        
                    else:
                        #Remount the FS readonly temporarily, to avoid data corruption.
                        runcmd = subprocess.Popen("mount -o remount,ro "+Partition+" >> /tmp/wxfixboot/termoutput.txt", stderr=subprocess.PIPE, shell=True)
                        stderr = runcmd.communicate()

                    #Check that this worked okay.
                    if str(stderr) != "(None, '')":
                        #It didn't, for some strange reason. ** In future, show the user a warning, with the error message.
                        print str(stderr)
                    else:

                        #Run an fsck command that works with MOST filesystems. *** In future, check for filesystems that don't support it, and write special code for them ***
                        runcmd = subprocess.Popen("fsck."+FSType+" -yv "+Partition+" >> /tmp/wxfixboot/termoutput.txt", stderr=subprocess.PIPE, shell=True)
                        stderr = runcmd.communicate()

                        #Check that this worked okay.
                        if str(stderr) != "(None, '')":
                            #It didn't, for some strange reason. ** In future, show the user a warning, with the error message.
                            pass
  
                        #Remount the FS read-write again.
                        runcmd = subprocess.Popen("mount -o remount,rw "+Partition+" >> /tmp/wxfixboot/termoutput.txt", stderr=subprocess.PIPE, shell=True)
                        stderr = runcmd.communicate()

                        #Check that this worked okay.
                        if str(stderr) != "(None, '')":
                            #It didn't, for some strange reason. ** In future, show the user a warning, with the error message.
                            pass
                    
    def BadSectorCheck(self):
        #Function to check all filesystems for bad sectors.
        logger.debug("Main Backend Thread: Starting self.BadSectorCheck...")
        global PartitionListWithFSType

        #Get a list of missing fsck modules (if any) based on the existing filesystems.
        MissingFSCKModules = self.FindMissingFSCKModules()

        for Partition in PartitionListWithFSType:
            time.sleep(0.5)
            #Make sure we're looking at a Device, if not, ignore it.
            if Partition[0] == "/":
                #We are looking at a partition. 
                #Find the FSType (the next element)
                FSType = PartitionListWithFSType[PartitionListWithFSType.index(Partition)+1]

                #Check if the required fsck module is present, and that the partition isn't RootFS *** In future, list partition that won't be checked and show the user.
                if "fsck."+FSType not in MissingFSCKModules and FSType != "Ignore" and Partition != RootFS:
                    #It is! Check if the partition is mounted.
                    try:
                        temp = subprocess.check_output("df | grep "+Partition, shell=True).split()[-1]
                    except subprocess.CalledProcessError:
                        #Nothing mounted there.
                        pass
                    else:
                        #Remount the FS readonly temporarily, to avoid data corruption.
                        runcmd = subprocess.Popen("mount -o remount,ro "+Partition+" >> /tmp/wxfixboot/termoutput.txt", stderr=subprocess.PIPE, shell=True)
                        stderr = runcmd.communicate()

                    #Check that this worked okay.
                    if str(stderr) != "(None, '')":
                        #It didn't, for some strange reason. ** In future, show the user a warning, with the error message.
                        print str(stderr)
                    else:

                        #Run an fsck command that works with ONLY DOS/VFAT filesystems. *** In future, check for filesystems that don't support it, and write special code for them ***
                        runcmd = subprocess.Popen("fsck."+FSType+" -yvt "+Partition+" >> /tmp/wxfixboot/termoutput.txt", stderr=subprocess.PIPE, shell=True)
                        stderr = runcmd.communicate()

                        #Check that this worked okay.
                        if str(stderr) != "(None, '')":
                            #It didn't, for some strange reason. ** In future, show the user a warning, with the error message.
                            pass
  
                        #Remount the FS read-write again.
                        runcmd = subprocess.Popen("mount -o remount,rw "+Partition+" >> /tmp/wxfixboot/termoutput.txt", stderr=subprocess.PIPE, shell=True)
                        stderr = runcmd.communicate()

                        #Check that this worked okay.
                        if str(stderr) != "(None, '')":
                            #It didn't, for some strange reason. ** In future, show the user a warning, with the error message.
                            pass

    def BackupBootSector(self):
        #Function to backup the bootsector.
        pass

    def BackupPartitionTable(self):
        #Function to backup the partition table.
        pass

    # *** FUNCTIONS TO MODIFY BOOTLOADERS START HERE ***
    def InstNewBL(self):
        #Function to install a new bootloader.
        #Check which bootloader is currently installed, and remove it.
        if BootLoader == "GRUB-LEGACY":
            self.RemoveGRUBLEGACY()
        elif BootLoader == "GRUB-MBR":
            self.RemoveGRUBMBR()
        elif BootLoader == "LILO-MBR":
            self.RemoveLILOMBR()
        elif BootLoader == "GRUB-EFI":
            self.RemoveGRUBEFI()
        elif BootLoader == "LILO-EFI":
            pass

        #Check which bootloader is to be installed.
        if BootLoaderToInstall == "GRUB-MBR":
            pass #Install package grub-pc and os-prober (Ubuntu or Debian, and derivatives, APT-GET -y), or grub2.$(uname -p) and os-prober.$(uname -p) (Fedora, Redhat, and derivatives, YUM -y)
        elif BootLoaderToInstall == "LILO-MBR":
            pass #Install package lilo (Ubuntu or Debian, and derivatives, APT-GET -y), doesn't exist in fedora/redhat, then run liloconfig, modify config file to suit needs, and finally /sbin/lilo to install to MBR. Don't bother with initramfs, it doesn't work, but if possible do use UUIDs.
        elif BootLoaderToInstall == "GRUB-EFI":
            pass #Install package grub-efi and os-prober (Ubuntu or Debian, and derivatives, APT-GET -y), or grub2-efi.$(uname -p) (Fedora, Redhat, and derivatives, YUM -y), NOT grub-efi.$(uname -p), as it's GRUB-LEGACY EFI! Mount efi partition, specify dir for efi partition with --efi-directory.
        elif BootLoaderToInstall == "LILO-EFI":
            pass #Install package elilo (Ubuntu or Debian, and derivatives, APT-GET -y), doesn't exist in Fedora/redhat, unmount efi partition, run elilo -b <efisyspartion> --autoconf to setup, check config, then elilo -b <efisyspartition>. Specify UUID to kernel for root partition using lsblk -o NAME,UUID, specify initrd/initramfs in file. Look for /initrd.img and /vmlinuz for each OS and add manually. If either /vmlinuz or /initrd.img doesn't exist use find /boot -iname '*init* '*vmlinu*' to find the latest versions of each in /boot and warn user of manual updating with kernel updates.

    def RemoveGRUBLEGACY(self):
        #Function to remove the archaic GRUB-LEGACY
        pass #Remove packages grub and grub-legacy-doc and grub-common (Ubuntu/Debian, and derivatives, APT-GET -y), doesn't exist in Fedora, and should be autoremoved on old versions anyway.

    def RemoveGRUBMBR(self):
        #Function to remove GRUB2
        pass #Remove packages grub-pc and grub-pc-bin and grub-common (Ubuntu/Debian, and derivatives, APT-GET -y), or grub2.$(uname -p)  (Fedora, Redhat, and derivatives, YUM -y), but not centos (doesn't exist).

    def RemoveLILOMBR(self):
        #Function to remove lilo
        pass #Remove packages lilo (Ubuntu/Debian, and derivatives, APT-GET -y), doesn't exist in fedora/redhat.

    def RemoveGRUBEFI(self):
        #Function to remove GRUB-EFI.
        pass #Remove packages grub-efi, grub-efi-amd64, grub-efi-amd64-bin, grub-efi-ia32, grub-efi-ia32-bin (Ubuntu/Debian, and derivatives, APT-GET -y), or grub-efi.$(uname -p), grub2-efi.$(uname -p)

    def RemoveLILOEFI(self):
        #Function to remove LILO-EFI
        pass #Remove package elilo (Ubuntu/Debian, and derivatives, APT-GET -y), doesn't exist in Fedora/redhat.

    def ReInstBL(self):
        #Function to reinstall the bootloader
        #Check which bootloader is to be reinstalled.
        pass
    
    def UpdBootLoader(self):
        #Function to update bootloader menu
        pass

    # *** FUNCTIONS TO MODIFY BOOTLOADERS END HERE ***
#End Main Backend Thread
#Begin Output Box Management Thread.
class OutputBoxThread(Thread):
    def __init__(self,ParentWindow):
        #Start the main part of this thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        self.start()

    def run(self):  
        logger.debug("OutputBoxThread() Started.")
        lastoutputfilecontents = "None"
        global OutputLog
        global PerformingOps
        while PerformingOps == True:
            logger.debug("OutputBoxThread in While Loop. Expect to see this for a while.")
            try:
                outputfile = open('/tmp/wxfixboot/termoutput.txt')
                outputfilecontents = outputfile.readlines()
            except:
                #Skip the rest of the loop
                time.sleep(0.1)
                continue

            #Only do anything if the contents are different from the last time
            if outputfilecontents[-20:] != lastoutputfilecontents:
                #Check how many new lines (max 20) to send to the outputbox.
                for elementnum in range(-20,0):
                    try:
                        lastoutputfilecontents.index(outputfilecontents[elementnum])
                    except IndexError: pass #Ignore, as it occours with short output files less than 20 lines long.
                    except ValueError as e:
                        logger.debug("OutputBoxThread: Expected error ValueError traceback: "+str(e))
                        #Include all lines newer and including this one.
                        for line in outputfilecontents[elementnum:]:
                             logger.info("OutputBoxThread: Command output: "+line)
                             OutputLog.append(line)
                             wx.CallAfter(self.ParentWindow.UpdateOutputBox, line)
                        break
                    else:
                        pass

                lastoutputfilecontents = outputfilecontents[-20:]
                time.sleep(0.1)

            outputfile.close()
            time.sleep(0.5)

        logger.debug("OutputBoxThread() Terminated and Finished...")

#End Output Box Management Thread
app = WxFixBoot(False)
app.MainLoop()
