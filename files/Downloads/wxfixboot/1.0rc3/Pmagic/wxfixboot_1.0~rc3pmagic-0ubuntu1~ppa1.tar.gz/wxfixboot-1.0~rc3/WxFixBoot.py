#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 1.0rc3
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# This program is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
from __future__ import division
import wx
import sys
from wx.lib.wordwrap import wordwrap
from wx.lib.pubsub import Publisher
from threading import Thread
import time
import os
import shutil
import subprocess
import logging
import getopt

def usage():
    print "\nUsage: WxFixBoot.py [OPTION]\n"
    print "       -h, --help:                   Show this help message"
    print "       -q, --quiet:                  Show only warning, error and critial messages in the log file."
    print "       -v, --verbose:                The default setting when no options are passed. Enable logging of info messages, as well as warnings, errors and critical errors."
    print "       -d, --debug:                  Log lots of very boring debug messages, usually used for diagnostic purposes, may result in very large log files\n"
    print "WxFixBoot is released under the GNU GPL Version 3"
    print "Copyright (C) Hamish McIntyre-Bhatty 2013-2014"

#If this isn't running as root, relaunch
if not os.geteuid()==0:
    subprocess.Popen(["/usr/share/wxfixboot/runasroot.sh"])
    sys.exit("\nSorry, this program must be run with root privileges.\nRestarting as Root...")

#Set up logging.
logger = logging.getLogger('WxFixBoot')
logging.basicConfig(filename='/var/log/wxfixboot.log', format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
logger.setLevel(logging.INFO)

#Set up according to cmdline options.
try:
    opts, args = getopt.getopt(sys.argv[1:], "hqvd", ["help", "quiet", "verbose", "debug"])
except getopt.GetoptError as err:
    #Invalid option. Show the help message and then exit.
    #Show the error.
    print str(err)
    usage()
    sys.exit(2)

#Determine the option given.
for o, a in opts:
    if o in ("-q", "--quiet"):
        logger.setLevel(logging.WARNING)
    elif o in ("-v", "--verbose"):
        logger.setLevel(logging.INFO)
    elif o in ("-d", "--debug"):
        logger.setLevel(logging.DEBUG)
    elif o in ("-h", "--help"):
        usage()
        sys.exit()
    else:
        assert False, "unhandled option"

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen(["/usr/share/wxfixboot/listdevices.sh"]).wait()

    #Create/Update a device list
    devicelist = []

    #New more efficent way of putting everything in one list.
    with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
        idedevicesfile = idedevicessource.readlines()
        if idedevicesfile != []:
            devicelist = devicelist + idedevicesfile
            devicelist.append('IDE/ATA Devices:')

    with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
        cddvddevicesfile = cddvddevicessource.readlines()
        if cddvddevicesfile != []:
            devicelist.append('CD/DVD Devices:')
            devicelist = devicelist + cddvddevicesfile

    with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
        usbsatadevicesfile = usbsatadevicessource.readlines()
        if usbsatadevicesfile != []:
            devicelist.append('USB or SATA Devices:')
            devicelist = devicelist + usbsatadevicesfile

    #Remove newline chars.
    return [(el.strip()) for el in devicelist]

def SetDefaults():
    #Options in MainWindow
    global ReinstallBootLoader
    global UpdateBootLoader
    global QuickFSCheck
    global BadSectCheck
    ReinstallBootLoader = False
    UpdateBootLoader = False 
    QuickFSCheck = False
    BadSectCheck = False

    #Options in Optionsdlg1
    global CreateLog
    global FullVerbose
    global Verify
    global BkpBootSect
    global BackupPartTable
    global UseChroot
    global BootLoaderTimeOut

    #Set them up for default settings.
    CreateLog = True
    FullVerbose = False
    Verify = True
    BkpBootSect = True
    BackupPartTable = True
    UseChroot = True
    BootLoaderTimeOut = -1 #Don't change the timeout by default.

    #Options in Bootloader Options dlg
    global BootLoaderToInstall
    global BootLoaderDestination
    global BLOptsDlgRun
    BootLoaderToInstall = "None"
    BootLoaderDestination = "None"
    BLOptsDlgRun = False

    #Options in Restore dlgs
    global RestoreBootSector
    global BootSectFile
    global RestorePartTable
    global PartTableFile
    RestoreBootSector = False
    BootSectFile = "None"
    RestorePartTable = False
    PartTableFile = "None"

#Starter Class
class WxFixBoot(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = "/usr/share/wxfixboot/splash.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

        #Make sure it's painted, which fixes the problem with the previous temperamental splash screen on DDRescue-GUI <= 1.2
        wx.Yield()

    def OnExit(self,e):
        #Start the init Frame.
        self.Hide()
        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True

            #Reset the top window and start InitFrame()
            InitFrame = InitialWindow()
            app.SetTopWindow(InitFrame)
            InitFrame.Show(True)

            #Skip the event so the init frame starts.
            e.Skip()

#End splash screen
#Begin Initialization frame
class InitialWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc3 is preparing to start...",size=(400,300),style=wx.CAPTION)
        self.InitPanel = wx.Panel(self)

        print "WxFixBoot Version 1.0~rc3 development Starting..."
        logger.warn("WxFixBoot Version 1.0~rc3 development Starting...")
        logger.warn("Do not use this on ANY production machine!")

        dlg = wx.MessageDialog(None, "Welcome to WxFixBoot Version 1.3rc3! As this is a development version, please check the log file at '/var/log/wxfixboot.log' for any errors. There is also debug output included if the --debug or -d options are passed on the commandline. This version isn't fully tested, and rprobably shouldn't be used in anything except a VM to prevent data loss (unless you're feeling brave!). Please click no to close the program if you aren't running this in a VM.", "WxFixBoot - Warning", style=wx.YES_NO | wx.ICON_ERROR, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
            wx.Exit()
            sys.exit("User aborted the program.")

        #Create GUI elements
        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBar()

        #Set up threading
        self.InitPublisher()

        #Start the Initalization Thread, which performs all necessary startup scripts and checks.
        logger.debug("Starting Initial thread...")
        InitThread()       

    def CreateText(self):
        self.DependsCheckText = wx.StaticText(self.InitPanel, -1, "Dependency check...", pos=(10,20))
        self.MountFSText = wx.StaticText(self.InitPanel, -1, "Mounting all Filesystems...", pos=(10,40))
        self.DetectPartText = wx.StaticText(self.InitPanel, -1, "Detecting Linux Partitions...", pos=(10,60))
        self.RootFSText = wx.StaticText(self.InitPanel, -1, "Determining Root Filesystem...", pos=(10,80))
        self.DetectOSesText = wx.StaticText(self.InitPanel, -1, "Detecting Linux OSes...", pos=(10,100))
        self.FWTypeText = wx.StaticText(self.InitPanel, -1, "Determining Firmware Type...", pos=(10,120))
        self.PartSchemeText = wx.StaticText(self.InitPanel, -1, "Determining Partition Scheme...", pos=(10,140))
        self.BootLoaderText = wx.StaticText(self.InitPanel, -1, "Determining Boot Loader...", pos=(10,160))
        self.UnmountFSText = wx.StaticText(self.InitPanel, -1, "Unmounting Filesystems...", pos=(10,180))
        self.CheckFSText = wx.StaticText(self.InitPanel, -1, "Quickly Checking Filesystems...", pos=(10,200))
        self.FinalCheckText= wx.StaticText(self.InitPanel, -1, "Final check...", pos=(10,220))

    def CreateButtons(self):
        #Create a button.
        self.startbutton = wx.Button(self.InitPanel, -1, "Start", pos=(150,235), size=(100,30))
        self.startbutton.Disable()

        #Bind it to an event here.
        self.Bind(wx.EVT_BUTTON, self.FinishedInitConf, self.startbutton)

    def CreateProgressBar(self):
        #Create a progressbar.
        self.InitProgressBar = wx.Gauge(self.InitPanel, -1, 100, pos=(10,270), size=(380,25))
        self.InitProgressBar.SetBezelFace(3)
        self.InitProgressBar.SetShadowWidth(3)
        self.InitProgressBar.SetValue(0)
        self.InitProgressBar.Show()

    def InitPublisher(self):
        #Update the progressbar when asked.
        Publisher().subscribe(self.UpdateProgressBar, "progressbarupdate")

        #Respond to dialog messages.
        Publisher().subscribe(self.ShowThreadYesNodlg, "showyesnodlg")
        Publisher().subscribe(self.ShowThreadInfodlg, "showinfodlg")
        Publisher().subscribe(self.ShowThreadChoicedlg, "showchoicedlg")
        Publisher().subscribe(self.ShowThreadTextEntrydlg, "showtextentrydlg")

        #Update the text on the main GUI when asked.
        Publisher().subscribe(self.UpdateDependsCheckText, "DependsUpdate")
        Publisher().subscribe(self.UpdateMountFSText, "MountFSUpdate")
        Publisher().subscribe(self.UpdateDetectPartText, "LinuxPartUpdate")
        Publisher().subscribe(self.UpdateDetectOSesText, "LinuxOSesUpdate")
        Publisher().subscribe(self.UpdateRootFSText, "RootFSUpdate")
        Publisher().subscribe(self.UpdateFWTypeText, "FWTypeUpdate")
        Publisher().subscribe(self.UpdatePartSchemeText, "PartSchemeUpdate")
        Publisher().subscribe(self.UpdateBootLoaderText, "BootLoaderUpdate")
        Publisher().subscribe(self.UpdateUnmountFSText, "UnmountFSUpdate")
        Publisher().subscribe(self.UpdateCheckFSText, "CheckFSUpdate")
        Publisher().subscribe(self.UpdateFinalCheckText, "FinalCheckUpdate")

    def UpdateProgressBar(self,msg):
        self.InitProgressBar.SetValue(int(msg.data))

    def ShowThreadYesNodlg(self,msg):
        global dlgResult
        dlg = wx.MessageDialog(None, msg.data, 'WxFixBoot - Question', wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("Init Window: Result of InitThread yesno dlg was: "+dlgResult)

    def ShowThreadInfodlg(self,msg):
        global dlgClosed
        dlg = wx.MessageDialog(None, msg.data, "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadChoicedlg(self,msg):
        global dlgResult
        data = msg.data.split('&')
        dlg = wx.SingleChoiceDialog(None, data[0], data[1], data[2:], pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("Init Window: Result of InitThread choice dlg was: "+dlgResult)

    def ShowThreadTextEntrydlg(self,msg):
        global dlgAnswer
        dlg = wx.TextEntryDialog(None, msg.data, "WxFixBoot - Text Entry", "", style=wx.OK|wx.CANCEL, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetValue()
        else:
            dlgAnswer = "Clicked no..."
        logger.debug("Init Window: Result of InitThread text entry dlg was: "+dlgAnswer)

    def UpdateDependsCheckText(self,msg):
        self.DependsCheckText.SetLabel(msg.data)

    def UpdateMountFSText(self,msg):
        self.MountFSText.SetLabel(msg.data)

    def UpdateDetectPartText(self,msg):
        self.DetectPartText.SetLabel(msg.data) 

    def UpdateDetectOSesText(self,msg):
        self.DetectOSesText.SetLabel(msg.data) 

    def UpdateRootFSText(self,msg):
        self.RootFSText.SetLabel(msg.data)

    def UpdateFWTypeText(self,msg):
        self.FWTypeText.SetLabel(msg.data)

    def UpdatePartSchemeText(self,msg):
        self.PartSchemeText.SetLabel(msg.data)

    def UpdateBootLoaderText(self,msg):
        self.BootLoaderText.SetLabel(msg.data)

    def UpdateUnmountFSText(self,msg):
        self.UnmountFSText.SetLabel(msg.data)

    def UpdateCheckFSText(self,msg):
        self.CheckFSText.SetLabel(msg.data)

    def UpdateFinalCheckText(self,msg):
        self.FinalCheckText.SetLabel(msg.data)
        self.startbutton.Enable()

    def FinishedInitConf(self,e):
        logger.info("Closing Initial Window and Starting Main Window...")
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        self.Destroy()
        MainFrame.Show(True)    

#End Initalization Frame
#Begin Initaization Thread.
class InitThread(Thread):
    def __init__(self):
        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it.
        #However, only delete it if no partitions are mounted in it. This has been done before during testing. Otherwise exit.
        try:
            subprocess.check_output("mount | grep '/tmp/wxfixboot'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            if os.path.exists("/tmp/wxfixboot"):
                shutil.rmtree("/tmp/wxfixboot")
                logger.debug("Cleared wxfixboot's temporary folder. Most of the time this doesn't need to be done.")
            os.mkdir("/tmp/wxfixboot")
        else:
            logger.critical("ERROR: Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage. Exiting now...")
            wx.Exit()
            sys.exit("ERROR! Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage.")

        #Initialize and start the thread.
        Thread.__init__(self)
        logger.debug("Started Init Thread...")
        self.start()

    def run(self):
        #Set some default settings and wait for the GUI to initialize.
        logger.debug("Initial Thread: Setting up global variables...")

        #Wait.
        time.sleep(1)

        #Check for dependencies
        logger.info("Initial Thread: Checking For Dependencies...")
        self.CheckDepends()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "10")
        logger.info("Initial Thread: Done Checking For Dependencies!")

        #Mount all filesystems.
        logger.info("Initial Thread: Mounting Filesystems...")
        self.MountAllFS()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "20")
        logger.info("Initial Thread: Done Mounting Filsystems!")

        #Detect Linux Partitions.
        logger.info("Initial Thread: Detecting Linux Filesystems...")
        self.DetectLinuxPartitions()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "30")
        logger.info("Initial Thread: Finished Detecting Linux Filesystems!")
  
        #Get the root filesystem.
        logger.info("Initial Thread: Determining Root Filesystem...")
        self.GetRootFS()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "40")
        logger.info("Initial Thread: Determined Root Filesystem as: "+RootFS)

        #Get a list of Linux OSes (if LiveDisk = True, this has already been run).
        logger.info("Initial Thread: Finding Linux OSes...")
        if LiveDisk == False:
            self.GetLinuxOSes()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "50")
        logger.info("Initial Thread: Found all Linux OSes. Default: "+DefaultOS)

        print "InitThread: Default Operating system: "+DefaultOS

        #Get the firmware type.
        logger.info("Initial Thread: Determining Firmware Type...")
        self.GetFirmwareType()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "60")
        logger.info("Initial Thread: Determined Firmware Type as: "+FWType)

        #Get the root device's partition scheme (GPT/MBR)
        logger.info("Initial Thread: Determining Partition type (GPT/MBR)")
        self.GetRootDevPartScheme()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "70")
        logger.info("Initial Thread: Partition Type is: "+PartScheme)

        #Get the BootLoader.
        logger.info("Initial Thread: Determining The BootLoader...")
        self.GetBootLoader()
        global BootLoader
        BootLoader = AutoBootLoader
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "80")
        logger.info("Initial Thread: BootLoader is: "+BootLoader)

        #Attempt unmount of all filesystems.
        logger.info("Initial Thread: Unmounting Filesystems...")
        self.UnmountAllFS()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "90")
        logger.info("Initial Thread: Unmounted Filesystems!")

        #Check filesystems.
        logger.info("Initial Thread: Checking Filesystems...")
        self.CheckFS()
        wx.CallAfter(Publisher().sendMessage, "progressbarupdate", "100")
        logger.info("Initial Thread: Filesystems Checked!")

        #Perform final check.
        logger.info("Initial Thread: Doing Final Check for error situations...")
        self.FinalCheck()
        time.sleep(2)
        logger.info("Initial Thread: Done Final Check!")
        logger.info("Initial Thread: Finished Determining Settings. Exiting Initial Thread...")

    def CheckDepends(self):
        #This is a dependency checking function, will will show a message and kill the app if the dependencies are not met.
        #Create a temporary list to allow wxfixboot to notify of particular unmet dependencies.
        templist = ['mount', '-V', 'umount', '-V', 'parted' ,'-v', 'lsb_release', '-v', 'dmidecode', '-V', 'grep', '-V', 'lsblk', '--help', 'df', '--version', 'chroot', '--version', 'dd', '--version', 'find', '--version']

        #Create a list to contain names of failed commands.
        failedlist = []
        for command in templist:
            #If the command doeas not start with '-', run it as it isn't just a argument.
            if command[0] != "-":
                argument = templist[templist.index(command)+1]
                try:
                    #Run the command and log the output (if in debug mode)
                    runcmd = subprocess.Popen([command, argument], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    stdout, stderr = runcmd.communicate()
                    logger.debug("Initial Thread: Dependency check: Command: "+command+" stdout: "+str(stdout)+", stderr: "+str(stderr))
                except (subprocess.CalledProcessError, OSError) as e:
                    logger.error("Initial Thread: Dependency problems! Command: "+command+" failed to execute or wasn't found.")
                    logger.error("Initial Thread: The error was: "+str(e))
                    failedlist.append(command)

        #Check if any commands failed.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("Initial Thread: Dependencies missing! WxFixBoot will exit. The missing dependencies are: "+', '.join(failedlist)+"Exit.")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "The following dependencies were not found on your system: "+', '.join(failedlist)+"\nPlease install the missing dependencies. WxFixBoot will now exit.")
            wx.Exit()
            sys.exit("Missing dependencies: "+', '.join(failedlist)+" Exiting...")
        else:
            wx.CallAfter(Publisher().sendMessage, "DependsUpdate", "Dependency check... Passed!")

    def MountAllFS(self):
        global dlgClosed
        dlgClosed = "Unknown"

        #Warn about removing devices.
        wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Please now remove all unnecessary devices connected to your computer, and then click okay.")

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

        #Mount everything in /etc/fstab
        runcmd = subprocess.Popen(['mount', '-a'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        stdout, stderr = runcmd.communicate()
        logger.debug("Initial Thread: MountAllFS: Command: 'mount -a' stdout: "+str(stdout)+", stderr: "+str(stderr))
        
        logger.debug("Initial Thread: 'mount -a' ran fine, continuing...")

        wx.CallAfter(Publisher().sendMessage, "MountFSUpdate", "Mounting all Filesystems... Done")

    def DetectLinuxPartitions(self):
        #Get a list of partitions of type ext (2,3 or 4) / btrfs / xfs / jfs / zfs. Quite a lot huh!
        global PartitionListWithFSType
        global LinuxPartList
        global DeviceList
        try:
            templist = []
            templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'ext\|btrfs\|xfs\|jfs\|zfs'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()
        except subprocess.CalledProcessError as e:
            #There are none, exit.
            logger.critical("No Linux Partitions of type ext(1,2,3,4), btrfs, xfs, jfs or zfs found!")
            logger.critical("The error was: "+str(e)+". Exiting...")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "You don't appear to have any Linux partitions. The supported filesystems are ext (any version), btrfs, xfs, jfs and zfs. If you do have Linux partitions, but wxfixboot hasn't found them, please file a bug or ask a question on wxfixboot's launchpad page. If you're using Windows or Mac OS X, then sorry as wxfixboot has no support for non-Linux operating systems and bootloaders, and you could instead use the tools provided by Microsoft and Apple to fix issues with your computer. WxFixBoot will now exit.")
            Wx.Exit()
            sys.exit("Fatal! No supported Linux filesystems found. Will now exit...")
        LinuxPartList = []

        #Check if there are any linux partitions.
        if templist == []:
            #There are none, exit.
            logger.critical("No Linux Partitions of type ext(1,2,3,4), btrfs, xfs, jfs or zfs found! Exiting...")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "You don't appear to have any Linux partitions. The supported filesystems are ext (any version), btrfs, xfs, jfs and zfs. If you do have Linux partitions, but wxfixboot hasn't found them, please file a bug or ask a question on wxfixboot's launchpad page. If you're using Windows or Mac OS X, then sorry as wxfixboot has no support for non-Linux operating systems and bootloaders, and you could instead use the tools provided by Microsoft and Apple to fix issues with your computer. WxFixBoot will now exit.")
            Wx.Exit()
            sys.exit("Fatal! No supported Linux filesystems found. Will now exit...")

        #Create a list of the partitions.
        for element in templist:
            if element[-4:-2] == 'sd' or element[-4:-2] == 'hd':
                LinuxPartList.append('/dev/'+element)

        logger.debug("Initial Thread: LinuxPartList Populated okay. Contents: "+' '.join(LinuxPartList))

        #Create a list for the devices.
        DeviceList = []

        #Create a list for the partitions.
        PartitionListWithFSType = []

        templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep -v 'NAME'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()

        #Populate the device list, and the Partition List including FS Type.
        for element in templist:
            #Check if the element is a device, and doesn't end with a digit (isn't a partition).
            if (element[-3:-1] == 'sd' or element[-3:-1] == 'hd') and element[-1].isdigit() == False:
                try:
                    #Check if the element is already in the list.
                    DeviceList.index(element[-3:])
                except ValueError:
                    #It isn't, add it.
                    DeviceList.append('/dev/'+element[-3:])
                else:
                    #It is, ignore it.
                    pass
            #If instead the partition is not a device, but instead a partition of any type, add it to the Partition List.
            elif (element[-4:-2] == 'sd' or element[-4:-2] == 'hd') and element[-1].isdigit() == True:
                PartitionListWithFSType.append('/dev/'+element[-4:])

        logger.debug("Initial Thread: DeviceList and PartitionListWithFSType Populated okay. Contents (respectively): "+' '.join(DeviceList)+" and: "+' '.join(PartitionListWithFSType)) 

        wx.CallAfter(Publisher().sendMessage, "LinuxPartUpdate", "Detecting Linux Partitions... Done")

    def GetRootFS(self):
        #Determine RootFS
        #Setup some global vars
        global dlgResult
        global dlgClosed
        global AutoRootFS
        global RootFS
        global AutoRootDev
        global RootDev
        global LiveDisk
        global DefaultOS
        global AutoDefaultOS
        dlgResult = "Unknown"
        dlgClosed = "Unknown"

        wx.CallAfter(Publisher().sendMessage, "showyesnodlg", "Is WxFixBoot being run on a live disk, such as Parted Magic?")

        #Trap the thread until the user answers.
        while dlgResult == "Unknown":
            time.sleep(0.5)
        
        if dlgResult == "Yes":
            logger.warning("Initial Thread: User reported WxFixBoot is on a live disk...")
            LiveDisk = True
            dlgResult = "Unknown"

            #Make an early call to GetLinuxOSes()
            self.GetLinuxOSes()

            #Create a temporary list from OSList
            templist = []
            for element in OSList:
                templist.append("&"+element)

            #Avoid an error by resetting this here.
            dlgResult = "Unknown"

            #'&' seperates elements in a list that will be created in the display method.
            wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "Please select the Linux Operating System you normally boot.&WxFixBoot - Select Operating System"+' '.join(templist))

            #Trap the thread until the diaog is dismissed.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            if dlgResult == "Clicked no..." or dlgResult == "":
                logger.critical("Initial Thread: User didn't select a default Linux Operating System! The RootFS cannot be determined; Cannot continue; Exiting...")
                wx.Exit()
                sys.exit("No RootFS selected. Exiting...")
            else:
                logger.info("Initial Thread: User selected default Linux OS of: "+dlgResult+". Continuing...")
                DefaultOS = dlgResult
                AutoDefaultOS = DefaultOS
                RootFS = dlgResult.split()[-1]
                AutoRootFS = RootFS
                RootDev = RootFS[0:8]
                AutoRootDev = RootDev 
                LiveDisk = True
                wx.CallAfter(Publisher().sendMessage, "RootFSUpdate", "Determining Root Filesystem... Success: "+RootFS)
        else:
            logger.warning("Initial Thread: User reported WxFixBoot isn't on a live disk...")
            RootFS = subprocess.check_output("df -k / | grep -v 'Filesystem'", shell=True).split()[0]
            AutoRootFS = RootFS
            RootDev = RootFS[0:8]
            AutoRootDev = RootDev
            LiveDisk = False
            wx.CallAfter(Publisher().sendMessage, "RootFSUpdate", "Determining Root Filesystem... Success: "+RootFS)

    def GetLinuxOSes(self):
        #Get the names of all Linux OSes on the HDDs.
        global dlgAnswer
        global dlgResult
        dlgAnswer = "Unknown"
        dlgResult = "Unknown"
        global OSList
        global DefaultOS
        global AutoDefaultOS
        OSList = []

        #Get Linux OSes.
        logger.debug("Initial Thread: Populating OSList...")
        for element in LinuxPartList:
            #Reset the Skip value to False.
            Skip = False

            if LiveDisk == False:
                #Only check if a partition equals the root partiton if not running from a live disk.

                if element == RootFS:
                    #The element is the root partition, tell the next if loop to not run.
                    Skip = True
                    try:
                        #Run the command to get the OS.
                        currentoslist = subprocess.check_output(["lsb_release", "-d"]).split()
                        currentos = ' '.join(currentoslist[1:])
                    except:
                        currentos = self.AskForOS(element)
                        if currentos == "None":
                            pass
                        else:
                            #Add this information to the OSList, and set it as the default OS
                            DefaultOS = currentos+' (Current) on device '+RootFS
                            AutoDefaultOS = DefaultOS
                            OSList.append(currentos+' (Current) on device '+RootFS)

                    else:
                        #Add this information to the OSList, and set it as the default OS
                        DefaultOS = currentos+' (Current) on device '+RootFS
                        AutoDefaultOS = DefaultOS
                        OSList.append(currentos+' (Current) on device '+RootFS)

            if element[0:7] == "/dev/sd" or element[0:7] == "/dev/hd":
                #We're interested in this element, because it's an HDD or usb disk partition.
                #Go back to the start if this has already been determined as RootFS
                if Skip == True:
                    continue

                #Make a temporary mountpoint in /mnt, to keep out of the way of any OS running.
                os.makedirs("/mnt"+element)
    
                #Mount the device to the mount point.
                subprocess.Popen(["mount", element, "/mnt"+element]).wait()

                try:
                    #Run a command in chroot to determine the OS
                    elementoslist = subprocess.check_output(["chroot", "/mnt"+element, "lsb_release", "-d"]).split()
                    elementos = ' '.join(elementoslist[1:])
                except:
                    elementos = self.AskForOS(element)
                    if elementos == "None":
                        pass
                    else:
                        #Add this information to the OSList
                        OSList.append(elementos+' on device '+element)
                else:
                    #Add this information to the OSList
                    OSList.append(elementos+' on device '+element)
                finally:
                    #Clean up.
                    Skip = None

                    #Unmount the filesystem.
                    time.sleep(0.2)
                    subprocess.check_output(["umount", "/mnt"+element])

                    #Remove the temporary mountpoint
                    os.rmdir("/mnt/"+element)

        logger.debug("Initial Thread: OSList Populated okay. Contents: "+' '.join(OSList))

        wx.CallAfter(Publisher().sendMessage, "LinuxOSesUpdate", "Detecting Linux OSes... Done")

    def AskForOS(self,element):
        #Reset dlgResult and dlgAnswer to avoid errors.
        global dlgResult
        global dlgAnswer
        dlgResult = "Unknown"
        dlgAnswer = "Unknown"

        #This might not be a Linux Operating System, or it might be a very old one.
        wx.CallAfter(Publisher().sendMessage, "showyesnodlg", "One of the detected Linux partitions, "+element+", doesn't appear to contain a recent Linux operating system.\nClick no to confirm this. If you believe it does contain a  recent Linux operating system, click yes.")

        #Trap the thread until the diaog is dismissed.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        if dlgResult == "No":
            logger.debug("Initial Thread: User reported no Linux OS in "+element)
            #User reported no OS in this partition, ignore it.
            return "None"
        else:
            logger.debug("Initial Thread: User reported Linux OS in "+element+". Asking name of OS...")
            #User reported that an OS is here.
            wx.CallAfter(Publisher().sendMessage, "showtextentrydlg", "Please enter the name of the operating system that is on "+element+".\nIf this is an old Linux distribution, it's better to click no here and ignore it for safety reasons.\nThe name you specify will be listed in the options dialog.")

            #Trap the thread until the diaog is dismissed.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            if dlgAnswer == "Clicked no...":
                logger.debug("Initial Thread: User reported old or or no OS in "+element+". Continuing...")
                #User reported no OS (or old OS) in this partition, ignore it.
                return "None"
            else:
                return dlgAnswer

    def GetFirmwareType(self):
        #Get the firmware type.
        global FWType
        global AutoFWType
        global EFIVars

        #Initialize EFIVars to prevent an error on BIOS systems.
        EFIVars = "None"

        try:
            subprocess.check_output("dmidecode -q | grep 'UEFI'", shell=True)
        except subprocess.CalledProcessError:
            logger.info("Initial Thread: Detected Firmware Type as BIOS...")
            FWType = "BIOS"
            AutoFWType = "BIOS"
        else:
            logger.info("Initial Thread: Detected Firmware Type as UEFI. Looking for EFI Variables...")
            FWType = "UEFI"
            AutoFWType = "UEFI"

            #Also, look for EFI variables.
            if os.path.exists("/sys/firmware/efi/vars"):
                EFIVars = True
            elif os.path.exists("/sys/firmware/efi/efivars"):  
                EFIVars = True
            else:
                logger.warning("Initial Thread: EFI vars not found in /sys/firmware/efi/vars or /sys/firmware/efi/efivars. Attempt manual mount...")
                #Attempt to manually mount the efi vars.
                try:
                    if not os.path.exists("/sys/firmware/efi/vars"):
                        os.mkdir("/sys/firmware/efi/vars")
                    subprocess.check_output(['mount', '-t', 'efivarfs', 'efivarfs', '/sys/firmware/efi/vars'])
                    EFIVars = True
                    logger.debug("Initial Thread: Mounted EFI Variables at: /sys/firmware/efi/vars. Continuing...")
                except (OSError, subprocess.CalledProcessError) as e:
                    logger.warning("Initial Thread: Failed to mount EFI vars! Warning user. Ignoring and continuing.")
                    #EFI vars not available or couldn't be mounted.
                    wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your computer uses EFI firmware, but the efi variables couldn't be mounted or weren't found. Please insure you've booted in EFI mode rather than legacy or CSM mode to enable access to the EFI variables. You can attempt installing an EFI bootloader without them, but it may not work as expected, and isn't recommended.")

        wx.CallAfter(Publisher().sendMessage, "FWTypeUpdate", "Determining Firmware Type... Success: "+AutoFWType)

    def GetRootDevPartScheme(self):
        #Get the partition type on the given Root Device.
        global PartScheme
        global AutoPartScheme
        PartScheme = subprocess.check_output("parted "+RootDev+" print | grep 'Partition Table'", shell=True).split()[2]
        AutoPartScheme = PartScheme
        wx.CallAfter(Publisher().sendMessage, "PartSchemeUpdate", "Determining Partition Scheme... Success: "+AutoPartScheme)

    def GetBootLoader(self):
        global dlgResult
        global BootLoader
        global AutoBootLoader
        global PrevBootLoaderSetting
        global EFISYSP
        global ManuallyMountedEFISYSP
        global OSList
        PrevBootLoaderSetting = "None"
        EFISYSP = "None"
        ManuallyMountedEFISYSP = "None"

        #Determine the current bootloader. 
        #Run some inital scripts
        logger.debug("Initial Thread: Copying MBR bootsector to /tmp/wxfixboot/mbrbootsect...")
        runcmd = subprocess.Popen("dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect", stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
        stdout, stderr = runcmd.communicate()
        logger.debug("Initial Thread: GetBootLoader: Command: 'dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect' stdout: "+str(stdout)+", stderr: "+str(stderr))
        
        logger.debug("Initial Thread: Copied MBR bootsector to file.")

        #Wrap this in a loop, so once a BootLoader is found, searching can stop.
        while True:
            #Check for BIOS/CSM bootloaders here.
            #Check for GRUB in the MBR
            logger.debug("Initial Thread: Checking for GRUB in bootsector...")
            AutoBootLoader = self.CheckForGRUBMBR()
            if AutoBootLoader == "GRUB-MBR":
                #Ask if user is using grub-legacy. ********************* UPDATE: CHECK THIS AUTOMATICALLY USING GRUB-INSTALL --VERSION *******************
                dlgResult = "Unknown"

                wx.CallAfter(Publisher().sendMessage, "showyesnodlg", "Is "+OSList[0]+" using grub legacy? If you're running a recent operating system, you're probably using grub2. If you are using grub legacy, you must click yes, and you will be unable to reinstall grub legacy, as WxFixBoot doesn't fully support it. You may install other bootloaders, provided your operating system supports them.")

                #Trap the thread until the diaog is dismissed.
                while dlgResult == "Unknown":
                    time.sleep(0.5)

                if dlgResult == "Yes":
                    AutoBootLoader = "GRUB-LEGACY"
                    logger.warning("Initial Thread: User reported that GRUB in MBR is GRUB-LEGACY! Some options will be disabled, as grub legacy isn't fully supported as it is obsolete. Continuing...")
                else:
                    logger.debug("Initial Thread: User reported that GRUB in MBR is GRUB2 (Shown as GRUB-MBR in GUI). Continuing...")
                    AutoBootLoader = "GRUB-MBR"

                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Check for LILO in MBR
            logger.debug("Initial Thread: Checking for LILO in bootsector...")
            AutoBootLoader = self.CheckForLILOMBR()
            if AutoBootLoader == "LILO-MBR":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Check for an EFI system partition.
            logger.debug("Initial Thread: Checking For an EFI Partition...")
            EFISYSP = self.CheckForEFIPartition()

            #If there is no EFI partition, exit now.
            if EFISYSP[0:7] != "/dev/sd" and EFISYSP[0:7] != "/dev/hd":
                #There is no EFI partition.
                #Do a manual selection of bootloader.
                logger.warning("Initial Thread: Asking user what the bootloader is, as neither GRUB nor LILO was detected in MBR, and no EFI partition was found...")
                AutoBootLoader = self.ManualBootLoaderSelect()
                #The program exits if nothing was chosen, so if it executes this, the bootloader has been set.
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Mount (or skip if mounted) the EFI partition.
            logger.info("Initial Thread: Attempting to mount the EFI partition (if it isn't already)...")
            EFISYSPMountPoint = self.MountEFIPartition(EFISYSP)
            logger.info("Initial Thread: EFI Partition mounted at: "+EFISYSPMountPoint+". Continuing to look for EFI bootloaders...")

            #Attempt to figure out which bootloader is present.
            #Check for GRUB-EFI
            logger.debug("Initial Thread: Checking for GRUB-EFI in EFI Partition...")
            AutoBootLoader = self.CheckForGRUBEFI(EFISYSPMountPoint)
            if AutoBootLoader == "GRUB-EFI":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Check for ELILO
            logger.debug("Initial Thread: Checking for LILO-EFI (ELILO) in EFI Partition...")
            AutoBootLoader = self.CheckForLILOEFI(EFISYSPMountPoint)
            if AutoBootLoader == "LILO-EFI":
                wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+AutoBootLoader)
                break

            #Obviously, no bootloader has been found.
            #Do a manual selection.
            logger.warning("Initial Thread: Asking user what the bootloader is, as no bootloader was found...")
            AutoBootLoader = self.ManualBootLoaderSelect()

            #The program exits if nothing was chosen, so if it executes this, the bootloader has been set.
            wx.CallAfter(Publisher().sendMessage, "BootLoaderUpdate", "Determining Boot Loader... Success: "+AutoBootLoader)
            break

    def CheckForGRUBMBR(self):
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'GRUB'", shell=True).replace('\n', '') #*** This could be done in pure python ***
        except subprocess.CalledProcessError:
            temp = "NULL"

        if temp == "Binary file (standard input) matches":
            #BootLoader is GRUB MBR
            return "GRUB-MBR"
        else:
            return "Not GRUB MBR"

    def CheckForLILOMBR(self):
        #Check for LILO in MBR
        try:
            temp = subprocess.check_output("cat /tmp/wxfixboot/mbrbootsect | grep 'LILO'", shell=True).replace('\n', '')
        except subprocess.CalledProcessError:
            temp = "NULL"

        if temp == "Binary file (standard input) matches":
            #BootLoader is LILO in MBR
            return "LILO-MBR"
        else:
            return "Not LILO MBR"

    def CheckForEFIPartition(self):
        global dlgResult
        dlgResult = "Unknown"
        if LiveDisk == False:
            try:
                EFISYSP = "/dev/"+subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep '/boot'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
            except subprocess.CalledProcessError:
                try:
                    logger.warning("Initial Thread: Failed to find the EFI Partition. Trying another way...")
                    #Try a second way to get the EFI system partition.
                    EFISYSP = subprocess.check_output("lsblk -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep 'ESP'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').split()[0]
                except subprocess.CalledProcessError:
                    #Ask the user where it is.
                    logger.warning("Initial Thread: Couldn't autodetermine EFI Partition. Asking the user instead...")
                    AskForEFIPartition = True
                else:
                    logger.debug("Initial Thread: Found EFI Partition at: "+EFISYSP)
                    return EFISYSP
            else:
                logger.info("Initial Thread: Found EFI Partition at: "+EFISYSP)
                return EFISYSP

        if LiveDisk == True or AskForEFIPartition == True:
            logger.warning("Initial Thread: Asking user where EFI Partition is. If you're running from a live disk, ignore this warning.")
            #Get a list of partitions of type vfat (if no fat partition are available, give up looking for an EFI Partition.
            try:
                templist = subprocess.check_output("lsblk -o NAME,FSTYPE | grep 'vfat'", shell=True).replace('\xe2\x94\x9c\xe2\x94\x80',' ').replace('\n','').split()
            except: templist = []

            #Create another list of only the devices.
            templist2 = []
            for element in templist:
                if element[0:2] == "sd" or element[0:2] == "hd":
                    templist2.append("&/dev/"+element)
                else:
                    #We aren't interested, as this is probably a listing for the FS type.
                    pass

            if templist2 != []:
                #'&' seperates elements in a list that will be created in the display method.
                wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "Please select your EFI partition. Click no if you don't have an EFI partition.&WxFixBoot - Select EFI Partition"+' '.join(templist2))

                #Trap the thread until the diaog is dismissed.
                while dlgResult == "Unknown":
                    time.sleep(0.5)

                if dlgResult == "Clicked no...":
                    logger.warning("Initial Thread: User said no EFI Partition exists. Continuing...")
                    return "Not Found"
                else:
                    logger.debug("Initial Thread: User reported EFI partition at: "+dlgResult+". Continuing...")
                    return dlgResult
            else:
                return "Not Found"
                    
    def MountEFIPartition(self,EFISYSP): 
        global ManuallyMountedEFISYSP
        #Get the EFI partition's current mountpoint, if it is mounted.
        try:
            EFISYSPMountPoint = subprocess.check_output("df | grep '"+EFISYSP+"'", shell=True).split()[-1]
        except subprocess.CalledProcessError:
            #It isn't mounted, mount it.
            logger.debug("Initial Thread: Temporarily Mounting EFI Partition at /mnt/efisysp...")
            EFISYSPMountPoint = "/mnt/efisysp"
            os.mkdir(MountPoint)
            subprocess.check_call(['mount', EFISYSP, MountPoint])
            ManuallyMountedEFISYSP = True
            logger.info("Initial Thread: Successfully Mounted EFI Partition...")
        else:
            #It's mounted, so nevermind.
            logger.info("Initial Thread: EFI Partition is already mounted at: "+EFISYSPMountPoint)
            ManuallyMountedEFISYSP = False
        finally:
            return EFISYSPMountPoint

    def CheckForGRUBEFI(self,EFISYSPMountPoint):
        global ManuallyMountedEFISYSP
        #Look for GRUB's EFI file.
        temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*grub*'", shell=True).replace('\n', '')

        #Look for GRUB-EFI.
        if temp != "":
            #Bootloader is GRUB-EFI.
            if ManuallyMountedEFISYSP == True:
                subprocess.call(['umount', EFISYSP])
                ManuallyMountedEFISYSP = None
            BootLoader = "GRUB-EFI"
        else:
            BootLoader = "Not GRUB-EFI"

        return BootLoader

    def CheckForLILOEFI(self,EFISYSPMountPoint):
        global ManuallyMountedEFISYSP
        #Look for LILO's EFI file.
        temp = subprocess.check_output("find "+EFISYSPMountPoint+" -iname '*elilo*'", shell=True).replace('\n', '')

        #Look for ELILO.
        if temp != "":
            #Bootloader is ELILO.
            if ManuallyMountedEFISYSP == True:
                subprocess.call(['umount', EFISYSP])
                ManuallyMountedEFISYSP = None
            BootLoader = "LILO-EFI"
        else:
            BootLoader = "Not ELILO"

        return BootLoader

    def ManualBootLoaderSelect(self):
        global dlgResult
        dlgResult = "Unknown"
        if EFISYSP == "Not Found" and FWType == "UEFI":
            logger.warning("Initial Thread: Only listing BIOS bootloaders, as there is no EFI partition.")
            wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.&WxFixBoot - Select Bootloader&GRUB-LEGACY&GRUB-MBR&LILO-MBR")

        elif EFISYSP != "Not Found" and FWType == "UEFI":
            wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.&WxFixBoot - Select Bootloader&GRUB-LEGACY&GRUB-MBR&GRUB-EFI&LILO-MBR&LILO-EFI")

        else:
            logger.info("Initial Thread: Only listing BIOS bootloaders, as this is a BIOS system.")
            wx.CallAfter(Publisher().sendMessage, "showchoicedlg", "WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.&WxFixBoot - Select Bootloader&GRUB-LEGACY&GRUB-MBR&LILO-MBR")

        #Trap the thread until the user answers.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        if dlgResult == "Clicked no...":
            #Quit.
            logger.critical("Initial Thread: User didn't manaully select a bootloader! There is no apparent bootloader; Cannot continue; Exiting...")
            wx.Exit()
            sys.exit("No bootloader found...")
        else:
            logger.debug("Initial Thread: User reported bootloader is: "+dlgResult+". Continuing...")
            return dlgResult

    def UnmountAllFS(self):
        #Attempt unmount of all filesystems, ignoring failed unmounts.
        try:
            runcmd = subprocess.Popen(['umount', '-ad'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            stdout, stderr = runcmd.communicate()
            logger.debug("Initial Thread: GetBootLoader: Command: 'umount -ad' stdout: "+str(stdout)+", stderr: "+str(stderr))
        except subprocess.CalledProcessError:
            pass
        finally:
            wx.CallAfter(Publisher().sendMessage, "UnmountFSUpdate", "Unmounting Filesystems... Success")

    def CheckFS(self):
        #Check all non-mounted filesystems.
        subprocess.check_output(['fsck', '-AR'])
        wx.CallAfter(Publisher().sendMessage, "CheckFSUpdate", "Quickly Checking Filesystems... Success")

    def FinalCheck(self):
        #Check for any conflicting options, and that each variable is set.
        global dlgClosed

        #Create a temporary list containing all variables to be checked, and a list to contain failed variables.
        templist = ['LiveDisk', 'PartitionListWithFSType', 'LinuxPartList', 'DeviceList', 'AutoRootFS', 'RootFS', 'AutoRootDev', 'RootDev', 'LiveDisk', 'DefaultOS', 'AutoDefaultOS', 'OSList', 'FWType', 'AutoFWType', 'EFIVars', 'PartScheme', 'AutoPartScheme', 'BootLoader', 'AutoBootLoader', 'PrevBootLoaderSetting', 'EFISYSP', 'ManuallyMountedEFISYSP']
        failedlist = []

        #Check each variable is set.
        for var in templist:
            if var in globals():
                if var != None:
                    #This is set okay.
                    pass
                else:
                    #It isn't.                    
                    logger.warning("Initial Thread: Error! Variable "+var+" hasn't been set, addng it to the failed list...")
                    failedlist.append(var)
            else:
                #It isn't.                    
                logger.warning("Initial Thread: Error! Variable "+var+" hasn't been set, addng it to the failed list...")
                failedlist.append(var)

        #Check if any variables weren't set.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("Initial Thread: Critical! Required Settings: "+', '.join(failedlist)+" have not been Determined! This is probably a bug in the program! Exiting...")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "The required variables: "+', '.join(failedlist)+", have not been set! WxFixBoot will now shut down to prevent damage to your system. This is probably a bug in the program. Check the log file at /var/log/wxfixboot.log")
            wx.Exit()
            sys.exit("Incorrectly set settings:"+', '.join(failedlist)+" Exiting...")

        #Set some other variables to a default value, avoiding problems down the line.
        SetDefaults()

        #Check and warn about conflicting settings.
        #Firmware type warnings.
        if FWType == "BIOS/CSM" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            logger.warning("Initial Thread: BootLoader is EFI-type, but system firmware is BIOS! Odd, perhaps a migrated drive? Continuing...")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your computer uses BIOS firmware, but you're using an EFI-enabled bootloader! BIOS firmware does not support booting EFI-enabled bootloaders, so it is recommended to install a BIOS-enabled legacy bootloader instead, such as GRUB2. You can safely ignore this message if your firmware type has been misdetected.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)

            dlgClosed == "Unknown"
        if FWType == "BIOS/CSM" and PartScheme == "gpt":
            logger.warning("Initial Thread: Firmware is BIOS, but the system is using a gpt partition table! This probably won't boot. WxFixBoot suggests repartitioning.")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your computer uses BIOS firmware, but you're using a gpt(GUID)-style partition scheme on your root device! BIOS firmware will likely fail to boot your operating system, so a repartition may be necessary. You can safely ignore this message if your firmware type has been misdetected.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)

            dlgClosed == "Unknown"
        #Partition scheme warnings.
        if PartScheme == "msdos" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            logger.warning("Initial Thread: MBR partition table with EFI bootloader! This might not work properly. WxFixBoot suggests repartitioning.")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your partition type on your root device is msdos(MBR), but you're using an EFI-enabled bootloader! Some firmware may not support this setup, so it is recommended to install a BIOS-enabled legacy bootloader instead.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)
        if PartScheme == "gpt" and (BootLoader == "GRUB-MBR" or BootLoader == "LILO-MBR"):
            logger.warning("Initial Thread: GPT Partition table with msdos bootloader! Most BIOS firmware cannot read GPT disks. WxFixBoot suggests repartitioning.")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: Your partition type on your root device is gpt(GUID), but you're using an BIOS-enabled bootloader! Almost all firmware won't support this setup, except very recent BIOS systems, so it is advised to install a EFI-enabled bootloader instead.")

            #Trap the thread until the user responds.
            while dlgClosed == "Unknown":
                time.sleep(0.5)

        #BootLoader warnings.
        if EFISYSP == "Not Found" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            logger.error("Initial Thread: Error: EFI bootloader without an EFI partition is a logical impossibility! WxFixBoot will not install an EFI bootloader without an EFI partition.")
            wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Warning: You're using an EFI-enabled bootloader, but don't have an EFI/UEFI system partition! Your computer may be unable to boot unless you create an EFI system partition. You'll have to do this with a partitioning tool like gparted. WxFixBoot will refuse to install an EFI-enabled bootloader without an EFI system partition.")

        wx.CallAfter(Publisher().sendMessage, "FinalCheckUpdate", "Final check... All Okay!")        

#End Initalization Thread.
#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc3 (29/5/2014)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        #Set up Publisher
        Publisher().subscribe(self.RefreshMainWindow, "MainWindowRefresh")

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Set up checkboxes (run it twice to fix an error)
        self.OnCheckBox(False)
        self.OnCheckBox(False)

        #Bind all events.
        self.BindEvents()

        logger.debug("MainWindow Started. Waiting for events...")
        
    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text
        wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(125,15))

        #Add an image.
        img = wx.Image("/usr/share/wxfixboot/wxfixboot.png", wx.BITMAP_TYPE_PNG)
        wx.StaticBitmap(self.MainPanel, -1, wx.BitmapFromImage(img), pos=(270,50))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(120,220))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply All Operations", pos=(125,180))

    def CreateCBs(self):
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorough)", pos=(10,40))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", pos=(10,70))
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall Current Bootloader", pos=(10,100))
        self.updateblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Current Bootloader", pos=(10,130))

        #If bootloader is grub legacy, disable some options.
        if BootLoader == "GRUB-LEGACY":
            self.DisableBLOptsGrubLegacy()

    def DisableBLOptsGrubLegacy(self):
        self.reinstblcb.Disable()
        self.updateblcb.Disable()

    def EnableBLOptsNoGrubLegacy(self):
        self.reinstblcb.Enable()
        self.reinstblcb.SetValue(False)
        self.updateblcb.Enable()
        self.updateblcb.SetValue(False)

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate the program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_PREFERENCES, "&Options", "General settings used to modify your system")

        #Creating the menubar.
        menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        menuBar.Append(filemenu,"&File") # Adding the "filemenu" to the MenuBar
        menuBar.Append(editmenu,"&Edit") # Adding the "editmenu" to the MenuBar
        menuBar.Append(viewmenu,"&View") # Adding the "viewmenu" to the MenuBar
        menuBar.Append(helpmenu,"&Help") # Adding the "helpmenu" to the MenuBar 

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(menuBar)

    def OnCheckBox(self,e):
        #Make sure conflicting options can never be set.
        logger.debug("MainWindow().OnCheckBox() has been triggered.")

        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
        else:
            self.chkfscb.Enable()

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
        else:
            self.badsectcheckcb.Enable()

        #Reinstall BootLoader Choicebox
        if self.reinstblcb.IsChecked() and (BootLoader != "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True):
            self.updateblcb.SetValue(0)
            self.updateblcb.Disable()
        elif self.reinstblcb.IsChecked() == False and BootLoader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.updateblcb.Enable()
        else:
            self.reinstblcb.SetValue(0)

        #Update BootLoader Choicebox
        if self.updateblcb.IsChecked() and (BootLoader != "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True):
            self.reinstblcb.SetValue(0)
            self.reinstblcb.Disable()
        elif self.updateblcb.IsChecked() == False and BootLoader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.reinstblcb.Enable()
        else:
            print RestorePartTable
            print RestoreBootSector
            self.updateblcb.SetValue(0)

    def Opts(self,e):
        logger.debug("Starting Options Window 1 and hiding MainWindow...")
        temp = self.SaveMainOpts()
        if temp == "Continue":
            self.Hide()
            OptionsWindow1().Show()

    def DevInfo(self,e):
        logger.debug("Starting Device Info Window...")
        temp = self.SaveMainOpts()
        if temp == "Continue":
            DevInfoWindow().Show()

    def ProgressWindow(self,e):
        logger.debug("Starting Progress Window...")
        temp = self.SaveMainOpts()
        if temp == "Continue":
            dlg = wx.MessageDialog(None, "Are you sure you want to continue? Using incorrect settings can cause serious damage to your system.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                self.Hide()
                ProgressWindow().Show()

    def RefreshMainWindow(self,msg):
        #Refresh the main window to reflect changes in the options, or after a restart.
        logger.debug("Refreshing MainWindow...")
            
        #Bootloader options. Also check if the partition table or boot sector are to be restored
        if BootLoader == "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True:
            self.DisableBLOptsGrubLegacy()
        else:
            self.EnableBLOptsNoGrubLegacy()

        #Set settings up how they were when MainWindow was hidden earlier, if possible.
        if BootLoader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.reinstblcb.SetValue(ReinstallBootLoader)
            self.updateblcb.SetValue(UpdateBootLoader)

        self.chkfscb.SetValue(QuickFSCheck)
        self.badsectcheckcb.SetValue(BadSectCheck)

        #Enable and Disable Checkboxes as necessary
        self.OnCheckBox(True)

        #Reveal MainWindow
        self.Show()

    def OnAbout(self,e):
        logger.debug("Showing About Box")
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot"
        aboutbox.Version = "1.0~rc3"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = wordwrap("Utility to quickly fix the bootloader on a computer",250,wx.ClientDC(self.MainPanel))
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.License = wordwrap("WxFixBoot is released under the GNU GPL v3",500,wx.ClientDC(self.MainPanel))
        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_CLOSE, self.OnExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        self.Bind(wx.EVT_BUTTON, self.ProgressWindow, self.applyopts)

        #Checkboxes on the main window.
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.reinstblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.updateblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.chkfscb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.badsectcheckcb)

    def SaveMainOpts(self):
        #Save all options here.
        logger.debug("Saving Options on MainWindow...")
        global BootLoaderToInstall
        global BootLoaderDestination
        global BootSectFile
        global RestoreBootSector
        global PartTableFile
        global RestorePartTable
        global ReinstallBootLoader
        global UpdateBootLoader
        global QuickFSCheck
        global BadSectCheck
        global BootLoader

        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
            BadSectCheck = True
        else:
            self.chkfscb.Enable()
            BadSectCheck = False

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
            QuickFSCheck = True
        else:
            self.badsectcheckcb.Enable()
            QuickFSCheck = False

        #Reinstall BootLoader Choicebox
        if self.reinstblcb.IsChecked():
            #Show an info message.
            dlg = wx.MessageDialog(None, "Do you want to continue? If you reinstall/update your bootloader, some options, such as installing a different bootloader, and restoring backups of the bootsector and partition table, will be disabled. Settings such as the new bootloader to install (if any) will also be reset and disabled. If you want to change other settings, you can always do it afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                ReinstallBootLoader = True

                #Disable some stuff
                BootLoaderToInstall = "None"
                BootLoaderDestination = "None"
                BootSectFile = "None"
                RestoreBootSector = False
                PartTableFile = "None"
                RestorePartTable = False
            else:
                return "Stop"
        else:
            ReinstallBootLoader = False

        #Update BootLoader Choicebox
        if self.updateblcb.IsChecked():
            #Show an info message.
            dlg = wx.MessageDialog(None, "Do you want to continue? If you reinstall/update your bootloader, some options, such as installing a different bootloader, and restoring backups of the bootsector and partition table, will be disabled. Settings such as the new bootloader to install (if any) will also be reset and disabled. If you want to change other settings, you can always do it afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                UpdateBootLoader = True

                #Disable some stuff
                BootLoaderToInstall = "None"
                BootLoaderDestination = "None"
                BootSectFile = "None"
                RestoreBootSector = False
                PartTableFile = "None"
                RestorePartTable = False
                return "Continue"
            else:
                return "Stop"
        else:
            UpdateBootLoader = False
            return "Continue"
        logger.debug("MainWindow options saved!")

    def OnExit(self,e):
        #Shut down.
        logger.debug("User triggered exit sequence. Exiting...")
        self.Destroy()

#End Main window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Options", size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)

        #Set up Publisher.
        Publisher().subscribe(self.RefreshOptionsDlg1, "AnOptionDlgHasClosed")

        self.CreateButtons()
        self.CreateText()
        self.UpdateBLOptsText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.SetupOptions()
        self.BindEvents()

        #Paint the lines on the Window
        wx.CallLater(200, self.DrawLines, "Empty arg")

        logger.debug("OptionsWindow1 Started.")

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Apply these Settings and Close", pos=(180,320))
        self.blOptsButton = wx.Button(self.OptsPanel1, -1, "View BootLoader Options", pos=(210,260))
        self.restorebootsectbutton = wx.Button(self.OptsPanel1, -1, "Restore Boot Sector", pos=(10,320))
        self.restoreparttablebutton = wx.Button(self.OptsPanel1, -1, "Restore Partition Table", pos=(427,320))

    def CreateText(self):
        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Please give all the settings a once-over", pos=(90,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", pos=(10,50))
        wx.StaticText(self.OptsPanel1, -1, "Installed BootLoader:", pos=(10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", pos=(10,110))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader timeout value:", pos=(10,200))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", pos=(10,220)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", pos=(310,50))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", pos=(310,80))
        wx.StaticText(self.OptsPanel1, -1, "BootLoader To Install:", pos=(30,255))
        wx.StaticText(self.OptsPanel1, -1, "Selected Firmware Type:", pos=(420,255))

    def CreateCBs(self):
        #Basic settings
        self.fullverbosecb = wx.CheckBox(self.OptsPanel1, -1, "Show diagnostic terminal output", pos=(10,140), size=(270,20))
        self.createlogcb = wx.CheckBox(self.OptsPanel1, -1, "Log and save output of all operations", pos=(10,170), size=(270,20))

        #Advanced settings
        self.verifycb = wx.CheckBox(self.OptsPanel1, -1, "Verify Everything after Operations", pos=(310,120), size=(315,20))
        self.usechrootcb = wx.CheckBox(self.OptsPanel1, -1, "Use chroot during operations", pos=(310,150), size=(315,20))
        self.bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector", pos=(310,180), size=(250,20))
        self.bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table", pos=(310,210), size=(290,20))

    def CreateChoiceBs(self):
        #Basic settings
        self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+AutoBootLoader, 'GRUB-LEGACY', 'GRUB-MBR', 'GRUB-EFI', 'LILO-MBR', 'LILO-EFI'])
        self.defaultoschoice = wx.Choice(self.OptsPanel1, -1, pos=(150,103), size=(140,30), choices=OSList)

        #Advanced settings
        self.rootdevchoice = wx.Choice(self.OptsPanel1, -1, pos=(440,73), choices=["Auto: "+AutoRootDev]+DeviceList)

    def CreateSpinners(self):
        #Basic option here.
        self.bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", pos=(190,197))
        self.bltimeoutspin.SetRange(-1,100)
        self.bltimeoutspin.SetValue(-1)

    def SetupOptions(self):
        #Load all Options here.
        logger.debug("Setting up options in OptionsDlg1...")
        #Boot Loader Time Out
        self.bltimeoutspin.SetValue(BootLoaderTimeOut)

        #Checkboxes
        #Create Log checkbox.
        if CreateLog == True:
            self.createlogcb.SetValue(True)
        else:
            self.createlogcb.SetValue(False)

        #Diagnostic output checkbox.
        if FullVerbose == True:
            self.fullverbosecb.SetValue(True)
        else:
            self.fullverbosecb.SetValue(False)

        #Verify checkbox
        if Verify == True:
            self.verifycb.SetValue(True)
        else:
            self.verifycb.SetValue(False)

        #Backup Boot Sector CheckBox
        if BkpBootSect == True:
            self.bkpbootsectcb.SetValue(True)
        else:
            self.bkpbootsectcb.SetValue(False)

        #Backup Partion Table CheckBox
        if BackupPartTable == True:
            self.bkpparttablecb.SetValue(True)
        else:
            self.bkpparttablecb.SetValue(False)

        #Use Chroot checkBox
        if UseChroot == True:
            self.usechrootcb.SetValue(True)
        else:
            self.usechrootcb.SetValue(False)

        #Installed BootLoader
        if BootLoader != AutoBootLoader:
            self.instblchoice.SetStringSelection(BootLoader)

        #Default OS
        if DefaultOS != AutoDefaultOS:
            self.defaultoschoice.SetStringSelection(DefaultOS)
        
        #Root Device
        if RootDev != AutoRootDev:
            self.rootdevchoice.SetStringSelection(RootDev)

            #Recalculate the partition scheme
            global PartScheme
            PartScheme = subprocess.check_output("parted "+RootDev+" print | grep 'Partition Table'", shell=True).split()[2]

        if RestoreBootSector == True or RestorePartTable == True:
            #Disable some options.
            self.blOptsButton.Disable()
            self.instblchoice.Disable()

            #Reset some settings.
            global BootLoaderToInstall
            global BootLoaderDestination
            BootLoaderToInstall = "None"
            BootLoaderDestination = "None"
        else:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()

        if ReinstallBootLoader == True or UpdateBootLoader == True:
            self.blOptsButton.Disable()
            self.restorebootsectbutton.Disable()
            self.restoreparttablebutton.Disable()

        logger.debug("Options in OptionsDlg1 saved!")

    def DrawLines(self,e):
        #Create some border lines on the panel.
        logger.debug("OptionsWindow1.().DrawLines() has been triggered.")
        dc = wx.PaintDC(self.OptsPanel1)
        dc.DrawLine(0, 67, 600, 67)
        dc.DrawLine(300, 67, 300, 245)
        dc.DrawLine(0, 245, 600, 245)
        dc.DrawLine(0, 300, 600, 300)

    def UpdateBLOptsText(self):
        #Set up the Device Context first.
        logger.debug("Updating Bootloader Options text in OptionsDlg1...")
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        font = self.OptsPanel1.GetFont()
        dc = wx.WindowDC(self.OptsPanel1)
        dc.SetFont(font)

        #Do the BootLoader to install text first.
        width, height = dc.GetTextExtent(BootLoaderToInstall)
        try:
            self.BootLoaderToInstallText
        except: pass
        else:
            self.BootLoaderToInstallText.Destroy()
        finally:
            self.BootLoaderToInstallText = wx.StaticText(self.OptsPanel1, -1, BootLoaderToInstall, pos=((200-int(width))/2,275), size=(int(width),int(height)))

        #Do the FWTypeText now.
        width, height = dc.GetTextExtent(FWType)
        try:
            self.FWTypeText
        except: pass
        else:
            self.FWTypeText.Destroy()
        finally:
            self.FWTypeText = wx.StaticText(self.OptsPanel1, -1, FWType, pos=(((200-int(width))/2)+395,275), size=(int(width),int(height)))

        logger.debug("BootLoader Options text in OptionsDlg1 updated!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CloseOpts)
        self.Bind(wx.EVT_BUTTON, self.LaunchblOpts, self.blOptsButton)
        self.Bind(wx.EVT_BUTTON, self.LaunchBootSectWindow, self.restorebootsectbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchPartTableWindow, self.restoreparttablebutton)
        self.Bind(wx.EVT_PAINT, self.DrawLines)

    def LaunchblOpts(self,e):
        #Safeguard program reliability (and continuity) by saving the settings in optionswindow1 first.
        self.SaveOptions("Empty arg")

        #Give some warnings here if needed.
        #Tell the user some options will be disabled if the bootloader is to be reinstalled or updated.
        if ReinstallBootLoader == True or UpdateBootLoader == True:
            wx.MessageDialog(self.OptsPanel1, "Your current bootloader is to be reinstalled/updated, therefore almost all bootloader-related options here will be disabled. If you want to install a different bootloader, please uncheck the reinstall/update bootloader option on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a MBR bootloader on BIOS systems.
        if AutoFWType == "BIOS":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is BIOS. Unless you're sure WxFixBoot has misdetected this, and it's actually UEFI, it's recommended that you install an MBR bootloader, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a EFI boot loader on UEFI systems.
        elif AutoFWType == "UEFI":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is UEFI. Unless you're sure WxFixBoot has misdetected this, and it's actually BIOS, it's recommended that you install an EFI bootloader, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if EFISYSP == "Not Found" and (BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI"):
            wx.MessageDialog(self.OptsPanel1, "You have a UEFI Bootloader, but no EFI Partition! Something has gone seriously wrong here! WxFixBoot will not install a UEFI bootloader without an EFI partition (as it's impossible), and those options will now be disabled.", "WxFixBoot - ERROR", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        elif EFISYSP == "Not Found":
            wx.MessageDialog(self.OptsPanel1, "You have no EFI Partition. If you wish to install an EFI bootloader, you'll need to create one first. WxFixBoot will not install a UEFI bootloader without an EFI partition (as it's impossible), and those options will now be disabled.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Open the Firmware Options window
        logger.debug("Starting Options Window 2 (aka BootLoader Options Dlg)...")
        self.Hide()
        OptionsWindow2().Show()

    def LaunchBootSectWindow(self,e):
        logger.debug("Starting Restore BootSector dialog...")
        self.Hide()
        RestBootSectorWindow().Show()

    def LaunchPartTableWindow(self,e):
        logger.debug("Starting Restore PartTable dialog...")
        self.Hide()
        RestPartTableWindow().Show()

    def RefreshOptionsDlg1(self,msg):
        #Check if the partition table or boot sector are to be restored. Ignore NameError errors.
        logger.debug("Refreshing OptionsDlg1...")
        try:
            print PartTableFile
            print BootSectFile
            print RestorePartTable
            print RestoreBootSector
            if RestorePartTable == True or RestoreBootSector == True:
                #Disable some options.
                self.blOptsButton.Disable()
                self.instblchoice.Disable()

                #Reset some settings.
                global BootLoaderToInstall
                global BootLoaderDestination
                global FWType
                BootLoaderToInstall = "None"
                BootLoaderDestination = "None"
                FWType = AutoFWType
            else:
                #Enable some options.
                self.blOptsButton.Enable()
                self.instblchoice.Enable()
        except NameError:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()

        #Update the BootLoaderToInstall and FWType text.
        self.UpdateBLOptsText()

        #Show OptionsDlg1.
        self.Show()

        #Paint the lines on the Window again.
        wx.CallLater(200, self.DrawLines, "Empty arg")

    def SaveOptions(self,e):
        #Save all options in this dialog here.
        global CreateLog
        global FullVerbose
        global Verify
        global BkpBootSect
        global BackupPartTable
        global UseChroot
        global BootLoader
        global PrevBootLoaderSetting
        global DefaultOS
        global RootDev
        global BootLoaderTimeOut

        logger.info("OptionsWindow1: Saving Options...")
        
        #Checkboxes.

        #Create Log checkbox.
        if self.createlogcb.IsChecked():
            CreateLog = True
        else:
            CreateLog = False
        logger.debug("OptionsWindow1: Saving Options: Value of CreateLog is: "+str(CreateLog))

        #Check FS cb
        if self.fullverbosecb.IsChecked():
            FullVerbose = True
        else:
            FullVerbose = False
        logger.debug("OptionsWindow1: Saving Options: Value of FullVerbose is: "+str(FullVerbose))

        #Remount FS CB
        if self.verifycb.IsChecked():
            Verify = True
        else:
            Verify = False
        logger.debug("OptionsWindow1: Saving Options: Value of Verify is: "+str(Verify))

        #Backup BootSector checkbox.
        if self.bkpbootsectcb.IsChecked():
            BkpBootSect = True
        else:
            BkpBootSect = False
        logger.debug("OptionsWindow1: Saving Options: Value of BkpBootSect is: "+str(BkpBootSect))

        #Backup Partition Table checkbox.
        if self.bkpparttablecb.IsChecked():
            BackupPartTable = True
        else:
            BackupPartTable = False
        logger.debug("OptionsWindow1: Saving Options: Value of BackupPartTable is: "+str(BackupPartTable))

        #Use chroot in operations checkbox
        if self.usechrootcb.IsChecked():
            UseChroot = True
        else:
            UseChroot = False
        logger.debug("OptionsWindow1: Saving Options: Value of UseChroot is: "+str(UseChroot))

        #ChoiceBoxes
        #Currently Installed BootLoader ChoiceBox
        PrevBootLoaderSetting = BootLoader
        if self.instblchoice.GetSelection() != 0:
            BootLoader = self.instblchoice.GetStringSelection()
        else:
            #Set it to the auto value, using AutoBootLoader
            BootLoader = AutoBootLoader
        logger.debug("OptionsWindow1: Saving Options: Value of BootLoader is: "+BootLoader)

        #Default OS choicebox ***** THIS NEEDS TO HAVE A SYSTEM TO SET THE BOOTLOADER'S DEFAULT OS. THIS CAN BE VERY DIFFICULT *****
        DefaultOS = self.defaultoschoice.GetStringSelection()
        logger.debug("OptionsWindow1: Saving Options: Value of DefaultOS is: "+DefaultOS)

        #Root device ChoiceBox
        if self.rootdevchoice.GetSelection() != 0:
            RootDev = self.rootdevchoice.GetStringSelection()
        else:
            #Set it to the auto value, in case this has already been changed..
            RootDev = AutoRootDev
        logger.debug("OptionsWindow1: Saving Options: Value of RootDev is: "+RootDev)

        #Spinner
        BootLoaderTimeOut = int(self.bltimeoutspin.GetValue())
        logger.debug("OptionsWindow1: Saving Options: Value of BootLoaderTimeOut is: "+str(BootLoaderTimeOut))

        logger.info("OptionsWindow1: Saved options.")

    def CloseOpts(self,e):
        #Save the options first.
        self.SaveOptions("empty arg")

        #Send a message to mainwindow so it can refresh.
        wx.CallAfter(Publisher().sendMessage, "MainWindowRefresh", "Closed")

        #Exit options window 1.
        logger.debug("OptionsWindow1 is closing. Revealing MainWindow...")
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - BootLoader Options", size=(450,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

        logger.debug("OptionsWindow2 Started.")

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(360,270))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace UEFI bootloader with BIOS version", pos=(10,160))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace BIOS bootloader with UEFI version", pos=(10,190))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Automatically modify the bootloader", pos=(10,220))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not modify the bootloader", pos=(10,250))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Install BootLoader in:", pos=(140,50))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System", pos=(140,80))
        wx.StaticText(self.OptsPanel2, -1, "On "+RootDev+":", pos=(165,97))
        wx.StaticText(self.OptsPanel2, -1, "BootLoader to install:", pos=(140,120))
 
    def CreateRadios(self):
        self.fwtyperadioauto = wx.RadioButton(self.OptsPanel2, -1, "Auto: "+AutoFWType, pos=(7,50), style=wx.RB_GROUP)
        self.fwtyperadioEFI = wx.RadioButton(self.OptsPanel2, -1, "EFI/UEFI", pos=(7,80))
        self.fwtyperadioBIOS = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(7,110))

    def CreateChoiceBs(self):
        self.instbldestchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,44), size=(150,30), choices=['Root Device: '+RootDev]+DeviceList)
        self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,79), choices=['Auto: '+AutoPartScheme, 'msdos', 'gpt'])
        if EFISYSP == "Not Found":
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,114), choices=['Auto', 'GRUB-MBR', 'LILO-MBR'])
        else:
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,114), choices=['Auto', 'GRUB-EFI', 'GRUB-MBR', 'LILO-EFI', 'LILO-MBR'])

    def SetDefaults(self):
        logger.debug("Setting up OptionsDlg2...")
        #Check if the dialog has already been run, or if the bootloader setting has changed (so it must discard the setting to avoid errors).
        if BLOptsDlgRun == False or BootLoader != PrevBootLoaderSetting:
            #Use defaults.
            #If bootloader is to be reinstalled, updated, or if an EFI partition isn't available, or if bootloader is grub-legacy, disable some stuff.
            if ReinstallBootLoader == True or UpdateBootLoader == True:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.instbldestchoice.Disable()
                self.bltoinstallchoice.Disable()
                self.unchangedcb.SetValue(True)
            elif EFISYSP == "Not Found":
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.unchangedcb.SetValue(True)
                wx.MessageDialog(self.OptsPanel1, "You don't appear to have an EFI partiion. If you want to install an EFI-enabled bootloader, you'll need to create an EFI partition first. You must manaully select a BIOS (MBR) bootloader now.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
            elif BootLoader == "GRUB-LEGACY":
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
                self.unchangedcb.SetValue(True)
            else:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.unchangedcb.SetValue(True)
                self.fwtyperadioauto.SetValue(True)
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.instbldestchoice.SetSelection(0)
                self.partitiontypechoice.SetSelection(0)
        else:
            #Setup using the previous options.
            global BootLoaderToInstall
            #First do options that will be set even if the current bootloader is to be reinstalled or updated.
            #Set up Partition Scheme selection (if PartScheme = AutoPartScheme, the first item (selected by default) will be right).
            if PartScheme != AutoPartScheme:
                self.partitiontypechoice.SetStringSelection(PartScheme)

            #Set up Firmware Type radio buttons.
            if FWType == AutoFWType:
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
            elif FWType == "BIOS":
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(True)
                self.fwtyperadioauto.SetValue(False)
            elif FWtype == "UEFI":
                self.fwtyperadioEFI.SetValue(True)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(False)

            #BootLoader To Install Choice
            if BootLoaderToInstall != "None" and BootLoaderToInstall != "Unknown" and ReinstallBootLoader == False and UpdateBootLoader == False:
                self.instbldestchoice.Enable()
                self.bltoinstallchoice.Enable()
                self.bltoinstallchoice.SetStringSelection(BootLoaderToInstall)
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
            elif ReinstallBootLoader == True or UpdateBootLoader == True:
                BootLoaderToInstall = "None"
                self.bltoinstallchoice.SetSelection(0)
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")
                self.instbldestchoice.Disable()
                self.bltoinstallchoice.Disable()
            else:
                self.bltoinstallchoice.SetSelection(0)
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")

            if ReinstallBootLoader == False or UpdateBootLoader == False:
                #Bootloader Destination choice.
                if BootLoaderDestination == RootDev:
                    self.instbldestchoice.SetSelection(0)
                else:
                    self.instbldestchoice.SetStringSelection(BootLoaderDestination)

            logger.debug("OptionsDlg2 Set up!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CheckOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CheckOpts)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOptsforNoModification, self.unchangedcb)
        self.Bind(wx.EVT_CHOICE, self.BlToInstallChoiceChange, self.bltoinstallchoice)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforAutoFW, self.fwtyperadioauto)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforEFIFW, self.fwtyperadioEFI)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforBIOSFW, self.fwtyperadioBIOS)

    def ActivateOptsforAutoFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForAutoFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and UpdateBootLoader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforEFIFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForEFIFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and BootLoader != "GRUB-LEGACY" and UpdateBootLoader == False:
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(True)
            self.BIOStoUEFIcb.Enable()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
        elif BootLoader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforBIOSFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForBIOSFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and BootLoader != "GRUB-LEGACY" and UpdateBootLoader == False:
            self.UEFItoBIOScb.SetValue(True)
            self.UEFItoBIOScb.Enable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
        elif BootLoader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforNoModification(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForNoModification() has been triggered...")
        if self.unchangedcb.IsChecked() and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootLoader == False and UpdateBootLoader == False:
            print "Setting up for no modification..."
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
        elif ReinstallBootLoader == False and UpdateBootLoader == False:
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        else:
            self.unchangedcb.SetValue(True)
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()

    def BlToInstallChoiceChange(self,e):
        logger.debug("OptionsWindow2().BLToInstallChoiceChange() has been triggered...")
        if self.bltoinstallchoice.GetSelection() == 0:
            self.unchangedcb.Enable()
            self.unchangedcb.SetValue(True)
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        else:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.unchangedcb.SetValue(False)
            self.unchangedcb.Disable()

    def CheckOpts(self,e):
        if self.unchangedcb.IsChecked() == False and self.UEFItoBIOScb.IsChecked() == False and self.useAutocb.IsChecked() == False and self.BIOStoUEFIcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0:
            #Do nothing, as settings are invalid.
            logger.error("OptionsWindow2: No options selected, although no modification checkbox is unticked, or invalid options. Won't save options, waitng for user change...")
            wx.MessageDialog(self.OptsPanel2, "Your current selection suggests a modification will take place, but doesn't specify which modification to do! Please select a valid operation (or none at all).", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        else:
            self.SaveBLOpts()

    def SaveBLOpts(self):
        #Save all selected Operations here.
        global BootLoaderToInstall
        global BootLoaderDestination
        global PrevBootLoaderSetting
        global PartScheme
        global BootLoader
        global FWType
        global AutoFWType

        logger.info("OptionsWindow2: Saving Options...")

        templist = ['GRUB-LEGACY', 'GRUB-EFI','GRUB-MBR','LILO-EFI','LILO-MBR']
        
        #Bootloader Destination choice.
        if self.instbldestchoice.GetStringSelection()[0:4] == "Root" or ReinstallBootLoader == True or UpdateBootLoader == True:
            BootLoaderDestination = RootDev
        else:
            BootLoaderDestination = self.instbldestchoice.GetStringSelection()
        logger.debug("OptionsWindow2: Saving Options: Value of BootLoaderDestination is: "+BootLoaderDestination)

        #Partition scheme choice.
        if self.partitiontypechoice.GetStringSelection()[0:4] == "Auto":
            #Use autodetect value.
            PartScheme = AutoPartScheme
        else:
            PartScheme = self.partitiontypechoice.GetStringSelection()
        logger.debug("OptionsWindow2: Saving Options: Value of PartScheme is: "+PartScheme)

        #Firmware Choice.
        if self.fwtyperadioEFI.GetValue():
            FWType = "UEFI"
        elif self.fwtyperadioBIOS.GetValue():
            FWType = "BIOS"
        else:
            #Use given value
            FWType = AutoFWType
        logger.debug("OptionsWindow2: Saving Options: Value of FWType is: "+FWType)

        #BootLoader to install choice.
        #Offer some warnings here if needed. This is a little complicated.
        if self.bltoinstallchoice.GetStringSelection()[0:4] == "Auto" and ReinstallBootLoader == False:
            #Use autodetect value
            if self.unchangedcb.IsChecked() == False:

                if self.UEFItoBIOScb.IsChecked():
                    if BootLoader == "GRUB-EFI" or BootLoader == "LILO-EFI":
                        bootloadernum = templist.index(BootLoader)
                        BootLoaderToInstall = templist[bootloadernum+1] 
                    else:
                        #Do nothing
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "None"

                elif self.BIOStoUEFIcb.IsChecked():
                    if BootLoader == "GRUB-MBR" or BootLoader == "LILO-MBR":
                        bootloadernum = templist.index(BootLoader)
                        BootLoaderToInstall = templist[bootloadernum-1]
                    else:
                        #Do nothing
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "None"

                elif self.useAutocb.IsChecked():
                    bootloadernum = templist.index(BootLoader)

                    if FWType == "BIOS" and BootLoader != "GRUB-MBR" and BootLoader != "LILO-MBR" and BootLoader != "GRUB-LEGACY":
                        BootLoaderToInstall = templist[bootloadernum+1]

                    elif FWType == "UEFI" and BootLoader != "GRUB-EFI" and BootLoader != "LILO-EFI" and BootLoader != "GRUB-LEGACY":
                        BootLoaderToInstall = templist[bootloadernum-1]

                    elif FWType == "BIOS" and BootLoader == "GRUB-LEGACY":
                        dlg = wx.MessageDialog(self.OptsPanel2, 'Seeing as your bootloader is grub legacy, and you use BIOS firmware, the recommended bootloader for your hardware is grub2 (listed as GRUB-MBR). If you want to install a different bootloader, click no and return to the firmware settings dialog to manually select your bootloader. Click yes to comfirm installing grub2, click no to do nothing.', 'WxFixBoot -- Comfirmation', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
                        if dlg == wx.ID_YES:
                            BootLoaderToInstall = "GRUB-MBR"
                        else:
                            #Do nothing
                            BootLoaderToInstall = "None"

                    elif FWType == "UEFI" and BootLoader == "GRUB-LEGACY":
                        wx.MessageDialog(self.OptsPanel2, "You have a combination of UEFI firmware and grub legacy. This is an odd combination, and WxFixBoot doesn't know what to do. If you've imaged your HDD from another system, you probably want to install grub-efi manually by returning to the firmware options dialog. If you manually suggested you have grub legacy earlier, please double check. Perhaps you want to install GRUB-EFI?", "WxFixBoot - Warning!", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()
                        BootLoaderToInstall = "Unknown"

                    else:
                        BootLoaderToInstall = "None"
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            else:
                #Do nothing.
                BootLoaderToInstall = "None"
        elif self.unchangedcb.IsChecked() == False and ReinstallBootLoader == False and UpdateBootLoader == False:
            BootLoaderToInstall = self.bltoinstallchoice.GetStringSelection()
        else:
            BootLoaderToInstall = "None"

        #Avoid an error situation.
        PrevBootLoaderSetting = BootLoader

        logger.debug("OptionsWindow2: Saving Options: Value of BootLoader (which shouldn't have changed since options window 1) is: "+BootLoader)
        logger.debug("OptionsWindow2: Saving Options: Value of BootLoaderToInstall is: "+BootLoaderToInstall)

        self.CloseBLOpts()
        
    def CloseBLOpts(self):
        logger.debug("OptionsWindow2 Closing.")
        #Save that this has been run once, so it can update itself with new info if it's started again.
        global BLOptsDlgRun
        BLOptsDlgRun = True

        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(Publisher().sendMessage, "AnOptionDlgHasClosed", "Closed.")

        #Exit.
        self.Destroy()

#End Options window 2
#Begin Restore Boot Sector Window
class RestBootSectorWindow(wx.Frame): #*** THIS NEEDS TO HAVE A WAY OF DETERMINING THE BACKUP TYPE IN THE FINAL VERSION ***
    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Restore a Boot Sector", size=(400,200), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.BootSectPanel = wx.Panel(self)

        global BootSectFile
        global RestoreBootSector
        BootSectFile = "None"
        RestoreBootSector = False

        #Create text
        wx.StaticText(self.BootSectPanel, -1, "Easily restore your bootsector here!", pos=(80,10))
        wx.StaticText(self.BootSectPanel, -1, "What type of Boot Sector backup do you have?", pos=(40,40))

        #Create Radio Buttons ** WRITE CODE TO DETERMINE TYPE OF BACKUP ***
        self.autodetectradio = wx.RadioButton(self.BootSectPanel, -1, "Autodetect", pos=(10,70), style=wx.RB_GROUP)
        self.msdosradio = wx.RadioButton(self.BootSectPanel, -1, "MBR(msdos)", pos=(150,70))
        self.gptradio = wx.RadioButton(self.BootSectPanel, -1, "GUID(gpt)", pos=(290,70))  
        self.autodetectradio.Disable()
        self.msdosradio.SetValue(True)

        #Create ChoiceBoxes
        self.bsfilechoice = wx.Choice(self.BootSectPanel, -1, pos=(10,110), size=(380,30), choices=['-- Please Select --', 'Specify File Path...'])

        #Create Buttons
        self.exitbutton = wx.Button(self.BootSectPanel, -1, "Close and Set Options", pos=(120,160))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.ExitWindow, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitWindow)
        self.Bind(wx.EVT_CHOICE, self.SelectBootSectorImage, self.bsfilechoice)

        logger.debug("Restore Boot Sector Window Started.")

    def SelectBootSectorImage(self,e):
        #Grab Boot Sector Image path.
        #Set up global variables.
        global BootSectFile
        global RestoreBootSector

        BootSectFile = self.bsfilechoice.GetStringSelection()

        #Determine what to do here.
        if BootSectFile == "-- Please Select --":
            BootSectFile = "None"
            RestoreBootSector = False
        elif BootSectFile == "Specify File Path...":
            Dlg = wx.FileDialog(self.BootSectPanel, "Select Boot Sector File...", wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            if Dlg.ShowModal() == wx.ID_OK:
                RestoreBootSector = True
                BootSectFile = Dlg.GetPath()
                self.bsfilechoice.Append(BootSectFile)
                self.bsfilechoice.SetStringSelection(BootSectFile)
            else:
                BootSectFile = "None"
                RestoreBootSector = False
                self.bsfilechoice.SetStringSelection("-- Please Select --")
        else:
            print "else"
            BootSectFile = self.bsfilechoice.GetStringSelection()
            RestoreBootSector = True

    def ExitWindow(self,e):
        logger.debug("Restore Boot Sector Window Closing.")
        global BootSectFile
        global RestoreBootSector

        if BootSectFile != "None" and RestoreBootSector != False:
            #Show an info message.
            dlg = wx.MessageDialog(None, "Do you want to continue? If you restore a partition table or bootsector, some options, such as installing a different bootloader, and reinstalling/updating your bootloader, will be disabled. Settings such as the new bootloader to install (if any) will also be reset and disabled. If you want to change other settings, you can always do it afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(Publisher().sendMessage, "AnOptionDlgHasClosed", "Closed.")

                #Exit.
                self.Destroy()
            else:
                BootSectFile = "None"
                RestoreBootSector = False
                self.bsfilechoice.SetStringSelection("-- Please Select --")
        else:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(Publisher().sendMessage, "AnOptionDlgHasClosed", "Closed.")

                #Exit.
                self.Destroy()

#End Restore Boot Sector Window
#Begin Restore Partition Table Window
class RestPartTableWindow(wx.Frame): #*** THIS NEEDS TO HAVE A WAY OF DETERMINING THE BACKUP TYPE IN THE FINAL VERSION ***
    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Restore the Partition Table", size=(400,200), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.PartTablePanel = wx.Panel(self)
        global PartTableFile
        global RestorePartTable
        PartTableFile = "None"
        RestorePartTable = False

        #Create text
        wx.StaticText(self.PartTablePanel, -1, "Easily restore your partition table here!", pos=(60,10))
        wx.StaticText(self.PartTablePanel, -1, "What type of partition table backup do you have?", pos=(30,40))

        #Create Radio Buttons ** WRITE CODE TO DETERMINE TYPE OF BACKUP ***
        self.autodetectradio = wx.RadioButton(self.PartTablePanel, -1, "Autodetect", pos=(10,70), style=wx.RB_GROUP)
        self.msdosradio = wx.RadioButton(self.PartTablePanel, -1, "MBR(msdos)", pos=(150,70))
        self.gptradio = wx.RadioButton(self.PartTablePanel, -1, "GUID(gpt)", pos=(290,70))  
        self.autodetectradio.Disable()
        self.msdosradio.SetValue(True)

        #Create ChoiceBoxes
        self.ptfilechoice = wx.Choice(self.PartTablePanel, -1, pos=(10,110), size=(380,30), choices=['-- Please Select --', 'Specify File Path...'])

        #Create Buttons
        self.exitbutton = wx.Button(self.PartTablePanel, -1, "Close and Set Options", pos=(120,160))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.ExitWindow, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitWindow)
        self.Bind(wx.EVT_CHOICE, self.SelectPartitionTableImage, self.ptfilechoice)

        logger.debug("Restore Partition Table Window Started.")

    def SelectPartitionTableImage(self,e):
        #Get Partition Table Image path.
        #Set up global variables.
        global PartTableFile
        global RestorePartTable

        PartTableFile = self.ptfilechoice.GetStringSelection()

        #Determine what to do here.
        if PartTableFile == "-- Please Select --":
            PartTableFile = "None"
            RestorePartTable = False
        elif PartTableFile == "Specify File Path...":
            Dlg = wx.FileDialog(self.PartTablePanel, "Select Partition Table File...", wildcard="ISO Image file (*.iso)|*.iso|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            if Dlg.ShowModal() == wx.ID_OK:
                RestorePartTable = True
                BootSectFile = Dlg.GetPath()
                self.ptfilechoice.Append(BootSectFile)
                self.ptfilechoice.SetStringSelection(BootSectFile)
            else:
                PartTableFile = "None"
                RestorePartTable = False
                self.ptfilechoice.SetStringSelection("-- Please Select --")
        else:
            PartTableFile = self.ptfilechoice.GetStringSelection()
            RestorePartTable = True

    def ExitWindow(self,e):
        logger.debug("Restore Partition Table Window Closing.")
        global PartTableFile
        global RestorePartTable

        if PartTableFile != "None" and RestorePartTable != False:
            #Show an info message.
            dlg = wx.MessageDialog(None, "Do you want to continue? If you restore a partition table or bootsector, some options, such as installing a different bootloader, and reinstalling/updating your bootloader, will be disabled. Settings such as the new bootloader to install (if any) will also be reset and disabled. If you want to change other settings, you can always do it afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_INFORMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(Publisher().sendMessage, "AnOptionDlgHasClosed", "Closed.")

                #Exit.
                self.Destroy()
            else:
                PartTableFile = "None"
                RestorePartTable = False
                self.ptfilechoice.SetStringSelection("-- Please Select --")
        else:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(Publisher().sendMessage, "AnOptionDlgHasClosed", "Closed.")

                #Exit.
                self.Destroy()

#End Restore Partition Table Window
#Begin Device Info Window
class DevInfoWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Device Information", size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", pos=(30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(330,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(70,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitDevInfoDlg)

        logger.debug("Device Info Window Started.")

    def UpdDevInfo(self,e):
        #Generate device data.
        devicelist = GetDevInfo()

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        logger.debug("Device Info Window Closing.")

        #Exit.
        self.Destroy()

#End Device Info Window
#Begin Progress Window
class ProgressWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Operations Progress", size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.ProgressPanel=wx.Panel(self)

        #Create buttons.
        self.ShowOutputButton = wx.ToggleButton(self.ProgressPanel, -1, "Show Terminal output", pos=(147,220))
        self.RestartButton = wx.Button(self.ProgressPanel, -1, "Restart WxFixBoot", pos=(10,220))
        self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(306,220))
        self.RestartButton.Disable()
        self.ExitButton.Disable()

        #Publisher
        Publisher().subscribe(self.UpdateOutputBox, "OutputBoxUpdate")
        Publisher().subscribe(self.UpdateProgress, "ProgressUpdate")
        Publisher().subscribe(self.UpdateCurrentOpText, "CurrentOpUpdate")
        Publisher().subscribe(self.MainBackendThreadFinished, "Finished")

        #Respond to dialog messages.
        Publisher().subscribe(self.ShowThreadYesNodlg, "showyesnodlg")
        Publisher().subscribe(self.ShowThreadInfodlg, "showinfodlg")
        Publisher().subscribe(self.ShowThreadChoicedlg, "showchoicedlg") 

        self.CreateText()
        self.CreateProgressBars()
        self.BindEvents()

        logger.debug("Progress Window Started.")
        logger.debug("Starting Main Backend Thread...")

        MainBackendThread()

    def CreateText(self):
        #Create Text.
        wx.StaticText(self.ProgressPanel, -1, "WxFixBoot is performing operations... Please wait.", pos=(40,10))
        wx.StaticText(self.ProgressPanel, -1, "Current Operation:", pos=(132,40))
        self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, "Initializating...", pos=(140,60))
        wx.StaticText(self.ProgressPanel, -1, "Current Operation Progress:", pos=(100,90))
        wx.StaticText(self.ProgressPanel, -1, "Overall Progress:", pos=(140,160))

    def CreateProgressBars(self):
        #Create the progress bar for the current operation.
        self.CurrentOpProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,120), size=(380,25))
        self.CurrentOpProgressBar.SetBezelFace(3)
        self.CurrentOpProgressBar.SetShadowWidth(3)
        self.CurrentOpProgressBar.SetValue(0)
        self.CurrentOpProgressBar.Show()

        #Create the progress bar for overall progress.
        self.TotalProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,190), size=(380,25))
        self.TotalProgressBar.SetBezelFace(3)
        self.TotalProgressBar.SetShadowWidth(3)
        self.TotalProgressBar.SetValue(0)
        self.TotalProgressBar.Show()

        #Set up progress monitoring.
        global TotalProgress
        global CurrentProgress

    def ShowThreadYesNodlg(self,msg):
        global dlgResult
        dlg = wx.MessageDialog(None, msg.data, 'WxFixBoot - Question', wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("Progress Window: Result of MainBackendThread cyesno dlg was: "+dlgResult)

    def ShowThreadInfodlg(self,msg):
        global dlgClosed
        dlg = wx.MessageDialog(None, msg.data, "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadChoicedlg(self,msg):
        global dlgResult
        data = msg.data.split('&')
        dlg = wx.SingleChoiceDialog(None, data[0], data[1], data[2:], pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("Progress Window: Result of MainBackendThread choice dlg was: "+dlgResult)

    def ShowOutput(self,e):
        logger.debug("ProgressWindow().ShowOutput() was Toggled to position: "+str(self.ShowOutputButton.GetValue())+", where True = Depressed and vice versa.")
        if self.ShowOutputButton.GetValue() == True:
            self.SetMinSize(wx.Size(400,410))

            #Create a text control for output.
            self.OutputBox = wx.TextCtrl(self.ProgressPanel, -1, "", pos=(10,260), size=(380,140), style=wx.TE_MULTILINE)
            self.OutputBox.SetBackgroundColour((0,0,0))
            self.OutputBox.SetDefaultStyle(wx.TextAttr(wx.WHITE))
        else:
            self.SetMinSize(wx.Size(400,310))
            self.SetSize(wx.Size(400,310))
            self.OutputBox.Destroy()

    def UpdateOutputBox(self,msg):
        #Check if outputbox is enabled. Do nothing if it isn't.
        try:
            self.OutputBox.GetSelection()
        except: pass
        else:
            self.OutputBox.AppendText(msg.data)

    def UpdateProgress(self,msg):
        #First do current progress.       
        #If the current progress is zero, replace the progressbars value with it, to avoid values over 100.
        if int(msg.data) == 0:
            self.CurrentOpProgressBar.SetValue(int(msg.data))
        else:
            self.CurrentOpProgressBar.SetValue(self.CurrentOpProgressBar.GetValue()+int(msg.data))

        if self.CurrentOpProgressBar.GetValue() >= 90 and self.TotalProgressBar.GetValue() < 100:
            self.TotalProgressBar.SetValue(self.TotalProgressBar.GetValue()+100/NoOfOps)
        elif self.CurrentOpProgressBar.GetValue() >= 90 and self.TotalProgressBar.GetValue() >= 100:
            self.TotalProgressBar.SetValue(100/NoOfOps)

    def UpdateCurrentOpText(self,msg):
        #Calculate length (in pixels) of string given, and then where on the x-axis to place it.
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        font = self.ProgressPanel.GetFont()
        dc = wx.WindowDC(self.ProgressPanel)
        dc.SetFont(font)
        width, height = dc.GetTextExtent(msg.data)

        #Create the Static Text, if it already exists, delete it.
        try:
            self.CurrentOpText
        except: pass
        else:
            self.CurrentOpText.Destroy()
        finally:
            self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, msg.data, pos=((400-int(width))/2,60), size=(int(width),int(height)))

    def MainBackendThreadFinished(self,msg):
        self.RestartButton.Enable()
        self.ExitButton.Enable()

    def RestartWxFixBoot(self,e):
        #Restart WxFixBoot
        logger.debug("Restarting WxFixBoot...")
        self.Hide()

        #Reset all settings to defaults, except ones like LiveDisk, which won't change.
        SetDefaults()

        global BootLoader
        global FWType
        global RootFS
        global RootDev
        global DefaultOS
        global PartScheme

        BootLoader = AutoBootLoader
        FWType = AutoFWType
        RootFS = AutoRootFS
        RootDev = AutoRootDev
        DefaultOS = AutoDefaultOS
        PartScheme = AutoPartScheme

        wx.MessageDialog(None, "Okay! WxFixBoot has reset all of its settings. You should now be returned to the Main Window, and everything should be it was when you first started WxFixBoot.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Show MainWindow
        wx.CallAfter(Publisher().sendMessage, "MainWindowRefresh", "Closed")

        #Hide Progress Window.
        self.Destroy()

    def OnExit(self,e):
        #*** MAKE SURE THAT PROGRESSWINDOW'S EXIT METHOD CHECKS IF OPERATIONS ARE RUNNING ***
        #Shut down.
        logger.debug("User triggered exit sequence. Exiting...")
        self.Destroy()

    def BindEvents(self):
        self.Bind(wx.EVT_TOGGLEBUTTON, self.ShowOutput, self.ShowOutputButton)
        self.Bind(wx.EVT_BUTTON, self.RestartWxFixBoot, self.RestartButton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

#End Progress Window
#Begin *UNFINISHED* Main Backend Thread
class MainBackendThread(Thread):
    def __init__(self):
        #Start the main part of this thread.
        Thread.__init__(self)
        self.start()

    def run(self):
        #Do setup
        global PerformingOps

        #Thread message dialogs.
        global dlgClosed
        global dlgResult
 
        #Helpful info collected in the startup scripts, and during use of the GUI.
        global LinuxPartList
        global RootFS
        global RootDev
        global LiveDisk
        global OSList
        global FWType
        global PartScheme
        global BootLoader
        global EFISYSP
        global ManuallyMountedEFISYSP

        #Quick operations on the main window.
        global ReinstallBootloader
        global UpdateBootLoader
        global QuickFSCheck
        global BadSectCheck

        #Advanced options in Optionsdlg1
        global FullVerbose
        global Verify
        global BkpBootSect
        global BackupPartTable
        global UseChroot
        global CreateLog
        global DefaultOS
        global BootLoaderTimeOut

        #Options in BootLoader Options dlg
        global BootLoaderToInstall
        global BootLoaderDestination

        #Options in Restore dlgs
        global RestoreBootSector
        global BootSectFile
        global RestorePartTable
        global PartTableFile

        #Count the number of operations to do.
        global NoOfOps
        NoOfOps = 0

        #Log the MainBackendThread start event (in debug mode).
        logger.debug("MainBackendThread() Started. Calculating Operations to do...")

        #List to contain operations (and their functions) to run.
        OperationsToDo = []
        FriendlyOperationsToDo = []

        #Run a series of if loops to determine what operations to do, which order to do them in, and the total number to do.
        #Do essential processes first.
        if RestorePartTable == True:
            NoOfOps += 1
            OperationsToDo.append(self.RestorePartitionTable)
            FriendlyOperationsToDo.append("self.RestorePartitionTable")

        if RestoreBootSector == True:
            NoOfOps += 1
            OperationsToDo.append(self.RestoreBootSector)
            FriendlyOperationsToDo.append("self.RestoreBootSector")

        if QuickFSCheck == True:
            NoOfOps += 1
            OperationsToDo.append(self.QuickFileSystemCheck)
            FriendlyOperationsToDo.append("self.QuickFileSystemCheck")

        if BadSectCheck == True:
            NoOfOps += 1
            OperationsToDo.append(self.BadSectorCheck)
            FriendlyOperationsToDo.append("self.BadSectorCheck")

        if BkpBootSect == True:
            NoOfOps += 1
            OperationsToDo.append(self.BackupBootSector)
            FriendlyOperationsToDo.append("self.BackupBootSector")

        if BackupPartTable == True:
            NoOfOps += 1
            OperationsToDo.append(self.BackupPartitionTable)
            FriendlyOperationsToDo.append("self.BackupPartitionTable")

        #Now do other processes
        if BootLoaderToInstall != "None":
            NoOfOps += 1
            OperationsToDo.append(self.InstNewBL)
            FriendlyOperationsToDo.append("self.InstNewBL")

        if ReinstallBootLoader == True:
            NoOfOps += 1
            OperationsToDo.append(self.ReInstBL)
            FriendlyOperationsToDo.append("self.ReInstBL")

        if UpdateBootLoader == True:
            NoOfOps += 1
            OperationsToDo.append(self.UpdBootLoader)
            FriendlyOperationsToDo.append("self.UpdBootLoader")

        #Log gathered operations to do, and the number (verbose mode).
        logger.info("Number of operations: "+str(NoOfOps))
        logger.info("Operations to do: "+' '.join(FriendlyOperationsToDo))
        logger.info("Starting to-be Operation Running Code...")

        #Set dlgClosed to avoid problems.
        dlgClosed = "Unknown"

        wx.CallAfter(Publisher().sendMessage, "showinfodlg", "WxFixBoot will now show you through a selftest which will show how this window will work in the final release. First the progress bars will be tested (they won't stop at 100% Complete)")

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

        #Update Progress (testing only)
        count = 0
        count2 = 0
        while count2 < NoOfOps*10:
            count += 1
            count2 += 1
            time.sleep(0.25)
            if count < 10:
                wx.CallAfter(Publisher().sendMessage, "ProgressUpdate", str(10))
            else:
                wx.CallAfter(Publisher().sendMessage, "ProgressUpdate", str(0))
                count = 0

        #Set dlgClosed to avoid problems.
        dlgClosed = "Unknown"

        wx.CallAfter(Publisher().sendMessage, "showinfodlg", "Progress bar test complete! You will now be shown some sample installation progress messages, and some fake terminal output, depending on the operations you have selected (which won't be performed). You will only see status messages if your selection included one or more of: Quick  FS Check, Bad Sector (Thorough) Check, or Backup Partition Table. Please open the terminal output box now. Wait 5 seconds after you see no more activity to enable restarting wxfixboot.")

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

        #Run the functions in the autodetermined list, and start operations. Also start the OutputBoxManager thread, and give it 30 seconds to run afterwards for testing purposes.
        PerformingOps = True
        OutputBoxThread()
        time.sleep(1)
        [function() for function in OperationsToDo]
        logger.info("Finished Operation Running Code.") 
        time.sleep(5)
        PerformingOps = False
        wx.CallAfter(Publisher().sendMessage, "Finished", "Main Backend Thread Finished")

    def RestorePartitionTable(self):
        pass

    def RestoreBootSector(self):
        pass

    def QuickFileSystemCheck(self):
        #Function to quickly check all filesystems.
        #************************* TEST CODE, REMOVE LATER **************************
        print "Quick FS Check"
        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "fsck 1.4.31 starting...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Checking ext4 FS on /dev/hda1...\n")
        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Performing quick FS check. Please Wait...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Checking ext4 FS on /dev/hda1...\n")
        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Checking ext4 FS on /dev/hda2...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Done! No errors reported.\n")
        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Please Wait...\n")
        #************************* END OF TEST CODE, REMOVE LATER **************************

    def BadSectorCheck(self):
        #Function to check all filesystems for bad sectors.
        #************************* TEST CODE, REMOVE LATER **************************
        print "Bad Sector Check"
        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "fsck 1.4.31 starting...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Checking ext4 FS on /dev/hda1...\n")
        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Performing bad sector check. Please Wait...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Checking ext4 FS on /dev/hda1...\n")
        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "10% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "20% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "30% Complete...")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "40% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "50% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "60% Complete...")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "70% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "80% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "90% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "100% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Done! No errors reported.")
        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Please Wait...")
        #************************* END OF TEST CODE, REMOVE LATER **************************

    def BackupBootSector(self):
        #Function to backup the bootsector.
        pass

    def BackupPartitionTable(self):
        #Function to backup the partition table.
        #************************* TEST CODE, REMOVE LATER **************************
        print "Backup PartTable"
        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Preparing to backup partition table...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Please Wait...\n")
        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Preparing to backup partition table. Please Wait...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Backing up partition table. Please Wait...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "50% Complete...\n")

        time.sleep(0.5)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "100% Complete...\n")

        time.sleep(1)

        wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", "Done! No errors reported.\n")
        wx.CallAfter(Publisher().sendMessage, "CurrentOpUpdate", "Please Wait...\n")
        #************************* END OF TEST CODE, REMOVE LATER **************************

    def InstNewBL(self):
        #Function to install a new bootloader.
        pass

    def ReInstBL(self):
        #Function to reinstall the bootloader
        pass

    def UpdBootLoader(self):
        #Function to update bootloader menu
        pass

#End *UNFINISHED* Main Backend Thread
#Begin Output Box Management Thread.
class OutputBoxThread(Thread):
    def __init__(self):
        #Start the main part of this thread.
        Thread.__init__(self)
        self.start()

    def run(self):  
        logger.debug("OutputBoxThread() Started.")
        lastoutputfilecontents = "NULL"
        global PerformingOps
        while PerformingOps == True:
            logger.debug("OutputBoxThread in While Loop. Expect to see this for a while.")
            try:
                outputfile = open('/tmp/wxfixboot/termoutput.txt')
                outputfilecontents = outputfile.readlines()
            except: time.sleep(1); continue
            #Only do anything if the contents are different from the last time
            if outputfilecontents[-5:] != lastoutputfilecontents:
                #Check how many new lines (max 5) to send to the outputbox.
                for elementnum in range(-5,0):
                    try:
                        lastoutputfilecontents.index(outputfilecontents[elementnum])
                    except IndexError: pass #Ignore, as it occours with short output files less than 5 lines long.
                    except ValueError as e:
                        logger.debug("OutputBoxThread: Expected error ValueError traceback: "+str(e))
                        #Include all lines newer and including this one.
                        for line in outputfilecontents[elementnum:]:
                             wx.CallAfter(Publisher().sendMessage, "OutputBoxUpdate", line)
                        break
                    else:
                        pass

                lastoutputfilecontents = outputfilecontents[-5:]
                time.sleep(0.1)

            outputfile.close()
            time.sleep(0.5)

        logger.debug("OutputBoxThread() Terminated and Finished...")

#End Output Box Management Thread
app = WxFixBoot(False)
app.MainLoop()
