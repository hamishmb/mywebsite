#!/usr/bin/env python
# -*- coding: utf-8 -*-
# WxFixBoot Version 1.0rc4
# Copyright (C) 2013-2014 Hamish McIntyre-Bhatty
# WxFixBoot is free software: you can redistribute it and/or modify it
# under the terms of the GNU General Public License version 3 or,
# at your option, any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#Import modules
from distutils.version import LooseVersion
import wx
import sys
from threading import Thread
import time
import os
import shutil
import subprocess
import logging
import getopt

def usage():
    print "\nUsage: WxFixBoot.py [OPTION]\n"
    print "       -h, --help:                   Show this help message"
    print "       -q, --quiet:                  Show only warning, error and critical messages in the log file. Very unhelpful for debugging."
    print "       -v, --verbose:                The default setting when no options are passed. Enable logging of info messages, as well as warnings, errors and critical errors."
    print "       -d, --debug:                  Log lots of very boring debug messages, usually used for diagnostic purposes.\n"
    print "WxFixBoot 1.0rc4 is released under the GNU GPL Version 3"
    print "Copyright (C) Hamish McIntyre-Bhatty 2013-2014"

#If this isn't running as root, relaunch.
if not os.geteuid() == 0:
    subprocess.Popen(["/usr/share/wxfixboot/helperscripts/runasroot.sh"])
    sys.exit("\nSorry, this program must be run with root privileges.\nRestarting as Root...")

#Check if the logfile is already present.
if os.path.isfile('/var/log/wxfixboot.log'):
    #It is, so launch a helper script to deal with asking the user what to do (as app.MainLoop() hasn't been called yet, so we can't yet use dialogs from this script). Also wait for it to finish before continuing.
    subprocess.Popen(['python', '/usr/share/wxfixboot/helperscripts/moveoldlogfiles.py']).wait()

#Set up logging.
logger = logging.getLogger('WxFixBoot')
logging.basicConfig(filename='/var/log/wxfixboot.log', format='%(asctime)s %(message)s', datefmt='%d/%m/%Y %I:%M:%S %p')
logger.setLevel(logging.INFO)

#Set up according to cmdline options.
try:
    opts, args = getopt.getopt(sys.argv[1:], "hqvd", ["help", "quiet", "verbose", "debug"])
except getopt.GetoptError as err:
    #Invalid option. Show the help message and then exit.
    #Show the error.
    print str(err)
    usage()
    sys.exit(2)

#Determine the option(s) given.
for o, a in opts:
    if o in ["-q", "--quiet"]:
        logger.setLevel(logging.WARNING)
    elif o in ["-v", "--verbose"]:
        logger.setLevel(logging.INFO)
    elif o in ["-d", "--debug"]:
        logger.setLevel(logging.DEBUG)
    elif o in ["-h", "--help"]:
        usage()
        sys.exit()
    else:
        assert False, "unhandled option"

#Define some global functions
def GetDevInfo():
    # Run a short bash script to collect data about connected devices.
    subprocess.Popen(["/usr/share/wxfixboot/helperscripts/listdevices.sh"]).wait()

    #Create/Update a device list
    devicelist = []

    #New more efficient way of putting everything in one list.
    with open('/tmp/wxfixboot/idedevices', 'r') as idedevicessource:
        idedevicesfile = idedevicessource.readlines()
        if idedevicesfile != []:
            devicelist = devicelist + idedevicesfile
            devicelist.append('IDE/ATA Devices:')

    with open('/tmp/wxfixboot/cddvddevices', 'r') as cddvddevicessource:
        cddvddevicesfile = cddvddevicessource.readlines()
        if cddvddevicesfile != []:
            devicelist.append('CD/DVD Devices:')
            devicelist = devicelist + cddvddevicesfile

    with open('/tmp/wxfixboot/usbsatadevices', 'r') as usbsatadevicessource:
        usbsatadevicesfile = usbsatadevicessource.readlines()
        if usbsatadevicesfile != []:
            devicelist.append('USB or SATA Devices:')
            devicelist = devicelist + usbsatadevicesfile

    #Remove newline chars.
    return [(el.strip()) for el in devicelist]

def SetDefaults():
    #Options in MainWindow
    global ReinstallBootloader
    global UpdateBootloader
    global QuickFSCheck
    global BadSectCheck
    ReinstallBootloader = False
    UpdateBootloader = False 
    QuickFSCheck = False
    BadSectCheck = False

    #Options in Optionsdlg1
    global SaveOutput
    global FullVerbose
    global Verify
    global BkpBootSect
    global BackupPartTable
    global MakeSystemSummary
    global BootloaderTimeout

    #Set them up for default settings.
    SaveOutput = True
    FullVerbose = False
    Verify = True
    BkpBootSect = False
    BackupPartTable = False
    MakeSystemSummary = True
    BootloaderTimeout = -1 #Don't change the timeout by default.

    #Options in Bootloader Options dlg
    global BootloaderToInstall
    global BLOptsDlgRun
    BootloaderToInstall = "None"
    BLOptsDlgRun = False

    #Options in Restore dlgs
    global RestoreBootSector
    global BootSectFile
    global BootSectorTargetDevice
    global BootSectorBackupType
    global RestorePartTable
    global PartTableFile
    global PartitionTableTargetDevice
    global PartTableBackupType
    RestoreBootSector = False
    BootSectFile = "None"
    BootSectorTargetDevice = "None"
    BootSectorBackupType = "None"
    RestorePartTable = False
    PartTableFile = "None"
    PartitionTableTargetDevice = "None"
    PartTableBackupType = "None"

    #Other Options
    global OptionsDlg1Run
    OptionsDlg1Run = False

def StartProcess(ExecCmds):
    #Start a process given a string with commands to execute.
    #This is here to counteract the language related bug, and to simplify the startup scripts.
    #Run the cmd, but run it though a special wrapper script, to insure output is always English, fixing bug no 1353713.
    logger.debug("StartProcess(): Starting process: "+ExecCmds)
    runcmd = subprocess.Popen("LC_ALL=C "+ExecCmds, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)
    stdout, stderr = runcmd.communicate()

    #Return the return code, and the output back to whichever function ran this process, so it can handle any errors.
    return [int(runcmd.returncode), str(stdout), str(stderr)]

def MountPartitionSafely(Partition, MountPoint):
    #Safely Mount Partitions here, as the code was getting duplicated.
    #Also, check that it isn't already mounted, and that nothing else is already mounted there.
    retval = StartProcess("df | grep "+MountPoint)[0]
    if retval == 0:
        #There is a partition mounted here. Check if it's the one we need mounted here.
        try:
            EFISYSPMountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            #Unmount the partition, and continue.
            logger.warning("MountPartitionSafely(): Warning: Unmounting filesystem in the way at "+MountPoint+"...")
            temp = StartProcess("umount "+MountPoint)
            stdout = temp[1]
            stderr = temp[2]
            logger.debug("MountPartitionSafely(): Command: umount "+MountPoint+" stdout: "+stdout+", stderr: "+stderr)
        else:
            #The correct partition is already mounted here.
            logger.debug("MountPartitionSafely(): Partition: "+Partition+" was already mounted at: "+MountPoint+". Continuing...")
            return "Already Mounted"

    #Create the dir if needed.
    if os.path.exists(MountPoint) == False:
        os.makedirs(MountPoint)
    
    #Mount the device to the mount point. No worries if it's already mounted, as we checked already, and even if it is, any kernel of 2.4 or newer supports mounting FSes twice, and otherwise it'll give an error anyway, which'll be caught and handled.
    temp = StartProcess("mount "+Partition+" "+MountPoint)
    stdout = temp[1]
    stderr = temp[2]

    if stderr == "None" or stdout == "":
        return "Succeeded"
        logger.debug("MountPartitionSafely(): Command: mount "+Partition+" "+MountPoint+" Succeeded! stdout: "+stdout+", stderr: "+stderr)
    else:
        logger.warning("MountPartitionSafely(): Warning: Command: mount "+Partition+" "+MountPoint+" Failed! stdout: "+stdout+", stderr: "+stderr)
        return stdout

#Starter Class
class WxFixBoot(wx.App):
    def OnInit(self):
        Splash = ShowSplash()
        Splash.Show()
        return True

#End Starter Class
#Begin splash screen
class ShowSplash(wx.SplashScreen):
    def __init__(self, parent=None):
        #Convert the image to a bitmap.
        aBitmap = wx.Image(name = "/usr/share/wxfixboot/splash.jpg").ConvertToBitmap()

        self.AlreadyExited = False

        #Display the splash screen.
        wx.SplashScreen.__init__(self, aBitmap, wx.SPLASH_CENTRE_ON_SCREEN | wx.SPLASH_TIMEOUT, 1500, parent)
        self.Bind(wx.EVT_CLOSE, self.OnCloseSplash)

        #Make sure it's painted, which fixes the problem with the previous temperamental splash screen on DDRescue-GUI <= 1.2
        wx.Yield()

    def OnCloseSplash(self,e):
        #Start the init Frame.
        self.Hide()
        if self.AlreadyExited == False:
            #Stop this from executing twice when the splash is clicked.
            self.AlreadyExited = True

            #Warn the user about running in a VM 
            dlg = wx.MessageDialog(None, "Welcome to WxFixBoot Version 1.0rc4! Do you want to continue starting WxFixBoot? As this is a development version, please check the log file at '/var/log/wxfixboot.log' afterwards for any errors. There is also debug output included if the --debug or -d options are passed on the commandline, which is a good idea in case you run into any problems. This version is nearly done, and should really be complete. It's probably safe to run this on a production machine now, except for bootloader operations.", "WxFixBoot - Warning", style=wx.YES_NO | wx.ICON_ERROR, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_NO:
                wx.Exit()
                sys.exit("User aborted the program.")

            #Reset the top window and start InitFrame()
            InitFrame = InitialWindow()
            app.SetTopWindow(InitFrame)
            InitFrame.Show(True)

            #Skip the event so the init frame starts.
            e.Skip()

#End splash screen
#Begin Initialization frame
class InitialWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,parent=None,title="WxFixBoot v1.0rc4 is preparing to start...",size=(400,300),style=wx.CAPTION)
        self.InitPanel = wx.Panel(self)

        print "WxFixBoot Version 1.0~rc4 development Starting..."
        logger.warn("WxFixBoot Version 1.0~rc4 development Starting...")
        logger.warn("Do not use this on ANY production machine!")

        #Create GUI elements
        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBar()

        #Start the Initalization Thread, which performs all necessary startup scripts and checks, and let it know this is the first start.
        logger.debug("Starting InitThread()...")
        InitThread(self,True)       

    def CreateText(self):
        self.DependsCheckText = wx.StaticText(self.InitPanel, -1, "Dependency check...", pos=(10,10))
        self.UnmountFSText = wx.StaticText(self.InitPanel, -1, "Unmounting all unneeded Filesystems...", pos=(10,30))
        self.CheckFSText = wx.StaticText(self.InitPanel, -1, "Quickly Checking Filesystems in fstab...", pos=(10,50))
        self.MountFSText = wx.StaticText(self.InitPanel, -1, "Mounting all Filesystems in fstab...", pos=(10,70))
        self.DetectDevsPartsPartSchemesText = wx.StaticText(self.InitPanel, -1, "Detecting Devices, Partitions, and Partition Schemes...", pos=(10,90))
        self.DetectPartText = wx.StaticText(self.InitPanel, -1, "Detecting Linux Partitions...", pos=(10,110))
        self.RootFSText = wx.StaticText(self.InitPanel, -1, "Determining Root Filesystem and Root Device...", pos=(10,130))
        self.DetectOSesText = wx.StaticText(self.InitPanel, -1, "Detecting Linux OSes...", pos=(10,150))
        self.FWTypeText = wx.StaticText(self.InitPanel, -1, "Determining Firmware Type...", pos=(10,170))
        self.BootloaderText = wx.StaticText(self.InitPanel, -1, "Determining Boot Loader...", pos=(10,190))
        self.FinalCheckText= wx.StaticText(self.InitPanel, -1, "Final check...", pos=(10,210))

    def CreateButtons(self):
        #Create a button., and disable it, to stop the user clicking it before we're ready.
        self.startbutton = wx.Button(self.InitPanel, -1, "Start", pos=(150,235), size=(100,30))
        self.startbutton.Disable()

        #Bind it to an event here.
        self.Bind(wx.EVT_BUTTON, self.FinishedInitConf, self.startbutton)

    def CreateProgressBar(self):
        #Create a progressbar.
        self.InitProgressBar = wx.Gauge(self.InitPanel, -1, 100, pos=(10,270), size=(380,25))
        self.InitProgressBar.SetBezelFace(3)
        self.InitProgressBar.SetShadowWidth(3)
        self.InitProgressBar.SetValue(0)
        self.InitProgressBar.Show()

    def UpdateProgressBar(self,msg):
        self.InitProgressBar.SetValue(int(msg))

    def ShowThreadMsgdlg(self,msg,kind="info"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=<kind>, msg=<message>)
        global dlgClosed
        if kind == "info":
            title = "WxFixBoot - Information"
            style = wx.OK | wx.ICON_INFORMATION
        elif kind == "warning":
            title = "WxFixBoot - Warning"
            style = wx.OK | wx.ICON_EXCLAMATION
        elif kind == "error":
            title = "WxFixBoot - Error"
            style = wx.OK | wx.ICON_ERROR

        dlg = wx.MessageDialog(self.InitPanel, msg, title, style, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadYesNodlg(self,msg,title="WxFixBoot - Question"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=<message>, title=<title>)
        global dlgResult
        dlg = wx.MessageDialog(self.InitPanel, msg, title, wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("InitialWindow().ShowThreadYesNodlg(): Result of InitThread yesno dlg was: "+dlgResult)

    def ShowThreadChoicedlg(self,msg,choices,title="WxFixBoot - Select an Option"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=<message>, title=<title>, choices=<data>)
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.InitPanel, msg, title, choices, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("InitialWindow().ShowThreadChoicedlg(): Result of InitThread choice dlg was: "+dlgResult)

    def ShowThreadTextEntrydlg(self,msg,title="WxFixBoot - Text Entry"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=<message>, title=<title>
        global dlgAnswer
        dlg = wx.TextEntryDialog(self.InitPanel, msg, title, "", style=wx.OK|wx.CANCEL, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetValue()
        else:
            dlgAnswer = "Clicked no..."
        logger.debug("InitialWindow().ShowThreadTextEntrydlg(): Result of InitThread text entry dlg was: "+dlgAnswer)

    def UpdateDependsCheckText(self,msg):
        self.DependsCheckText.SetLabel(msg)

    def UpdateUnmountFSText(self,msg):
        self.UnmountFSText.SetLabel(msg)

    def UpdateMountFSText(self,msg):
        self.MountFSText.SetLabel(msg)

    def UpdateDetectDevsPartsPartSchemesText(self,msg):
        self.DetectDevsPartsPartSchemesText.SetLabel(msg)

    def UpdateDetectPartText(self,msg):
        self.DetectPartText.SetLabel(msg) 

    def UpdateDetectOSesText(self,msg):
        self.DetectOSesText.SetLabel(msg) 

    def UpdateRootFSText(self,msg):
        self.RootFSText.SetLabel(msg)

    def UpdateFWTypeText(self,msg):
        self.FWTypeText.SetLabel(msg)

    def UpdatePartSchemeText(self,msg):
        self.PartSchemeText.SetLabel(msg)

    def UpdateBootloaderText(self,msg):
        self.BootloaderText.SetLabel(msg)

    def UpdateCheckFSText(self,msg):
        self.CheckFSText.SetLabel(msg)

    def UpdateFinalCheckText(self,msg):
        self.FinalCheckText.SetLabel(msg)
        self.startbutton.Enable()

    def FinishedInitConf(self,e):
        logger.info("Closing Initial Window and Starting Main Window...")

        #Show the user some important information
        wx.MessageDialog(self.InitPanel, "Note: Make sure you have a working internet connection before performing any operations. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        self.Destroy()

        #Start MainFrame.
        MainFrame.Show(True)    

#End Initalization Frame
#Begin Initaization Thread.
class InitThread(Thread):
    def __init__(self, ParentWindow, Starting):
        #Make a temporary directory for data used by this program. If it already exists, delete it and recreate it, unless this isn't first run.
        #However, only delete it if no partitions are mounted in it. This has been done before during testing. Otherwise exit.
        self.Starting = Starting
        if self.Starting == True:
            retval = StartProcess("mount | grep '/tmp/wxfixboot'")
            if retval != 0:
                if os.path.exists("/tmp/wxfixboot"):
                    shutil.rmtree("/tmp/wxfixboot")
                    logger.debug("InitThread(): Cleared wxfixboot's temporary folder. Most of the time this doesn't need to be done, but it's probably not a problem. Logging this purely for paranoia's sake :)")
                os.mkdir("/tmp/wxfixboot")
            else:
                logger.critical("InitThread(): CRITICAL ERROR: Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage. Exiting now...")
                self.ShowMsgDlg(Kind="error", Message="Critical Error! Mounted filesystems were found in /tmp/wxfixboot! This should never happen! Please unmount them first to prevent damage. WxFixBoot will now exit.")
                wx.Exit()
                sys.exit("CRITICAL ERROR! Mounted filesystems were found in /tmp/wxfixboot! Please unmount them first to prevent damage.")

        #Initialize the thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        self.start()

    def run(self):
        if self.Starting == True:
            #Set some default settings and wait for the GUI to initialize.
            logger.debug("InitThread(): Starting...")

            #Wait for the GUI.
            time.sleep(1)

            #Check for dependencies
            logger.info("InitThread(): Checking For Dependencies...")
            self.CheckDepends()
            wx.CallAfter(self.ParentWindow.UpdateDependsCheckText, "Dependency check... Passed!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "10")
            logger.info("InitThread(): Done Checking For Dependencies!")

            #Unmount all filesystems, to avoid any (highly unlikely) data corruption.
            logger.info("InitThread(): Unmounting Filesystems...")
            self.UnmountAllFS()
            wx.CallAfter(self.ParentWindow.UpdateUnmountFSText, "Unmounting all unneeded Filesystems... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "20")
            logger.info("InitThread(): Done Unmounting Filsystems!")

            #Check filesystems.
            logger.info("InitThread(): Checking Filesystems...")
            self.CheckFS()
            wx.CallAfter(self.ParentWindow.UpdateCheckFSText, "Quickly Checking Filesystems in fstab... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "30")
            logger.info("InitThread(): Filesystems Checked!")

            #Mount all filesystems.
            logger.info("InitThread(): Mounting Filesystems...")
            self.MountAllFS()
            wx.CallAfter(self.ParentWindow.UpdateMountFSText, "Mounting all Filesystems in fstab... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "40")
            logger.info("InitThread(): Done Mounting Filsystems!")

            #Detect Devices, Partitions, and Partition Schemes
            logger.info("InitThread(): Detecting Devices, Partitions, and PartSchemes...")
            self.DetectDevicesPartitionsAndPartSchemes()
            wx.CallAfter(self.ParentWindow.UpdateDetectDevsPartsPartSchemesText, "Detecting Devices, Partitions, and Partition Schemes... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "50")
            logger.info("InitThread(): Finished Detecting Devices, Partitions, and PartSchemes!")

            #Detect Linux Partitions.
            logger.info("InitThread(): Detecting Linux Partitions...")
            self.DetectLinuxPartitions()
            wx.CallAfter(self.ParentWindow.UpdateDetectPartText, "Detecting Linux Partitions... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "60")
            logger.info("InitThread(): Finished Detecting Linux Partitions!")
  
            #Get the root filesystem and root device.
            logger.info("InitThread(): Determining Root Filesystem and Root Device...")
            self.GetRootFSandRootDev()
            wx.CallAfter(self.ParentWindow.UpdateRootFSText, "Determining Root Filesystem and Root Device... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "70")
            logger.info("InitThread(): Determined Root Filesystem as: "+RootFS+ " , Root Device as "+RootDev)

            #Get a list of Linux OSes (if LiveDisk = True, this has already been run).
            logger.info("InitThread(): Finding Linux OSes...")
            if LiveDisk == False:
                self.GetLinuxOSes()
            wx.CallAfter(self.ParentWindow.UpdateDetectOSesText, "Detecting Linux OSes... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "80")
            logger.info("InitThread(): Found all Linux OSes. Default: "+DefaultOS)

            #Get the firmware type.
            logger.info("InitThread(): Determining Firmware Type...")
            self.GetFirmwareType()
            wx.CallAfter(self.ParentWindow.UpdateFWTypeText, "Determining Firmware Type... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "90")
            logger.info("InitThread(): Determined Firmware Type as: "+FWType)

            #Get the Bootloader.
            logger.info("InitThread(): Determining The Bootloader...")
            self.GetBootloader()
            wx.CallAfter(self.ParentWindow.UpdateBootloaderText, "Determining Boot Loader... Done!")
            wx.CallAfter(self.ParentWindow.UpdateProgressBar, "100")
            logger.info("InitThread(): Bootloader is: "+Bootloader)

            #Perform final check.
            logger.info("InitThread(): Doing Final Check for error situations...")
            self.FinalCheck()
            wx.CallAfter(self.ParentWindow.UpdateFinalCheckText, "Final check... All Okay!")
            logger.info("InitThread(): Done Final Check!")
            logger.info("InitThread(): Finished Determining Settings. Exiting InitThread()...")
        else:
            #Get the Bootloader. It reads self.Starting for itself.
            logger.info("InitThread(): Determining The Bootloader...")
            self.GetBootloader()
            logger.info("InitThread(): Bootloader is: "+Bootloader)

    def ShowMsgDlg(self,Message,Kind="info"):
        #Method to handle showing thread message dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowMsgDlg(Kind=<kind>, Message=<message>)
        #Reset dlgClosed, avoiding errors.
        global dlgClosed
        dlgClosed = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=Kind, msg=Message)

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

    def ShowYesNoDlg(self,Message,Title="WxFixBoot - Question"):
        #Method to handle showing thread yes/no dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowYesNoDlg(Message=<message>, Title = <title>)
        #Reset dlgResult, avoiding errors.
        global dlgResult
        dlgResult = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=Message, title=Title)

        #Trap the thread until the user responds.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        #Return dlgResult directly potentially avoiding problems.
        return dlgResult

    def ShowChoiceDlg(self,Message,Title,Choices):
        #Method to handle showing thread choice dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowChoiceDlg(Message=<message>, Title=<title>, Choices=<choices>)
        while True:
            #Reset dlgResult, avoiding errors.
            global dlgResult
            dlgResult = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=Message, title=Title, choices=Choices)

            #Trap the thread until the user responds.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgResult in ["", "Clicked no..."]:
                self.ShowMsgDlg(Kind="warning", Message="Please make a valid selection.")
            else:
                #Return dlgResult directly potentially avoiding problems.
                return dlgResult

    def ShowTextEntryDlg(self,Message,Title="WxFixBoot - Text Entry"):
        #Method to handle showing thread text entry dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowTextEntryDlg(Message=<message>, Title=<title>)
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=Message, title=Title)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgAnswer == "":
                self.ShowMsgDlg(Kind="warning", Message="Please enter a value or click cancel.")
            else:
                #Return dlgAnswer directly potentially avoiding problems.
                return dlgAnswer

    def CheckDepends(self):
        #This is a dependency checking function, will will show an error message and kill the app if the dependencies are not met.
        #Create a temporary list to allow wxfixboot to notify of particular unmet dependencies.
        templist = ['mount', '-V', 'umount', '-V', 'parted' ,'-v', 'lsb_release', '-v', 'dmidecode', '-V', 'grep', '-V', 'lsblk', '--help', 'df', '--version', 'chroot', '--version', 'dd', '--version', 'find', '--version']

        #Create a list to contain names of failed commands.
        failedlist = []
        for command in templist:
            #If the command does not start with '-', run it as it isn't just an argument.
            if command[0] != "-":
                argument = templist[templist.index(command)+1]
                #Run the command with its argument and log the output (if in debug mode)
                temp = StartProcess(command+" "+argument)
                retval = temp[0]
                stdout = temp[1]
                stderr = temp[2]
                logger.debug("InitThread().CheckDepends(): Dependency check: Command: "+command+" stdout: "+stdout+", stderr: "+stderr)

                if retval != 0:
                    logger.error("InitThread().CheckDepends(): Error: Dependency problems! Command: "+command+" failed to execute or wasn't found.")
                    logger.error("InitThread().CheckDepends(): Error: The error was: "+stderr)
                    failedlist.append(command)

        #Check if any commands failed.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("InitThread().CheckDepends(): Critical Error: Dependencies missing! WxFixBoot will exit. The missing dependencies are: "+', '.join(failedlist)+"Exit.")
            self.ShowMsgDlg(Kind="error", Message="The following dependencies were not found on your system: "+', '.join(failedlist)+"\nPlease install the missing dependencies. WxFixBoot will now exit.")

            wx.Exit()
            sys.exit("Missing dependencies: "+', '.join(failedlist)+" Exiting...")

    def UnmountAllFS(self):
        #Unmount any unnecessary filesystems, to prevent the very unlikely case of data corruption.
        #Warn about removing devices.
        self.ShowMsgDlg(Kind="info", Message="Any unnecessary filesystems will now be unmounted. Please now remove all unneeded devices connected to your computer, and close any other running programs, and then click okay. On the contrary, if you're doing a disk check, please plug in any devices you wish to check now.")

        #Attempt unmount of all filesystems, attempting to mount read-only upon failed unmounts.
        temp = StartProcess("umount -ad")
        stdout = temp[1]
        stderr = temp[2]
        logger.debug("InitThread().UnmountAllFS(): Command: 'umount -ad' stdout: "+stdout+", stderr: "+stderr)

    def CheckFS(self):
        #Check all non-mounted filesystems.
        temp = StartProcess("fsck -ARMp")
        stdout = temp[1]
        stderr = temp[2]
        logger.debug("InitThread().CheckFS(): Command: 'fsck -ARMp' stdout: "+stdout+", stderr: "+stderr)

    def MountAllFS(self):
        #Mount filsystems defined in the /etc/fstab of the current operating system.
        #All other filesystems will be mounted when/as needed.
        temp = StartProcess("mount -av")
        stdout = temp[1]
        stderr = temp[2]
        logger.debug("InitThread().MountAllFS(): Command: 'mount -a' stdout: "+stdout+", stderr: "+stderr)
        logger.debug("InitThread().MountAllFS(): 'mount -a' ran fine, continuing...")

    def DetectDevicesPartitionsAndPartSchemes(self):
        #Detect all devices, partitions, and their partition schemes.
        #Define Global Variables.
        global PartitionListWithFSType
        global DeviceList
        global PartSchemeList
        global AutoPartSchemeList
        global GPTInAutoPartSchemeList
        global MBRInAutoPartSchemeList

        #Create a list for the devices.
        DeviceList = []

        #Create a list for Partition Schemes.
        AutoPartSchemeList = []

        #Create a list for the partitions.
        PartitionListWithFSType = []

        temp = StartProcess("lsblk -r -o NAME,FSTYPE | grep -v 'NAME'")[1]
        templist = temp.split()

        #Populate the device list, and the Partition List including FS Type.
        for element in templist:
            #Check if the element is a device, and doesn't end with a digit (isn't a partition).
            if element[0:2] in ['sd', 'hd'] and element[-1].isdigit() == False:

                #First AutoPartSchemeList
                try:
                    #Check if the element is already in DeviceList, as if it is, it won't be duplicated in AutoPartSchemeList either this way.
                    DeviceList.index('/dev/'+element)
                except ValueError:
                    #It isn't, add it.
                    PartScheme = self.GetDevPartScheme('/dev/'+element)
                    AutoPartSchemeList.append(PartScheme)

                #Now DeviceList
                try:
                    #Check if the element is already in DeviceList.
                    DeviceList.index(element)
                except ValueError:
                    #It isn't, add it.
                    DeviceList.append('/dev/'+element)

            #If instead the partition is not a device, but instead a partition of any type, add it to the Partition List with FSType, along with the next element, if it is not a device or partition.
            elif element[0:2] in ['sd', 'hd'] and element[-1].isdigit() == True:

                PartitionListWithFSType.append('/dev/'+element)
                temp = templist[templist.index(element)+1]

                #Add the next element if it's an FSType. If it isn't, put "Unknown" in its place.
                if temp[0:2] not in ['sd', 'hd']:
                    PartitionListWithFSType.append(temp)
                else:
                    PartitionListWithFSType.append("Unknown")

        #Now set PartSchemeList the same as AutoPartSchemeList.
        PartSchemeList = AutoPartSchemeList[:]

        logger.debug("InitThread().DetectDevicesPartitionsAndPartSchemes(): DeviceList, PartitionListWithFSType and PartSchemeList Populated okay. Contents (respectively): "+' '.join(DeviceList)+" and: "+' '.join(PartitionListWithFSType)+" and: "+' '.join(PartSchemeList))

        #Finally, save two variables showing whether there are any mbr or gpt entries on the disks.
        #GPT
        try:
            PartSchemeList.index("gpt")
        except ValueError:
            GPTInAutoPartSchemeList = False
        else:
            GPTInAutoPartSchemeList = True

        #MBR(MSDOS)
        try:
            PartSchemeList.index("msdos")
        except ValueError:
            MBRInAutoPartSchemeList = False
        else:
            MBRInAutoPartSchemeList = True

    def GetDevPartScheme(self,Device):
        #Get the partition type on the given Device, and return it.
        temp = StartProcess("parted "+Device+" print | grep 'Partition Table'")[1]
        return temp.split()[2]

    def DetectLinuxPartitions(self):
        #Get a list of partitions of type ext (2,3 or 4) / btrfs / xfs / jfs / zfs / minix / reiserfs.
        global LinuxPartList

        #Run the command to find them, and save the results in a list.
        temp = StartProcess("lsblk -r -o NAME,FSTYPE | grep 'ext\|btrfs\|xfs\|jfs\|zfs\|minix\|reiserfs'")[1]
        templist = temp.split()

        #Check if there are any linux partitions in the list.
        if templist == []:
            #There are none, exit.
            logger.critical("InitThread().DetectLinuxPartitions(): Critical Error: No Linux Partitions of type ext(1,2,3,4), btrfs, xfs, jfs, zfs, minix or resierfs found! Exiting...")
            self.ShowMsgDlg(Kind="error", Message="You don't appear to have any Linux partitions. The supported filesystems are ext (any version), btrfs, xfs, jfs, zfs, minix and resierfs. If you do have Linux partitions, but wxfixboot hasn't found them, or your partition type isn't supported, please file a bug or ask a question on wxfixboot's launchpad page. If you're using Windows or Mac OS X, then sorry as wxfixboot has no support for non-Linux operating systems and bootloaders, and you could instead use the tools provided by Microsoft and Apple to fix issues with your computer. WxFixBoot will now exit.")

            #Exit.
            wx.Exit()
            sys.exit("Critical Error! No supported Linux filesystems found. Will now exit...")

        LinuxPartList = []

        #Create a list of only the partitions in the templist.
        for element in templist:
            if element[0:2] in ['sd', 'hd'] and element[-1].isdigit():
                LinuxPartList.append('/dev/'+element)

        logger.debug("InitThread().DetectLinuxPartitions(): LinuxPartList Populated okay. Contents: "+' '.join(LinuxPartList))

    def GetRootFSandRootDev(self):
        #Determine RootFS, and RootDev
        #Setup some global vars
        global AutoRootFS
        AutoRootFS = "Unknown"
        global RootFS
        global AutoRootDev
        global RootDev
        global LiveDisk
        global DefaultOS
        global AutoDefaultOS

        temp = self.ShowYesNoDlg(Message="Is WxFixBoot being run on a live disk, such as Parted Magic?", Title="WxFixBoot - Live Disk?")
        
        if temp == "Yes":
            logger.warning("InitThread().GetRootFSandRootDev(): Warning: User reported WxFixBoot is on a live disk...")

            #Make an early call to GetLinuxOSes()
            LiveDisk = True
            self.GetLinuxOSes()

            self.ShowChoiceDlg(Message="Please select the Linux Operating System you normally boot.", Title="WxFixBoot - Select Operating System", Choices=OSList)

            #Save the info.
            logger.info("InitThread().GetRootFSandRootDev(): User selected default Linux OS of: "+dlgResult+". Continuing...")
            DefaultOS = dlgResult
            AutoDefaultOS = DefaultOS
            RootFS = dlgResult.split()[-1]
            AutoRootFS = RootFS
            RootDev = RootFS[0:8]
            AutoRootDev = RootDev 
        else:
            logger.warning("InitThread().GetRootFSandRootDev(): Warning: User reported WxFixBoot isn't on a live disk...")

            self.ShowMsgDlg(Kind="info", Message="Your currently booted OS will then be taken as the default OS. You can reset this later if you wish.")

            #By the way the default OS in this case is set later, when OS detection takes place.
            RootFS = StartProcess("df -k / | grep -v 'Filesystem'")[1].split()[0]
            AutoRootFS = RootFS
            RootDev = RootFS[0:8]
            AutoRootDev = RootDev
            LiveDisk = False

    def GetLinuxOSes(self):
        #Get the names of all Linux OSes on the HDDs.
        global OSList
        global DefaultOS
        global AutoDefaultOS
        OSList = []

        #Get Linux OSes.
        logger.debug("InitThread().GetLinuxOSes(): Populating OSList...")
        for Partition in LinuxPartList:
            #Skip some stuff if we're ot on a live disk and Partition == AutoRootFS.
            if LiveDisk == False and Partition == AutoRootFS:
                #Look for an OS on this partition.
                temp = StartProcess("lsb_release -sd")
                retval = temp[0]
                OS = temp[1].replace('\n', '')

                #Run the function to get the architechure, letting the function know that it shouldn't use chroot.
                OSArch = self.DetermineOSArchitecture(Partition=Partition, Chroot=False)

                #If the OS's name wasn't found, but its architecture was, there must be an OS here, so ask the user for its name.
                if retval != 0 and OSArch != "None":
                    #As this is the current OS, force the user to name it, or be stuck permanently in a loop.
                    OS = "None"
                    while OS == "None":
                        OS = self.AskForOSName(Partition=Partition, OSArch=OSArch)

                #Don't use elif here, so we'll also save it if self.AskForOSName() was used to determine the name. If it is still None, the user skipped naming it. Ignore it instead.
                if OS != "" and OSArch != "None":
                    #Add this information to the OSList, and set it as the default OS
                    DefaultOS = OS+' (Current OS) '+OSArch+' on partition '+Partition
                    AutoDefaultOS = DefaultOS
                    OSList.append(OS+' (Current OS) '+OSArch+' on partition '+Partition)

            elif Partition[0:7] in ['/dev/sd', '/dev/hd']:
                #We're interested in this element, because it's an HDD or usb disk partition.
                #Mount the partition safely, using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint="/mnt"+Partition)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, as it's safer to do so.
                    logger.warning("InitThread().GetLinuxOSes(): Command: 'mount "+Partition+" /mnt"+Partition+" -r' errored with stderr: "+retstr+"! Ignoring it, as it's safer using a very old linux kernel.")
                else:
                    #Look for an OS on this partition.
                    temp = StartProcess("chroot /mnt"+Partition+" lsb_release -sd")
                    retval = temp[0]
                    OS = temp[1].replace('\n', '')

                    #Run the function to get the architechure, letting the function know that it shouldn't use chroot.
                    OSArch = self.DetermineOSArchitecture(Partition=Partition, Chroot=True)

                    #If the OS's name wasn't found, but its architecture was, there must be an OS here, so ask the user for its name.
                    if retval != 0 and OSArch != "None":
                        OS = self.AskForOSName(Partition=Partition, OSArch=OSArch)

                    #Don't use elif here, so we'll also save it if self.AskForOSName was used to determine the name. If it is still None, the user skipped naming it. Ignore it instead and skip the rest of the loop.
                    if OS != "None" and OSArch != "None":
                        #Add this information to the OSList.
                        OSList.append(OS+' '+OSArch+' on partition '+Partition)

                #Unmount the filesystem.
                time.sleep(0.2)
                StartProcess("umount /mnt"+Partition)

                #Remove the temporary mountpoint
                os.rmdir("/mnt/"+Partition)

        logger.debug("InitThread().GetLinuxOSes(): OSList Populated okay. Contents: "+' '.join(OSList))

    def DetermineOSArchitecture(self, Partition, Chroot):
        #Look for OS architecture on given partition, looking for 64-bit first, then 32-bit.
        #First set cmd to 64-bit to get it looking for the 64-bit arch first. 
        lookfor = "64-bit"

        #Use a loop to avoid duplicating code.
        while True:
            #Prepare the command based on which arch we're looking for.
            if lookfor == "64-bit":
                cmd = "file -L /usr/bin/ld | grep -wo '64-bit'"
            else:
                cmd = "file -L /usr/bin/ld | grep -wo '32-bit'"

            #If we're using chroot, add that to the command.
            if Chroot == True:
                cmd = "chroot /mnt"+Partition+" "+cmd

            #Now let's check if the OS uses this arch.
            temp = StartProcess(cmd)
            PartitionArch = temp[1].replace('\n', '')
            retval = temp[0]

            if retval != 0 and lookfor == "64-bit":
                #Now look for 32-bit and restart the loop.
                lookfor = "32-bit"
            elif retval != 0:
                #We couldn't find it as either 32-bit or 64-bit!
                PartitionArch = "None"
                break
            else:
                break

        #Return the arch (or None, if we didn't find it).
        return PartitionArch

    def AskForOSName(self,Partition,OSArch):
        #Ask the user if an OS exists on the given partition.
        #This might be a very old one linux OS.
        if Partition == AutoRootFS:
            self.ShowMsgDlg(Kind="warning", Message="WxFixBoot couldn't find the name of the currently running OS, with architecture: "+OSArch+". You need to click okay here to name it for WxFixBoot to function correctly.")
            temp = "Yes"
        else:
            temp = self.ShowYesNoDlg(Message="There is a Linux operating system on partition: "+Partition+", with architecture: "+OSArch+" , but WxFixBoot couldn't find its name. It isn't the currently running OS. Do you want to name it and include it in the list?. Only click yes if you believe it is a recent OS.")

        if temp == "No":
            logger.info("InitThread().AskForOSName(): User didn't want to name the OS in "+Partition+"! Ignoring it...")
            #User reported no OS in this partition, ignore it.
            return "None"
        else:
            logger.debug("InitThread().AskForOSName(): User reported recent Linux OS in "+Partition+". Asking name of OS...")
            #User reported that an OS is here.
            temp = self.ShowTextEntryDlg(Message="Please enter the name of the operating system that is on "+Partition+".\nIf this is an old Linux distribution, it's probably better to click no here and ignore it for safety reasons, with the exception of it being the currently running OS.\nThe name you specify will be used later in the program", Title="WxFixBoot - Enter OS Name")

            if temp == "Clicked no...":
                logger.debug("InitThread().AskForOSName(): User reported old OS in "+Partition+". Continuing and ignoring it...")
                #User reported old OS in this partition, ignore it.
                return "None"
            else:
                return temp

    def GetFirmwareType(self):
        #Get the firmware type.
        global FWType
        global AutoFWType
        global EFIVars

        #Set EFIVars to prevent an error on BIOS systems.
        EFIVars = False

        #Check if the firmware type is UEFI.
        retval = StartProcess("dmidecode -q | grep 'UEFI'")[0]

        if retval != 0:
            #It's BIOS.
            logger.info("InitThread().GetFirmwareType(): Detected Firmware Type as BIOS...")
            FWType = "BIOS"
            AutoFWType = "BIOS"
        else:
            #It's UEFI.
            logger.info("InitThread().GetFirmwareType(): Detected Firmware Type as UEFI. Looking for UEFI Variables...")
            FWType = "UEFI"
            AutoFWType = "UEFI"

            #Also, look for UEFI variables.
            #Make sure efivars module is loaded. If it doesn't exist, continue anyway.
            temp = StartProcess("modprobe efivars")
            stdout = temp[1].replace('\n', '')
            stderr = temp[2]
            logger.debug("InitThread().GetFirmwareType(): Command: 'modprobe efivars' stdout: "+stdout+", stderr: "+stderr)

            #Look for the UEFI vars in some common directories.
            if os.path.exists("/sys/firmware/efi/vars"):
                EFIVars = True
                logger.info("InitThread().GetFirmwareType(): Found UEFI Variables at /sys/firmware/efi/vars...")
            elif os.path.exists("/sys/firmware/efi/efivars"):  
                EFIVars = True
                logger.info("InitThread().GetFirmwareType(): Found UEFI Variables at /sys/firmware/efi/efivars...")
            else:
                logger.warning("InitThread().GetFirmwareType(): Warning: UEFI vars not found in /sys/firmware/efi/vars or /sys/firmware/efi/efivars. Attempt manual mount...")
                #Attempt to manually mount the efi vars, as we couldn't find them.
                if not os.path.exists("/sys/firmware/efi/vars"):
                    os.mkdir("/sys/firmware/efi/vars")

                temp = StartProcess("mount -t efivarfs efivars /sys/firmware/efi/vars")
                stdout = temp[1].replace('\n', '')
                stderr = temp[2]
                if stderr == "None" or stdout != "None":
                    logger.warning("InitThread().GetFirmwareType(): Warning: Failed to mount UEFI vars! Warning user. Ignoring and continuing.")
                    #UEFI vars not available or couldn't be mounted.
                    self.ShowMsgDlg(Kind="warning", Message="Your computer uses UEFI firmware, but the UEFI variables couldn't be mounted or weren't found. Please insure you've booted in UEFI mode rather than legacy or CSM mode to enable access to the UEFI variables. You can attempt installing a UEFI bootloader without them, but it may not work, and isn't recommended.")
                else:
                    #Successfully mounted them.
                    EFIVars = True
                    logger.info("InitThread().GetFirmwareType(): Mounted UEFI Variables at: /sys/firmware/efi/vars. Continuing...")

    def GetBootloader(self):
        #Determine the current bootloader.
        global Bootloader
        global AutoBootloader
        global PrevBootloaderSetting
        global AutoEFISYSP
        global UEFISYSP
        global ManuallyMountedEFISYSP
        global OSList
        global HelpfulEFIPartition
        global FatPartitions
        if self.Starting == True:
            HelpfulEFIPartition = False
            PrevBootloaderSetting = "None"
            UEFISYSP = "None"
            AutoEFISYSP = "None"
            ManuallyMountedEFISYSP = "None"
            FatPartitions=['None']

        #Run some inital scripts
        logger.debug("InitThread().GetBootloader(): Copying MBR bootsector to /tmp/wxfixboot/mbrbootsect...")
        temp = StartProcess("dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect")
        stdout = temp[1].replace('\n', '')
        stderr = temp[2]
        logger.debug("InitThread().GetBootloader(): GetBootloader: Command: 'dd if="+RootDev+" bs=512 count=1 > /tmp/wxfixboot/mbrbootsect' stdout: "+stdout+", stderr: "+stderr)
        
        logger.debug("InitThread().GetBootloader(): Copied MBR bootsector to file.")

        #Wrap this in a loop, so once a Bootloader is found, searching can stop.
        while True:
            #Check for a UEFI partition, but only if this is the first run.
            #Otherwise, skip some stuff.
            if self.Starting == True:
                #Check for an UEFI system partition.
                logger.debug("InitThread().GetBootloader(): Checking For a UEFI partition...")
                AutoEFISYSP = self.CheckForEFIPartition()
                UEFISYSP = AutoEFISYSP

            #If there is no UEFI partition, ask the user.
            if UEFISYSP[0:7] not in ["/dev/sd", "/dev/hd"]:
                #There is no UEFI partition.
                #If self.Starting = True, then we'll look for BIOS bootloaders here.
                if self.Starting == True:
                    #Check for GRUB in the MBR
                    logger.debug("InitThread().GetBootloader(): Checking for GRUB in bootsector...")
                    AutoBootloader = self.CheckForGRUBBIOS()
                    if AutoBootloader == "GRUB2":
                        AutoBootloader = self.DetermineGRUBBIOSVersion()
                        break

                    #Check for LILO in MBR
                    logger.debug("InitThread().GetBootloader(): Checking for LILO in bootsector...")
                    AutoBootloader = self.CheckForLILO()
                    if AutoBootloader == "LILO":
                        logger.info("InitThread().GetBootloader(): Found LILO in MBR (shown as LILO in GUI. Continuing...")
                        break

                #No bootloader was found, so ask the user instead.
                #Do a manual selection of the bootloader.
                logger.warning("InitThread().GetBootloader(): Warning: Asking user what the bootloader is, as neither GRUB nor LILO was detected in MBR, and no UEFI partition was found...")
                AutoBootloader = self.ManualBootloaderSelect()
                break

            #Mount (or skip if mounted) the UEFI partition.
            logger.info("InitThread().GetBootloader(): Attempting to mount the UEFI partition (if it isn't already)...")
            EFISYSPMountPoint = self.MountEFIPartition(UEFISYSP)
            logger.info("InitThread().GetBootloader(): UEFI Partition mounted at: "+EFISYSPMountPoint+". Continuing to look for UEFI bootloaders...")

            #Attempt to figure out which bootloader is present.
            #Check for GRUB-UEFI
            logger.debug("InitThread().GetBootloader(): Checking for GRUB-UEFI in UEFI Partition...")
            AutoBootloader = self.CheckForGRUBEFI(EFISYSPMountPoint)
            if AutoBootloader == "GRUB-UEFI":
                logger.info("InitThread().GetBootloader(): Found GRUB in UEFI Partition (shown as GRUB-UEFI in GUI). Continuing...")
                break

            #Check for ELILO
            logger.debug("InitThread().GetBootloader(): Checking for ELILO (ELILO) in UEFI Partition...")
            AutoBootloader = self.CheckForELILO(EFISYSPMountPoint)
            if AutoBootloader == "ELILO":
                logger.info("InitThread().GetBootloader(): Found LILO in UEFI Partition (shown as ELILO in GUI). Continuing...")
                break

            #Obviously, no bootloader has been found.
            #Do a manual selection.
            logger.warning("InitThread().GetBootloader(): Warning: Asking user what the bootloader is, as no bootloader was found...")
            AutoBootloader = self.ManualBootloaderSelect()

            #The program waits until something was chosen, so if it executes this, the bootloader has been set.
            break

        #Set the default bootloader value.
        Bootloader = AutoBootloader

        #If this was started after selecting a new bootloader, send a message to OptionsWindow2, so the program continues.
        if self.Starting == False:
            wx.CallAfter(self.ParentWindow.EFIPartitionScanned, AutoBootloader)

    def CheckForEFIPartition(self):
        global FatPartitions
        FatPartitions = ['None']

        #Get a list of partitions of type vfat, if any.
        templist = StartProcess("lsblk -r -o NAME,FSTYPE | grep 'vfat'")[1].split()

        #Create another list of only the devices. Ignore anything else.
        for element in templist:
            if element[0:2] in ['sd', 'hd']:
                FatPartitions.append("/dev/"+element)

        if LiveDisk == False:
            try:
                UEFISYSP = "/dev/"+StartProcess("lsblk -r -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep '/boot'")[1].split()[0]
            except IndexError:
                logger.warning("InitThread().CheckForEFIPartition(): Warning: Failed to find the UEFI Partition. Trying another way...")
                #Try a second way to get the UEFI system partition.
                try:
                    UEFISYSP = "/dev/"+StartProcess("lsblk -r -o NAME,FSTYPE,MOUNTPOINT,LABEL | grep 'ESP'")[1].split()[0]
                except IndexError:
                    #Ask the user where it is.
                    logger.warning("InitThread().CheckForEFIPartition(): Warning: Couldn't autodetermine UEFI Partition. Asking the user instead...")
                    AskForEFIPartition = True
                else:
                    logger.info("InitThread().CheckForEFIPartition(): Found UEFI Partition at: "+UEFISYSP)
                    return UEFISYSP
            else:
                logger.info("InitThread().CheckForEFIPartition(): Found UEFI Partition at: "+UEFISYSP)
                return UEFISYSP

        if LiveDisk == True or AskForEFIPartition == True:
            logger.warning("InitThread().CheckForEFIPartition(): Warning: Asking user where UEFI Partition is. If you're running from a live disk, ignore this warning.")
            if FatPartitions != ['None']:
                temp = self.ShowChoiceDlg(Message="Please select your UEFI partition. You can change this later in the bootloader options window if you change your mind, or if it's wrong.\nClick no if you don't have a UEFI partition.", Title="WxFixBoot - Select UEFI Partition", Choices=FatPartitions)

                if temp in ["Clicked no...", "None"]:
                    logger.warning("InitThread().CheckForEFIPartition(): Warning: User said no UEFI Partition exists. Continuing...")
                    return "None"
                else:
                    logger.info("InitThread().CheckForEFIPartition(): User reported UEFI partition at: "+dlgResult+". Continuing...")
                    return temp
            else:
                return "None"
                    
    def MountEFIPartition(self,UEFISYSP):
        #Get the UEFI partition's current mountpoint, if it is mounted.
        logger.debug("InitThread().MountEFIPartition(): Preparing to mount UEFI system Partition if needed...")

        #It isn't mounted, mount it, and also create the directory if needed.
        logger.debug("InitThread().MountEFIPartition(): Mounting UEFI Partition at /boot/efi...")
        EFISYSPMountPoint = "/boot/efi"

        #Mount it using the global mount function.            
        temp = MountPartitionSafely(Partition=UEFISYSP, MountPoint=EFISYSPMountPoint)
        if temp == "Success":
            logger.info("InitThread().MountEFIPartition(): Successfully Mounted UEFI Partition...")
        elif temp == "Already Mounted":
            logger.info("InitThread().MountEFIPartition(): UEFI Partition already mounted at /boot/efi...")
        else:
            #This very rarely happens!
            logger.error("InitThread().MountEFIPartition(): Error: Failed to mount UEFI Partition! Continuing anyway, with reported mountpoint as /boot/efi...")
        
        return EFISYSPMountPoint

    def CheckForGRUBBIOS(self):
        #Check for GRUB (2 and Legacy)
        temp = StartProcess("cat /tmp/wxfixboot/mbrbootsect | grep 'GRUB'")[1].replace('\n', '')
        if temp == "Binary file (standard input) matches":
            #Bootloader is GRUB MBR
            return "GRUB2"
        else:
            return "Not GRUB MBR"

    def DetermineGRUBBIOSVersion(self):
        #Check if the system is using grub-legacy or grub2.
        if LiveDisk == False:
            #Find the name of the current OS.
            for OS in OSList:
                if OS.split()[-4] == "OS)":
                    temp = ' '.join(OS.split()[0:-5])

            #Ask the user if this OS installed the bootloader.
            temp = self.ShowYesNoDlg(Message="Was the bootloader installed by the current OS ("+temp+")? If this OS is the most recently installed one, it probably installed the bootloader. If you're not sure, click No.")
        
            if temp == "Yes":
                #Run a command to print grub's version.
                temp = StartProcess("grub-install --version")
                stdout = temp[1].replace('\n', '')
                stderr = temp[2]
                logger.debug("InitThread().DetermineGRUBVersion(): Command: 'grub-install --version' stdout: "+stdout+", stderr: "+stderr)

                #Try to grab the first number in the list, getting rid of the brackets. If it fails, we've almost certainly got GRUB2.
                temp = "empty"
                stdout = stdout.replace("(", "").replace(")", "")
                for version in stdout.split():
                    try:
                        float(version)
                    except ValueError: pass
                    else:
                        temp = version
                        break

                #Check if there is a version number found. If not, it's grub2.
                if temp == "empty":
                    logger.info("InitThread().DetermineGRUBVersion(): Found GRUB2 in MBR (Shown as GRUB2 in GUI). Continuing...")
                    return "GRUB2"
                else:
                    #If a number was found, check if it's lower than or equal to 1.97 (aka it's grub legacy)
                    if float(temp) <= 1.97:
                        return "GRUB-LEGACY"
                        logger.warning("InitThread().DetermineGRUBVersion(): Warning: Found GRUB-LEGACY in MBR! Some options will be disabled, as grub legacy isn't fully supported because it is obsolete. Continuing...")
                    else:
                        logger.info("InitThread().DetermineGRUBVersion(): Found GRUB2 in MBR (Shown as GRUB2 in GUI). Continuing...")
                        return "GRUB2"
        
        #Ask the user (this'll be run if user said no to YesNo dlg above too -- this isn't in an else staement).
        logger.info("InitThread().DetermineGRUBVersion(): Only listing GRUB2 and GRUB-LEGACY, as wxfixboot couldn't tell if bootloader was grub2 or legacy.")
        temp = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine if your bootloader was GRUB-LEGACY or GRUB2 (grub2), so please specify which it is here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2"])

        if temp != "GRUB-LEGACY/I don't know":
            logger.debug("InitThread().DetermineGRUBVersion(): User reported bootloader is: "+temp+". Continuing...")
            return temp
        else:
            logger.debug("InitThread().DetermineGRUBVersion(): User reported bootloader is: GRUB-LEGACY. Continuing...")
            return "GRUB-LEGACY"

    def CheckForLILO(self):
        #Check for LILO in MBR
        temp = StartProcess("cat /tmp/wxfixboot/mbrbootsect | grep 'LILO'")[1].replace('\n', '')
        if temp == "Binary file (standard input) matches":
            #Bootloader is LILO in MBR
            return "LILO"
        else:
            return "Not LILO MBR"

    def CheckForGRUBEFI(self,EFISYSPMountPoint):
        global HelpfulEFIPartition
        #Look for GRUB's UEFI file.
        temp = StartProcess("find "+EFISYSPMountPoint+" -iname '*grub*'")[1].replace('\n', '')
        if temp == "":
            Bootloader = "Not GRUB-UEFI"
            HelpfulEFIPartition = False
        else:
            #Bootloader is GRUB-UEFI.
            Bootloader = "GRUB-UEFI"
            HelpfulEFIPartition = True

        return Bootloader

    def CheckForELILO(self,EFISYSPMountPoint):
        global HelpfulEFIPartition
        #Look for LILO's UEFI file.
        temp = StartProcess("find "+EFISYSPMountPoint+" -iname '*elilo*'")[1].replace('\n', '')
        if temp == "":
            Bootloader = "Not ELILO"
            HelpfulEFIPartition = False
        else:
            #Bootloader is ELILO.
            Bootloader = "ELILO"
            HelpfulEFIPartition = True

        return Bootloader

    def ManualBootloaderSelect(self):
        logger.debug("InitThread().ManualBootloaderSelect(): Manually selecting bootloader...")
        #Offer different selection based on the current state of the system.
        if UEFISYSP == "None" and FWType == "UEFI":
            logger.warning("InitThread().ManualBootloaderSelect(): Warning: Only listing BIOS bootloaders, as there is no UEFI partition.")
            temp = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2", "LILO"])

        elif UEFISYSP != "None" and FWType == "UEFI":
            temp = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2", "GRUB-UEFI", "LILO", "ELILO"])

        else:
            logger.info("InitThread().ManualBootloaderSelect(): Only listing BIOS bootloaders, as this is a BIOS system.")
            temp = self.ShowChoiceDlg(Message="WxFixBoot was unable to automatically determine your bootloader, so please manually select it here.", Title="WxFixBoot - Select Bootloader", Choices=["GRUB-LEGACY/I don't know", "GRUB2", "LILO"])

        if temp != "GRUB-LEGACY/I don't know":
            logger.debug("InitThread().ManualBootloaderSelect(): User reported bootloader is: "+dlgResult+". Continuing...")
            return dlgResult
        else:
            logger.debug("InitThread().ManualBootloaderSelect(): User reported bootloader is: GRUB-LEGACY. Continuing...")
            return "GRUB-LEGACY"

    def FinalCheck(self):
        #Check for any conflicting options, and that each variable is set.
        #Create a temporary list containing all variables to be checked, and a list to contain failed variables.
        templist = ['LiveDisk', 'PartitionListWithFSType', 'LinuxPartList', 'DeviceList', 'AutoRootFS', 'RootFS', 'AutoRootDev', 'RootDev', 'LiveDisk', 'DefaultOS', 'AutoDefaultOS', 'OSList', 'FWType', 'AutoFWType', 'EFIVars', 'PartSchemeList', 'AutoPartSchemeList', 'GPTInAutoPartSchemeList', 'MBRInAutoPartSchemeList', 'Bootloader', 'AutoBootloader', 'PrevBootloaderSetting', 'UEFISYSP', 'ManuallyMountedEFISYSP']
        failedlist = []

        #Check each global variable is set and declared.
        for var in templist:
            if var in globals():
                if var == None:
                    #It isn't.                    
                    logger.critical("InitThread().FinalCheck(): Critical Error: Variable "+var+" hasn't been set, adding it to the failed list...")
                    failedlist.append(var)
            else:
                #It isn't.                    
                logger.critical("InitThread().FinalCheck(): Critical Error: Variable "+var+" hasn't been declared, adding it to the failed list...")
                failedlist.append(var)

        #Check if any variables weren't set.
        if failedlist != []:
            #Missing dependencies!
            logger.critical("InitThread().FinalCheck(): Critical Error: Required Settings: "+', '.join(failedlist)+" have not been Determined! This is probably a bug in the program! Exiting...")
            self.ShowMsgDlg(Kind="error", Message="The required variables: "+', '.join(failedlist)+", have not been set! WxFixBoot will now shut down to prevent damage to your system. This is probably a bug in the program. Check the log file at /var/log/wxfixboot.log")

            wx.Exit()
            sys.exit("WxFixBoot: Critial Error: Incorrectly set settings:"+', '.join(failedlist)+" Exiting...")

        #Set some other variables to default values, avoiding problems down the line.
        SetDefaults()

        #Check and warn about conflicting settings.
        #Firmware type warnings.
        if FWType == "BIOS" and Bootloader in ['GRUB-UEFI', 'ELILO']:
            logger.warning("InitThread().FinalCheck(): Warning: Bootloader is UEFI-type, but system firmware is BIOS! Odd, perhaps a migrated drive? Continuing...")
            self.ShowMsgDlg(Kind="warning", Message="Your computer uses BIOS firmware, but you're using an UEFI-enabled bootloader! BIOS firmware does not support booting UEFI-enabled bootloaders, so it is recommended to install a BIOS-enabled legacy bootloader instead, such as GRUB2. You can safely ignore this message if your firmware type has been misdetected.")

        if FWType == "BIOS" and GPTInAutoPartSchemeList == True:
            logger.warning("InitThread().FinalCheck(): Warning: Firmware is BIOS, but at least one device on the system is using a gpt partition table! This device probably won't be bootable. WxFixBoot suggests repartitioning, if you intend to boot from that device.")
            self.ShowMsgDlg(Kind="warning", Message="Your computer uses BIOS firmware, but you're using a gpt(GUID)-style partition scheme on at least one device! BIOS firmware will likely fail to boot your operating system, if it resides on that device, so a repartition may be necessary for that device. You can safely ignore this message if your firmware type has been misdetected, or if you aren't booting from that device.")

        #Partition scheme warnings.
        if MBRInAutoPartSchemeList == True and Bootloader in ['GRUB-UEFI', 'ELILO']:
            logger.warning("InitThread().FinalCheck(): Warning: MBR partition table on at least one device, and a UEFI bootloader is in use! This might not work properly. WxFixBoot suggests repartitioning.")
            self.ShowMsgDlg(Kind="warning", Message="Your partition type on at least one device is msdos(MBR), but you're using an UEFI-enabled bootloader! Some firmware may not support this setup, especially if the UEFI system partition resides on this device, so it is recommended to install a BIOS-enabled legacy bootloader instead, or repartition the device. Ignore this message otherwise.")

        if GPTInAutoPartSchemeList == True and Bootloader in ['GRUB2', 'LILO', 'GRUB-LEGACY']:
            logger.warning("InitThread().FinalCheck(): Warning: GPT Partition table on at least one device with msdos bootloader! Most BIOS firmware cannot read GPT disks. WxFixBoot suggests repartitioning.")
            self.ShowMsgDlg(Kind="warning", Message="Your partition type on at least one device is gpt(GUID), but you're using an BIOS-enabled bootloader! Almost all firmware won't support this setup, assuming the bootloader uses that device to boot from, except very recent BIOS systems, so it is advised to install a UEFI-enabled bootloader instead, or repartition the device.")

        #Bootloader warnings.
        if UEFISYSP == "None" and Bootloader in ['GRUB-UEFI', 'ELILO']:
            logger.error("InitThread().FinalCheck(): Error: UEFI bootloader without a UEFI partition is a logical impossibility! WxFixBoot will not install a UEFI bootloader without a UEFI partition.")
            self.ShowMsgDlg(Kind="warning", Message="You're using an UEFI-enabled bootloader, but don't have an UEFI system partition! Your computer may be unable to boot unless you create a UEFI system partition. You'll have to do this with a partitioning tool like gparted, and some online instructions. WxFixBoot will refuse to install an UEFI-enabled bootloader without a UEFI system partition.")

        elif HelpfulEFIPartition == False and UEFISYSP != "None":
            logger.warning("InitThread().FinalCheck(): Warning: Empty UEFI partition!")
            self.ShowMsgDlg(Kind="warning", Message="Your UEFI system partition is empty or doesn't contain any detected bootloaders. If you just created your UEFI system partition, please insure it's formatted as fat32/fat16 (Known as vfat in Linux), and then you may continue to install a UEFI bootloader on it. If WxFixBoot didn't detect your UEFI-enabled bootloader, then that's okay, it's still perfectly safe to perform operations on the bootloader..")        

#End Initalization Thread.
#Begin Main Window
class MainWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self,None,title="WxFixBoot v1.0rc4 (31/8/2014)",size=(400,300),style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.MainPanel = wx.Panel(self)

        #Create a Statusbar in the bottom of the window and set the text.
        self.MakeStatusBar()

        #Add text
        self.CreateText()

        #Create some buttons
        self.CreateButtons()

        #Create some checkboxes
        self.CreateCBs()

        #Create the menus.
        self.CreateMenus()

        #Set up checkboxes
        self.OnCheckBox("empty arg")

        #Bind all events.
        self.BindEvents()

        logger.debug("MainWindow Started. Waiting for events...")
        
    def MakeStatusBar(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText("Ready.")

    def CreateText(self):
        #Add the selection text
        wx.StaticText(self.MainPanel, -1, "Welcome to WxFixBoot!", pos=(125,15))
        wx.StaticText(self.MainPanel, -1, "Please set the basic settings here first.", pos=(70,35))

        #Add an image.
        img = wx.Image("/usr/share/pixmaps/wxfixboot.png", wx.BITMAP_TYPE_PNG)
        wx.StaticBitmap(self.MainPanel, -1, wx.BitmapFromImage(img), pos=(270,70))

    def CreateButtons(self):
        self.aboutbutton = wx.Button(self.MainPanel, wx.ID_ANY, "About", pos=(10,220))
        self.exitbutton = wx.Button(self.MainPanel, wx.ID_ANY, "Quit", pos=(300,220))
        self.optsbutton = wx.Button(self.MainPanel, wx.ID_ANY, "View Program Options", pos=(120,220))
        self.applyopts = wx.Button(self.MainPanel, wx.ID_ANY, "Apply All Operations", pos=(125,180))

    def CreateCBs(self):
        self.badsectcheckcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (thorough)", pos=(10,60))
        self.chkfscb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Check All File Systems (quick)", pos=(10,90))
        self.reinstblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Reinstall/Fix Current Bootloader", pos=(10,120))
        self.updateblcb = wx.CheckBox(self.MainPanel, wx.ID_ANY, "Update Current Bootloader Config", pos=(10,150))

        #If bootloader is grub legacy, disable some options.
        if Bootloader == "GRUB-LEGACY":
            self.DisableBLOptsGrubLegacy()

    def DisableBLOptsGrubLegacy(self):
        self.reinstblcb.Disable()
        self.updateblcb.Disable()

    def EnableBLOptsNoGrubLegacy(self):
        self.reinstblcb.Enable()
        self.reinstblcb.SetValue(False)
        self.updateblcb.Enable()
        self.updateblcb.SetValue(False)

    def CreateMenus(self):
        filemenu = wx.Menu()
        viewmenu = wx.Menu()
        editmenu = wx.Menu()
        helpmenu = wx.Menu() 
   
        #Adding Menu Items.
        self.menuAbout = helpmenu.Append(wx.ID_ABOUT, "&About", "Information about this program")
        self.menuExit = filemenu.Append(wx.ID_EXIT,"&Exit", "Terminate this program")
        self.menuDevInfo = viewmenu.Append(wx.ID_ANY,"&Device Information", "Information about all detected devices") 
        self.menuOpts = editmenu.Append(wx.ID_PREFERENCES, "&Options", "General settings used to modify your system")

        #Creating the menubar.
        menuBar = wx.MenuBar()

        #Adding menus to the MenuBar
        menuBar.Append(filemenu,"&File")
        menuBar.Append(editmenu,"&Edit")
        menuBar.Append(viewmenu,"&View")
        menuBar.Append(helpmenu,"&Help")

        #Adding the MenuBar to the Frame content.
        self.SetMenuBar(menuBar)

    def OnCheckBox(self,e):
        logger.debug("MainWindow().OnCheckBox() was triggered.")
        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
        else:
            self.chkfscb.Enable()

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
        else:
            self.badsectcheckcb.Enable()

        #Reinstall Bootloader Choicebox
        if self.reinstblcb.IsChecked() and (Bootloader != "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True):
            self.reinstblcbwaschecked = True
            self.updateblcb.SetValue(0)
            self.updateblcb.Disable()
        elif self.reinstblcb.IsChecked() == False and Bootloader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.updateblcb.Enable()
            self.reinstblcbwaschecked = False
        else:
            self.reinstblcb.SetValue(0)
            self.reinstblcbwaschecked = False

        #Update Bootloader Choicebox
        if self.updateblcb.IsChecked() and (Bootloader != "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True):
            self.updateblcbwaschecked = True
            self.reinstblcb.SetValue(0)
            self.reinstblcb.Disable()
        elif self.updateblcb.IsChecked() == False and Bootloader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.reinstblcb.Enable()
            self.updateblcbwaschecked = False
        else:
            self.updateblcb.SetValue(0)
            self.updateblcbwaschecked = False

    def Opts(self,e):
        global OptionsDlg1Run
        logger.debug("Starting Options Window 1 and hiding MainWindow...")

        if self.reinstblcbwaschecked == True or self.updateblcbwaschecked == True:
            dlg = wx.MessageDialog(self.MainPanel, "Do you want to continue? If you reinstall or update your bootloader, some options, such as installing a different bootloader, and restoring backups of the bootsector and partition table, will be reset and disabled. If you want to change other settings, you can always do it after restarting wxfixboot.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_QUESTION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_NO:
                wx.MessageDialog(self.MainPanel, "You will now be returned to the Main Window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                return

        self.SaveMainOpts()

        if UEFISYSP == "None":
            wx.MessageDialog(self.MainPanel, "Seeing as you have no UEFI partition, you will be unable to select a UEFI bootloader to install, or as your current bootloader. NB: In the bootloader options window, you can select a new UEFI partition.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        elif HelpfulEFIPartition == False:
            wx.MessageDialog(self.MainPanel, "No bootloaders were found on your UEFI partition, and no MBR bootloaders were found either. However, you will still be able to select a UEFI bootloader to install, or as your current bootloader, as UEFI bootloader detection is a lttle bit sketchy. NB: In the bootloader options window, you can select a different UEFI partition.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if FWType == "BIOS":
            wx.MessageDialog(self.MainPanel, "Make sure you set the Root Device correctly here! Chances are, you won't need to change it, but it always needs to be set to the device your system boots off (usually the first hard drive in the system). You can see this information in the default OS selection in the following window. For example if your OS boots off /dev/sdc3, the root device should be set to /dev/sdc. The root device here will also be the device that's backed up if either backup option is selected. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
        else:
            wx.MessageDialog(self.MainPanel, "Make sure you set the Root Device correctly here, because it will be the device that's backed up if you choose to back up the partition table. The boot sector in this case is the UEFI System Partition, if there is one. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        OptionsDlg1Run = True
        self.Hide()
        OptionsWindow1(self).Show()

    def DevInfo(self,e):
        logger.debug("Starting Device Info Window...")
        DevInfoWindow(self).Show()

    def ProgressWindow(self,e):
        if OptionsDlg1Run == True and self.reinstblcbwaschecked == False and self.updateblcbwaschecked == False:
            logger.debug("Starting Progress Window...")
            self.SaveMainOpts()
            ProgressFrame = ProgressWindow()
            app.SetTopWindow(ProgressFrame)
            ProgressFrame.Show(True)
            self.Destroy()
        else:
            wx.MessageDialog(self.MainPanel, "Please check the settings in Options Window 1 before continuing, especially after changing the options on the Main Window! Preferably, also check the Bootloader Options Window.", "WxFixBoot - Error", style=wx.OK | wx.ICON_EXCLAMATION, pos=wx.DefaultPosition).ShowModal()

    def RefreshMainWindow(self,msg):
        #Refresh the main window to reflect changes in the options, or after a restart.
        logger.debug("Refreshing MainWindow...")
            
        #Bootloader options. Also check if the partition table or boot sector are to be restored
        if Bootloader == "GRUB-LEGACY" or RestorePartTable == True or RestoreBootSector == True:
            self.DisableBLOptsGrubLegacy()
        else:
            self.EnableBLOptsNoGrubLegacy()

        #Set settings up how they were when MainWindow was hidden earlier, if possible.
        if Bootloader != "GRUB-LEGACY" and RestorePartTable == False and RestoreBootSector == False:
            self.reinstblcb.SetValue(ReinstallBootloader)
            self.updateblcb.SetValue(UpdateBootloader)

        self.chkfscb.SetValue(QuickFSCheck)
        self.badsectcheckcb.SetValue(BadSectCheck)

        #Enable and Disable Checkboxes as necessary
        self.OnCheckBox("Empty arg")

        #Reset these to avoid errors.
        self.reinstblcbwaschecked = False
        self.updateblcbwaschecked = False

        #Reveal MainWindow
        self.Show()

    def OnAbout(self,e):
        logger.debug("Showing About Box")
        aboutbox = wx.AboutDialogInfo()
        aboutbox.Name = "WxFixBoot"
        aboutbox.Version = "1.0~rc4"
        aboutbox.Copyright = "(C) 2013-2014 Hamish McIntyre-Bhatty"
        aboutbox.Description = "Utility to quickly fix the bootloader on\na computer"
        aboutbox.WebSite = ("https://launchpad.net/wxfixboot", "Launchpad page")
        aboutbox.Developers = ["Hamish McIntyre-Bhatty"]
        aboutbox.License = "WxFixBoot is released under the GNU GPL v3,and as such has ABSOLUTELY NO WARRANTY.\nYou are allowed to copy, redistribute, and modify this open-source program only if you do so under the terms of the GNU GPL v3.\nFor more information, visit: http://www.gnu.org/licenses/"
        # Show the wx.AboutBox
        wx.AboutBox(aboutbox)

    def BindEvents(self): 
        #Bind all mainwindow events in a seperate function
        self.Bind(wx.EVT_MENU, self.OnAbout, self.menuAbout)
        self.Bind(wx.EVT_MENU, self.OnExit, self.menuExit)
        self.Bind(wx.EVT_CLOSE, self.OnExit)
        self.Bind(wx.EVT_BUTTON, self.OnAbout, self.aboutbutton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.exitbutton)
        self.Bind(wx.EVT_MENU, self.DevInfo, self.menuDevInfo)
        self.Bind(wx.EVT_MENU, self.Opts, self.menuOpts)
        self.Bind(wx.EVT_BUTTON, self.Opts, self.optsbutton)
        self.Bind(wx.EVT_BUTTON, self.ProgressWindow, self.applyopts)

        #Checkboxes on the main window.
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.reinstblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.updateblcb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.chkfscb)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.badsectcheckcb)

    def SaveMainOpts(self):
        #Save all options here.
        logger.debug("Saving Options on MainWindow...")
        global BootloaderToInstall
        global BootSectFile
        global RestoreBootSector
        global PartTableFile
        global RestorePartTable
        global ReinstallBootloader
        global UpdateBootloader
        global QuickFSCheck
        global BadSectCheck
        global Bootloader

        #Bad Sector Check Choicebox
        if self.badsectcheckcb.IsChecked():
            self.chkfscb.Disable()
            BadSectCheck = True
        else:
            self.chkfscb.Enable()
            BadSectCheck = False

        #Quick Disk Check Choicebox
        if self.chkfscb.IsChecked():
            self.badsectcheckcb.Disable()
            QuickFSCheck = True
        else:
            self.badsectcheckcb.Enable()
            QuickFSCheck = False

        #Reinstall Bootloader Choicebox
        if self.reinstblcb.IsChecked():
            ReinstallBootloader = True

            #Disable some stuff
            BootloaderToInstall = "None"
            BootSectFile = "None"
            RestoreBootSector = False
            PartTableFile = "None"
            RestorePartTable = False
        else:
            ReinstallBootloader = False

        #Update Bootloader Choicebox
        if self.updateblcb.IsChecked():
            UpdateBootloader = True

            #Disable some stuff
            BootloaderToInstall = "None"
            BootSectFile = "None"
            RestoreBootSector = False
            PartTableFile = "None"
            RestorePartTable = False
        else:
            UpdateBootloader = False

        logger.debug("MainWindow options saved!")

    def OnExit(self,e):
        #Shut down.
        exitdlg = wx.MessageDialog(self.MainPanel, 'Are you sure you want to exit?', 'WxFixBoot -- Question!', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
        if exitdlg == wx.ID_YES:
            logger.debug("User triggered exit sequence. Exiting...")
            #Run the exit sequence
            if os.path.exists("/tmp/wxfixboot"):
                shutil.rmtree('/tmp/wxfixboot')
            self.Destroy()

#End Main window
#Begin Device Info Window
class DevInfoWindow(wx.Frame):
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, parent=wx.GetApp().TopWindow, title="WxFixBoot - Device Information", size=(400,310), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.DevInfoPanel=wx.Panel(self)
        self.ParentWindow = ParentWindow

        #Update/Create Device Info
        self.UpdDevInfo("emptyarg")

        #Create other GUI elemnts.
        wx.StaticText(self.DevInfoPanel, -1, "Here are all the detected devices on your computer", pos=(30,10))
        self.okbutton = wx.Button(self.DevInfoPanel, -1, "Okay", pos=(330,270), size=(60,30))
        self.refreshbutton = wx.Button(self.DevInfoPanel, -1, "Refresh", pos=(10,270), size=(70,30))

        #Bind events
        self.Bind(wx.EVT_BUTTON, self.UpdDevInfo, self.refreshbutton)
        self.Bind(wx.EVT_BUTTON, self.ExitDevInfoDlg, self.okbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitDevInfoDlg)

        logger.debug("Device Info Window Started.")

    def UpdDevInfo(self,e):
        #Generate device data.
        devicelist = GetDevInfo()

        #Create/Update a list box.
        try:
            if Listbox:
                Listbox.Destroy()
        except NameError: pass
        finally:
            listbox = wx.ListBox(self.DevInfoPanel, -1, size=(380,220), pos=(10,30), choices=devicelist, style=wx.LB_SINGLE)

    def ExitDevInfoDlg(self,e):
        logger.debug("Device Info Window Closing.")

        #Exit.
        self.Destroy()

#End Device Info Window
#Begin Options Window 1
class OptionsWindow1(wx.Frame):
    def __init__(self, ParentWindow):
        wx.Frame.__init__(self, wx.GetApp().TopWindow, title="WxFixBoot - Options", size=(600,360), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel1=wx.Panel(self)
        self.ParentWindow = ParentWindow

        self.CreateButtons()
        self.CreateText()
        self.UpdateBLOptsText()
        self.CreateCBs()
        self.CreateChoiceBs()
        self.CreateSpinners()
        self.SetupOptions()
        self.BindEvents()

        #Paint the lines on the Window witha delay, so the window's ready in time.
        wx.CallLater(200, self.DrawLines, "Empty arg")

        logger.debug("OptionsWindow1 Started.")

    def CreateButtons(self):
        #Create Some buttons.
        self.exitbutton = wx.Button(self.OptsPanel1, -1, "Apply these Settings and Close", pos=(180,320))
        self.blOptsButton = wx.Button(self.OptsPanel1, -1, "View Bootloader Options", pos=(210,260))
        self.restorebootsectbutton = wx.Button(self.OptsPanel1, -1, "Restore Boot Sector", pos=(10,320))
        self.restoreparttablebutton = wx.Button(self.OptsPanel1, -1, "Restore Partition Table", pos=(427,320))

    def CreateText(self):
        #Create the text.
        wx.StaticText(self.OptsPanel1, -1, "Welcome to Options. Please give all the settings a once-over.", pos=(115,10))
        wx.StaticText(self.OptsPanel1, -1, "Basic Settings:", pos=(10,50))
        wx.StaticText(self.OptsPanel1, -1, "Installed Bootloader:", pos=(10,80))
        wx.StaticText(self.OptsPanel1, -1, "Default OS to boot:", pos=(10,110))
        wx.StaticText(self.OptsPanel1, -1, "Bootloader timeout value:", pos=(10,200))
        wx.StaticText(self.OptsPanel1, -1, "(seconds, -1 represents current value)", pos=(10,220)) 
        wx.StaticText(self.OptsPanel1, -1, "Advanced Settings:", pos=(310,50))
        wx.StaticText(self.OptsPanel1, -1, "Root device:", pos=(340,80))
        wx.StaticText(self.OptsPanel1, -1, "Bootloader To Install:", pos=(30,255))
        wx.StaticText(self.OptsPanel1, -1, "Selected Firmware Type:", pos=(420,255))

    def CreateCBs(self):
        #Basic settings
        self.fullverbosecb = wx.CheckBox(self.OptsPanel1, -1, "Show diagnostic terminal output", pos=(10,155), size=(270,20))

        #Advanced settings
        self.makesummarycb = wx.CheckBox(self.OptsPanel1, -1, "Save System Report To File", pos=(340,120), size=(315,20))
        self.logoutputcb = wx.CheckBox(self.OptsPanel1, -1, "Save terminal output in Report", pos=(340,150), size=(270,20))
        self.bkpbootsectcb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Bootsector", pos=(340,180), size=(250,20))
        self.bkpparttablecb = wx.CheckBox(self.OptsPanel1, -1, "Backup the Partition Table", pos=(340,210), size=(290,20))

    def CreateChoiceBs(self):
        #Basic settings
        self.defaultoschoice = wx.Choice(self.OptsPanel1, -1, pos=(150,103), size=(140,30), choices=OSList)

        #Advanced settings
        self.rootdevchoice = wx.Choice(self.OptsPanel1, -1, pos=(470,73), choices=["Auto: "+AutoRootDev]+DeviceList)

    def CreateSpinners(self):
        #Basic option here.
        self.bltimeoutspin = wx.SpinCtrl(self.OptsPanel1, -1, "", pos=(190,197))
        self.bltimeoutspin.SetRange(-1,100)
        self.bltimeoutspin.SetValue(-1)

    def OnCheckBox(self,e):
        #Manage the checkboxes states.
        if self.makesummarycb.IsChecked():
            self.logoutputcb.Enable()
            self.logoutputcb.SetValue(True)
        else:
            self.logoutputcb.SetValue(False)
            self.logoutputcb.Disable()

    def SetupOptions(self):
        #Load all Options here.
        logger.debug("Setting up options in OptionsDlg1...")

        global BootloaderToInstall
        global DefaultOS

        #Boot Loader Time Out
        self.bltimeoutspin.SetValue(BootloaderTimeout)

        #Checkboxes
        #Save output checkbox.
        if SaveOutput == True:
            self.logoutputcb.SetValue(True)
        else:
            self.logoutputcb.SetValue(False)

        #Diagnostic output checkbox.
        if FullVerbose == True:
            self.fullverbosecb.SetValue(True)
        else:
            self.fullverbosecb.SetValue(False)

        #Backup Boot Sector CheckBox
        if BkpBootSect == True:
            self.bkpbootsectcb.SetValue(True)
        else:
            self.bkpbootsectcb.SetValue(False)

        #Backup Partition Table CheckBox
        if BackupPartTable == True:
            self.bkpparttablecb.SetValue(True)
        else:
            self.bkpparttablecb.SetValue(False)

        #System Summary checkBox
        if MakeSystemSummary == True:
            self.makesummarycb.SetValue(True)
        else:
            self.makesummarycb.SetValue(False)

        if UEFISYSP == "None":
            self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+AutoBootloader, 'GRUB-LEGACY', 'GRUB2', 'LILO'])
        else:
            self.instblchoice = wx.Choice(self.OptsPanel1, -1, pos=(150,73), size=(140,30), choices=['Auto: '+AutoBootloader, 'GRUB-LEGACY', 'GRUB2', 'GRUB-UEFI', 'LILO', 'ELILO'])

        #Installed Bootloader
        if Bootloader != AutoBootloader:
            self.instblchoice.SetStringSelection(Bootloader)

        #Default OS
        self.defaultoschoice.SetStringSelection(DefaultOS)
        
        #Root Device
        if RootDev != AutoRootDev:
            self.rootdevchoice.SetStringSelection(RootDev)

        if RestoreBootSector == True or RestorePartTable == True:
            #Disable/reset some options.
            self.blOptsButton.Disable()
            self.instblchoice.Disable()
            self.defaultoschoice.Disable()
            self.bltimeoutspin.SetValue(-1)
            self.bltimeoutspin.Disable()

            #Reset some settings.
            BootloaderToInstall = "None"
            DefaultOS = AutoDefaultOS
        else:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()
            self.defaultoschoice.Enable()

        #Disable some options if the bootloader is to be reinstalled or updated.
        if ReinstallBootloader == True or UpdateBootloader == True:
            self.blOptsButton.Disable()
            self.restorebootsectbutton.Disable()
            self.restoreparttablebutton.Disable()

        logger.debug("Options in OptionsDlg1 set up!")

    def DrawLines(self,e):
        #Create some border lines on the panel.
        logger.debug("OptionsWindow1().DrawLines() has been triggered.")
        dc = wx.PaintDC(self.OptsPanel1)
        dc.DrawLine(0, 67, 600, 67)
        dc.DrawLine(315, 67, 315, 245)
        dc.DrawLine(0, 245, 600, 245)
        dc.DrawLine(0, 300, 600, 300)

    def UpdateBLOptsText(self):
        #Set up the Device Context first.
        logger.debug("Updating Bootloader Options text in OptionsDlg1...")
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        font = self.OptsPanel1.GetFont()
        dc = wx.WindowDC(self.OptsPanel1)
        dc.SetFont(font)

        #Do the Bootloader to install text first.
        width, height = dc.GetTextExtent(BootloaderToInstall)
        try:
            self.BootloaderToInstallText
        except: pass
        else:
            self.BootloaderToInstallText.Destroy()
        finally:
            self.BootloaderToInstallText = wx.StaticText(self.OptsPanel1, -1, BootloaderToInstall, pos=((200-int(width))/2,275), size=(int(width),int(height)))

        #Do the FWTypeText now.
        width, height = dc.GetTextExtent(FWType)
        try:
            self.FWTypeText
        except: pass
        else:
            self.FWTypeText.Destroy()
        finally:
            self.FWTypeText = wx.StaticText(self.OptsPanel1, -1, FWType, pos=(((200-int(width))/2)+395,275), size=(int(width),int(height)))

        logger.debug("Bootloader Options text in OptionsDlg1 updated!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CloseOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CloseOpts)
        self.Bind(wx.EVT_BUTTON, self.LaunchblOpts, self.blOptsButton)
        self.Bind(wx.EVT_BUTTON, self.LaunchBootSectWindow, self.restorebootsectbutton)
        self.Bind(wx.EVT_BUTTON, self.LaunchPartTableWindow, self.restoreparttablebutton)
        self.Bind(wx.EVT_CHECKBOX, self.OnCheckBox, self.makesummarycb)
        self.Bind(wx.EVT_PAINT, self.DrawLines)

    def LaunchblOpts(self,e):
        #Safeguard program reliability (and continuity) by saving the settings in optionswindow1 first.
        self.SaveOptions("Empty arg")

        #Give some warnings here if needed.
        #Tell the user some options will be disabled if the bootloader is to be reinstalled or updated.
        if ReinstallBootloader == True or UpdateBootloader == True:
            wx.MessageDialog(self.OptsPanel1, "Your current bootloader is to be reinstalled/updated, therefore almost all bootloader-related options here will be disabled. If you want to install a different bootloader, please uncheck the reinstall/update bootloader option on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a MBR bootloader on BIOS systems.
        if AutoFWType == "BIOS":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is BIOS. Unless you're sure WxFixBoot has misdetected this, and it's actually UEFI, it's recommended that you install an MBR bootloader, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Recommend a UEFI boot loader on UEFI systems.
        elif AutoFWType == "UEFI":
            wx.MessageDialog(self.OptsPanel1, "Your firmware type is UEFI. Unless you're sure WxFixBoot has misdetected this, and it's actually BIOS, it's recommended that you install a UEFI bootloader, or your system might not boot correctly.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if UEFISYSP == "None" and Bootloader in ['GRUB-UEFI', 'ELILO']:
            wx.MessageDialog(self.OptsPanel1, "You have a UEFI Bootloader, but no UEFI Partition! Something has gone seriously wrong here! WxFixBoot will not install a UEFI bootloader without a UEFI partition (as it's impossible), and those options will now be disabled.", "WxFixBoot - ERROR", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        elif UEFISYSP == "None":
            wx.MessageDialog(self.OptsPanel1, "You have no UEFI Partition. If you wish to install a UEFI bootloader, you'll need to create one first. WxFixBoot will not install a UEFI bootloader without a UEFI partition (as it's impossible), and those options will now be disabled.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        wx.MessageDialog(self.OptsPanel1, "Most of the settings in the following dialog do not need to be and shouldn't be touched, with the exception of autodetermining the bootloader, or manually selecting one. The firmware type and partition schemes should not normally be changed. Thank you.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Open the Firmware Options window
        logger.debug("Starting Options Window 2 (aka Bootloader Options Dlg)...")
        self.Hide()
        OptionsWindow2(self).Show()

    def LaunchBootSectWindow(self,e):
        logger.debug("Starting Restore BootSector dialog...")
        #Show helpful info if we're usng UEFI.
        if FWType == "UEFI":
             wx.MessageDialog(self.OptsPanel1, "Because you're using UEFI, the Target Device selection in the following dialog will be ignored, and the backup will always be restored to the UEFI Partition. Please keep this in mind and be sure that the UEFI Partition chosen is correct (you can check and change this in the Bootloader Options).", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        self.Hide()
        RestoreWindow(ParentWindow=self,Type="BootSector").Show()

    def LaunchPartTableWindow(self,e):
        logger.debug("Starting Restore PartTable dialog...")
        self.Hide()
        RestoreWindow(ParentWindow=self,Type="PartTable").Show()

    def RefreshOptionsDlg1(self,msg):
        #Check if the partition table or boot sector are to be restored.
        logger.debug("Refreshing OptionsDlg1...")
        if RestorePartTable == True or RestoreBootSector == True:
            #Disable/reset some options.
            self.blOptsButton.Disable()
            self.instblchoice.Disable()
            self.defaultoschoice.Disable()
            self.bltimeoutspin.SetValue(-1)
            self.bltimeoutspin.Disable()

            #Reset some settings.
            global BootloaderToInstall
            global FWType
            global DefaultOS
            BootloaderToInstall = "None"
            FWType = AutoFWType
            DefaultOS = AutoDefaultOS
        else:
            #Enable some options.
            self.blOptsButton.Enable()
            self.instblchoice.Enable()
            self.defaultoschoice.Enable()
            self.bltimeoutspin.Enable()

        #Setup options again, but destroy a widget first so it isn't duplicated.
        self.instblchoice.Destroy()
        self.SetupOptions()

        #Update the BootloaderToInstall and FWType text.
        self.UpdateBLOptsText()

        #Show OptionsDlg1.
        self.Show()

        #Paint the lines on the Window again.
        wx.CallLater(200, self.DrawLines, "Empty arg")

    def SaveOptions(self,e):
        #Save all options in this window here.
        global SaveOutput
        global FullVerbose
        global SaveOutput
        global BkpBootSect
        global BackupPartTable
        global MakeSystemSummary
        global Bootloader
        global PrevBootloaderSetting
        global DefaultOS
        global RootDev
        global RootFS
        global BootloaderTimeout

        logger.info("OptionsWindow1: Saving Options...")
        
        #Checkboxes.

        #Create Log checkbox.
        if self.logoutputcb.IsChecked():
            SaveOutput = True
        else:
            SaveOutput = False
        logger.debug("OptionsWindow1: Saving Options: Value of SaveOutput is: "+str(SaveOutput))

        #Check FS cb
        if self.fullverbosecb.IsChecked():
            FullVerbose = True
        else:
            FullVerbose = False
        logger.debug("OptionsWindow1: Saving Options: Value of FullVerbose is: "+str(FullVerbose))

        #Remount FS CB
        if self.logoutputcb.IsChecked():
            SaveOutput = True
        else:
            SaveOutput = False
        logger.debug("OptionsWindow1: Saving Options: Value of SaveOutput is: "+str(SaveOutput))

        #Backup BootSector checkbox.
        if self.bkpbootsectcb.IsChecked():
            BkpBootSect = True
        else:
            BkpBootSect = False
        logger.debug("OptionsWindow1: Saving Options: Value of BkpBootSect is: "+str(BkpBootSect))

        #Backup Partition Table checkbox.
        if self.bkpparttablecb.IsChecked():
            BackupPartTable = True
        else:
            BackupPartTable = False
        logger.debug("OptionsWindow1: Saving Options: Value of BackupPartTable is: "+str(BackupPartTable))

        #Use chroot in operations checkbox
        if self.makesummarycb.IsChecked():
            MakeSystemSummary = True
        else:
            MakeSystemSummary = False
        logger.debug("OptionsWindow1: Saving Options: Value of MakeSystemSummary is: "+str(MakeSystemSummary))

        #ChoiceBoxes
        #Currently Installed Bootloader ChoiceBox
        PrevBootloaderSetting = Bootloader
        if self.instblchoice.GetSelection() != 0:
            Bootloader = self.instblchoice.GetStringSelection()
        else:
            #Set it to the auto value, using AutoBootloader
            Bootloader = AutoBootloader
        logger.debug("OptionsWindow1: Saving Options: Value of Bootloader is: "+Bootloader)

        #Default OS choicebox
        DefaultOS = self.defaultoschoice.GetStringSelection()
        logger.debug("OptionsWindow1: Saving Options: Value of DefaultOS is: "+DefaultOS)

        #Root Filesystem.
        RootFS = self.defaultoschoice.GetStringSelection().split()[-1]
        logger.debug("OptionsWindow1: Saving Options: Value of RootFS is: "+RootFS)

        #Root device ChoiceBox
        if self.rootdevchoice.GetSelection() != 0:
            RootDev = self.rootdevchoice.GetStringSelection()            
        else:
            #Set it to the auto value, in case this has already been changed.
            RootDev = AutoRootDev
        logger.debug("OptionsWindow1: Saving Options: Value of RootDev is: "+RootDev)

        #Spinner
        BootloaderTimeout = int(self.bltimeoutspin.GetValue())
        logger.debug("OptionsWindow1: Saving Options: Value of BootloaderTimeout is: "+str(BootloaderTimeout))

        logger.info("OptionsWindow1: Saved options.")

    def CloseOpts(self,e):
        #Save the options first.
        self.SaveOptions("empty arg")

        #Send a message to mainwindow so it can refresh.
        wx.CallAfter(self.ParentWindow.RefreshMainWindow, "Closed")

        #Exit options window 1.
        logger.debug("OptionsWindow1 is closing. Revealing MainWindow...")
        self.Destroy()

#End Options window 1
#Begin Options window 2
class OptionsWindow2(wx.Frame):
    def __init__(self,ParentWindow):
        wx.Frame.__init__(self, parent=wx.GetApp().TopWindow, title="WxFixBoot - Bootloader Options", size=(450,330), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.OptsPanel2 = wx.Panel(self)
        self.ParentWindow = ParentWindow

        self.CreateButtons()
        self.CreateCheckboxes()
        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.SetDefaults()
        self.BindEvents()

        logger.debug("OptionsWindow2 Started.")

    def CreateButtons(self):
        self.exitbutton = wx.Button(self.OptsPanel2, -1, "Close", pos=(355,290))

    def CreateCheckboxes(self):
        self.UEFItoBIOScb = wx.CheckBox(self.OptsPanel2, -1, "Replace a UEFI bootloader with the BIOS equivalent", pos=(10,180))
        self.BIOStoUEFIcb = wx.CheckBox(self.OptsPanel2, -1, "Replace a BIOS bootloader with the UEFI equivalent", pos=(10,210))
        self.useAutocb = wx.CheckBox(self.OptsPanel2, -1, "Automatically determine the bootloader to install", pos=(10,240))
        self.unchangedcb = wx.CheckBox(self.OptsPanel2, -1, "Do not install a new bootloader", pos=(10,270))

    def CreateText(self):
        wx.StaticText(self.OptsPanel2, -1, "Firmware type:", pos=(10,20))
        wx.StaticText(self.OptsPanel2, -1, "Options:", pos=(130,20))
        wx.StaticText(self.OptsPanel2, -1, "Partitioning System", pos=(140,40))
        wx.StaticText(self.OptsPanel2, -1, "On "+RootDev+":", pos=(163,57))
        wx.StaticText(self.OptsPanel2, -1, "Bootloader to install:", pos=(140,80))
        wx.StaticText(self.OptsPanel2, -1, "UEFI Partition:", pos=(140,120))
 
    def CreateRadios(self):
        #Create radio buttons.
        self.fwtyperadioauto = wx.RadioButton(self.OptsPanel2, -1, "Auto: "+AutoFWType, pos=(10,60), style=wx.RB_GROUP)
        self.fwtyperadioEFI = wx.RadioButton(self.OptsPanel2, -1, "UEFI/UEFI", pos=(10,90))
        self.fwtyperadioBIOS = wx.RadioButton(self.OptsPanel2, -1, "BIOS/Legacy", pos=(10,120))

    def CreateChoiceBs(self):
        #Make sure the right device's partition scheme is used here.
        tempnum = DeviceList.index(RootDev)

        #Set up self.partitiontypechoice based on whether that value has been changed for this device.
        if PartSchemeList[tempnum] == AutoPartSchemeList[tempnum]:
            self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,39), choices=['Auto: '+PartSchemeList[tempnum], 'msdos', 'gpt'])
        else:
            self.partitiontypechoice = wx.Choice(self.OptsPanel2, -1, pos=(295,39), choices=['Auto: '+AutoPartSchemeList[tempnum], 'Manual Value: '+PartSchemeList[tempnum], 'msdos', 'gpt'])  
            self.partitiontypechoice.SetSelection(1)     

        #Disable UEFI bootloaders if there is no UEFI system partition.
        if UEFISYSP == "None":
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,74), choices=['Auto', 'GRUB2', 'LILO'])
        else:
            self.bltoinstallchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,74), choices=['Auto', 'GRUB-UEFI', 'GRUB2', 'ELILO', 'LILO'])

        self.efisyspchoice = wx.Choice(self.OptsPanel2, -1, pos=(295,112), choices=FatPartitions) 

    def SetDefaults(self):
        global BootloaderToInstall
    
        logger.debug("Setting up OptionsWindow2...")
        self.efisyspchoice.SetStringSelection(UEFISYSP)
        #Check if the dialog has already been run, or if the bootloader setting has changed (so it must discard the setting to avoid errors).
        if BLOptsDlgRun == False or Bootloader != PrevBootloaderSetting:
            #Use defaults.
            self.bltoinstallchoicelastvalue = "Auto"
            #If bootloader is to be reinstalled, updated, or if a UEFI partition isn't available, or if bootloader is grub-legacy, disable some stuff.
            if ReinstallBootloader == True or UpdateBootloader == True:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.bltoinstallchoice.Disable()
                self.unchangedcb.SetValue(True)
            elif UEFISYSP == "None":
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.unchangedcb.SetValue(True)
            elif Bootloader == "GRUB-LEGACY":
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
                self.unchangedcb.SetValue(True)
            else:
                self.UEFItoBIOScb.Disable()
                self.BIOStoUEFIcb.Disable()
                self.useAutocb.Disable()
                self.useAutocb.SetValue(False)
                self.unchangedcb.SetValue(True)
                self.fwtyperadioauto.SetValue(True)
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.partitiontypechoice.SetSelection(0)
        else:
            #Setup using the previous options.
            #First do options that will be set even if the current bootloader is to be reinstalled or updated.
            #Set up Firmware Type radio buttons.
            if FWType == AutoFWType:
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(True)
            elif FWType == "BIOS":
                self.fwtyperadioEFI.SetValue(False)
                self.fwtyperadioBIOS.SetValue(True)
                self.fwtyperadioauto.SetValue(False)
            elif FWType == "UEFI":
                self.fwtyperadioEFI.SetValue(True)
                self.fwtyperadioBIOS.SetValue(False)
                self.fwtyperadioauto.SetValue(False)

            #Bootloader To Install Choice
            if BootloaderToInstall not in ["None","Unknown"] and ReinstallBootloader == False and UpdateBootloader == False:
                self.bltoinstallchoice.Enable()
                self.bltoinstallchoice.SetStringSelection(BootloaderToInstall)
                self.bltoinstallchoicelastvalue = BootloaderToInstall
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
            elif ReinstallBootloader == True or UpdateBootloader == True:
                BootloaderToInstall = "None"
                self.bltoinstallchoice.SetSelection(0)
                self.bltoinstallchoicelastvalue = "Auto"
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")
                self.bltoinstallchoice.Disable()
            else:
                self.bltoinstallchoicelastvalue = "None"
                self.bltoinstallchoice.SetSelection(0)
                #Insure the window gets updated properly.
                self.BlToInstallChoiceChange("empty arg")
                self.ActivateOptsforNoModification("empty arg")

        logger.debug("OptionsDlg2 Set up!")

    def BindEvents(self):
        self.Bind(wx.EVT_BUTTON, self.CheckOpts, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.CheckOpts)
        self.Bind(wx.EVT_CHECKBOX, self.ActivateOptsforNoModification, self.unchangedcb)
        self.Bind(wx.EVT_CHOICE, self.BlToInstallChoiceChange, self.bltoinstallchoice)
        self.Bind(wx.EVT_CHOICE, self.EFISysPChoiceChange, self.efisyspchoice) 
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforAutoFW, self.fwtyperadioauto)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforEFIFW, self.fwtyperadioEFI)
        self.Bind(wx.EVT_RADIOBUTTON, self.ActivateOptsforBIOSFW, self.fwtyperadioBIOS)

    def ActivateOptsforAutoFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForAutoFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and UpdateBootloader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforEFIFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForEFIFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and Bootloader != "GRUB-LEGACY" and UpdateBootloader == False:
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(True)
            self.BIOStoUEFIcb.Enable()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
        elif Bootloader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforBIOSFW(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForBIOSFW() has been triggered...")
        if self.unchangedcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and Bootloader != "GRUB-LEGACY" and UpdateBootloader == False:
            self.UEFItoBIOScb.SetValue(True)
            self.UEFItoBIOScb.Enable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
        elif Bootloader == "GRUB-LEGACY" and self.unchangedcb.IsChecked() == False:
            self.useAutocb.Enable()
            self.useAutocb.SetValue(True)

    def ActivateOptsforNoModification(self,e):
        logger.debug("OptionsWindow2().ActivateOptsForNoModification() has been triggered...")
        if self.unchangedcb.IsChecked() and self.bltoinstallchoice.GetSelection() == 0 and ReinstallBootloader == False and UpdateBootloader == False:
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
        elif ReinstallBootloader == False and UpdateBootloader == False:
            #In this circumstance, use the correct settings for the current firmware type selected.
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        else:
            self.unchangedcb.SetValue(True)
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()

    def BlToInstallChoiceChange(self,e):
        logger.debug("OptionsWindow2().BLToInstallChoiceChange() has been triggered...")
        if self.bltoinstallchoice.GetSelection() == 0 and self.bltoinstallchoicelastvalue != self.bltoinstallchoice.GetStringSelection():
            self.bltoinstallchoicelastvalue = self.bltoinstallchoice.GetStringSelection()
            self.unchangedcb.Enable()
            self.unchangedcb.SetValue(True)
            if self.fwtyperadioauto.GetValue():
                self.ActivateOptsforAutoFW("Emptyarg")
            elif self.fwtyperadioEFI.GetValue():
                self.ActivateOptsforEFIFW("Emptyarg")
            elif self.fwtyperadioBIOS.GetValue():
                self.ActivateOptsforBIOSFW("Emptyarg")
        elif self.bltoinstallchoice.GetSelection() != 0:
            self.bltoinstallchoicelastvalue = self.bltoinstallchoice.GetStringSelection()
            self.UEFItoBIOScb.SetValue(False)
            self.UEFItoBIOScb.Disable()
            self.useAutocb.SetValue(False)
            self.useAutocb.Disable()
            self.BIOStoUEFIcb.SetValue(False)
            self.BIOStoUEFIcb.Disable()
            self.unchangedcb.SetValue(False)
            self.unchangedcb.Disable()

    def EFISysPChoiceChange(self,e):
        #Function to handle selection of new UEFI system partition. It's pretty self-explanatory.
        global UEFISYSP
        logger.debug("OptionsWindow2().EFISysPChoiceChange() has been triggered...")
        if self.efisyspchoice.GetStringSelection() == UEFISYSP:
            logger.debug("OptionsWindow2().EFISysPChoiceChange(): No action required, UEFISYSP unchanged...")
        elif self.efisyspchoice.GetStringSelection() == "None":
            logger.debug("OptionsWindow2().EFISysPChoiceChange(): UEFISYSP changed to None. Disabling UEFI Bootloader installation and exiting OptionsWindow2()...")
            UEFISYSP = self.efisyspchoice.GetStringSelection()

            dlg = wx.MessageDialog(self.OptsPanel2, "As you have selected no UEFI partition, WxFixBoot will disable UEFI bootloaders and bring you back to the first options window", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            #Send a message to OptionsDlg1, so it can show itself again.
            wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

            #Exit.
            self.Destroy()

        else:
            logger.debug("OptionsWindow2().EFISysPChoiceChange(): UEFISYSP changed! Rescanning for UEFI bootloaders and exiting OptionsWindow2()...")
            UEFISYSP = self.efisyspchoice.GetStringSelection()
            dlg = wx.MessageDialog(self.OptsPanel2, "You have selected a different UEFI Partition. Please wait a few seconds while it is mounted and scanned for bootloaders. If none are found, you will be prompted to enter one manually. After that, you will be returned to the first options window, with any new bootloader settings detected. Any settings you have set here will be ignored and reset, unless you go back and set them again.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
            self.Hide()

            #Check for bootloaders on the suggested UEFI partition.
            InitThread(self,False)

    def ShowThreadChoicedlg(self,msg,choices,title="WxFixBoot - Select an Option"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=<message>, title=<title>, choices=<data>)
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.OptsPanel2, msg, title, choices, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("InitialWindow().ShowThreadChoicedlg(): Result of InitThread choice dlg was: "+dlgResult)

    def EFIPartitionScanned(self,msg):
        #Okay, the UEFI partition has been scanned, and the bootloader has been set, either manually or automatically.
        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

        #Exit.
        self.Destroy()

    def CheckOpts(self,e):
        if self.unchangedcb.IsChecked() == False and self.UEFItoBIOScb.IsChecked() == False and self.useAutocb.IsChecked() == False and self.BIOStoUEFIcb.IsChecked() == False and self.bltoinstallchoice.GetSelection() == 0:
            #Do nothing, as settings are invalid.
            logger.error("OptionsWindow2: No options selected, although no modification checkbox is unticked, or invalid options. Won't save options, waitng for user change...")
            wx.MessageDialog(self.OptsPanel2, "Your current selection suggests a modification will take place, but doesn't specify which modification to do! Please select a valid operation (or, alternatively, none).", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
        else:
            self.SaveBLOpts()

    def SaveBLOpts(self):
        #Save all selected Operations here.
        global BootloaderToInstall
        global PrevBootloaderSetting
        global PartSchemeList
        global Bootloader
        global FWType
        global AutoFWType

        logger.info("OptionsWindow2: Saving Options...")

        templist = ['GRUB-LEGACY', 'GRUB-UEFI','GRUB2','ELILO','LILO']

        #Partition scheme choice.
        if self.partitiontypechoice.GetStringSelection()[0:6] == "Manual":
            #No action required.
            logger.debug("OptionsWindow2: Saving Options: No Change in any PartScheme values...")
        else:
            #Figure out which entry in PartSchemeList to change and then delete and recreate it using the options in the dlg (msdos, or gpt)
            tempnum = DeviceList.index(RootDev)
            PartSchemeList.pop(tempnum)
            PartSchemeList.insert(tempnum, self.partitiontypechoice.GetStringSelection().split()[-1])
            if self.partitiontypechoice.GetStringSelection()[0:4] != "Auto":
                logger.debug("OptionsWindow2: Saving Options: Changed value of PartScheme for device: "+RootDev+" to: "+PartSchemeList[tempnum])
            else:
                logger.debug("OptionsWindow2: Saving Options: Changed value of PartScheme for device: "+RootDev+" to: "+PartSchemeList[tempnum]+" the default...")

        #Firmware Choice.
        if self.fwtyperadioEFI.GetValue():
            FWType = "UEFI"
        elif self.fwtyperadioBIOS.GetValue():
            FWType = "BIOS"
        else:
            #Use auto value.
            FWType = AutoFWType
        logger.debug("OptionsWindow2: Saving Options: Value of FWType is: "+FWType)

        #Bootloader to install choice.
        #Offer some warnings here if needed. This is a little complicated, but is still fairly easy to read.
        if self.bltoinstallchoice.GetStringSelection()[0:4] == "Auto" and ReinstallBootloader == False:
            #Use autodetect value
            if self.unchangedcb.IsChecked() == False:

                if self.UEFItoBIOScb.IsChecked():

                    if Bootloader in ['GRUB-UEFI', 'ELILO']:
                        #Find the BIOS/MBR equivalent to a UEFI bootloader.
                        bootloadernum = templist.index(Bootloader)
                        BootloaderToInstall = templist[bootloadernum+1] 
                    else:
                        #Do nothing, already using BIOS bootloader.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"

                elif self.BIOStoUEFIcb.IsChecked():

                    if UEFISYSP != "None" and Bootloader in ['GRUB2', 'LILO']:
                        #Find the UEFI/UEFI equivalent to a BIOS bootloader, provided there is a UEFI partition.
                        bootloadernum = templist.index(Bootloader)
                        BootloaderToInstall = templist[bootloadernum-1]
                    elif UEFISYSP == "None":
                        #Refuse to install a UEFI bootloader, as there is no UEFI partition.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader to install requires a UEFI partition, which either doesn't exist or has been selected as None. Please create or select a UEFI partition to install a UEFI bootloader.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"
                    else:
                        #Do nothing, already using UEFI/UEFI bootloader.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader, using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"

                elif self.useAutocb.IsChecked():

                    bootloadernum = templist.index(Bootloader)

                    if FWType == "BIOS" and Bootloader not in ['GRUB2', 'LILO', 'GRUB-LEGACY']:
                        #Find the BIOS/MBR equivalent to a UEFI bootloader.
                        BootloaderToInstall = templist[bootloadernum+1]

                    elif FWType == "UEFI" and Bootloader not in ['GRUB-UEFI', 'ELILO', 'GRUB-LEGACY'] and UEFISYSP != "None":
                        #Find the UEFI/UEFI equivalent to a BIOS bootloader, provided there is a UEFI partition, and it isn't GRUB-LEGACY
                        BootloaderToInstall = templist[bootloadernum-1]

                    elif FWType == "BIOS" and Bootloader == "GRUB-LEGACY":
                        #Recommend GRUB2 for BIOS systems using GRUB-LEGACY
                        dlg = wx.MessageDialog(self.OptsPanel2, 'Seeing as your bootloader is grub legacy, and you use BIOS firmware, the recommended bootloader for your hardware is grub2 (listed as GRUB2), if at least oone of your  operating systems supports it. If you want to install a different bootloader, click no and return to the firmware settings dialog to manually select your bootloader. Click yes to comfirm installing grub2, click no to do nothing.', 'WxFixBoot -- Comfirmation', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
                        if dlg == wx.ID_YES:
                            BootloaderToInstall = "GRUB2"
                        else:
                            #Do nothing
                            BootloaderToInstall = "None"

                    elif FWType == "UEFI" and Bootloader == "GRUB-LEGACY":
                        #Suggest GRUB-UEFI for UEFI systems using GRUB-LEGACY
                        wx.MessageDialog(self.OptsPanel2, "You have a combination of UEFI firmware and grub legacy. This is an odd combination, and WxFixBoot doesn't know what to do. If you've imaged your HDD from another system, you probably want to install grub-efi manually by returning to the firmware options dialog. If you manually suggested you have grub legacy earlier, please double check. Perhaps you want to install GRUB-UEFI? If so, please manually select it in the Bootloader options dlg.", "WxFixBoot - Warning!", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "Unknown"

                    elif FWType == "UEFI" and UEFISYSP == "None":
                        #Refuse to install a UEFI bootloader, as there is no UEFI partition.
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader to install requires a UEFI partition, which either doesn't exist or has been selected as None. The current bootloader to install has been reset. Please create or select a UEFI partition to install a UEFI bootloader.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                        BootloaderToInstall = "None"

                    else:
                        #Correct bootloader for firmware type.
                        BootloaderToInstall = "None"
                        wx.MessageDialog(self.OptsPanel2, "Your current bootloader already supports your firmware type, so it won't be modified based on your firmware. If you wish to, you can install an alternative bootloader, or reinstall the bootoader using the selection on the main window.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

            else:
                #Do nothing.
                BootloaderToInstall = "None"

        elif self.unchangedcb.IsChecked() == False and ReinstallBootloader == False and UpdateBootloader == False:
            BootloaderToInstall = self.bltoinstallchoice.GetStringSelection()
        else:
            BootloaderToInstall = "None"

        if BootloaderToInstall == Bootloader:
            BootloaderToInstall = "None"
            wx.MessageDialog(self.OptsPanel2, "Your current bootloader is the same as the one you've selected to install! Please select 'Reinstall Bootloader' on the Main Window instead.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        if BootloaderToInstall in ['LILO', 'ELILO']:  
            wx.MessageDialog(self.OptsPanel2, "You've selected/WxFixBoot has autodetermined to use LILO or ELILO as the bootloader to install! Note: ELILO and LILO packages don't exist in some Linux Distributions (Redhat, and anything based on it, for example), and both can be a complete pain to set up/maintain. Please do not use either unless you know how to set up and maintain them, and you're sure you want them. If WxFixBoot recommended either to you, it's a good idea to select the equivalent GRUB version manually instead: GRUB-UEFI for ELILO, GRUB2 for LILO.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        #Avoid an error situation.
        PrevBootloaderSetting = Bootloader

        logger.debug("OptionsWindow2: Saving Options: Value of BootloaderToInstall is: "+BootloaderToInstall)
        logger.info("OptionsWindow2: Finished saving options.")

        self.CloseBLOpts()
        
    def CloseBLOpts(self):
        logger.debug("OptionsWindow2 Closing.")
        #Save that this window has been run once, so it can update itself with the new info if it's started again.
        global BLOptsDlgRun
        BLOptsDlgRun = True

        #Send a message to OptionsDlg1, so it can show itself again.
        wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

        #Exit.
        self.Destroy()

#End Options window 2
#Begin Restore Window
class RestoreWindow(wx.Frame):
    def __init__(self,ParentWindow,Type):
        if Type == "BootSector":
            logger.debug("Restore Boot Sector Window Started.")
            title = "WxFixBoot - Restore the Boot Sector"
        else:
            logger.debug("Restore Partition Table Window Started.")
            title = "WxFixBoot - Restore the Partition Table"

        wx.Frame.__init__(self, parent=wx.GetApp().TopWindow, title=title, size=(400,200), style=wx.DEFAULT_FRAME_STYLE ^ wx.RESIZE_BORDER)
        self.RestorePanel = wx.Panel(self)
        self.ParentWindow = ParentWindow
        self.Type = Type

        self.CreateText()
        self.CreateRadios()
        self.CreateChoiceBs()
        self.CreateButtons()
        self.BindEvents()

        #Set up the window.
        self.SetupOptions()

    def CreateText(self):
        #Create text
        if self.Type == "BootSector":
            wx.StaticText(self.RestorePanel, -1, "Easily restore your bootsector here!", pos=(80,10))
            wx.StaticText(self.RestorePanel, -1, "What type of Boot Sector backup do you have?", pos=(40,40))
        else:
            wx.StaticText(self.RestorePanel, -1, "Easily restore your partition table here!", pos=(60,10))
            wx.StaticText(self.RestorePanel, -1, "What type of partition table backup do you have?", pos=(30,40))

        wx.StaticText(self.RestorePanel, -1, "Backup file:", pos=(40,100))
        wx.StaticText(self.RestorePanel, -1, "Target Device:", pos=(260,100))

    def CreateRadios(self):
        #Create Radio Buttons
        self.autodetectradio = wx.RadioButton(self.RestorePanel, -1, "Autodetect", pos=(10,70), style=wx.RB_GROUP)
        self.msdosradio = wx.RadioButton(self.RestorePanel, -1, "MBR(msdos)", pos=(150,70))
        self.gptradio = wx.RadioButton(self.RestorePanel, -1, "GUID(gpt)", pos=(290,70))  

    def CreateChoiceBs(self):
        #Create ChoiceBoxes
        self.filechoice = wx.Choice(self.RestorePanel, -1, pos=(10,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])
        self.targetchoice = wx.Choice(self.RestorePanel, -1 , pos=(230,120), size=(150,30), choices=['-- Please Select --', 'Specify File Path...'])

    def CreateButtons(self):
        #Create Buttons
        self.exitbutton = wx.Button(self.RestorePanel, -1, "Close and Set Options", pos=(120,160))

    def BindEvents(self):
        #Bind events
        self.Bind(wx.EVT_BUTTON, self.ExitWindow, self.exitbutton)
        self.Bind(wx.EVT_CLOSE, self.ExitWindow)
        self.Bind(wx.EVT_CHOICE, self.SelectFile, self.filechoice)
        self.Bind(wx.EVT_CHOICE, self.SelectTargetDevice, self.targetchoice)

    def SetupOptions(self):
        #Set up the choiceboxes according to the values of the variables.
        if self.Type == "BootSector":
            File = BootSectFile
            TargetDevice = BootSectorTargetDevice
        else:
            File = PartTableFile
            TargetDevice = PartitionTableTargetDevice

        #Image file choice.
        if File != "None":
            self.filechoice.Append(File)
            self.filechoice.SetStringSelection(File)

        #Target device file choice.
        if TargetDevice != "None":
            self.targetchoice.Append(TargetDevice)
            self.targetchoice.SetStringSelection(TargetDevice)

    def SelectFile(self,e):
        #Grab Image path.
        logger.debug("RestoreWindow().SelectFile() has been triggered...")

        #Set up global variables.
        global BootSectFile
        global RestoreBootSector
        global BootSectorBackupType
        global PartTableFile
        global RestorePartTable
        global PartTableBackupType

        File = self.filechoice.GetStringSelection()

        #Determine what to do here.
        if File == "-- Please Select --":
            File = "None"
            Restore = False

        elif File == "Specify File Path...":
            if self.Type == "BootSector":
                Dlg = wx.FileDialog(self.RestorePanel, "Select Boot Sector File...", wildcard="GPT Backup File (*.gpt)|*.gpt|MBR Backup File (*.mbr)|*.mbr|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)
            else:
                Dlg = wx.FileDialog(self.RestorePanel, "Select Partition Table File...", wildcard="GPT Backup File (*.gpt)|*.gpt|MBR Backup File (*.mbr)|*.mbr|IMG Image file (*.img)|*.img|All Files/Devices (*)|*", style=wx.OPEN)

            if Dlg.ShowModal() == wx.ID_OK:
                Restore = True
                File = Dlg.GetPath()
                self.filechoice.Append(File)
                self.filechoice.SetStringSelection(File)
            else:
                File = "None"
                Restore = False
                self.filechoice.SetStringSelection("-- Please Select --")

        else:
            File = self.filechoice.GetStringSelection()
            Restore = True

        #Detect backup type, if files are selected.
        if File != "None" and Restore == True:
            #Use os.stat(filename).st_size, if bigger than 512 bytes (MBR bootsector), it's GPT
            temp = os.stat(File).st_size
            if temp < 512:
                #Bad file.
                wx.MessageDialog(self.RestorePanel, "The size of the selected file is less than 512 bytes! This is not a backup file. Please select a new file.", "WxFixBoot - Error", style=wx.OK | wx.ICON_ERROR, pos=wx.DefaultPosition).ShowModal()
                File = "None"
                Restore = "False"
                BackupType = "None"
                self.autodetectradio.SetValue(True)
                temp = self.filechoice.GetSelection()
                self.filechoice.Delete(temp)
                self.filechoice.SetStringSelection("-- Please Select --")
                return
            elif temp == 512:
                #Backup is MBR(msdos)
                BackupType = "msdos"
                self.msdosradio.SetValue(True)
            elif temp > 512 and temp < 20000:
                #Backup is GPT  
                BackupType = "gpt"
                self.gptradio.SetValue(True)
            else:
                #Backup is *PROBABLY* GPT, but might not be a backup file! If this is the BootSector, it's fine, because for that we backup the UEFI partition.
                BackupType = "gpt"
                self.gptradio.SetValue(True)
                if self.Type == "PartTable":
                    wx.MessageDialog(self.RestorePanel, "Your backup file type is probably GPT, but WxFixBoot isn't sure, as the file size is odd. Please insure that this is a backup file!", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

            wx.MessageDialog(self.RestorePanel, "Your backup file type was detected as: "+BackupType+". If this is correct, then continuing is safe. If not, be careful and insure you made the backup file with WxFixBoot, and manually select the backup type. If you made the backup with another program, please use that program to restore it instead to avoid problems.", "WxFixBoot - Confirmation", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        else:
            BackupType = "None"
            self.autodetectradio.SetValue(True)

        #Save File, Restoring, and BackupType to the correct global variables, depending on which purpose this class is serving (Boot Sector Restoration Window, or Partition Table Restoration Window).
        logger.info("RestoreWindow().SelectFile(): Current config: File = "+File+", Restore = "+Restore+", BackupType = "+BackupType+"...")

        if self.Type == "BootSector":
            BootSectFile = File
            RestoreBootSector = Restore
            BootSectorBackupType = BackupType
        else:
            PartTableFile = File
            RestorePartTable = Restore
            PartTableBackupType = BackupType

    def SelectTargetDevice(self,e):
        #Grab Boot Sector Image path.
        logger.debug("RestoreWindow().SelectTargetDevice() has been triggered...")

        #Set up global variables.
        global BootSectorTargetDevice
        global PartitionTableTargetDevice

        TargetDevice = self.targetchoice.GetStringSelection()

        #Determine what to do here.
        if TargetDevice == "-- Please Select --":
            TargetDevice = "None"
        elif TargetDevice == "Specify File Path...":
            Dlg = wx.FileDialog(self.RestorePanel, "Select Target Device...", wildcard="All Files/Devices (*)|*", defaultDir='/dev', style=wx.OPEN)
            if Dlg.ShowModal() == wx.ID_OK:
                TargetDevice = Dlg.GetPath()
                self.targetchoice.Append(TargetDevice)
                self.targetchoice.SetStringSelection(TargetDevice)
            else:
                TargetDevice = "None"
                self.targetchoice.SetStringSelection("-- Please Select --")
        else:
            TargetDevice = self.targetchoice.GetStringSelection()

        #Save TargetDevice to the correct global variable, depending on which purpose this class is serving (Boot Sector Restoration Window, or Partition Table Restoration Window).
        logger.info("RestoreWindow().SelectTargetDevice(): CUrrent config: TargetDevice = "+TargetDevice+"...")

        if self.Type == "BootSector":
            BootSectorTargetDevice = TargetDevice
        else:
            PartitionTableTargetDevice = TargetDevice

    def ExitWindow(self,e):
        if self.Type == "BootSector":
            File = BootSectFile
            Restore = RestoreBootSector
            TargetDevice = BootSectorTargetDevice
        else:
            File = PartTableFile
            Restore = RestorePartTable
            TargetDevice = PartitionTableTargetDevice

        if File != "None" and Restore == True and TargetDevice != "None":
            #Show an info message.
            dlg = wx.MessageDialog(self.RestorePanel, "Do you want to continue? This operation can cause data loss. Only continue if you are certain you've selected the right target device and backup file, and if the backup was created with WxFixBoot. If you restore a partition table or bootsector, some options, such as installing a different bootloader, and reinstalling/updating your bootloader, will be disabled. Settings such as the new bootloader to install (if set) will also be reset and disabled. If you want to change other settings, you can always restart WxFixBoot afterward.", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_EXCLAMATION, pos=wx.DefaultPosition)
            if dlg.ShowModal() == wx.ID_YES:
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

        elif File != "None" or Restore == True or TargetDevice != "None":
            wx.MessageDialog(self.RestorePanel, "You haven't entered all of the required settings! Please either enter all required settings, or none of them, to disable boot sector/partition table restoration.", "WxFixBoot - Warning", style=wx.OK | wx.ICON_WARNING, pos=wx.DefaultPosition).ShowModal()

        else:
            dlg = wx.MessageDialog(self.RestorePanel, "Do you want to exit this Window, without setting any settings (and unsetting current settings)?", "WxFixBoot - Information", style=wx.YES_NO | wx.ICON_EXCLAMATION, pos=wx.DefaultPosition)

            if dlg.ShowModal() == wx.ID_YES:
                logger.debug("Restore Boot Sector/Partion Table Window Closing.")
                #Send a message to OptionsDlg1, so it can show itself again.
                wx.CallAfter(self.ParentWindow.RefreshOptionsDlg1, "Closed.")

                #Exit.
                self.Destroy()

#End Restore Window
#Begin Progress Window
class ProgressWindow(wx.Frame):
    def __init__(self):
        wx.Frame.__init__(self, parent=None, title="WxFixBoot - Operations Progress", size=(500,300), style=wx.CAPTION|wx.MINIMIZE)
        self.ProgressPanel=wx.Panel(self)

        global OutputLog
        OutputLog = ""

        self.CreateText()
        self.CreateButtons()
        self.CreateProgressBars()
        self.BindEvents()

        logger.debug("Progress Window Started.")
        logger.debug("Starting Main Backend Thread...")

        MainBackendThread(self)

    def CreateText(self):
        #Create Text.
        wx.StaticText(self.ProgressPanel, -1, "WxFixBoot is performing operations... Please wait.", pos=(100,10), size=(299,15))
        wx.StaticText(self.ProgressPanel, -1, "Current Operation:", pos=(191,40), size=(167,15))
        self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, "Initializating...", pos=(207,60), size=(85,15))
        wx.StaticText(self.ProgressPanel, -1, "Current Operation Progress:", pos=(166,90), size=(168,15))
        wx.StaticText(self.ProgressPanel, -1, "Overall Progress:", pos=(200,160), size=(100,15))

    def CreateButtons(self):
        #Create buttons.
        self.ShowOutputButton = wx.ToggleButton(self.ProgressPanel, -1, "Show Terminal output", pos=(345,220))
        self.RestartButton = wx.Button(self.ProgressPanel, -1, "Restart WxFixBoot", pos=(10,220))
        self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(189,260))
        self.RestartButton.Disable()
        self.ExitButton.Disable()

    def CreateProgressBars(self):
        #Create the progress bar for the current operation.
        self.CurrentOpProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,120), size=(480,25))
        self.CurrentOpProgressBar.SetBezelFace(3)
        self.CurrentOpProgressBar.SetShadowWidth(3)
        self.CurrentOpProgressBar.SetValue(0)
        self.CurrentOpProgressBar.Show()

        #Create the progress bar for overall progress.
        self.TotalProgressBar = wx.Gauge(self.ProgressPanel, -1, 100, pos=(10,190), size=(480,25))
        self.TotalProgressBar.SetBezelFace(3)
        self.TotalProgressBar.SetShadowWidth(3)
        self.TotalProgressBar.SetValue(0)
        self.TotalProgressBar.Show()

    def ShowThreadMsgdlg(self,msg,kind="info"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=<kind>, msg=<message>)
        global dlgClosed
        if kind == "info":
            title = "WxFixBoot - Information"
            style = wx.OK | wx.ICON_INFORMATION
        elif kind == "warning":
            title = "WxFixBoot - Warning"
            style = wx.OK | wx.ICON_EXCLAMATION
        elif kind == "error":
            title = "WxFixBoot - Error"
            style = wx.OK | wx.ICON_ERROR

        dlg = wx.MessageDialog(self.ProgressPanel, msg, title, style, pos=wx.DefaultPosition).ShowModal()
        dlgClosed = "True"

    def ShowThreadYesNodlg(self,msg,title="WxFixBoot - Question"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=<message>, title=<title>)
        global dlgResult
        dlg = wx.MessageDialog(self.ProgressPanel, msg, title, wx.YES_NO | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
            dlgResult = "Yes"
        else:
            dlgResult = "No"
        logger.debug("ProgressWindow().ShowThreadYesNodlg(): Result of MainBackendThread yesno dlg was: "+dlgResult)

    def ShowThreadChoicedlg(self,msg,choices,title="WxFixBoot - Select an Option"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=<message>, title=<title>, choices=<data>)
        global dlgResult
        data = msg.split('&')
        dlg = wx.SingleChoiceDialog(self.ProgressPanel, msg, title, choices, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgResult = dlg.GetStringSelection()
        else:
            dlgResult = "Clicked no..."
        logger.debug("ProgressWindow().ShowThreadChoicedlg(): Result of MainBackendThread choice dlg was: "+dlgResult)

    def ShowThreadTextEntrydlg(self,msg,title="WxFixBoot - Text Entry"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=<message>, title=<title>)
        global dlgAnswer
        dlg = wx.TextEntryDialog(self.ProgressPanel, msg, title, "", style=wx.OK|wx.CANCEL, pos=wx.DefaultPosition)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetValue()
        else:
            dlgAnswer = "Clicked no..."
        logger.debug("ProgressWindow().ShowThreadTextEntrydlg(): Result of MainBackendThread text entry dlg was: "+dlgAnswer)

    def ShowThreadFiledlg(self,title="WxFixBoot - Select A File",wildcard="All Files/Devices (*)|*"):
        #Use this with: wx.CallAfter(self.ParentWindow.ShowThreadFiledlg, title=<title>, wildcard=<wildcard>)
        global dlgAnswer
        dlg = wx.FileDialog(self.ProgressPanel, message=title, wildcard=wildcard, style=wx.SAVE)
        if dlg.ShowModal() == wx.ID_OK:
            dlgAnswer = dlg.GetPath()
        else:
            dlgAnswer = "None"
        logger.debug("ProgressWindow().ShowThreadFiledlg(): Result of MainBackendThread file dlg was: "+dlgAnswer)

    def ShowOutput(self,e):
        #This now also works in openbox by resetting the minimum size too, forcing openbox to increase/decrease the size.
        logger.debug("ProgressWindow().ShowOutput() was Toggled to position: "+str(self.ShowOutputButton.GetValue())+", where True = Depressed and vice versa.")
        if self.ShowOutputButton.GetValue() == True:
            #Reset the frame size.
            self.SetMinSize(wx.Size(500,550))

            #Create a text control for output.
            self.OutputBox = wx.TextCtrl(self.ProgressPanel, -1, "", pos=(10,260), size=(480,240), style=wx.TE_MULTILINE|wx.TE_READONLY|wx.TE_WORDWRAP)
            self.OutputBox.SetBackgroundColour((0,0,0))
            self.OutputBox.SetDefaultStyle(wx.TextAttr(wx.WHITE))

            #Populate the outputbox with all the previous output.
            try:
                for line in OutputLog:
                    self.OutputBox.AppendText(line)
            except: pass
 
            #Move ExitButton, while preserving its enabled/disabled status.
            temp = self.ExitButton.Enabled
            self.ExitButton.Destroy()
            self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(406,510))

            if temp == False:
                self.ExitButton.Disable()

            self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)     
        else:
            #Move ExitButton, while preserving its enabled/disabled status.
            temp = self.ExitButton.Enabled
            self.ExitButton.Destroy()
            self.ExitButton = wx.Button(self.ProgressPanel, -1, "Exit", pos=(189,260))

            if temp == False:
                self.ExitButton.Disable()
                PartTableFile = "None"

            self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)

            #Reset the frame size.
            self.SetMinSize(wx.Size(500,300))
            self.SetSize(wx.Size(500,300))
            self.OutputBox.Destroy()

    def UpdateOutputBox(self,msg):
        #Check if outputbox is enabled. Do nothing if it isn't.
        try:
            self.OutputBox.GetSelection()
        except: pass
        else:
            self.OutputBox.AppendText(msg)

    def UpdateCurrentProgress(self,msg):
        #Do current progress.
        #Called at various points during operation code.
        self.CurrentOpProgressBar.SetValue(int(msg))
        if self.CurrentOpProgressBar.GetValue() == 100:
            self.UpdateTotalProgress()
            #Stop this resetting when all operations are complete.
            if self.TotalProgressBar.GetValue() != 100:
                self.CurrentOpProgressBar.SetValue(0)

    def UpdateTotalProgress(self):
        #Do total progress.
        #This is called when self.CurrentOpProgressBar reaches 100 (aka full).
        if self.TotalProgressBar.GetValue() < 100:
            self.TotalProgressBar.SetValue(self.TotalProgressBar.GetValue()+(100/NoOfOps))

    def UpdateCurrentOpText(self,msg):
        #Calculate length (in pixels) of string given, and then where on the x-axis to place it.
        #This is a replacement for wx.ALIGN_CENTER, as it seems broken in Linux.
        font = self.ProgressPanel.GetFont()
        dc = wx.WindowDC(self.ProgressPanel)
        dc.SetFont(font)
        width, height = dc.GetTextExtent(msg)

        #Create the Static Text, if it already exists, delete it.
        try:
            self.CurrentOpText
        except: pass
        else:
            self.CurrentOpText.Destroy()
        finally:
            self.CurrentOpText = wx.StaticText(self.ProgressPanel, -1, msg, pos=((500-int(width))/2,60), size=(int(width),int(height)))

    def MainBackendThreadFinished(self):
        self.RestartButton.Enable()
        self.ExitButton.Enable()

    def RestartWxFixBoot(self,e):
        #Restart WxFixBoot
        logger.debug("Restarting WxFixBoot...")
        self.Hide()

        #Reset all settings to defaults, except ones like LiveDisk, which won't ever need to change.
        SetDefaults()

        global Bootloader
        global FWType
        global RootFS
        global RootDev
        global DefaultOS
        global PartScheme
        global UEFISYSP

        Bootloader = AutoBootloader
        FWType = AutoFWType
        RootFS = AutoRootFS
        RootDev = AutoRootDev
        DefaultOS = AutoDefaultOS
        PartSchemeList = AutoPartSchemeList
        UEFISYSP = AutoEFISYSP

        wx.MessageDialog(self.ProgressPanel, "Okay! WxFixBoot has reset all of its settings. You should now be returned to the Main Window, and everything should be it was when you first started WxFixBoot.", "WxFixBoot - Information", style=wx.OK | wx.ICON_INFORMATION, pos=wx.DefaultPosition).ShowModal()

        #Show MainWindow
        MainFrame = MainWindow()
        app.SetTopWindow(MainFrame)
        MainFrame.Show(True)

        #Destroy Progress Window.
        logger.debug("WxFixBoot has been reset and restarted, returning to MainWindow()")
        self.Destroy()

    def OnExit(self,e):
        #No need to check if operations are running, the button isn't clickable if any are.
        exitdlg = wx.MessageDialog(self.ProgressPanel, 'Are you sure you want to exit?', 'WxFixBoot -- Question!', wx.YES_NO | wx.ICON_QUESTION).ShowModal()
        if exitdlg == wx.ID_YES:
            #Run the exit sequence
            logger.debug("User triggered exit sequence. Exiting...")
            if os.path.exists("/tmp/wxfixboot"):
                shutil.rmtree('/tmp/wxfixboot')
            self.Destroy()

    def BindEvents(self):
        self.Bind(wx.EVT_TOGGLEBUTTON, self.ShowOutput, self.ShowOutputButton)
        self.Bind(wx.EVT_BUTTON, self.RestartWxFixBoot, self.RestartButton)
        self.Bind(wx.EVT_BUTTON, self.OnExit, self.ExitButton)
        self.Bind(wx.EVT_CLOSE, self.OnExit)

#End Progress Window
#Begin Main Backend Thread
class MainBackendThread(Thread):
    def __init__(self,ParentWindow):
        #Start the main part of this thread.
        Thread.__init__(self)
        self.ParentWindow = ParentWindow
        self.start()

    def run(self):
        #Do setup
        self.templog = []
        time.sleep(1)

        #Helpful info collected in the startup scripts, and during use of the GUI.
        global LinuxPartList
        global RootFS
        global RootDev
        global LiveDisk
        global OSList
        global FWType
        global PartSchemeList
        global Bootloader
        global UEFISYSP
        global ManuallyMountedEFISYSP
        global PartitionListWithFSType

        #Quick operations on the main window.
        global ReinstallBootloader
        global UpdateBootloader
        global QuickFSCheck
        global BadSectCheck

        #Advanced options in Optionsdlg1
        global FullVerbose
        global SaveOutput
        global BkpBootSect
        global BackupPartTable
        global MakeSystemSummary
        global SaveOutput
        global DefaultOS
        global BootloaderTimeout

        #Options in Bootloader Options dlg
        global BootloaderToInstall

        #Options in Restore dlgs
        global RestoreBootSector
        global BootSectFile
        global BootSectorTargetDevice
        global BootSectorBackupType
        global RestorePartTable
        global PartTableFile
        global PartitionTableTargetDevice
        global PartTableBackupType

        #Additional variables used in the Main Backend Thread
        global NoOfOps
        global OutputLog
        global OSesWithBootloaderToRemoveList
        global OSForBootloaderInstallation
        global BootloaderTimeout
        global KernelOptions

        #Log the MainBackendThread start event (in debug mode).
        logger.debug("MainBackendThread(): Started. Calculating Operations to do...")

        self.CountOperations()
        self.StartOperations()

    def CountOperations(self):
        #Count the number of operations to do.
        global NoOfOps
        NoOfOps = 0

        #List to contain operations (and their functions) to run.
        self.OperationsToDo = []

        #Run a series of if loops to determine what operations to do, which order to do them in, and the total number to do.
        #Do essential processes first.
        if BackupPartTable == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.BackupPartitionTable)
            
            logger.info("MainBackendThread().CountOperations(): Added self.BackupPartitionTable to self.OperationsToDo...")

        if BkpBootSect == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.BackupBootSector)
            logger.info("MainBackendThread().CountOperations(): Added self.BackupBootSector to self.OperationsToDo...")

        if RestorePartTable == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.RestorePartitionTable)
            logger.info("MainBackendThread().CountOperations(): Added self.RestorePartitionTable to self.OperationsToDo...")

        if RestoreBootSector == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.RestoreBootSector)
            logger.info("MainBackendThread().CountOperations(): Added self.RestoreBootSector to self.OperationsToDo...")

        if QuickFSCheck == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.QuickFileSystemCheck)
            logger.info("MainBackendThread().CountOperations(): Added self.QuickFileSystemCheck to self.OperationsToDo...")

        if BadSectCheck == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.BadSectorCheck)
            logger.info("MainBackendThread().CountOperations(): Added self.BadSectorCheck to self.OperationsToDo...")

        #Now do other processes
        if BootloaderToInstall != "None":
            NoOfOps += 1
            self.OperationsToDo.append(self.ManageBootloaders)
            logger.info("MainBackendThread().CountOperations(): Added self.ManageBootloaders to self.OperationsToDo...")

        if ReinstallBootloader == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.ReinstallBootloader)
            logger.info("MainBackendThread().CountOperations(): Added self.ReinstallBootloader to self.OperationsToDo...")

        if UpdateBootloader == True:
            NoOfOps += 1
            self.OperationsToDo.append(self.UpdateBootloader)
            logger.info("MainBackendwx.CallAfter(self.ParentWindow.ShowThreadFiledlg, msg=<message>, title=<title>, wildcard=<wildcard>)Thread().CountOperations(): Added self.UpdateBootloader to self.OperationsToDo...")

        #Check if we need to prepare to install a new bootloader, and do so first if needed.
        for element in [self.ManageBootloaders, self.ReinstallBootloader, self.UpdateBootloader]:
            if element in self.OperationsToDo:
                self.OperationsToDo.insert(0, self.PrepareForBootloaderInstallation)                

        #Log gathered operations to do, and the number (verbose mode, default).
        logger.info("MainBackendThread().CountOperations(): Number of operations: "+str(NoOfOps))
        logger.info("MainBackendThread().CountOperations(): Starting Operation Running Code...")

    def StartOperations(self):
        #Start doing operations.
        global OutputLog
        OutputLog = []

        self.ShowMsgDlg(Kind="info", Message="The required operations will now be performed. Wait 5 seconds after you see no more activity to enable restarting/exiting wxfixboot.")

        #Run functions to do operations.
        for function in self.OperationsToDo:
            function()

        logger.info("Finished Operation Running Code.") 

        wx.CallAfter(self.ParentWindow.MainBackendThreadFinished)

    ####################Dialog functions to keep the code tidy.####################

    def ShowMsgDlg(self,Message,Kind="info"):
        #Method to handle showing thread message dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowMsgDlg(Kind=<kind>, Message=<message>)
        #Reset dlgClosed, avoiding errors.
        global dlgClosed
        dlgClosed = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadMsgdlg, kind=Kind, msg=Message)

        #Trap the thread until the user responds.
        while dlgClosed == "Unknown":
            time.sleep(0.5)

    def ShowYesNoDlg(self,Message,Title="WxFixBoot - Question"):
        #Method to handle showing thread yes/no dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowYesNoDlg(Message=<message>, Title = <title>)
        #Reset dlgResult, avoiding errors.
        global dlgResult
        dlgResult = "Unknown"

        wx.CallAfter(self.ParentWindow.ShowThreadYesNodlg, msg=Message, title=Title)

        #Trap the thread until the user responds.
        while dlgResult == "Unknown":
            time.sleep(0.5)

        #Return dlgResult directly potentially avoiding problems.
        return dlgResult

    def ShowChoiceDlg(self,Message,Title,Choices):
        #Method to handle showing thread choice dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowChoiceDlg(Message=<message>, Title=<title>, Choices=<choices>)
        while True:
            #Reset dlgResult, avoiding errors.
            global dlgResult
            dlgResult = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadChoicedlg, msg=Message, title=Title, choices=Choices)

            #Trap the thread until the user responds.
            while dlgResult == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgResult == "" or dlgResult == "Clicked no...":
                self.ShowMsgDlg(Kind="warning", Message="Please make a valid selection.")
            else:
                #Return dlgResult directly potentially avoiding problems.
                return dlgResult

    def ShowTextEntryDlg(self,Message,Title="WxFixBoot - Text Entry"):
        #Method to handle showing thread text entry dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowTextEntryDlg(Message=<message>, Title=<title>)
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadTextEntrydlg, msg=Message, title=Title)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgAnswer == "":
                self.ShowMsgDlg(Kind="warning", Message="Please enter a value or click cancel.")
            else:
                #Return dlgAnswer directly potentially avoiding problems.
                return dlgAnswer

    def ShowFileDlg(self,Title="WxFixBoot - Select A File",Wildcard="All Files/Devices (*)|*"):
        #Method to handle showing thread file dialogs, reducing code duplication and compilications and errors.
        #Use this with: self.ShowFileDlg(Title=<title>, Wildcard=<wildcard>)
        #Make sure the user gives a value, using a while loop.
        while True:
            #Reset dlgAnswer, avoiding errors.
            global dlgAnswer
            dlgAnswer = "Unknown"

            wx.CallAfter(self.ParentWindow.ShowThreadFiledlg, title=Title, wildcard=Wildcard)

            #Trap the thread until the user responds.
            while dlgAnswer == "Unknown":
                time.sleep(0.5)

            #Stop the user from avoiding entering anything.
            if dlgAnswer == "None":
                self.ShowMsgDlg(Kind="warning", Message="You must select a file!")
            else:
                #Return dlgAnswer directly potentially avoiding problems.
                return dlgAnswer

    ####################End of Dialog functions.####################
    ####################Core functions that are used all the time, kept here to avoid duplication.####################

    def StartThreadProcess(self, ExecCmds, Piping=False, ShowOutput=True, ReturnOutput=False):
        #Start a process given a list with commands to execute, specifically for this thread, as it also sends the output to self.UpdateOutputBox().
        #This now uses a set of default values, to keep it simple. It can be called with self.StartThreadProcess(ExecCmds=[], ShowOutput=True) etc. Only ExecCmds is compulsory.
        #Reset templog
        templog = []

        #Run the cmd.
        if Piping == False:
            logger.debug("MainBackendThread().StartThreadProcess(): Starting process: "+' '.join(ExecCmds))
            runcmd = subprocess.Popen(ExecCmds, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        else:
            logger.debug("MainBackendThread().StartThreadProcess(): Starting process: "+ExecCmds)
            runcmd = subprocess.Popen(ExecCmds, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, shell=True)

        while runcmd.poll() == None:
            #Send given line to the outputbox and Log it too, if ShowOutput == True or if FullVerbose == True 
            line = runcmd.stdout.readline()
            templog.append(line)
            OutputLog.append(line)
            if ShowOutput == True or FullVerbose == True:
                self.UpdateOutputBox(line=line)

        #Save runcmd.stdout.readlines, and runcmd.returncode, as they tend to reset fairly quickly.
        output = runcmd.stdout.readlines()
        retval = int(runcmd.returncode)

        #Add any missing output (this is what templog is helpful for: it'll contain only output from this command).
        for line in output:
            if line not in templog:
                templog.append(line)
                OutputLog.append(line)
                if ShowOutput == True or FullVerbose == True:
                    self.UpdateOutputBox(line=line)

        if ReturnOutput == False:
            #Return the return code back to whichever function ran this process, so it can handle any errors.
            return retval
        else:
            #Return the return code, as well as the output, because if we're hiding it, it's probably because we want it.
            return [retval, ''.join(templog)]

    def UpdateOutputBox(self, line):
        #Send given line to the outputbox.
        logger.info("MainBackendThread().UpdateOutputBox(): Command output: "+line)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, line)

    def RemountPartitionRW(self, Partition):
        #Remount a given FS (or mountpoint) read-write.
        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            logger.debug("MainBackendThread().RemountPartitionRW(): Partition: "+Partition+" isn't mounted, so we'll mount it RW now...")
            retval = self.StartThreadProcess(ExecCmds=['mount', Partition], ShowOutput=False)
        else:
            logger.debug("MainBackendThread().RemountPartitionRW(): Remounting partition: "+Partition+"...")
            retval = self.StartThreadProcess(ExecCmds=['mount', '-o', 'remount,rw', Partition], ShowOutput=False)

        #Check that this worked okay.
        if retval != 0:
            #It didn't, for some strange reason.
            logger.warning("MainBackendThread().RemountPartitionRW(): Warning: Remounting partition: "+Partition+": Failed!")
        else:
            logger.info("MainBackendThread().RemountPartitionRW(): Remounting partition: "+Partition+": Success!")

        #Return the return value
        return retval

    def RemountPartitionRO(self, Partition):
        #Remount a given FS (or mountpoint) read-only.
        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            logger.debug("MainBackendThread().RemountPartitionRO(): Partition: "+Partition+" isn't mounted, so we'll mount it RO now...")
            retval = self.StartThreadProcess(ExecCmds=['mount', '-o', 'ro', Partition], ShowOutput=False)
        else:
            logger.debug("MainBackendThread().RemountPartitionRO(): Remounting partition: "+Partition+"...")
            retval = self.StartThreadProcess(['mount', '-o', 'remount,ro', Partition], ShowOutput=False)

        #Check that this worked okay.
        if retval != 0:
            #It didn't, for some strange reason.
            logger.warning("MainBackendThread().RemountPartitionRO(): Warning: Remounting partition: "+Partition+": Failed!")
        else:
            logger.info("MainBackendThread().RemountPartitionRO(): Remounting partition: "+Partition+": Success!")

        #Return the return value
        return retval

    def UnmountPartition(self, Partition):
        #Unmount the given partition, or mountpoint.
        #Check if it is mounted.
        try:
            MountPoint = StartProcess("df | grep '"+Partition+"'")[1].split()[-1]
        except IndexError:
            #The Partition isn't mounted.
            #Set retval to 0 and log this.
            retval = 0
            logger.info("MainBackendThread().UnmountPartition(): Partition: "+Partition+" was not mounted. Continuing...")
        else:
            logger.debug("MainBackendThread().UnmountPartition(): Unmounting partition: "+Partition+"...")
            retval = self.StartThreadProcess(['umount', Partition], ShowOutput=False)

            #Check that this worked okay.
            if retval != 0:
                #It didn't, for some strange reason.
                logger.warning("MainBackendThread().UnmountPartition(): Warning: Unmounting partition: "+Partition+": Failed!")
            else:
                logger.info("MainBackendThread().UnmountPartition(): Unmounting partition: "+Partition+": Success!")
            
        #Return the return value
        return retval

    def SetUpChroot(self, MountPoint):
        #Function to set up a chroot for the given mountpoint.
        logger.debug("MainBackendThread().SetUpChroot(): Setting up chroot for MountPoint: "+MountPoint+"...")

        #Mount /dev, /dev/pts, /proc and /sys for the chroot. Ignore return values.
        retval = self.StartThreadProcess(['mount', '--bind', '/dev', MountPoint+'/dev'], ShowOutput=False)
        retval = self.StartThreadProcess(['mount', '--bind', '/dev/pts', MountPoint+'/dev/pts'], ShowOutput=False)
        retval = self.StartThreadProcess(['mount', '--bind', '/proc', MountPoint+'/proc'], ShowOutput=False)
        retval = self.StartThreadProcess(['mount', '--bind', '/sys', MountPoint+'/sys'], ShowOutput=False)

        #Copy /etc/resolv.conf to MountPoint/etc/resov.conf, so the other OS can have internet access (normally resolv.conf is recreated on bootup anyway, so this shouldn't cause any problems).
        retval = self.StartThreadProcess(['cp', '/etc/resolv.conf', MountPoint+'/etc/resolv.conf'], ShowOutput=False)

    def TearDownChroot(self, MountPoint):
        #Function to remove a chroot at the given mountpoint.
        logger.debug("MainBackendThread().TearDownChroot(): Removing chroot at MountPoint: "+MountPoint+"...")

        #Unmount /dev, /dev/pts, /proc and /sys in the chroot. Ignore return values.
        retval = self.StartThreadProcess(['umount', MountPoint+'/dev'], ShowOutput=False)
        retval = self.StartThreadProcess(['umount', MountPoint+'/dev/pts'], ShowOutput=False)
        retval = self.StartThreadProcess(['umount', MountPoint+'/proc'], ShowOutput=False)
        retval = self.StartThreadProcess(['umount', MountPoint+'/sys'], ShowOutput=False)

    def GetPartitionUUID(self,Partition):
        #Function to retrive a partition's uuid.
        temp = self.StartThreadProcess(['blkid', '-o', 'list'], ShowOutput=False, ReturnOutput=True)
        retval = temp[0]
        output = temp[1].split('\n')

        if retval != 0:
            #Return "None"
            return "None"
        else:
            UUID="None"

            for line in output:
                if Partition in line:
                    UUID=line.split()[-1]

            return UUID            

    ####################End of Core functions.####################
    ####################Helper Functions that are used a few times by other functions.####################

    def FindMissingFSCKModules(self):
        #Function to check for and return all missing fsck modules (fsck.vfat, fsck.minix, etc), based on the FS types in PartitionListWithFSType.
        logger.info("MainBackendThread().FindMissingFSCKModules(): Looking for missing FSCK modules to ignore...")
        templist = []

        for FSType in PartitionListWithFSType:
            #Check if we're looking at a FSType, not a device, and that we've not marked it "Unknown". Otherwise ignore it.
            if FSType[0] != "/" and FSType != "Unknown":
                try:
                    runcmd = subprocess.Popen(["fsck."+FSType], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
                    stdout, stderr = runcmd.communicate()
                except OSError:
                    #OS probably couldn't find it, add it to the list.
                    templist.append("fsck."+FSType)
                else:
                    if str(stderr) != "None":
                        #It was found, but errored for no reason. Add it to the failed list.
                        templist.append("fsck."+FSType)

        #Return the list, so FSCheck functions know which FSes to ignore.
        logger.info("MainBackendThread().FindMissingFSCKModules(): Done! Ignoring FSCK modules: "+', '.join(templist))
        return templist

    def LookForAPTOnPartition(self, APTExecList):
        #Look for apt using the command lists given (they include the partition, by the way).
        logger.debug("MainBackendThread().LookForPackageManagerOnPartition() has been triggered...")

        #Check for APT
        try:
            subprocess.check_output(APTExecList)
        except:
            #Couldn't find apt!
            return "None"
        else:
            #Found APT!
            #Return 'APT'
            return "apt-get"

    def LookForBootloaderOnPartition(self, PackageManager, MountPoint, UsingChroot):
        #Look for the currently installed bootloader in the given mount point.
        logger.debug("MainBackendThread().LookForBootloaderOnPartition() has been triggered...")

        #Okay, let's run a command in the chroot that was set up in self.FindBootloaderRemovalOSes(), depending on which package manager this OS uses, and which bootloader is currently installed.
        #To do this, we need to tell self.StartThreadProcess() that we're going to be using pipes on the commandline, so we can use shell=True.

        if Bootloader == "GRUB-LEGACY":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep -w 'grub'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep -w 'grub'", Piping=True, ShowOutput=False)

        elif Bootloader == "GRUB2":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep 'grub-pc'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep 'grub-pc'", Piping=True, ShowOutput=False)

        elif Bootloader == "LILO":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep 'lilo'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep 'lilo'", Piping=True, ShowOutput=False)

        elif Bootloader == "GRUB-UEFI":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep 'grub-efi'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep 'grub-efi'", Piping=True, ShowOutput=False)

        elif Bootloader == "ELILO":
            if UsingChroot == True:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("chroot "+MountPoint+" dpkg --get-selections | grep 'elilo'", Piping=True, ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess("dpkg --get-selections | grep 'elilo'", Piping=True, ShowOutput=False)

        #Now we can check the return value. If it's 0, the bootloader is present in this OS. Otherwise, it isn't.
        if retval == 0:
            logger.info("MainBackendThread().LookForBootloaderOnPartition(): Found "+Bootloader+" in "+MountPoint+", where '' is the current OS...")
            return "Yes"
        else:
            logger.debug("MainBackendThread().LookForBootloaderOnPartition(): Didn't find "+Bootloader+" in "+MountPoint+", where '' is the current OS...")
            return "No"

    def FindCheckableFileSystems(self):
        #Find all checkable filesystems, and then return them to self.BadSectorCheck()/self.QuickFSCheck()
        logger.info("MainBackendThread().FindCheckableFileSystems(): Finding and returning all filesystems/partitions that can be checked...")

        #Do setup.
        DoNotCheckList = []
        CheckList = []

        #Get a list of missing fsck modules (if any) based on the existing filesystems.
        MissingFSCKModules = self.FindMissingFSCKModules()

        #Determine checkable partitions.
        for Partition in PartitionListWithFSType:
            #Make sure we're looking at a partition, if not, ignore it.
            if Partition[0] == "/":
                #Find the FSType (the next element)
                FSType = PartitionListWithFSType[PartitionListWithFSType.index(Partition)+1]

                #Check if the required fsck module is present, and that the partition isn't RootFS
                if "fsck."+FSType not in MissingFSCKModules and FSType != "Unknown":
                    #If we're not running on a live disk, skip the filesystem if it's the same as RootFS (in which case checking it may corrupt data)
                    if LiveDisk == False and Partition == AutoRootFS:
                        CheckTheFS = "No"
                        RemountPartitionAfter = "No"
                        continue

                    #Check if the partition is mounted.
                    try:
                        temp = subprocess.check_output("df | grep "+Partition, shell=True).split()[-1]
                    except subprocess.CalledProcessError:
                        #Not mounted.
                        CheckTheFS = "Yes"
                        RemountPartitionAfter = "No"
                    else:
                        #Remount the FS readonly temporarily, to avoid data corruption.
                        retval = self.RemountPartitionRO(Partition=Partition)

                        #Check that this worked okay.
                        if retval != 0:
                            #It didn't, for some strange reason. Log it.
                            logger.warning("MainBackendThread().FindCheckableFileSystems(): Warning: Failed to remount the partition: "+Partition+" Read-Only, which is necessary for safe disk checking! Ignoring it, becuase it's probably a home directory (if running an OS on the HDD, and not a live disk) or an essential system dir...")
                            CheckTheFS = "No"
                            RemountPartitionAfter = "No"
                        else:
                            CheckTheFS = "Yes"
                            RemountPartitionAfter = "Yes"
                else:
                    CheckTheFS = "No"
                    RemountPartitionAfter = "No"

                if CheckTheFS == "No":
                    #Add it to the non-checkable list
                    DoNotCheckList.append(Partition+" with Filesystem: "+FSType)
                else:
                    #Add it to the templist for checking.
                    CheckList.append(Partition+" "+FSType+" "+RemountPartitionAfter)

        #Report uncheckable partitions.
        if DoNotCheckList != []:
            #Some filesystems will not be checked. Warn the user.
            self.ShowMsgDlg(Kind="warning", Message="The following filesystems will not be checked:\n\n"+'\n'.join(DoNotCheckList)+".\n\nThe most likely reason for this is that some of the filesystem types are unsupported by the current running operating system. WxFixBoot will now continue to check the remaining filesystems.")

        logger.info("MainBackendThread().FindCheckableFileSystems(): Done! Filesystems that won't be checked: "+'\n'.join(DoNotCheckList)+"...")
        return CheckList

    def HandleFilesystemCheckReturnValues(self, ExecList, retval):
        #Function to handle Filesystem Checker return codes, because it's more complicated than you'd think, and it simpifies the code.
        #Return values of 1,2 or 3 happen if errors were corrected.
        if retval in [1, 2, 3]:
            if ExecList[0] == "xfs_repair":
                #Fs Corruption Detected.
                logger.warning("MainBackendThread().HandleFilesystemCheckReturnValues(): Warning: xfs_repair detected filesystem corruption on FileSystem: "+Partition+". It's probably (and hopefully) been fixed, but we're logging this anyway.")
                self.ShowMsgDlg(Kind="warning", Message="Corruption was found on the filesystem: "+Partition+"! Fortunately, the checker utility has probably fixed the corruption. Click okay to continue.")
            elif ExecList[0] in ['fsck.jfs', 'fsck.minix', 'fsck.reiserfs', 'fsck.vfat', 'fsck.ext2', 'fsck.ex3', 'fsck.ext4', 'fsck.ext4dev']:
                #Fixed Errors.
                logger.info("MainBackendThread().HandleFilesystemCheckReturnValues(): "+ExecList[0]+" successfully fixed errors on the partition: "+Partition+". Continuing...")
                self.ShowMsgDlg(Kind="warning", Message="The filesystem checker found and successfully fixed errors on partition: "+Partition+" Click okay to continue.")
        else:
            #Something bad happened!
            logger.error("MainBackendThread().HandleFilesystemCheckReturnValues(): Error: "+ExecList[0]+" Errored with exit value "+str(retval)+"! This could indicate filesystem corruption or bad sectors! Asking the user whether to skip any bootloader operations...")
            temp = self.ShowYesNoDlg(Message="Error! The filesystem checker gave exit value: "+str(retval)+"! This could indicate filesystem corruption, a problem with the filesystem checker, or bad sectors on partition: "+Partition+". If you perform bootloader operations on this partition, WxFixBoot could become unstable, and your system could become unbootable. Do you want to disable bootloader operations, as is strongly recommended?", Title="WxFixBoot - Disable Bootloader Operations?")

            if temp == "Yes":
                #A Good choice. WxFixBoot will now disable any bootloader operations.
                logger.warning("MainBackendThread().HandleFilesystemCheckReturnValues(): Warning: User disabled bootloader operations as recommended, due to bad sectors/HDD problems...")
                global OSesWithBootloaderToRemoveList
                global OSForBootloaderInstallation
                OSesWithBootloaderToRemoveList = ['None']
                OSForBootloaderInstallation = "None,FSCKProblems"
            else:
                #Seriously? Well, okay, we'll do it anyway... This is probably a very bad idea...
                logger.warning("MainBackendThread().HandleFilesystemCheckReturnValues(): Warning: User ignored the warning and went ahead with bootloader modifications (if any) anyway, even with possible HDD problems/Bad sectors! This is a REALLY bad idea, but we'll do it anyway, as requested...")

    def FindBootloaderRemovalOSes(self, OSListWithPackageManagers):
        #Function to find the OS(es) that currently have the bootloader installed, so we know where to remove it from.
        #Define a global var.
        global OSesWithBootloaderToRemoveList
        OSesWithBootloaderToRemoveList = []

        for OS in OSListWithPackageManagers:
            #Grab the Package Manager and the partition the OS resides on.
            PackageManager = OS.split()[-1]
            Partition = OS.split()[-5]
            MountPoint = "/mnt"+Partition

            #Run some different instructions depending on whether the partition = AutoRootFS or not.
            if LiveDisk == False and Partition == AutoRootFS:
                #It is! We can skip some steps!
                #Try to find if this OS has the bootloader installed in it.
                found = self.LookForBootloaderOnPartition(PackageManager=PackageManager, MountPoint=MountPoint, UsingChroot=False)

            else:
                #Do some additional steps if we're using
                #Mount the partition safely, using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, and skip the rest of the loop, as it's safer to do so.
                    logger.warning("MainBackendThread().FindBootloaderRemovalOSes(): Command: 'mount "+MountPoint+" /mnt/"+MountPoint+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                    continue

                #Set up a chroot.
                self.SetUpChroot(MountPoint=MountPoint)

                #Try to find if the OS has the bootloader installed in it.
                found = self.LookForBootloaderOnPartition(PackageManager=PackageManager, MountPoint=MountPoint, UsingChroot=True)
                
                #Tear down the chroot.
                self.TearDownChroot(MountPoint=MountPoint)

                #Unmount the partition.
                self.UnmountPartition(Partition=Partition)

            #Check if the bootloader was found on that partition. If it wasn't, don't do anything.
            if found == "Yes":
                #It was! Add it to the list.
                OSesWithBootloaderToRemoveList.append(OS)
                logger.debug("MainBackendThread().FindBootloaderRemovalOSes(): Found bootloader to remove: "+Bootloader+" On OS: +"+OS+". Adding it to the list. Continuing...")

        #Return the list to self.PrepareForBootloaderInstallation()
        logger.debug("MainBackendThread().FindBootloaderRemovalOSes(): Finished populating OSesWithBootloaderToRemoveList. Contents: "+' '.join(OSesWithBootloaderToRemoveList)+"...")
        return OSesWithBootloaderToRemoveList

    def AskUserForBootloaderInstallationOS(self, OSListWithPackageManagers):
        #Function to ask the user where the new bootloader is to be installed.
        global OSForBootloaderInstallation

        #Ask the user which candidate to use for bootloader installation.
        temp = self.ShowChoiceDlg(Message="Please select the OS you'd like to use for bootloader installation.\nIdeally, select the one that you use most frequently.\nIf you're reinstalling or updating the bootloader, please insure you select the OS that installed it.", Title="WxFixBoot - Select OS For Bootloader Installation", Choices=OSListWithPackageManagers)

        #Use the user's suggestion.
        logger.info("MainBackendThread().AskUserForInstallationOS(): Using: "+temp+" for bootloader installation.")
        OSForBootloaderInstallation = temp

    ####################End of Helper Functions.####################
    ####################Essential Functions, that must be run before doing bootloader oparations.####################

    def BackupPartitionTable(self):
        #Function to backup the partition table.
        #For GPT disks, backup with sgdisk -b/--backup=<file> <SOURCEDIRVE>.
        #For MBR disks, backup with dd if=/dev/sdX of=<somefile> bs=512 count=1.
        #We need to find RootDev's partition scheme from the PartSchemeList here.
        tempnum = DeviceList.index(RootDev)
        PartScheme = PartSchemeList[tempnum]

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to backup the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to Backup the Partition Table...###\n")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)

        if PartScheme == "msdos":
            #Let's backup the MBR, but we need to ask where to back it up first.
            BackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Partition Table Backup File", Wildcard="MBR Backup File (*.mbr)|*.mbr|IMG Image file (*.img)|*.img|All Files/Devices (*)|*")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Backing up the Partition Table...###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)

            #Backup the MBR of RootDev.
            logger.info("MainBackendThread().BackupPartitionTable(): Backing up MBR partition table to file: "+BackupFile+", from device: "+RootDev+"...")
            retval = self.StartThreadProcess(['dd', 'if='+RootDev, 'of='+BackupFile, 'bs=512', 'count=1'], ShowOutput=False)
        else:
            #Let's backup the GPT, but we need to ask where to back it up first.
            BackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Partition Table Backup File", Wildcard="GPT Backup File (*.gpt)|*.gpt|IMG Image file (*.img)|*.img|All Files/Devices (*)|*")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Backing up the Partition Table...###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)

            #Backup the GPT.
            logger.info("MainBackendThread().BackupPartitionTable(): Backing up GPT partition table to file: "+BackupFile+", from device: "+RootDev+"...")
            retval = self.StartThreadProcess(['sgdisk', '--backup='+BackupFile, RootDev], ShowOutput=False)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Backing up Partition Table!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Finished Backing up the Partition Table!###\n")
        logger.info("MainBackendThread().BackupPartitionTable(): Finished Backing up Partition Table! Exit code: "+str(retval))

    def BackupBootSector(self):
        #Function to backup the bootsector.
        #For GPT disks, backup UEFI System Partition.
        #For MBR disks, backup with dd if=/dev/sdX of=<somefile> bs=512 count=1.
        #We need to find RootDev's partition scheme from the PartSchemeList here.
        tempnum = DeviceList.index(RootDev)
        PartScheme = PartSchemeList[tempnum]

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to backup the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to Backup the Boot Sector...###\n")

        if PartScheme == "msdos":
            #Let's backup the MBR, but we need to ask where to back it up first.
            BackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Bootsector Backup File", Wildcard="IMG Image file (*.img)|*.img|All Files/Devices (*)|*")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up the Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)
            wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Backing up the Boot Sector...###\n")

            #Backup the MBR of RootDev.
            logger.info("MainBackendThread().BackupBootSector(): Backing up MBR bootsector to file: "+BackupFile+", from device: "+RootDev+"...")
            retval = self.StartThreadProcess(['dd', 'if='+RootDev, 'of='+BackupFile, 'bs=512', 'count=1'], ShowOutput=False)
        else:
            #Let's backup the UEFISYSP, but check there is one first.
            if UEFISYSP == "None":
                logger.error("MainBackendThread().BackupBootSector(): Error: Failed to backup UEFI Partition, because there isn't one!")
                self.ShowMsgDlg(Kind="error", Message="Sorry, you have no UEFI Partition, so WxFixBoot couldn't backup your bootsector! Click okay to skip this operation.")
            else:
                #We need to ask where to back it up to.
                BackupFile = self.ShowFileDlg(Title="WxFixBoot - Select Bootsector Backup File", Wildcard="IMG Image file (*.img)|*.img|All Files/Devices (*)|*")
                wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Backing up the Partition Table...")
                wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)

                #Backup the UEFISYSP.
                logger.info("MainBackendThread().BackupBootSector(): Backing up UEFI System Partition ("+UEFISYSP+") to file: "+BackupFile+"...")
                retval = self.StartThreadProcess(['dd', 'if='+UEFISYSP, 'of='+BackupFile], ShowOutput=False)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Backing up the Partition Table!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Finished Backing up the Boot Sector!###\n")
        logger.info("MainBackendThread().BackupBootSector(): Finished backing up Boot Sector! Exit code: "+str(retval))

    def RestorePartitionTable(self):
        #Function to restore the partition table.
        #Use sgdisk for GPT disks, restore with sgdisk -l/--load-backup=<file> <TARGETDEVICE>
        #Use dd for MBR disks, restore with dd if=<somefile> of=/dev/sdX bs=1 count=64 skip=446 seek=446
        #We need to check if PartTableFile is on a different partition or device, so we can make sure it's available.
        logger.info("MainBackendThread().RestorePartitionTable(): Preparing to restore the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to restore the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to restore the Partition Table...###\n")

        if "/mnt/" in PartTableFile:
            #It is! Determine which partition we need to mount.
            temp = PartTableFile.split('/')
            PartitionToMount = "/"+'/'.join(temp[2:4])

            #Mount it, and set a variable so we can unmount it afterwards.
            MountPartitionSafely(Partition=PartitionToMount, MountPoint="/mnt"+PartitionToMount)
            MountedFS = PartitionToMount
            logger.info("MainBackendThread().RestorePartitionTable(): Okay. Mounted the partition: "+MountedFS+" that houses the file. Now let's restore the Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)
        else:
            #Nope, it's on this partition.
            MountedFS = "None"
            logger.info("MainBackendThread().RestorePartitionTable(): Okay. Now let's restore the Partition Table...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Restoring the Partition Table...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Restoring the Partition Table...###\n")

        if PartTableBackupType == "msdos":
            #Let's restore the MBR Partition Table.
            logger.info("MainBackendThread().RestorePartitionTable(): Restoring MBR partition table from file: "+PartTableFile+" to device: "+PartitionTableTargetDevice+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            retval = self.StartThreadProcess(['dd', 'if='+PartTableFile, 'of='+PartitionTableTargetDevice, 'bs=1', 'count=64', 'skip=446', 'seek=446'], ShowOutput=False)
        else:
            #Let's restore the GPT.
            retval = self.StartThreadProcess(['sgdisk', '--load-backup='+PartTableFile, PartitionTableTargetDevice], ShowOutput=False)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            logger.info("MainBackendThread().RestorePartitionTable(): Restoring GPT partition table from file: "+PartTableFile+" to device: "+PartitionTableTargetDevice+"...")

        #Unmount the partition containing the file, if there is one.
        if MountFS != "None":
            logger.info("MainBackendThread().RestorePartitionTable(): Unmounting partition: "+MountFS+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 85)
            self.UnmountPartition(Partition=MountedFS)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Restoring the Partition Table!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Finished Restoring the Partition Table!###\n")
        logger.info("MainBackendThread().RestorePartitionTable(): Finished Restoring the Partition Table!")

    def RestoreBootSector(self):
        #Function to restore the bootsector‎.
        #For GPT disks, restore with dd.
        #For MBR disks, restore with dd if=<somefile> of=/dev/sdX bs=446 count=1
        #We need to check if BootSectFile is on a different partition or device, so we can make sure it's available.
        logger.info("MainBackendThread().RestoreBootSector(): Preparing to restore the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to restore the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to restore the Boot Sector...###\n")

        if "/mnt/" in BootSectFile:
            #It is! Determine which partition we need to mount.
            temp = BootSectFile.split('/')
            PartitionToMount = "/"+'/'.join(temp[2:4])

            #Mount it, and set a variable so we can unmount it afterwards.
            MountPartitionSafely(Partition=PartitionToMount, MountPoint="/mnt"+PartitionToMount)
            MountedFS = PartitionToMount
            logger.info("MainBackendThread().RestoreBootSector(): Okay. Mounted the partition: "+MountedFS+" that houses the file. Now let's restore the Boot Sector...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)
        else:
            #Nope, it's on this partition.
            MountedFS = "None"
            logger.info("MainBackendThread().RestoreBootSector(): Okay. Now let's restore the Boot Sector...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 35)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Restoring the Boot Sector...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Restoring the Boot Sector...###\n")

        if BootSectorBackupType == "msdos":
            #Let's restore the MBR bootsector.
            logger.info("MainBackendThread().RestoreBootSector(): Restoring MBR boot sector from file: "+BootSectFile+" to device: "+BootSectorTargetDevice+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            self.StartThreadProcess(['dd', 'if='+BootSectFile, 'of='+BootSectorTargetDevice, 'bs=446', 'count=1'], ShowOutput=False)
        else:
            #Restore the UEFISYSP.
            logger.info("MainBackendThread().RestoreBootSector(): Restoring UEFI Partition ("+UEFISYSP+") from file: "+BootSectFile+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 65)
            self.StartThreadProcess(['dd', 'if='+BootSectFile, 'of='+UEFISYSP], ShowOutput=False)

        #Unmount the partition containing the file, if there is one.
        if MountFS != "None":
            logger.info("MainBackendThread().RestoreBootSector(): Unmounting partition: "+MountFS+"...")
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 85)
            self.UnmountPartition(Partition=MountedFS)

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Restoring the Boot Sector!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Finished Restoring the Boot Sector...###\n")
        logger.info("MainBackendThread().RestoreBootSector(): Finished restoring the boot sector!")

    def QuickFileSystemCheck(self):
        #Function to quickly check all filesystems.
        logger.debug("MainBackendThread(): Starting self.QuickFileSystemCheck...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing for Quick Filesystem Check...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to do the Quick Filesystem Check...###\n")

        #Determine which partitions are to be checked.
        CheckList = self.FindCheckableFileSystems()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30)

        #Find the length of the list (this is needed to update the progressbars).
        CheckListLength = len(CheckList)

        #Run the check on the checkable partitions
        for Element in CheckList:
            #Gather info.
            SplitElement = Element.split()
            Partition = SplitElement[0]
            FSType = SplitElement[1]
            RemountPartitionAfter = SplitElement[2]

            logger.info("MainBackendThread().QuickFileSystemCheck(): Preparing to check partition: "+Partition+"...")
            wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to check "+Partition+"###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Checking Partition: "+Partition)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30+(50/CheckListLength))

            time.sleep(1)

            #Create a command list that will work based on the fstype of this partition. If there aren't any use cases for the fstype, display a message to the user and skip it.
            if FSType == "jfs":
                ExecList = ['fsck.jfs', '-vf', Partition]
            elif FSType == "minix":
                ExecList = ['fsck.minix', '-avf', Partition]
            elif FSType == "reiserfs":
                ExecList = ['fsck.reiserfs', '-apf', Partition]
            elif FSType == "xfs":
                ExecList = ['xfs_repair', '-Pvd', Partition]
            elif FSType == "vfat":
                ExecList = ['fsck.vfat', '-yv', Partition]
            elif FSType in ['ext2', 'ext3', 'ext4', 'ext4dev']:
                ExecList = ['fsck.'+FSType, '-yvf', Partition]
            else:
                ExecList = ['None']
                logger.warning("MainBackendThread().QuickFileSystemCheck(): Warning: Skipping Partition: "+Partition+", as wxfixboot doesn't support checking it yet...")
                self.ShowMsgDlg(Kind="error", Message="Sorry, the filesystem on partition: "+Partition+" could not be checked, as wxfixboot doesn't support checking it yet. "+Partition+" will now be skipped.")

            #Run the command with Piping = False, if ExecList != ['None'], otherwise do nothing, but do remount the partition if needed.
            if ExecList != ['None']:
                retval = self.StartThreadProcess(ExecList)

            #Check the return values, and run the handler if needed.
            if retval == 0:
                #Success.
                logger.info("MainBackendThread().QuickFileSystemCheck(): Checked partition: "+Partition+" No Errors Found!")
            else:
                self.HandleFilesystemCheckReturnValues(ExecList=ExecList, retval=retval)

            if RemountPartitionAfter == "Yes":
                logger.debug("MainBackendThread().QuickFileSystemCheck(): Remounting Partition: "+Partition+" Read-Write...")
                retval = self.RemountPartitionRW(Partition=Partition)

                #Check if it worked.
                if retval != 0:
                    #Log it.
                    logger.warning("MainBackendThread().BadSectorCheck(): Warning: Failed to remount partition: "+Partition+" after check. We probably need to reboot first. Never mind...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Quick Filesystem Check!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Finished Quick Filesystem Check!###\n")
            
    def BadSectorCheck(self):
        #Function to check all filesystems for bad sectors.
        logger.debug("MainBackendThread(): Starting self.BadSectorCheck...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing for Bad Sector Check...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to do the Bad Sector Check...###\n")

        #Determine which partitions are to be checked.
        CheckList = self.FindCheckableFileSystems()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30)

        #Find the length of the list (this is needed to update the progressbars).
        CheckListLength = len(CheckList)

        #Run the check on the checkable partitions
        for Element in CheckList:
            #Gather info.
            SplitElement = Element.split()
            Partition = SplitElement[0]
            FSType = SplitElement[1]
            RemountPartitionAfter = SplitElement[2]

            logger.info("MainBackendThread().BadSectorCheck(): Preparing to check partition: "+Partition+"...")
            wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to check "+Partition+"###\n")
            wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Checking Partition: "+Partition)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 30+(50/CheckListLength))

            time.sleep(1)

            #Run a command that will work based on the fstype of this partition. If there aren't any use cases for the fstype, display a message to the user and skip it. Ignore return values.
            if FSType == "jfs":
                #No support for bad sector check in jfs. Notify the user and do a normal check instead.
                self.ShowMsgDlg(Kind="info", Message="Sorry, the filesystem type on partition: "+Partition+" (jfs) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['fsck.jfs', '-vf', Partition]
            elif FSType == "minix":
                self.ShowMsgDlg(Kind="info", Message="Sorry, the filesystem type on partition: "+Partition+" (minix) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['fsck.minix', '-avf', Partition]
            elif FSType == "reiserfs":
                self.ShowMsgDlg(Kind="info", Message="Sorry, the filesystem type on partition: "+Partition+" (reiserfs) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['fsck.reiserfs', '-apf', Partition]
            elif FSType == "xfs":
                self.ShowMsgDlg(Kind="info", Message="Sorry, the filesystem type on partition: "+Partition+" (xfs) doesn't support checking for bad sectors. WxFixBoot will perform a normal filesystem check instead.")
                ExecList = ['xfs_repair', '-Pvd', Partition]
            elif FSType == "vfat":
                ExecList = ['fsck.vfat', '-yvt', Partition]
            elif FSType in ['ext2', 'ext3', 'ext4', 'ext4dev']:
                ExecList = ['fsck.'+FSType, '-yvcf', Partition]
            else:
                ExecList = ['None']
                self.ShowMsgDlg(Kind="info", Message="Sorry, the filesystem on partition: "+Partition+" could not be checked, as wxfixboot doesn't support checking it yet. "+Partition+" will now be skipped.")

            #Run the command with Piping = False, if ExecList != ['None'], otherwise do nothing, but do remount the partition if needed.
            if ExecList != ['None']:
                retval = self.StartThreadProcess(ExecList)

            #Check the return values, and run the handler if needed.
            if retval == 0:
                #Success.
                logger.info("MainBackendThread().QuickFileSystemCheck(): Checked partition: "+Partition+" No Errors Found!")
            else:
                self.HandleFilesystemCheckReturnValues(ExecList=ExecList, retval=retval)

            if RemountPartitionAfter == "Yes":
                logger.debug("MainBackendThread().BadSectorCheck(): Remounting Partition: "+Partition+" Read-Write...")
                retval = self.RemountPartitionRW(Partition=Partition)

                #Check if it worked.
                if retval != 0:
                    #Log it.
                    logger.warning("MainBackendThread().BadSectorCheck(): Warning: Failed to remount partition: "+Partition+" after check. We probably need to reboot first. Never mind...")

        #Update Current Operation Text.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished Bad Sector Check!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###PFinished Bad Sector Check!###\n")

    ####################End of Essential Functions.####################
    ####################Start Of Bootloader Operation functions.####################

    def PrepareForBootloaderInstallation(self):
        #Determine all the package managers on the system, including all OSes and the OS running, but not the live disk (if there is one).
        logger.debug("MainBackendThread().PrepareForBootloaderInstallation(): Determining package managers for all Linux OSes...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing for bootloader operations...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 10)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing for bootloader operations...###\n")

        OSListWithPackageManagers = []
        
        #Use OSList to find all partitions with Linux OSes on them.
        #Start of for loop.
        for OS in OSList:
            #Get the partition that each OS is on.
            Partition = OS.split()[-1]

            #If not on a live disk, and this OS is the one running, skip some stuff.
            if LiveDisk == False and Partition == AutoRootFS:
                #Find the package manager on this partition, if one exists.
                #This is the RootFS, so don't use chroot in the given command lists.
                temp = self.LookForAPTOnPartition(APTExecList=["apt-get", "-h"])

                #Add the OS and its package manager to the list, if there is one.
                if temp != "None":
                   logger.info("MainBackendThread().PrepareForBootloaderInstallation(): Found possible package management candidate: "+OS+" with Package Manager "+temp)
                   OSListWithPackageManagers.append(OS+" with Package Manager "+temp)
                            
                #Skip the rest of the for loop.
                continue

            #Mount the partition safely, using the global mount function.
            retstr = MountPartitionSafely(Partition=Partition, MountPoint="/mnt"+Partition)

            #Check if anything went wrong.
            if retstr not in ["Succeeded", "Already Mounted"]:
                #Probably already mounted on a very old linux kernel, just ignore it, as it's safer to do so.
                logger.warning("MainBackendThread().PrepareForBootloaderInstallation(): Command: 'mount "+Partition+" /mnt/"+Partition+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
            else:
                #Find the package manager on this partition, if one exists.
                #This isn't the RootFS, so use chroot in the given command lists.
                temp = self.LookForAPTOnPartition(APTExecList=["chroot", "/mnt"+Partition, "apt-get", "-h"])

                #Add the OS and its package manager to the list, if there is one.
                if temp != "None":
                    logger.info("MainBackendThread().PrepareForBootloaderInstallation(): Found possible package management candidate: "+OS+" with Package Manager "+temp)
                    OSListWithPackageManagers.append(OS+" with Package Manager "+temp)

        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 70)

        #Check if there are any candidates for bootloader installation/removal. Hopefully there are!
        if OSListWithPackageManagers == []:
            #Oh dear... There aren't.
            logger.error("MainBackendThread().PrepareForBootloaderInstallation(): Couldn't find an OS with APT! Will have to disable some operations!")
            self.ShowMsgDlg(Kind="error", Message="Sorry! No supported package managers could be found on any of your operating systems! At the moment, APT is supported, which covers most Linux Operating Systems. WxFixBoot will have to skip some operations that require a package manager, such as installing, removing and reinstalling the bootloader. For release 1.1 or 1.2 wxfixboot will likely support another package manager, such as Slackware's system. If you think you do have an OS with a supported package manager, please report a bug or email me directly.")

            #Set these to "None", so the packagemanager-dependant code can skip itself.
            PackageManager = "None"
            PartitionWithPackageManager = "None"
            #Update Current Operation Text.
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)
        else:
            #Very good! There is at least one candidate.
            logger.info("MainBackendThread().PrepareForBootloaderInstallation(): Found at least one candidate for installing and removing bootloaders! Continuing...")

            #Also, we need to find which OS(es) installed the bootloader (or have it installed currently), and ask the user which OS to install the bootloader with.
            OSesWithBootloaderToRemoveList = self.FindBootloaderRemovalOSes(OSListWithPackageManagers)
            logger.info("MainBackendThread().PrepareForBootloaderInstallation(): List of OSes to have the bootloader removed: "+' '.join(OSesWithBootloaderToRemoveList)+"...")
            #Update Current Operation Text.
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 85)
            self.AskUserForBootloaderInstallationOS(OSListWithPackageManagers)
            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Done!###\n") 

    def ManageBootloaders(self):
        #First remove the old bootloader, then install the new one.
        self.GetOldBootloaderConfig()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 25)
        self.RemoveOldBootloader()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 50)
        self.InstallNewBootloader()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 75)
        self.SetNewBootloaderConfig()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

    def ReinstallBootloader(self):
        #Function to reinstall/fix the bootloader.
        logger.info("MainBackendThread().ReinstallBootloader(): Preparing to reinstall the bootloader...")
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to reinstall the bootloader...###\n")

        #Set BootloaderToInstall as the current bootloader to allow this to work properly.
        global BootloaderToInstall
        BootloaderToInstall = Bootloader

        #Call self.ManageBootloaders to perform the reinstallation safely.
        logger.info("MainBackendThread().ReinstallBootloader(): Reinstalling the Bootloader...")
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Reinstalling the Bootloader...###\n")
        self.ManageBootloaders()
        logger.info("MainBackendThread().ReinstallBootloader(): Done!")

    def UpdateBootloader(self):
        #Function to update bootloader menu and config
        logger.info("MainBackendThread().UpdateBootloader(): Preparing to update the bootloader...")
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to update the bootloader...###\n")

        #Set BootloaderToInstall as the current bootloader to allow this to work properly.
        global BootloaderToInstall
        BootloaderToInstall = Bootloader
        logger.info("MainBackendThread().UpdateBootloader(): Updating the bootloader's config...")
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to update the bootloader's configuration...###\n")

        #Get the bootloader's config.
        self.GetOldBootloaderConfig()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 50)

        #Set the bootloaders new config.
        self.SetNewBootloaderConfig()
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

        logger.info("MainBackendThread().UpdateBootloader(): Done!")

    ####################Start Of Bootloader Configuration Obtaining Functions.####################

    def GetOldBootloaderConfig(self):
        #Get the old bootloader's config before removing it, so we can reuse it (if possible) with the new one.
        logger.debug("MainBackendThread().GetOldBootloaderConfig(): Preparing to get bootloader config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to get bootloader config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 2)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to get old bootloader config...###\n")

        #Define gloabal vars
        global BootloaderTimeout
        global KernelOptions

        #Use two lists for global kernel options and timeouts, so if they differ for each instance of the bootloader (assuming there is more than one), we can ask the user which is best, or go with wxfixboot's default (timeout=10, kopts="quiet splash nomodeset")
        KernelOptsList = []
        TimeoutsList = []

        #Set two temporary vars.
        timeout = ""
        kopts = ""

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Getting old bootloader config...")
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Getting old bootloader config...###\n")

        #Loop through each OS in OSesWithBootloaderToRemoveList, and provide information to the function that gets the configuration.
        logger.info("MainBackendThread().GetOldBootloaderConfig(): Looking for configuration in OSes marked for bootloader removal...")
        for OS in OSesWithBootloaderToRemoveList:
            #Grab the OS's partition.
            Partition = OS.split()[-5]
            logger.debug("MainBackendThread().GetOldBootloaderConfig(): Looking for config in OS: "+OS+"...")

            #Check if the Partition is AutoRootFS, if we're not on a live disk.
            if LiveDisk == False and Partition == AutoRootFS:
                #If so, make sure this will work for this OS too, and avoid setting mountpoint, so the config instructions below look in the right place for the config files.
                MountPoint = ""
            else:
                #If not, set mountpoint to the actual mountpoint.
                MountPoint = "/mnt"+Partition

                #Mount it safely using the global mount function.
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check if anything went wrong.
                if retstr not in ["Succeeded", "Already Mounted"]:
                    #Probably already mounted on a very old linux kernel, just ignore it, and skip the rest of the loop, as it's safer to do so.
                    logger.warning("MainBackendThread().GetOldBootloaderConfig(): Command: 'mount "+MountPoint+" /mnt/"+MountPoint+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                    continue

            #Look for the configuration file, based on which GetConfig() function we're about to run.
            if Bootloader == "GRUB-LEGACY":
                #Check MountPoint/boot/grub/menu.lst exists.
                if os.path.isfile(MountPoint+"/boot/grub/menu.lst"):
                    #It does, we'll run the function to find the config now.
                    temp = self.GetGRUBLEGACYConfig(filetoopen=MountPoint+"/boot/grub/menu.lst")
                    timeout = temp[0]

            elif Bootloader in ['GRUB2', 'GRUB-UEFI']:
                #Check MountPoint/etc/default/grub exists, which should be for either GRUB2 or GRUB-UEFI.
                if os.path.isfile(MountPoint+"/etc/default/grub"):
                    #It does, we'll run the function to find the config now.
                    temp = self.GetGRUB2Config(filetoopen=MountPoint+"/etc/default/grub")
                    timeout = temp[0]
                    kopts = temp[1]

            elif Bootloader in ['LILO', 'ELILO']:
                #Check the config file exists for both lilo and elilo.
                if Bootloader == "LILO" and os.path.isfile(MountPoint+"/etc/lilo.conf"):
                    #It does, we'll run the function to find the config now.
                    temp = self.GetLILOConfig(filetoopen=MountPoint+"/etc/lilo.conf")
                    timeout = temp[0]
                    kopts = temp[1]
                elif Bootloader == "ELILO" and os.path.isfile(MountPoint+"/etc/elilo.conf"):
                    #It does, we'll run the function to find the config now.
                    temp = self.GetLILOConfig(filetoopen=MountPoint+"/etc/elilo.conf")
                    timeout = temp[0]
                    kopts = temp[1]

            #Unmount the partition, if needed.
            if MountPoint != "":
                self.UnmountPartition(Partition=MountPoint)

            #Now we have the config, let's add it to the list, if it's unique. This will also catch the NameError excetpion created if the bootloader's config file wasn't found. 
            #First do timeout.
            if timeout != "":
                try:
                    TimeoutsList.index(timeout)
                except ValueError:
                    #It's unique.
                    TimeoutsList.append(timeout)
                except NameError: pass

            if kopts != "":
                #Now kopts.
                try:
                    KernelOptsList.index(kopts)
                except ValueError:
                    #It's unique.
                    KernelOptsList.append(kopts)
                except NameError: pass

            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 2+(14/len(OSesWithBootloaderToRemoveList)))

        #We're finished getting the config.
        logger.info("MainBackendThread().GetOldBootloaderConfig(): Finished looking for configuration in OSes marked for bootloader removal.")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Determining configuration to use...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 14)

        #Now let's check how many options there are in each of these lists, and run different code accordingly.
        #First TimeoutsList, but only if we aren't using a preset value for BootloaderTimeout.
        if BootloaderTimeout == -1:
            if len(TimeoutsList) == 0:
                #No timeout was found!
                temp = self.ShowTextEntryDlg(Message="WxFixBoot couldn't find the currently installed bootloader's timeout value. Please enter a value, or use WxFixBoot's default (10 seconds).", Title="WxFixBoot - Enter timeout value")
                BootloaderTimeout = int(temp)
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using user's bootloader timeout value: "+str(BootloaderTimeout))
            elif len(TimeoutsList) == 1:
                #As there is one, do what the user said, and set it directly.
                BootloaderTimeout = int(TimeoutsList[0])
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using only bootloader timeout value found: "+str(BootloaderTimeout))
            else:
                #Ask the user which timeout to use, as there are more than one.
                TimeoutsList.append("WxFixBoot's Default (10)")
                temp = self.ShowChoiceDlg(Message="WxFixBoot found multiple timeout settings. Please select the one you want.", Title="WxFixBoot -- Select Timeout Setting", Choices=TimeoutsList)

                #Save it.
                if temp == "WxFixBoot's Default (10)":
                    BootloaderTimeout = 10
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default bootloader timeout value: 10")
                else:
                    BootloaderTimeout = int(temp)
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using user chosen bootloader timeout value: "+str(BootloaderTimeout))

        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 21)

        #Now do the kernel options.
        if len(KernelOptsList) == 0:
            #No kernel options were found!
            #Ask the user to use WxFixBoot's default, or do manual config.
            temp = self.ShowYesNoDlg(Message="WxFixBoot couldn't find the current bootloader's default kernel options. Do you want to use WxFixBoot's default options? Most of the time, you should click yes and use the defaults, which are almost always fine. However, if you know exactly what you're doing, you can click no, and modify them yourself.", Title="WxFixBoot - Use Default Kernel Options?")

            if temp == "Yes":
                KernelOptions = "quiet splash nomodeset"
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default kernel options: 'quiet splash nomodeset'")
            else:
                #Ask the user for the kernel options to use.
                temp = self.ShowTextEntryDlg(Message="WxFixBoot's default kernel options are: 'quiet splash nomodeset'. If you've changed your mind, click cancel, and the defaults will be used.", Title="WxFixBoot - Enter Kernel Options")

                if temp == "Clicked no...":
                    KernelOptions = "quiet splash nomodeset"
                    logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default kernel options: 'quiet splash nomodeset'")
                else:
                    KernelOptions = temp
        elif len(KernelOptsList) == 1:
            #Use the single set of options found.
            KernelOptions = KernelOptsList[0]
            logger.info("MainBackendThread().GetOldBootloaderConfig(): Using only kernel options found: "+KernelOptions)
        else:
            #Ask the user which timeout to use, as there are more than one.
            KernelOptionsList.append("WxFixBoot's Default ('quiet splash nomodeset')")
            temp = self.ShowChoiceDlg(Message="WxFixBoot found multiple kernel options settings. Please select the one you want.", Title="WxFixBoot -- Select Kernel Options", Choices=KernelOptionsList)

            #Save it.
            if temp == "WxFixBoot's Default ('quiet splash nomodeset')":
                KernelOptions = "quiet splash nomodeset"
                logger.info("MainBackendThread().GetOldBootloaderConfig(): Using WxFixBoot's default kernel options: 'quiet splash nomodeset'")
            else:
                KernelOptions = temp
                logger.warning("MainBackendThread().GetOldBootloaderConfig(): Waring: Using user entered kernel options: "+KernelOptions)

        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 25)

    def GetGRUBLEGACYConfig(self, filetoopen):
        #Function to get important bits of config from grub-legacy before removing it.
        #In this case, the only useful info is the timeout, so just get this.
        #Set temporary vars
        Timeout = ""

        #Open the file in read mode, so we can save the important bits of config.
        infile = open(filetoopen, 'r')

        #Look for the timeout setting.
        for line in infile:
            if 'timeout' in line and 'sec' not in line:
                #Found it! Save it to BootloaderTimeout, but only if BootloaderTimeout = -1 (we aren't changing the timeout).
                if BootloaderTimeout == -1:
                    temp = line.split()[1].replace('\n', '')
                    if temp.isdigit():
                        #Great! We got it.
                        Timeout = int(temp)
                    #Exit the loop to save time.
                    break

        #Close the file.
        infile.close()

        return [Timeout]

    def GetGRUB2Config(self, filetoopen):
        #Function to get important bits of config from grub2 (MBR or UEFI) before removing it.
        #Set temporary vars
        Timeout = ""
        Kopts = ""

        #Open the file in read mode, so we can save the important bits of config.
        infile = open(filetoopen, 'r')

        #Loop through each line in the file, paying attention only to the important ones.
        for line in infile:
            #Look for the timeout setting.
            if 'GRUB_TIMEOUT' in line and '=' in line:
                #Found it! Save it to BootloaderTimeout, but only if BootloaderTimeout = -1 (we aren't changing the timeout).
                if BootloaderTimeout == -1:
                    #Save it, carefully avoiding errors.
                    junk, sep, temp = line.partition('=')
                    temp = temp.replace(' ','').replace('\n', '').replace("\'", "")
                    if temp.isdigit():
                        #Great! We got it.
                        Timeout = int(temp)

            #Look for kernel options used globally in all the boot options.
            elif 'GRUB_CMDLINE_LINUX_DEFAULT' in line and '=' in line:
                #Found them! Save it to GlobalKernelOptions
                junk, sep, temp = line.partition('=')
                Kopts = temp.replace("\"", "")

        #Close the file.
        infile.close()

        #Return these values to self.RemoveOldBootloader()
        return [Timeout, Kopts]

    def GetLILOConfig(self, filetoopen):
        #Function to get important bits of config from lilo before removing it.
        #Set temporary vars
        Timeout = ""
        Kopts = ""

        #Open the file in read mode, so we can save the important bits of config.
        infile = open(filetoopen, 'r')

        #Loop through each line in the file, paying attention only to the important ones.
        for line in infile:
            #Look for the delay setting.
            if 'delay' in line and '=' in line:
                #Found it! Save it to BootloaderTimeout, but only if BootloaderTimeout = -1 (we aren't changing the timeout).
                if BootloaderTimeout == -1:
                    #Save it, carefully avoiding errors.
                    junk, sep, temp = line.partition('=')
                    temp = temp.replace(' ','').replace('\n', '')
                    if temp.isdigit():
                        #Great! We got it.
                        #However, because lilo and elilo save this in 10ths of a second, divide it by ten first.
                        Timeout = int(temp)/10

            #Look for kernel options used globally in all the boot options.
            elif 'append' in line and '=' in line:
                #Found them! Save it to GlobalKernelOptions
                junk, sep, temp = line.partition('=')
                Kopts = temp.replace("\"", "").split()

        #Close the file.
        infile.close()

        #Return these values to self.RemoveOldBootloader()
        return [Timeout, Kopts]

    ####################End Of Bootloader Configuration Obtaining Functions.####################
    ####################Start Of Bootloader Removal Functions.####################

    def RemoveOldBootloader(self):
        #Remove the currently installed bootloader.
        logger.debug("MainBackendThread().RemoveOldBootloader(): Preparing to remove old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Removing old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 27)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Removing old bootloaders...###\n")

        #Loop through each OS in OSesWithBootloaderToRemoveList, and provide information to the function that will remove the bootloader.
        for OS in OSesWithBootloaderToRemoveList:
            #For each OS that needs the bootloader removed, grab the partition, and the package manager.
            Partition = OS.split()[-5]
            PackageManager = OS.split()[-1]

            logger.info("MainBackendThread().RemoveOldBootloader(): Removing "+Bootloader+" from OS: "+OS+"...")

            #Grab the architecture.
            Arch = OS.split()[-8]
            if Arch == "64-bit":
                Arch = "x86_64"
            else:
                Arch = "i686"
            
            #If we're not on a live disk, and the partition is AutoRootFS, let the remover function know that we aren't using chroot.
            if LiveDisk == False and Partition == AutoRootFS:
                if Bootloader == "GRUB-LEGACY":
                    retval = self.RemoveGRUBLEGACY(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "GRUB2":
                    retval = self.RemoveGRUB2(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "LILO":
                    retval = self.RemoveLILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "GRUB-UEFI":
                    retval = self.RemoveGRUBEFI(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
                elif Bootloader == "ELILO":
                    retval = self.RemoveELILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)

            #Otherwise, setup the chroot and everything else first, and tell it we are using chroot, and pass the mountpoint to it.
            else:
                #Mount the partition using the global mount function.
                MountPoint = "/mnt"+Partition
                retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

                #Check this worked okay, and issue an error if it didn't.
                if retstr not in ['Succeeded', 'Already Mounted']:
                    logger.error("MainBackendThread().RemoveOldBootloader(): Error: Failed to remount partition: "+Partition+"! Warn the user and skip this OS.")
                    self.ShowMsgDlg(Kind="error", Message="WxixBoot failed to mount the partition containing the OS: "+OS+"! This OS will now be skipped.")
                else:
                    #Set up chroot.
                    self.SetUpChroot(MountPoint=MountPoint)

                    #If there's a seperate /boot partition for this OS, make sure it's mounted.
                    self.StartThreadProcess(['chroot', MountPoint, 'mount', '-av'], ShowOutput=False)

                    #Remove the bootloader.
                    if Bootloader == "GRUB-LEGACY":
                        retval = self.RemoveGRUBLEGACY(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "GRUB2":
                        retval = self.RemoveGRUB2(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "LILO":
                        retval = self.RemoveLILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "GRUB-UEFI":
                        retval = self.RemoveGRUBEFI(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                    elif Bootloader == "ELILO":
                        retval = self.RemoveELILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)

                    #Tear down chroot.
                    self.TearDownChroot(MountPoint=MountPoint)

            if retval != 0:
                #Something went wrong! Log it and notify the user.
                logger.error("MainBackendThread().RemoveOldBootloader(): Error: Failed to remove "+Bootloader+" from OS: "+OS+"! We'll continue anyway. Warn the user.")
                self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to remove "+Bootloader+" from the OS: "+OS+"! This probably doesn't matter; when we install the new bootloader, it should take precedence over the old one anyway. Make sure you check that OS after WxFixBoot finishes its operations.")

            wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 27+(22/len(OSesWithBootloaderToRemoveList)))

        #Log and notify the user that we're finished remving bootloaders.
        logger.info("MainBackendThread().RemoveOldBootloader(): Finished removing bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished removing old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 50)
        self.ShowMsgDlg(Kind="info", Message="Finished removing old bootloaders! WxFixBoot will now install and set up the new one.")

    def RemoveGRUBLEGACY(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove GRUB-LEGACY. ** Keep this for now: Remove packages grub and grub-legacy-doc and grub-common (Ubuntu/Debian, and derivatives, APT-GET -y), and should be autoremoved on old versions anyway.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'grub', 'grub-legacy-doc', 'grub-common'], ShowOutput=False)
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'grub', 'grub-legacy-doc', 'grub-common'], ShowOutput=False)
        else:
            logger.warning("MainBackendThread().RemoveGRUBLEGACY(): Warning: The bootloader to be removed doesn't exist in this OS! Never mind.")
            self.ShowMsgDlg(Kind="warning", Message="Something has gone slightly wrong here. Your bootloader is apparently GRUB-LEGACY, but packages for it don't exist in the OS: "+OS+" that was marked as needing it removed! Never mind, this probably doesn't matter, so we'll keep going anyway.")
            retval = 0
        
        #Return the return value.
        return retval

    def RemoveGRUB2(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove GRUB2 ** Keep this for now: Remove packages grub-pc and grub-pc-bin and grub-common (Ubuntu/Debian, and derivatives, APT-GET -y).
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'grub-pc', 'grub-pc-bin', 'grub-common'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'grub-pc', 'grub-pc-bin', 'grub-common'],)
        
        #Return the return value.
        return retval

    def RemoveLILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove lilo ** keep this for now: Remove packages lilo (Ubuntu/Debian, and derivatives, APT-GET -y).
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'lilo'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'lilo'])
        else:
            logger.warning("MainBackendThread().RemoveLILO(): Warning: The bootloader to be removed doesn't exist in this OS! Never mind.")
            self.ShowMsgDlg(Kind="warning", Message="Something has gone slightly wrong here. Your bootloader is apparently LILO, but packages for it don't exist in the OS: "+OS+" that was marked as needing it removed! Never mind, this probably doesn't matter, so we'll keep going anyway.")
            retval = 0
        
        #Return the return value.
        return retval

    def RemoveGRUBEFI(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove GRUB-UEFI. ** Keep this for now: Remove packages grub-efi, grub-efi-amd64, grub-efi-amd64-bin, grub-efi-ia32, grub-efi-ia32-bin (Ubuntu/Debian, and derivatives, APT-GET -y), or grub-efi.$(uname -p), grub2-efi.$(uname -p)
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'grub-efi', 'grub-efi-amd64', 'grub-efi-amd64-bin', 'grub-efi-ia32', 'grub-efi-ia32-bin', 'grub-common', 'grub2-common'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'grub-efi', 'grub-efi-amd64', 'grub-efi-amd64-bin', 'grub-efi-ia32', 'grub-efi-ia32-bin', 'grub-common', 'grub2-common'])
        
        #Return the return value.
        return retval

    def RemoveELILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to remove ELILO ** Keep this for now: Remove package elilo (Ubuntu/Debian, and derivatives, APT-GET -y).
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'remove', '-y', 'elilo'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'remove', '-y', 'elilo'])
        else:
            logger.warning("MainBackendThread().RemoveELILO(): Warning: The bootloader to be removed doesn't exist in this OS! Never mind.")
            self.ShowMsgDlg(Kind="warning", Message="Something has gone slightly wrong here. Your bootloader is apparently ELILO, but packages for it don't exist in the OS: "+OS+" that was marked as needing it removed! Never mind, this probably doesn't matter, so we'll keep going anyway.")
            retval = 0
        
        #Return the return value.
        return retval

    ####################End Of Bootloader Removal Functions.####################
    ####################Start Of Bootloader Installation Functions.####################

    def InstallNewBootloader(self):
        #Function to install a new bootloader.
        #Install the new bootloader on the chosen OS.
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to install the new bootloader...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 52)       
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to install the new bootloader...###\n")

        #For OSForBootloaderInstallation, grab the partition, and the package manager.
        Partition = OSForBootloaderInstallation.split()[-5]
        PackageManager = OSForBootloaderInstallation.split()[-1]

        logger.info("MainBackendThread().InstallNewBootloader(): Preparing to install the new bootloader "+BootloaderToInstall+" in OS: "+OSForBootloaderInstallation+"...")

        #Grab the architecture.
        Arch = OSForBootloaderInstallation.split()[-8]
        if Arch == "64-bit":
            Arch = "x86_64"
        else:
            Arch = "i686"

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Installing the new bootloader...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 55)       
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Installing the new bootloader...###\n")

        #If we're not on a live disk, and the partition is AutoRootFS, let the installer function know that we aren't using chroot.
        if LiveDisk == False and Partition == AutoRootFS:
            if BootloaderToInstall == "GRUB2":
                retval = self.InstallGRUB2(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
            elif BootloaderToInstall == "LILO":
                retval = self.InstallLILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
            elif BootloaderToInstall == "GRUB-UEFI":
                #Mount the UEFI partition at /boot/efi.
                #Unmount it first though, in case it's already mounted.
                self.UnmountPartition(Partition=UEFISYSP)
                MountPartitionSafely(Partition=UEFISYSP, MountPoint="/boot/efi")

                retval = self.InstallGRUBEFI(PackageManager=PackageManager, UseChroot=False, Arch=Arch)
            elif BootloaderToInstall == "ELILO":
                #Unmount the UEFI Partition now.
                self.UnmountPartition(Partition=UEFISYSP)

                retval = self.InstallELILO(PackageManager=PackageManager, UseChroot=False, Arch=Arch)

        #Otherwise, setup the chroot and everything else first, and tell it we are using chroot, and pass the mountpoint to it.
        else:
            #Mount the partition using the global mount function.
            MountPoint = "/mnt"+Partition
            retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

            #Check this worked okay, and issue an error if it didn't.
            if retstr not in ['Succeeded', 'Already Mounted']:
                logger.error("MainBackendThread().InstallNewBootloader(): Error: Failed to remount partition: "+Partition+"! Warn the user and skip this OS.")
                self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to mount the partition containing the OS: "+OSForBootloaderInstallation+"! Bootloader installation cannot continue! This may leave your system in an unbootable state. It is recommended to do a Bad Sector check, and then try again.")
            else:
                #Set up chroot.
                self.SetUpChroot(MountPoint=MountPoint)

                #If there's a seperate /boot partition for this OS, make sure it's mounted.
                self.StartThreadProcess(['chroot', MountPoint, 'mount', '-av'], ShowOutput=False)

                #Install the bootloader.
                if BootloaderToInstall == "GRUB2":
                    retval = InstallGRUB2(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                elif BootloaderToInstall == "LILO":
                    retval = InstallLILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                elif BootloaderToInstall == "GRUB-UEFI":
                    #Mount the UEFI partition at MountPoint/boot/efi.
                    #Unmount it first though, in case it's already mounted.
                    self.UnmountPartition(Partition=UEFISYSP)
                    MountPartitionSafely(Partition=UEFISYSP, MountPoint=MountPoint+"/boot/efi")
                    retval = InstallGRUBEFI(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)
                elif BootloaderToInstall == "ELILO":
                    retval = InstallELILO(PackageManager=PackageManager, UseChroot=True, MountPoint=MountPoint, Arch=Arch)

                #Tear down chroot.
                self.TearDownChroot(MountPoint=MountPoint)

        if retval != 0:
            #Something went wrong! Log it and notify the user.
            logger.error("MainBackendThread().InstallNewBootloader(): Error: Failed to install "+BootloaderToInstall+" on OS: "+OSForBootloaderInstallation+"! This may mean the system is now unbootable! We'll continue anyway. Warn the user.")
            self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to install "+BootloaderToInstall+" on the OS: "+OSForBootloaderInstallation+"! This may leave your system in an unbootable state. It is recommended to do a Bad Sector check, unplug any non-essential devices, and then try again.")

        #Log and notify the user that we're finished removing bootloaders.
        logger.info("MainBackendThread().InstallNewBootloader(): Finished Installing bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished removing old bootloaders...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 75)

    def InstallGRUB2(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to install GRUB2. ** Keep this for now: Install package grub-pc and os-prober (Ubuntu or Debian, and derivatives, APT-GET -y).
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'install', '-y', 'grub-pc', 'os-prober'], ShowOutput=False)
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'install', '-y', 'grub-pc', 'os-prober'], ShowOutput=False)
        
        #Return the return value.
        return retval

    def InstallLILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to install LILO. ** Keep this for now: Install package lilo (Ubuntu or Debian, and derivatives, APT-GET -y), using command DEBIAN_FRONTEND=noninteractive apt-get -y install lilo, to avoid seeing prompts.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get install -y lilo", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" DEBIAN_FRONTEND=noninteractive apt-get install -y lilo", Piping=True)
        
        #Return the return value.
        return retval

    def InstallGRUBEFI(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to Install GRUB-UEFI. ** Keep this for now: Install package grub-efi and os-prober (Ubuntu or Debian, and derivatives, APT-GET -y). Mount efi partition to /boot/efi, run grub-install specify dir for efi partition with --efi-directory (probably /boot/efi), target with --target=<target> (probably x86_64-efi). Make sure to add an entry to /etc/fstab, if needed, so the efi partition gets mounted on bootup.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess(['apt-get', 'install', '-y', 'grub-efi', 'os-prober'])
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'apt-get', 'install', '-y', 'grub-efi', 'os-prober'])
        
        #Return the return value.
        return retval

    def InstallELILO(self, PackageManager, UseChroot, Arch, MountPoint="None"):
        #Function to install ELILO. Install package elilo (Ubuntu or Debian, and derivatives, APT-GET -y), using command DEBIAN_FRONTEND=noninteractive apt-get -y install elilo, to avoid seeing prompts. unmount efi partition, run elilo -b <efisyspartion> --autoconf to setup, check and set config, then elilo -b <efisyspartition> --efiboot. Specify UUID to kernel for root partition using lsblk -o NAME,UUID, specify initrd/initramfs in file. Look for /initrd.img and /vmlinuz for each OS and add manually. If either /vmlinuz or /initrd.img doesn't exist use find /boot -iname '*init* '*vmlinu*' to find the latest versions of each in /boot and warn user of manual updating with kernel updates. Make sure to add an entry to /etc/fstab, if needed, so the efi partition gets mounted on bootup.
        if PackageManager == "apt-get":
            if UseChroot == False:
                retval = self.StartThreadProcess("DEBIAN_FRONTEND=noninteractive apt-get install -y elilo", Piping=True)
            else:
                retval = self.StartThreadProcess("chroot "+MountPoint+" DEBIAN_FRONTEND=noninteractive apt-get install -y elilo", Piping=True)
        
        #Return the return value.
        return retval

    ####################End Of Bootloader Installation Functions.####################
    ####################Start Of Bootloader Configuration Setting Functions.####################

    def SetNewBootloaderConfig(self):
        #Function to manage setting new bootloader config.
        logger.debug("MainBackendThread().SetNewBootloaderConfig(): Preparing to set bootloader config in OS: "+OSForBootloaderInstallation+"...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Preparing to set the new bootloader's config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 77)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Preparing to set the new bootloader's config...###\n")

        #Grab the OS's partition and package manager.
        Partition = OSForBootloaderInstallation.split()[-5]
        PackageManager = OSForBootloaderInstallation.split()[-1]

        #Set two temporary vars.
        timeout = ""
        kopts = ""

        #Grab the architecture.
        Arch = OSForBootloaderInstallation.split()[-8]
        if Arch == "64-bit":
            Arch = "x86_64"
        else:
            Arch = "i686"

        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Setting the new bootloader's config...")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 79)
        wx.CallAfter(self.ParentWindow.UpdateOutputBox, "\n###Setting the new bootloader's config...###\n")

        #Check if the Partition is AutoRootFS, if we're not on a live disk.
        if LiveDisk == False and Partition == AutoRootFS:
            #If so, make sure this will work for this OS too, and avoid setting mountpoint, so the config instructions below look in the right place for the config files.
            MountPoint = ""
        else:
            #If not, set mountpoint to the actual mountpoint.
            MountPoint = "/mnt"+Partition

            #Mount it safely using the global mount function.
            retstr = MountPartitionSafely(Partition=Partition, MountPoint=MountPoint)

            #Check if anything went wrong.
            if retstr not in ["Succeeded", "Already Mounted"]:
                #Probably already mounted on a very old linux kernel, just ignore it, and skip the rest of the loop, as it's safer to do so.
                logger.warning("MainBackendThread().SetNewBootloaderConfig(): Command: 'mount "+MountPoint+" /mnt/"+MountPoint+" -r' errored with stderr: "+str(stderr)+"! Ignoring it, as it's safer if we're using a very old linux kernel.")
                return "Failed"
            else:
                #Set up chroot.
                self.SetUpChroot(MountPoint=MountPoint)

        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 81)

        #Look for the configuration file, based on which SetConfig() function we're about to run.
        if BootloaderToInstall == "GRUB2":
            #Check MountPoint/etc/default/grub exists, which should be for either GRUB2 or GRUB-UEFI.
            if os.path.isfile(MountPoint+"/etc/default/grub", PackageManager):
                #It does, we'll run the function to set the config now.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2-BIOS Configuration...")
                self.SetGRUB2Config(filetoopen=MountPoint+"/etc/default/grub")

            #Now Install GRUB2 to the MBR.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing GRUB2 to MBR...")
            self.InstallGRUB2ToMBR(PackageManager=PackageManager, MountPoint=MountPoint)

            #Update GRUB.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Updating GRUB2 Configuration...")
            self.UpdateGRUB2(PackageManager=PackageManager, MountPoint=MountPoint)

            #Set the default OS.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2 Default OS...")
            self.SetGRUB2DefaultOS(PackageManager=PackageManager, MountPoint=MountPoint)

        elif BootloaderToInstall == "GRUB-UEFI":
            #Check MountPoint/etc/default/grub exists, which should be for either GRUB2 or GRUB-UEFI.
            if os.path.isfile(MountPoint+"/etc/default/grub"):
                #It does, we'll run the function to set the config now.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2-UEFI Configuration...")
                self.SetGRUB2Config(filetoopen=MountPoint+"/etc/default/grub")

            #Mount the UEFI partition at MountPoint/boot/efi.
            MountPartitionSafely(Partition=UEFISYSP, MountPoint=MountPoint+"/boot/efi")

            #Now Install GRUB-UEFI to the UEFI Partition.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing GRUB2 to UEFISYSP...")
            self.InstallGRUBUEFIToPartition(PackageManager=PackageManager, MountPoint=MountPoint, UEFISYSPMountPoint=MountPoint+"/boot/efi", Arch=Arch)

            #Update GRUB.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Updating GRUB2 Configuration...")
            self.UpdateGRUB2(PackageManager=PackageManager, MountPoint=MountPoint)

            #Set the default OS.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting GRUB2 Default OS...")
            self.SetGRUB2DefaultOS(PackageManager=PackageManager, MountPoint=MountPoint)

        elif BootloaderToInstall == "LILO":
            #Make LILO's config file.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Making LILO's configuration file...")
            if MountPoint == "":
                self.StartThreadProcess(['liloconfig'], ShowOutput=False)
            else:
                self.StartThreadProcess(['chroot', MountPoint, 'liloconfig'], ShowOutput=False)

            #Check the config file exists for lilo
            if os.path.isfile(MountPoint+"/etc/lilo.conf"):
                #It does, we'll run the function to set the config now.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting LILO Configuration...")
                self.SetLILOConfig(filetoopen=MountPoint+"/etc/lilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)
    
                #Also, set the OS entries.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Creating LILO OS Entries...")
                self.MakeLILOOSEntries(filetoopen=MountPoint+"/etc/lilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)

            #Now Install LILO to the MBR.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing LILO to the MBR...")
            self.InstallLILOToMBR(PackageManager=PackageManager, MountPoint=MountPoint)

        elif BootloaderToInstall == "ELILO":
            #Make ELILO's config file.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Making ELILO's configuration file...")
            if MountPoint == "":
                self.StartThreadProcess(['elilo', '-b', UEFISYSP, '--autoconf'], ShowOutput=False)
            else:
                self.StartThreadProcess(['chroot', MountPoint, 'elilo', '-b', UEFISYSP, '--autoconf'], ShowOutput=False)

            #Check elilo's config file exists.
            if os.path.isfile(MountPoint+"/etc/elilo.conf"):
                #It does, we'll run the function to set the config now.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Setting ELILO Configuration...")
                self.SetELILOConfig(filetoopen=MountPoint+"/etc/elilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)

                #Also, set the OS entries.
                logger.info("MainBackendThread().SetNewBootloaderConfig(): Creating ELILO OS Entries...")
                self.MakeLILOOSEntries(filetoopen=MountPoint+"/etc/elilo.conf", PackageManager=PackageManager, MountPoint=MountPoint)

            #Unmount the UEFI Partition now.
            self.UnmountPartition(Partition=UEFISYSP)

            #Now Install ELILO to the UEFI Partition.
            logger.info("MainBackendThread().SetNewBootloaderConfig(): Installing ELILO to UEFISYSP...")
            self.InstallELILOToPartition(PackageManager=PackageManager, MountPoint=MountPoint, UEFISYSPMountPoint=MountPoint+"/boot/efi", Arch=Arch)

        #Unmount the partition, if needed.
        if MountPoint != "":
            #Tear down chroot.
            self.TearDownChroot(MountPoint=MountPoint)
            self.UnmountPartition(Partition=MountPoint)

        logger.debug("MainBackendThread().SetNewBootloaderConfig(): Finished setting bootloader config.")
        wx.CallAfter(self.ParentWindow.UpdateCurrentOpText, msg="Finished installing the new bootloader!")
        wx.CallAfter(self.ParentWindow.UpdateCurrentProgress, 100)

    def SetGRUB2Config(self, filetoopen):
        #Function to set GRUB2 config. ** Keep this for now: Find the grub2 name for the default OS by running: lsb_release -i -s for each OS, and trying to match versions. If this doesn't work, try to use the first element in wxfixboot's OS names list (normally this should work). If not, give up and ask the user to manually select it from a dialog.

        #Open the file in read mode, so we can find the new config that needs setting. Also, use a list to temporarily store the modified lines.
        conffile = open(filetoopen, 'r')
        templist = []

        #Loop through each line in the file, paying attention only to the important ones.
        for line in conffile:
            #Look for the timeout setting.
            if 'GRUB_TIMEOUT' in line and '=' in line:
                #Found it! Set the value to the current value of BootloaderTimeout.
                head, sep, temp = line.partition('=')
                temp = str(BootloaderTimeout)

                #Reassemble the line.
                line = head+sep+temp+"\n"

            #Look for kernel options setting.
            elif 'GRUB_CMDLINE_LINUX_DEFAULT' in line and '=' in line:
                #Found it! Set it to the options in KernelOptions, carefully making sure we aren't double-quoting it.
                head, sep, temp = line.partition('=')
                temp = KernelOptions.replace('\"', '').replace("\'", "").replace("\n", "")

                #Reassemble the line.
                line = head+sep+"'"+temp+"'"+"\n"

            #Look for the "GRUB_DEFAULT" setting.
            elif "GRUB_DEFAULT" in line and '=' in line:
                #Found it. Set it to 'saved', so we can set the default bootloader.
                head, sep, temp = line.partition('=')
                temp = "saved"

                #Reassemble the line.
                line = head+sep+temp+"\n"

            #Comment out the GRUB_HIDDEN_TIMEOUT line.
            elif 'GRUB_HIDDEN_TIMEOUT' in line and 'GRUB_HIDDEN_TIMEOUT_QUIET' not in line and '=' in line:
                line = "#"+line+"\n"

            templist.append(line)

        #Write the finished lines to the file.
        conffile.close()
        conffile = open(filetoopen, 'w')
        conffile.write(''.join(templist))
        conffile.close()

    def InstallGRUB2ToMBR(self, PackageManager, MountPoint):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the MBR.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['grub-install', RootFS], ShowOutput=False)
            else:
                retval = self.StartThreadProcess(['grub2-install', RootFS], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'grub-install', RootFS], ShowOutput=False)
            else:
                retval = self.StartThreadProcess(['chroot', MountPoint, 'grub2-install', RootFS], ShowOutput=False)

        #Return the return value.
        return retval

    def InstallGRUBUEFIToPartition(self, PackageManager, MountPoint, UEFISYSPMountPoint, Arch):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the UEFI partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['grub-install', '--efi-directory='+UEFISYSPMountPoint, '--target='+Arch+'-efi'], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'grub-install', '--efi-directory='+UEFISYSPMountPoint, '--target='+Arch+'-efi'], ShowOutput=False)

        #Return the return value.
        return retval

    def UpdateGRUB2(self, PackageManager, MountPoint):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the UEFI partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['update-grub'], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'update-grub'], ShowOutput=False)

        #Return the return value.
        return retval

    def SetGRUB2DefaultOS(self, PackageManager, MountPoint):
        #Now we need to set the default os.
        #I couldn't find a reliable way of doing this, so give the user a choice box instead.
        #Make a list of OSes grub2 found (hopefully all of them).
        if PackageManager == "apt-get":
            temp = self.StartThreadProcess(["grep", "menuentry ", MountPoint+"/boot/grub/grub.cfg"], ShowOutput=False, ReturnOutput=True)
            retcode = temp[0]
            grubmenuentries = temp[1]

        if retcode != 0:
            #Don't set the default bootloader.
            self.ShowMsgDlg(Kind="error", Message="WxFixBoot failed to set the default bootloader. Your bootloader was installed properly, so this doesn't really matter. Click okay to continue.")
        else:
            #Now finally make the list of grub's OS names.
            GRUBOSNameList = []

            #Split with each newline character found in the returned string.
            templist = grubmenuentries.split('\n')
            for OSName in templist:
                #Get each OS name, removing all of the unneeeded characters.
                junk,sep,info = OSName.partition("'")
                info,sep,junk = info.partition("'")
                GRUBOSNameList.append(info)

            #Now ask the user to select the correct one.
            Default = self.ShowChoiceDlg(Message="Please select the OS you want to uses the bootloader's Default OS", Title="WxFixBoot - Select Default OS", Choices=GRUBOSNameList)

            #Use the user's selection to set the default OS.
            if LiveDisk == False and MountPoint == "":
                #If the OS is AutoRootFS, and we're not on a live disk, do it differently.
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess(["grub-set-default", Default], ShowOutput=False)
                else:
                    retval = self.StartThreadProcess(["grub2-set-default", Default], ShowOutput=False)
            else:
                if PackageManager == "apt-get":
                    retval = self.StartThreadProcess(["chroot", MountPoint, "grub-set-default", Default], ShowOutput=False)
                else:
                    retval = self.StartThreadProcess(["chroot", MountPoint, "grub2-set-default", Default], ShowOutput=False)

            #Return the return value.
            return retval

    def SetLILOConfig(self, filetoopen, PackageManager, MountPoint):
        #Function to set LILO config. ** Keep this for now: Set this easily in pretty much the same way as we get the config, only we save everything to a file this time. Set the default with default = <OSNAMEHERE>. Run liloconfig, modify the config and add OSes, and finally run /sbin/lilo to install to MBR. Use read-write for each OS, if possible use UUIDs. Look for /initrd.img and /vmlinuz for each OS and add manually. If either /vmlinuz or /initrd.img doesn't exist use find /boot -iname '*initr* '*vmlinu*' to find the latest versions of each in /boot and warn user of manual updating with kernel updates.
        #Open the file in read mode, so we can find the important bits of config to edit. Also, use a list to temporarily store the modified lines.
        conffile = open(filetoopen, 'r')
        templist = []

        #Loop through each line in the file, paying attention only to the important ones.
        for line in conffile:
            #Look for the delay setting.
            if 'delay' in line and '=' in line:
                #Found it! Set it to our value.
                #Save it, carefully avoiding errors.
                head, sep, temp = line.partition('=')
                temp = str(BootloaderTimeout)

                #Reassemble the line.
                line = head+sep+temp+"\n"

            #Look for kernel options setting.
            elif 'append' in line and '=' in line:
                #Found it, set it to our value.
                head, sep, temp = line.partition('=')
                temp = KernelOptions.replace('\"', '')

                #Reassemble the line.
                line = head+sep+"'"+temp+"'\n"

            #Look for the 'boot' setting.
            elif 'boot' in line and '=' in line:
                #Found it, set it to RootDev. ** Really, we need to use the UUID, but do that later. **
                head, sep, temp = line.partition('=')
                temp = RootDev

                #Reassemble the line.
                line = head+sep+temp+"\n"

            templist.append(line)

        #Write the finished lines to the file.
        conffile.close()
        conffile = open(filetoopen, 'w')
        conffile.write(''.join(templist))
        conffile.close()

    def SetELILOConfig(self, filetoopen, PackageManager, MountPoint):
        #Function to set ELILO config. ** Keep this for now: Set this easily in pretty much the same way as we get the config, only we save everything to a file this time. Set the default with default = <OSNAMEHERE>. Run liloconfig, modify the config and add OSes, and finally run /sbin/lilo to install to MBR. Use read-write for each OS, if possible use UUIDs. Look for /initrd.img and /vmlinuz for each OS and add manually. If either /vmlinuz or /initrd.img doesn't exist use find /boot -iname '*initr* '*vmlinu*' to find the latest versions of each in /boot and warn user of manual updating with kernel updates.
        #Open the file in read mode, so we can find the important bits of config to edit. Also, use a list to temporarily store the modified lines.
        conffile = open(filetoopen, 'r')
        templist = []

        #Loop through each line in the file, paying attention only to the important ones.
        for line in conffile:
            #Look for the delay setting.
            if 'delay' in line and '=' in line:
                #Found it! Set it to our value.
                #Save it, carefully avoiding errors.
                head, sep, temp = line.partition('=')
                temp = str(BootloaderTimeout)

                #Reassemble the line.
                line = head+sep+temp+"\n"

            #Look for kernel options setting.
            elif 'append' in line and '=' in line:
                #Found it, set it to our value.
                head, sep, temp = line.partition('=')
                temp = KernelOptions.replace('\"', '')

                #Reassemble the line.
                line = head+sep+"'"+temp+"'\n"

            #Look for the 'boot' setting.
            elif 'boot' in line and '=' in line:
                #Found it, set it to RootDev.
                head, sep, temp = line.partition('=')
                temp = UEFISYSP

                #Reassemble the line.
                line = head+sep+temp+"\n"

            #Get rid of any boot entries.
            elif 'image=' in line or '\t' in line:
                #Skip this line, and don't append it to the list.
                continue

            templist.append(line)

        #Write the finished lines to the file.
        conffile.close()
        conffile = open(filetoopen, 'w')
        conffile.write(''.join(templist))
        conffile.close()

    def MakeLILOOSEntries(self, filetoopen, PackageManager, MountPoint):
        #Okay, we've saved the kopts, timeout, and the boot device in the list.
        #Now we'll set the OS entries, and then the default.
        #Loop through the file, and add each entry to a temporary list. Also, set the default OS.
        conffile = open(filetoopen, 'r')
        templist = []

        for line in conffile:
            if 'default' in line and '=' in line:
                #Get the LILO name for DefaultOS.
                #If DefaultOS is the currently running one, we'll need to access a different part of the variable.
                if DefaultOS.split()[-5] == "OS)":
                    OSName = ''.join(DefaultOS.split()[0:-6])
                else:
                    OSName = ''.join(DefaultOS.split()[0:-4])

                #Remove all of the spaces.
                DefaultOSName = OSName.replace(' ','')

                #Set default to the name.
                line = "default="+DefaultOSName

            templist.append(line)

        #Now make the OS entries.
        for OS in OSList:
            #Names in LILO are not allowed to have spaces, so let's grab the names and remove the spaces from them.
            #If this OS is the currently running one, we'll need to access a different part of the element.
            if OS.split()[-5] == "OS)":
                OSName = ''.join(OS.split()[0:-6])
            else:
                OSName = ''.join(OS.split()[0:-4])

            #Grab the OS's partition.
            Partition = OS.split()[-1]

            #Remove all the spaces.
            OSName = OSName.replace(' ','')

            #Now let's make the entries.
            if OS[-5] == "OS)":
                #Check /vmlinuz and /initrd.img exist.
                if os.path.isfile("/vmlinuz"):
                    #Good, add this to the file.
                    templist.append("\nimage=/vmlinuz\n")
                else:
                    #Not so good... This probably means changing LILO's config each time we do a kernel update... Let's ask the user if we should still add it.
                    temp = self.ShowYesNodlg(Message="Warning: /vmlinuz (shortcut to the latest kernel) wasn't found for the OS: "+OS+"! LILO will still work, but this might mean you'll have to manaully change LILO's config file each time you update your kernel on this OS. You can do this with WxFixBoot, but that won't stop it from being annoying and introducing security risks if you forget. Do you want to add it to the boot menu anyway?", Title="WxFixBoot - Add OS to boot menu?")

                    if temp == "No":
                        #Okay, go back to the start of the loop.
                        continue
                    else:
                        #Right, we'll have to hunt out the Kernel.
                        Kernel = self.FindLatestVersion(Directory="/boot", Type="Kernel")

                        #Check if we found it.
                        if Kernel == "None":
                            #We didn't! Tell the user.
                            self.ShowMsgdlg(Message="Sorry, WxFixBoot couldn't find the latest kernel for this OS. This OS will now be skipped.", Type="error")
                        else:
                            #We did! Add it to the file.
                            templist.append("\nimage=/boot/"+Kernel+"\n")

                if os.path.isfile("/initrd.img"):
                    #Good, add this to the file.
                    templist.append("\tinitrd=/initrd.img\n")
                else:
                    #Not so good... This probably means changing LILO's config each time we do a kernel update... Let's ask the user if we should still add it.
                    temp = self.ShowYesNodlg(Message="Warning: /initrd.img (shortcut to the latest initrd.img) wasn't found for the OS: "+OS+"! LILO will still work, but this might mean you'll have to manaully change LILO's config file each time you update your kernel on this OS. You can do this with WxFixBoot, but that won't stop it from being annoying and introducing security risks if you forget. Do you want to add it to the boot menu anyway?", Title="WxFixBoot - Add OS to boot menu?")

                    if temp == "No":
                        #Okay, go back to the start of the loop.
                        continue
                    else:
                        #Right, we'll have to hunt out the Initrd/Initramfs.
                        Initrd = self.FindLatestVersion(Directory="/boot", Type="Initrd")

                        #Check if we found it.
                        if Initrd == "None":
                            #We didn't! Tell the user.
                            self.ShowMsgdlg(Message="Sorry, WxFixBoot couldn't find the latest initrd.img for this OS. This OS will now be skipped.", Type="error")
                        else:
                            #We did! Add it to the file.
                            templist.append("\nimage=/boot/"+Initrd+"\n")
            else:
                #Check /vmlinuz and /initrd.img exist.
                if os.path.isfile(MountPoint+"/vmlinuz"):
                    #Good, add this to the file.
                    templist.append("\nimage="+MountPoint+"/vmlinuz\n")
                else:
                    #Not so good... This probably means changing LILO's config each time we do a kernel update... Let's ask the user if we should still add it.
                    temp = self.ShowYesNodlg(Message="Warning: /vmlinuz (shortcut to the latest kernel) wasn't found for the OS: "+OS+"! LILO will still work, but this might mean you'll have to manaully change LILO's config file each time you update your kernel on this OS. Do you want to add it to the boot menu anyway?", Title="WxFixBoot - Add OS to boot menu?")

                    if temp == "No":
                        #Okay, go back to the start of the loop.
                        continue
                    else:
                        #Right, we'll have to hunt out the Kernel.
                        Kernel = self.FindLatestVersion(Directory=MountPoint+"/boot", Type="Kernel")

                        #Check if we found it.
                        if Kernel == "None":
                            #We didn't! Tell the user.
                            self.ShowMsgdlg(Message="Sorry, WxFixBoot couldn't find the latest kernel for this OS. This OS will now be skipped.", Type="error")
                        else:
                            #We did! Add it to the file.
                            templist.append("\nimage="+MountPoint+"/boot/"+Kernel+"\n")

                if os.path.isfile(MountPoint+"/initrd.img"):
                    #Good, add this to the file.
                    templist.append("\tinitrd="+MountPoint+"/initrd.img\n")
                else:
                    #Not so good... This probably means changing LILO's config each time we do a kernel update... Let's ask the user if we should still add it.
                    temp = self.ShowYesNodlg(Message="Warning: /initrd.img (shortcut to the latest initrd.img) wasn't found for the OS: "+OS+"! LILO will still work, but this might mean you'll have to manaully change LILO's config file each time you update your kernel on this OS. Do you want to add it to the boot menu anyway?", Title="WxFixBoot - Add OS to boot menu?")

                    if temp == "No":
                        #Okay, go back to the start of the loop.
                        continue
                    else:
                        #Right, we'll have to hunt out the Initrd/Initramfs.
                        Initrd = self.FindLatestVersion(Directory=MountPoint+"/boot", Type="Initrd")

                        #Check if we found it.
                        if Initrd == "None":
                            #We didn't! Tell the user.
                            self.ShowMsgdlg(Message="Sorry, WxFixBoot couldn't find the latest initrd.img for this OS. This OS will now be skipped.", Type="error")
                        else:
                            #We did! Add it to the file.
                            templist.append("\nimage="+MountPoint+"/boot/"+Initrd+"\n")

            #Set the root device.
            #Use UUID's here if we can.
            UUID = self.GetPartitionUUID(Partition)
            if UUID == "None":
                templist.append("\troot="+Partition+"\n")
            else:
                templist.append("\troot=UUID="+UUID+"\n")

            #Set the label.
            templist.append("\tlabel="+OSName+"\n")

            #Set one other necessary boot option.
            templist.append("\tread-only\n")

        #Write the finished lines to the file.
        conffile.close()
        conffile = open(filetoopen, 'w')
        conffile.write(''.join(templist))
        conffile.close()

    def FindLatestVersion(self, Directory, Type):
        #Try the find the latest kernel/initrd in the given directory.
        FileList = os.listdir(Directory)

        if Type == "Kernel":
            #Make a list of kernels.
            List = []
            for File in FileList:
                if 'vmlinu' in File:
                    List.append(File)
        else:
            #Make a list of initrds/initramfses.
            List = []
            for File in FileList:
                if 'initr' in File:
                    List.append(File)

        if len(List) == 0:
            #No kernels/initrds found.
            return "None"
        elif len(List) == 1:
            #One kernel/initrd found, return it.
            return List[0]
        else:
            #Multiple kernels/initrds found!
            #Find the one with the highest number.
            #Make a list of version numbers.
            Versions = []
            for Thing in List:
                Versions.append(Thing.split("-")[1])

            #Order them.
            SortedVersions = sorted(Versions, key=LooseVersion).reverse()

            #Save the kernel/initrd(s) that have the latest version number (the first element in the list).
            NewList = []
            for Thing in List:
                if SortedVersions[0] in Thing:
                    NewList.append(Thing)

            if len(NewList) == 1:
                #Good, there is only one kernel/initrd with that version number. Return it.
                return NewList[1]
            else:
                #Multiple kernels/initrds with that version number. Let's look at the revision number for every kernel/initrd in that list.
                Revs = []
                for Thing in NewList:
                    Revs.append(Thing.split("-")[2])

                SortedRevs = sorted(Revs, key=LooseVersion).reverse()

                #Save the kernels/initrd(s) that have that version number, and the latest revision number (the first element in the list).
                NewestList = []
                for Thing in NewList:
                    if SortedRevs[0] in Thing:
                        NewestList.append(Thing)

                if len(NewestList) == 0:
                    #Finally, we have the latest kernel! Return it.
                    return NewestList[1]
                else:
                    #Give up, this is getting impossible!
                    return "None"

    def InstallLILOToMBR(self, PackageManager, MountPoint):
        #Install lilo to the MBR of RootDev.
        if MountPoint == "":
            retval = self.StartThreadProcess(['lilo', '-M', RootDev], ShowOutput=False)
        else:
            retval = self.StartThreadProcess(['chroot', MountPoint, 'lilo', '-M', RootDev], ShowOutput=False)

        #Return the return value.
        return retval

    def InstallELILOToPartition(self, PackageManager, MountPoint, UEFISYSPMountPoint, Arch):
        #Okay, we've modified the kernel options and the timeout. Now we need to install grub to the UEFI partition.
        if MountPoint == "":
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['elilo', '-b', UEFISYSP, '--efiboot'], ShowOutput=False)
        else:
            if PackageManager == "apt-get":
                retval = self.StartThreadProcess(['chroot', MountPoint, 'elilo', '-b', UEFISYSP, '--efiboot'], ShowOutput=False)

        #Return the return value.
        return retval

    ####################End Of Bootloader Configuration Setting Functions.####################
    ####################End Of Bootloader Operation functions.####################

#End Main Backend Thread
app = WxFixBoot(False)
app.MainLoop()
